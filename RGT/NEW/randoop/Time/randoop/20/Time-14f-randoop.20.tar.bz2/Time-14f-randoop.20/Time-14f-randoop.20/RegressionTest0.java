import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 1, (int) 'a', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.DateTime.Property property6 = dateTime2.property(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime2.withFieldAdded(durationFieldType5, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray3 = julianChronology0.get(readablePeriod1, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Date date0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("DateTimeField[era]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[era]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            int int6 = dateTime4.get(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((int) ' ', 57600001);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.toDateTime(dateTimeZone8);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((java.lang.Object) dateTime5, chronology10);
        try {
            dateTimeFormatter1.printTo(stringBuffer2, (org.joda.time.ReadablePartial) monthDay11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        java.lang.Appendable appendable3 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.toDateTime(dateTimeZone9);
        try {
            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test017");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        long long6 = delegatedDateTimeField4.roundHalfEven((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime(dateTimeZone12);
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((java.lang.Object) dateTime9, chronology14);
//        int[] intArray17 = new int[] {};
//        try {
//            int[] intArray19 = delegatedDateTimeField4.addWrapField((org.joda.time.ReadablePartial) monthDay15, (int) (byte) 0, intArray17, (int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036825975809L) + "'", long6 == (-9223372036825975809L));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(intArray17);
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test018");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        try {
//            org.joda.time.Instant instant2 = instant0.minus((-9223372036825975809L));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: 1560632435748 + 9223372036825975809");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.years();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
        try {
            long long11 = julianChronology0.getDateTimeMillis(0, (int) (short) 10, 97, 4, (int) (byte) 10, (int) (short) 10, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10, 1, 57600001, 0, 0, (int) ' ', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600001 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) -1, 0, 10, 4, 0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField7 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType5, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.MonthDay.Property property2 = monthDay0.property(dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfDay();
        try {
            long long10 = julianChronology0.getDateTimeMillis((int) (byte) -1, (int) (short) 10, (int) (byte) 1, 100, (int) (byte) 10, (int) (byte) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
        java.util.Locale locale15 = null;
        try {
            java.lang.String str16 = monthDay8.toString("", locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 1, (java.lang.Number) 100L, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
        org.joda.time.MonthDay monthDay18 = monthDay13.minusMonths((int) (short) -1);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) '#', locale20);
        int int22 = skipDateTimeField4.getMinimumValue();
        try {
            long long25 = skipDateTimeField4.set((long) 0, "BC");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"BC\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "35" + "'", str21.equals("35"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        long long6 = delegatedDateTimeField4.roundHalfEven((long) 'a');
//        long long8 = delegatedDateTimeField4.roundFloor((long) 1);
//        try {
//            long long11 = delegatedDateTimeField4.add((-1L), 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036825975809L) + "'", long6 == (-9223372036825975809L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62105328000000L) + "'", long8 == (-62105328000000L));
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test034");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        org.joda.time.DurationFieldType durationFieldType11 = null;
//        try {
//            org.joda.time.DateTime dateTime13 = dateTime6.withFieldAdded(durationFieldType11, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
//        java.lang.String str12 = monthDay8.toString();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((java.lang.Object) dateTime15, chronology20);
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.MonthDay monthDay24 = monthDay21.withPeriodAdded(readablePeriod22, (int) (byte) 10);
//        boolean boolean25 = monthDay8.isEqual((org.joda.time.ReadablePartial) monthDay24);
//        try {
//            org.joda.time.MonthDay monthDay27 = monthDay24.withMonthOfYear(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "--12-31" + "'", str12.equals("--12-31"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime2.minus(readableDuration9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime2, dateTimeZone11);
        try {
            org.joda.time.DateTime dateTime14 = dateTime2.withDayOfYear((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType5, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("BC");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"BC/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@77d80e9");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.years();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime3.withDayOfYear((int) '#');
        try {
            java.lang.String str10 = dateTime3.toString("DateTimeField[era]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.years();
        org.joda.time.DurationField durationField3 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.minuteOfDay();
        java.lang.Class<?> wildcardClass5 = dateTimeField4.getClass();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 100, "--12-31");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.DateTime.Property property4 = dateTime2.property(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(1, (int) (byte) 1, 0, 10, (int) '#', dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "DateTimeField[era]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 1, (int) (byte) -1, (int) (short) 100, (int) (byte) 100, 0, 10, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        boolean boolean5 = dateTime2.isBeforeNow();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 0, (int) '4', (int) (short) 10, (int) (byte) 1, (-1), (int) (byte) 1, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        long long6 = delegatedDateTimeField4.roundHalfEven((long) 'a');
//        long long8 = delegatedDateTimeField4.roundFloor((long) 1);
//        org.joda.time.DurationField durationField9 = delegatedDateTimeField4.getLeapDurationField();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036825975809L) + "'", long6 == (-9223372036825975809L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62105328000000L) + "'", long8 == (-62105328000000L));
//        org.junit.Assert.assertNull(durationField9);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        boolean boolean3 = julianChronology0.equals((java.lang.Object) (short) 100);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.year();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType5, 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay((int) ' ');
        boolean boolean6 = dateTime3.isEqualNow();
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime3.toCalendar(locale7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime3);
        boolean boolean10 = dateTime3.isEqualNow();
        org.joda.time.DateTime dateTime12 = dateTime3.plusDays((int) (short) 10);
        try {
            org.joda.time.DateTime dateTime16 = dateTime12.withDate(100, (int) (short) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(calendar8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("--12-31");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--12-31\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.weeks();
        org.joda.time.DurationField durationField3 = julianChronology0.centuries();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.MonthDay monthDay11 = monthDay8.withField(dateTimeFieldType9, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
//        org.joda.time.Chronology chronology14 = monthDay13.getChronology();
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay13, 0, locale16);
//        java.lang.String str18 = delegatedDateTimeField4.toString();
//        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology19);
//        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.era();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone25);
//        org.joda.time.DateTime dateTime28 = dateTime26.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime26.toDateTime(dateTimeZone29);
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay((java.lang.Object) dateTime26, chronology31);
//        org.joda.time.Chronology chronology33 = monthDay32.getChronology();
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = delegatedDateTimeField23.getAsShortText((org.joda.time.ReadablePartial) monthDay32, 0, locale35);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay32, 0, locale38);
//        long long41 = delegatedDateTimeField4.roundCeiling((long) (short) 10);
//        try {
//            long long44 = delegatedDateTimeField4.getDifferenceAsLong(62135568000035L, (long) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "BC" + "'", str17.equals("BC"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[era]" + "'", str18.equals("DateTimeField[era]"));
//        org.junit.Assert.assertNotNull(julianChronology19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "BC" + "'", str36.equals("BC"));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "BC" + "'", str39.equals("BC"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-9223372036825975809L) + "'", long41 == (-9223372036825975809L));
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
//        long long6 = offsetDateTimeField4.remainder((long) '#');
//        long long8 = offsetDateTimeField4.roundCeiling((long) 1439);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 62135568000035L + "'", long6 == 62135568000035L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9223372036825975809L) + "'", long8 == (-9223372036825975809L));
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = julianChronology0.weeks();
//        org.joda.time.DurationField durationField3 = julianChronology0.centuries();
//        long long6 = durationField3.subtract((long) (short) 10, (int) (byte) 100);
//        org.joda.time.DurationFieldType durationFieldType7 = null;
//        try {
//            org.joda.time.field.DecoratedDurationField decoratedDurationField8 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-315576000421990L) + "'", long6 == (-315576000421990L));
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay18 = monthDay13.minusMonths((int) (short) -1);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) '#', locale20);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone23);
//        org.joda.time.DateTime dateTime26 = dateTime24.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime24.toDateTime(dateTimeZone27);
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((java.lang.Object) dateTime24, chronology29);
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.MonthDay monthDay33 = monthDay30.withPeriodAdded(readablePeriod31, (int) (byte) 10);
//        java.lang.String str34 = monthDay30.toString();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone36);
//        org.joda.time.DateTime dateTime39 = dateTime37.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTime dateTime41 = dateTime37.toDateTime(dateTimeZone40);
//        org.joda.time.Chronology chronology42 = null;
//        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay((java.lang.Object) dateTime37, chronology42);
//        org.joda.time.ReadablePeriod readablePeriod44 = null;
//        org.joda.time.MonthDay monthDay46 = monthDay43.withPeriodAdded(readablePeriod44, (int) (byte) 10);
//        boolean boolean47 = monthDay30.isEqual((org.joda.time.ReadablePartial) monthDay46);
//        java.util.Locale locale48 = null;
//        try {
//            java.lang.String str49 = skipDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay30, locale48);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "35" + "'", str21.equals("35"));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "--12-31" + "'", str34.equals("--12-31"));
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(monthDay46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusHours(1);
        boolean boolean6 = dateTime2.isAfter(0L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology0);
        try {
            org.joda.time.DateTime dateTime9 = dateTime5.withDate(0, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.years();
        org.joda.time.DurationField durationField3 = julianChronology0.weeks();
        try {
            org.joda.time.Instant instant4 = new org.joda.time.Instant((java.lang.Object) durationField3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
//        long long6 = offsetDateTimeField4.remainder((long) '#');
//        int int7 = offsetDateTimeField4.getOffset();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime10.toDateTime(dateTimeZone13);
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((java.lang.Object) dateTime10, chronology15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (byte) 10);
//        java.util.Locale locale20 = null;
//        try {
//            java.lang.String str21 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay19, locale20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'era' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 62135568000035L + "'", long6 == 62135568000035L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(monthDay19);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.minutes();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
//        long long6 = offsetDateTimeField4.remainder((long) '#');
//        int int7 = offsetDateTimeField4.getOffset();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime10.toDateTime(dateTimeZone13);
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((java.lang.Object) dateTime10, chronology15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (byte) 10);
//        int[] intArray23 = new int[] { 100, 0 };
//        try {
//            int[] intArray25 = offsetDateTimeField4.addWrapField((org.joda.time.ReadablePartial) monthDay19, (int) (byte) 100, intArray23, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 62135568000035L + "'", long6 == 62135568000035L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(intArray23);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.Chronology chronology14 = monthDay13.getChronology();
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay13, 0, locale16);
        java.lang.String str18 = delegatedDateTimeField4.toString();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology19);
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone25);
        org.joda.time.DateTime dateTime28 = dateTime26.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime26.toDateTime(dateTimeZone29);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay((java.lang.Object) dateTime26, chronology31);
        org.joda.time.Chronology chronology33 = monthDay32.getChronology();
        java.util.Locale locale35 = null;
        java.lang.String str36 = delegatedDateTimeField23.getAsShortText((org.joda.time.ReadablePartial) monthDay32, 0, locale35);
        java.util.Locale locale38 = null;
        java.lang.String str39 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay32, 0, locale38);
        long long42 = delegatedDateTimeField4.set((long) (byte) 1, 1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "BC" + "'", str17.equals("BC"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[era]" + "'", str18.equals("DateTimeField[era]"));
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "BC" + "'", str36.equals("BC"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "BC" + "'", str39.equals("BC"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1L + "'", long42 == 1L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        try {
            long long9 = gregorianChronology1.getDateTimeMillis(4, 57600001, (int) (byte) 100, 100, (int) '4', (int) (short) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime5.toDateTime(dateTimeZone8);
//        boolean boolean10 = dateTime9.isEqualNow();
//        int int11 = dateTime9.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime9.minus(readablePeriod12);
//        int int14 = dateTime9.getSecondOfDay();
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, (org.joda.time.ReadableInstant) dateTime9);
//        try {
//            org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((int) (byte) 10, (int) (byte) -1, chronology15);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must not be smaller than 1");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600001 + "'", int11 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 57600 + "'", int14 == 57600);
//        org.junit.Assert.assertNotNull(chronology15);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.Chronology chronology14 = monthDay13.getChronology();
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay13, 0, locale16);
        java.lang.String str18 = delegatedDateTimeField4.toString();
        try {
            long long21 = delegatedDateTimeField4.add((long) (byte) 10, 57600001);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "BC" + "'", str17.equals("BC"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[era]" + "'", str18.equals("DateTimeField[era]"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay(2, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYear((int) '4', 3);
        org.joda.time.format.DateTimeParser dateTimeParser7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
//        org.joda.time.DurationField durationField4 = julianChronology2.years();
//        org.joda.time.DurationField durationField5 = julianChronology2.weeks();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology2.minuteOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField6);
//        long long9 = skipUndoDateTimeField7.roundHalfEven((long) (short) 0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-315576000421990L), (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-315576000421938L) + "'", long2 == (-315576000421938L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(0);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
        org.joda.time.DateTime dateTime2 = instant1.toDateTimeISO();
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay(1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillisOfDay((int) ' ');
        boolean boolean11 = dateTime8.isEqualNow();
        java.util.Locale locale12 = null;
        java.util.Calendar calendar13 = dateTime8.toCalendar(locale12);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime8);
        boolean boolean15 = dateTime8.isEqualNow();
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime8.withDurationAdded(readableDuration16, 0);
        try {
            org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, (org.joda.time.ReadableDateTime) dateTime4, (org.joda.time.ReadableDateTime) dateTime18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(calendar13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((java.lang.Object) dateTime15, chronology20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.MonthDay monthDay24 = monthDay21.withPeriodAdded(readablePeriod22, (int) (byte) 10);
        org.joda.time.MonthDay monthDay26 = monthDay21.minusMonths((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) (byte) 1);
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay();
        int[] intArray38 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int39 = offsetDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) monthDay32, intArray38);
        int int40 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay21, intArray38);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType41, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
        org.joda.time.MonthDay monthDay18 = monthDay13.minusMonths((int) (short) -1);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) '#', locale20);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray22 = monthDay13.getFieldTypes();
        try {
            org.joda.time.MonthDay monthDay24 = monthDay13.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "35" + "'", str21.equals("35"));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray22);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        long long6 = delegatedDateTimeField4.roundHalfEven((long) 'a');
//        long long8 = delegatedDateTimeField4.roundFloor((long) 1);
//        long long10 = delegatedDateTimeField4.roundHalfCeiling(0L);
//        try {
//            long long13 = delegatedDateTimeField4.getDifferenceAsLong((-9223372036825975809L), 0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036825975809L) + "'", long6 == (-9223372036825975809L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62105328000000L) + "'", long8 == (-62105328000000L));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-9223372036825975809L) + "'", long10 == (-9223372036825975809L));
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = julianChronology0.weeks();
//        org.joda.time.DurationField durationField3 = julianChronology0.centuries();
//        long long6 = durationField3.subtract((long) (short) 10, (int) (byte) 100);
//        long long9 = durationField3.subtract((long) 1, (long) (short) 10);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-315576000421990L) + "'", long6 == (-315576000421990L));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31557600421999L) + "'", long9 == (-31557600421999L));
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.Chronology chronology14 = monthDay13.getChronology();
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay13, 0, locale16);
        java.lang.String str19 = delegatedDateTimeField4.getAsShortText((long) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType20, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "BC" + "'", str17.equals("BC"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "AD" + "'", str19.equals("AD"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField3 = julianChronology1.years();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.yearOfEra();
        org.joda.time.DurationField durationField13 = gJChronology10.halfdays();
        try {
            long long19 = gJChronology10.getDateTimeMillis((long) (short) 10, 3, (int) ' ', 57600, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(100L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        java.io.Writer writer5 = null;
        try {
            dateTimeFormatter4.printTo(writer5, (long) 1439);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
//        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, (-62105328000000L));
//        java.lang.String str7 = dateTimeZone1.getShortName((-315576000421990L));
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime10.toDateTime(dateTimeZone13);
//        boolean boolean15 = dateTime14.isEqualNow();
//        int int16 = dateTime14.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime14.minus(readablePeriod17);
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        boolean boolean20 = dateTime14.isAfter(readableInstant19);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant19, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62105328000000L) + "'", long5 == (-62105328000000L));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-07:52:58" + "'", str7.equals("-07:52:58"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57600001 + "'", int16 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("57600001");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) -1, (int) (byte) 10, 97, (int) (short) 0, 0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType4, (int) ' ', 1439);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        try {
            long long7 = gregorianChronology1.getDateTimeMillis(10, (int) (byte) 100, 6, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.Appendable appendable1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        org.joda.time.DateMidnight dateMidnight4 = dateTime3.toDateMidnight();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateMidnight4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateMidnight4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay18 = monthDay13.minusMonths((int) (short) -1);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) '#', locale20);
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (int) (byte) 1);
//        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay();
//        int[] intArray34 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
//        int int35 = offsetDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) monthDay28, intArray34);
//        int int36 = skipDateTimeField4.getMaximumValue(readablePartial22, intArray34);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone38);
//        org.joda.time.DateTime dateTime41 = dateTime39.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.DateTime dateTime43 = dateTime39.toDateTime(dateTimeZone42);
//        org.joda.time.Chronology chronology44 = null;
//        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay((java.lang.Object) dateTime39, chronology44);
//        org.joda.time.ReadablePeriod readablePeriod46 = null;
//        org.joda.time.MonthDay monthDay48 = monthDay45.withPeriodAdded(readablePeriod46, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay50 = monthDay45.minusMonths((int) (short) -1);
//        int[] intArray51 = monthDay50.getValues();
//        org.joda.time.MonthDay.Property property52 = monthDay50.dayOfMonth();
//        java.util.Locale locale54 = null;
//        org.joda.time.MonthDay monthDay55 = property52.setCopy("2", locale54);
//        java.lang.String str56 = property52.getAsText();
//        int int57 = property52.getMaximumValueOverall();
//        int int58 = property52.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone60 = null;
//        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone60);
//        org.joda.time.DateTime dateTime63 = dateTime61.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone64 = null;
//        org.joda.time.DateTime dateTime65 = dateTime61.toDateTime(dateTimeZone64);
//        org.joda.time.Chronology chronology66 = null;
//        org.joda.time.MonthDay monthDay67 = new org.joda.time.MonthDay((java.lang.Object) dateTime61, chronology66);
//        int int68 = property52.compareTo((org.joda.time.ReadablePartial) monthDay67);
//        java.util.Locale locale69 = null;
//        try {
//            java.lang.String str70 = skipDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay67, locale69);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "35" + "'", str21.equals("35"));
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(intArray34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1439 + "'", int36 == 1439);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(monthDay48);
//        org.junit.Assert.assertNotNull(monthDay50);
//        org.junit.Assert.assertNotNull(intArray51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(monthDay55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "31" + "'", str56.equals("31"));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 31 + "'", int57 == 31);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 31 + "'", int58 == 31);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone7);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((java.lang.Object) dateTime4, chronology9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (byte) 10);
//        java.lang.String str14 = monthDay10.toString();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime17.toDateTime(dateTimeZone20);
//        org.joda.time.Chronology chronology22 = null;
//        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((java.lang.Object) dateTime17, chronology22);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.MonthDay monthDay26 = monthDay23.withPeriodAdded(readablePeriod24, (int) (byte) 10);
//        boolean boolean27 = monthDay10.isEqual((org.joda.time.ReadablePartial) monthDay26);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay10);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "--12-31" + "'", str14.equals("--12-31"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = iSOChronology5.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology7.getZone();
        long long10 = dateTimeZone6.getMillisKeepLocal(dateTimeZone8, (-62105328000000L));
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) delegatedDateTimeField4, (java.lang.Object) iSOChronology11);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62105328000000L) + "'", long10 == (-62105328000000L));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime5.toDateTime(dateTimeZone8);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((java.lang.Object) dateTime5, chronology10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, (int) (byte) 10);
//        java.lang.String str15 = monthDay11.toString();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime18.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime18.toDateTime(dateTimeZone21);
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((java.lang.Object) dateTime18, chronology23);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.MonthDay monthDay27 = monthDay24.withPeriodAdded(readablePeriod25, (int) (byte) 10);
//        boolean boolean28 = monthDay11.isEqual((org.joda.time.ReadablePartial) monthDay27);
//        int int29 = monthDay2.compareTo((org.joda.time.ReadablePartial) monthDay27);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "--12-31" + "'", str15.equals("--12-31"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(monthDay27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
//        long long6 = offsetDateTimeField4.remainder((long) '#');
//        int int7 = offsetDateTimeField4.getMaximumValue();
//        try {
//            long long10 = offsetDateTimeField4.add(10L, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 62135568000035L + "'", long6 == 62135568000035L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("-07:52:58");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-07:52:58\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
//        java.util.Date date3 = dateTime2.toDate();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology4.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology6.getZone();
//        long long9 = dateTimeZone5.getMillisKeepLocal(dateTimeZone7, (-62105328000000L));
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime11 = dateTime2.withZone(dateTimeZone7);
//        int int12 = dateTime11.getYear();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62105328000000L) + "'", long9 == (-62105328000000L));
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withFieldAdded(durationFieldType5, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-57540000L), (long) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2013900000) + "'", int2 == (-2013900000));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant3 = instant0.withDurationAdded((long) (short) 100, (int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = instant0.toMutableDateTimeISO();
        org.joda.time.Instant instant7 = instant0.withDurationAdded((long) (byte) 10, 10);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTwoDigitYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.era();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) julianChronology1);
        int int5 = dateTime4.getYearOfCentury();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay18 = monthDay13.minusMonths((int) (short) -1);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) '#', locale20);
//        int int22 = skipDateTimeField4.getMinimumValue();
//        long long24 = skipDateTimeField4.roundHalfEven((-1L));
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone26 = iSOChronology25.getZone();
//        java.lang.String str27 = dateTimeZone26.toString();
//        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(dateTimeZone26);
//        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology30);
//        org.joda.time.DateTimeField dateTimeField32 = julianChronology30.era();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32, dateTimeFieldType33);
//        long long36 = delegatedDateTimeField34.roundHalfEven((long) 'a');
//        long long38 = delegatedDateTimeField34.roundFloor((long) 1);
//        long long40 = delegatedDateTimeField34.roundHalfCeiling(0L);
//        org.joda.time.ReadablePartial readablePartial41 = null;
//        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int44 = julianChronology43.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField45 = julianChronology43.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField46 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology42, dateTimeField45);
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone48);
//        org.joda.time.DateTime dateTime51 = dateTime49.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.DateTime dateTime53 = dateTime49.toDateTime(dateTimeZone52);
//        org.joda.time.Chronology chronology54 = null;
//        org.joda.time.MonthDay monthDay55 = new org.joda.time.MonthDay((java.lang.Object) dateTime49, chronology54);
//        org.joda.time.ReadablePeriod readablePeriod56 = null;
//        org.joda.time.MonthDay monthDay58 = monthDay55.withPeriodAdded(readablePeriod56, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay60 = monthDay55.minusMonths((int) (short) -1);
//        java.util.Locale locale62 = null;
//        java.lang.String str63 = skipDateTimeField46.getAsText((org.joda.time.ReadablePartial) monthDay55, (int) '#', locale62);
//        org.joda.time.ReadablePartial readablePartial64 = null;
//        org.joda.time.DateTimeZone dateTimeZone65 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone65);
//        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology66.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField69 = new org.joda.time.field.OffsetDateTimeField(dateTimeField67, (int) (byte) 1);
//        org.joda.time.MonthDay monthDay70 = new org.joda.time.MonthDay();
//        int[] intArray76 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
//        int int77 = offsetDateTimeField69.getMaximumValue((org.joda.time.ReadablePartial) monthDay70, intArray76);
//        int int78 = skipDateTimeField46.getMaximumValue(readablePartial64, intArray76);
//        int int79 = delegatedDateTimeField34.getMaximumValue(readablePartial41, intArray76);
//        try {
//            int[] intArray81 = skipDateTimeField4.add((org.joda.time.ReadablePartial) monthDay28, (int) (byte) 0, intArray76, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 98");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "35" + "'", str21.equals("35"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "America/Los_Angeles" + "'", str27.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(julianChronology30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-9223372036825975809L) + "'", long36 == (-9223372036825975809L));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62105328000000L) + "'", long38 == (-62105328000000L));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-9223372036825975809L) + "'", long40 == (-9223372036825975809L));
//        org.junit.Assert.assertNotNull(julianChronology42);
//        org.junit.Assert.assertNotNull(julianChronology43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(monthDay58);
//        org.junit.Assert.assertNotNull(monthDay60);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "35" + "'", str63.equals("35"));
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertNotNull(intArray76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2 + "'", int77 == 2);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1439 + "'", int78 == 1439);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendSecondOfMinute(1);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendFraction(dateTimeFieldType7, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
//        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, (-62105328000000L));
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        java.lang.String str7 = dateTimeZone3.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62105328000000L) + "'", long5 == (-62105328000000L));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "America/Los_Angeles" + "'", str7.equals("America/Los_Angeles"));
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DurationField durationField4 = julianChronology2.years();
        org.joda.time.DurationField durationField5 = julianChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology2.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField6);
        int int8 = skipUndoDateTimeField7.getMinimumValue();
        int int10 = skipUndoDateTimeField7.getMinimumValue((long) 31);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        java.lang.Appendable appendable3 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfDay((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime6.withMillis((long) 57600001);
        try {
            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        long long6 = delegatedDateTimeField4.roundHalfEven((long) 'a');
//        org.joda.time.ReadablePartial readablePartial7 = null;
//        int int8 = delegatedDateTimeField4.getMinimumValue(readablePartial7);
//        long long11 = delegatedDateTimeField4.addWrapField((long) (byte) 10, (int) (short) 100);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036825975809L) + "'", long6 == (-9223372036825975809L));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1969-365T16:00:00.097-08:00", dateTimeFormatter2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-365T16:00:00.097-08:00\" is malformed at \"69-365T16:00:00.097-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 1);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay();
        int[] intArray12 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int13 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) monthDay6, intArray12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.String str15 = monthDay6.toString(dateTimeFormatter14);
        try {
            org.joda.time.Instant instant16 = org.joda.time.Instant.parse("America/Los_Angeles", dateTimeFormatter14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "����W���" + "'", str15.equals("����W���"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
        org.joda.time.MonthDay monthDay18 = monthDay13.minusMonths((int) (short) -1);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) '#', locale20);
        int int22 = skipDateTimeField4.getMinimumValue();
        int int24 = skipDateTimeField4.getMaximumValue(10L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "35" + "'", str21.equals("35"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1439 + "'", int24 == 1439);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone7);
//        boolean boolean9 = dateTime8.isEqualNow();
//        int int10 = dateTime8.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime8.minus(readablePeriod11);
//        int int13 = dateTime8.getSecondOfDay();
//        org.joda.time.DateTime.Property property14 = dateTime8.millisOfSecond();
//        java.lang.String str15 = property14.getAsString();
//        org.joda.time.DateTime dateTime17 = property14.addToCopy(0);
//        boolean boolean18 = buddhistChronology1.equals((java.lang.Object) dateTime17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        try {
//            int[] intArray21 = buddhistChronology1.get(readablePeriod19, (long) 6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600001 + "'", int10 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57600 + "'", int13 == 57600);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "6/15/19");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay((int) ' ');
        boolean boolean6 = dateTime3.isEqualNow();
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime3.toCalendar(locale7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.halfdayOfDay();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, dateTimeFieldType14);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) '#');
        boolean boolean18 = gJChronology9.equals((java.lang.Object) '#');
        org.joda.time.DateTimeField dateTimeField19 = gJChronology9.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(calendar8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
//        int[] intArray14 = monthDay13.getValues();
//        org.joda.time.MonthDay.Property property15 = monthDay13.dayOfMonth();
//        java.util.Locale locale17 = null;
//        org.joda.time.MonthDay monthDay18 = property15.setCopy("2", locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property15.getAsText(locale19);
//        org.joda.time.ReadableInstant readableInstant21 = null;
//        try {
//            int int22 = property15.compareTo(readableInstant21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31" + "'", str20.equals("31"));
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.DurationField durationField2 = julianChronology0.years();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (short) 10);
//        int int6 = dateTime3.getMonthOfYear();
//        org.joda.time.YearMonthDay yearMonthDay7 = dateTime3.toYearMonthDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        try {
//            int int9 = dateTime3.get(dateTimeFieldType8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(yearMonthDay7);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        try {
            long long6 = dateTimeFormatter4.parseMillis("6/15/19");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"6/15/19\" is malformed at \"/15/19\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("AD");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"AD\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
//        java.lang.String str2 = dateTimeZone1.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((int) ' ');
//        boolean boolean8 = dateTime5.isEqualNow();
//        java.util.Locale locale9 = null;
//        java.util.Calendar calendar10 = dateTime5.toCalendar(locale9);
//        org.joda.time.LocalDateTime localDateTime11 = dateTime5.toLocalDateTime();
//        boolean boolean12 = dateTimeZone1.isLocalDateTimeGap(localDateTime11);
//        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
//        int int14 = copticChronology13.getMinimumDaysInFirstWeek();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(calendar10);
//        org.junit.Assert.assertNotNull(localDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(copticChronology13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay((int) ' ');
        boolean boolean6 = dateTime3.isEqualNow();
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime3.toCalendar(locale7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime3);
        boolean boolean10 = dateTime3.isEqualNow();
        org.joda.time.DateTime dateTime12 = dateTime3.plusDays((int) (short) 10);
        org.joda.time.DateTime.Property property13 = dateTime3.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(calendar8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.String str14 = monthDay5.toString(dateTimeFormatter13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay16 = monthDay5.minus(readablePeriod15);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "����W���" + "'", str14.equals("����W���"));
        org.junit.Assert.assertNotNull(monthDay16);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 100);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getDurationField();
        java.lang.String str8 = offsetDateTimeField4.getName();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "era" + "'", str8.equals("era"));
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
//        org.joda.time.DurationField durationField4 = julianChronology2.years();
//        org.joda.time.DurationField durationField5 = julianChronology2.weeks();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology2.minuteOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField6);
//        long long10 = skipUndoDateTimeField7.set((long) (short) 0, (int) (byte) 1);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone12);
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTime(dateTimeZone16);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((java.lang.Object) dateTime13, chronology18);
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay19.withPeriodAdded(readablePeriod20, (int) (byte) 10);
//        java.util.Locale locale23 = null;
//        try {
//            java.lang.String str24 = skipUndoDateTimeField7.getAsText((org.joda.time.ReadablePartial) monthDay22, locale23);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-57540000L) + "'", long10 == (-57540000L));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(monthDay22);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone7);
//        boolean boolean9 = dateTime8.isEqualNow();
//        int int10 = dateTime8.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime8.minus(readablePeriod11);
//        int int13 = dateTime8.getSecondOfDay();
//        org.joda.time.DateTime.Property property14 = dateTime8.millisOfSecond();
//        java.lang.String str15 = property14.getAsString();
//        org.joda.time.DateTime dateTime17 = property14.addToCopy(0);
//        boolean boolean18 = buddhistChronology1.equals((java.lang.Object) dateTime17);
//        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int20 = julianChronology19.getMinimumDaysInFirstWeek();
//        boolean boolean22 = julianChronology19.equals((java.lang.Object) (short) 100);
//        boolean boolean23 = buddhistChronology1.equals((java.lang.Object) boolean22);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600001 + "'", int10 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57600 + "'", int13 == 57600);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(julianChronology19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(10L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
//        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
//        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
//        java.lang.String str14 = offsetDateTimeField4.getAsShortText((long) 57600);
//        long long16 = offsetDateTimeField4.roundHalfEven((long) '#');
//        java.util.Locale locale17 = null;
//        int int18 = offsetDateTimeField4.getMaximumShortTextLength(locale17);
//        try {
//            long long21 = offsetDateTimeField4.getDifferenceAsLong((-315576000421938L), (long) 3);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2" + "'", str14.equals("2"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-9223372036825975809L) + "'", long16 == (-9223372036825975809L));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
        java.lang.String str14 = offsetDateTimeField4.getAsShortText((long) 57600);
        try {
            long long17 = offsetDateTimeField4.add((long) (short) 0, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2" + "'", str14.equals("2"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '#');
        try {
            long long9 = offsetDateTimeField6.add((long) (short) 10, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillis((long) 1439);
        int int10 = dateTime6.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        dateTimeFormatterBuilder2.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone7);
//        boolean boolean9 = dateTime8.isEqualNow();
//        int int10 = dateTime8.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime8.minus(readablePeriod11);
//        int int13 = dateTime8.getSecondOfDay();
//        org.joda.time.DateTime.Property property14 = dateTime8.millisOfSecond();
//        java.lang.String str15 = property14.getAsString();
//        org.joda.time.DateTime dateTime17 = property14.addToCopy(0);
//        boolean boolean18 = buddhistChronology1.equals((java.lang.Object) dateTime17);
//        org.joda.time.DurationField durationField19 = buddhistChronology1.days();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600001 + "'", int10 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57600 + "'", int13 == 57600);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(durationField19);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField3 = julianChronology1.years();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.yearOfEra();
        int int13 = gJChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology10);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
        java.util.Locale locale14 = null;
        try {
            java.lang.String str15 = monthDay5.toString("JulianChronology[America/Los_Angeles]", locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.weeks();
        org.joda.time.DurationField durationField3 = julianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.year();
        try {
            long long12 = julianChronology0.getDateTimeMillis((int) '#', 69, 3, 2922789, (int) (byte) -1, (-1), 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.era();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        long long7 = delegatedDateTimeField5.roundHalfEven((long) 'a');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField5, 0);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = iSOChronology10.getZone();
//        java.lang.String str12 = dateTimeZone11.toString();
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone11);
//        java.util.Locale locale14 = null;
//        try {
//            java.lang.String str15 = skipDateTimeField9.getAsText((org.joda.time.ReadablePartial) monthDay13, locale14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'era' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-9223372036825975809L) + "'", long7 == (-9223372036825975809L));
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((java.lang.Object) dateTime15, chronology20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.MonthDay monthDay24 = monthDay21.withPeriodAdded(readablePeriod22, (int) (byte) 10);
        org.joda.time.MonthDay monthDay26 = monthDay21.minusMonths((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) (byte) 1);
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay();
        int[] intArray38 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int39 = offsetDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) monthDay32, intArray38);
        int int40 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay21, intArray38);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.MonthDay monthDay42 = monthDay21.plus(readablePeriod41);
        org.joda.time.MonthDay.Property property43 = monthDay21.monthOfYear();
        int int44 = property43.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = gregorianChronology1.get(readablePeriod5, (long) 2, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime2.withHourOfDay(0);
        int int7 = dateTime6.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay(2, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYear((int) '4', 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (byte) 1, (int) (short) 100);
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendYear(10, (int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
//        int[] intArray14 = monthDay13.getValues();
//        org.joda.time.MonthDay.Property property15 = monthDay13.dayOfMonth();
//        java.lang.String str16 = property15.getAsString();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31" + "'", str16.equals("31"));
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
//        java.lang.String str2 = dateTimeZone1.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((int) ' ');
//        boolean boolean8 = dateTime5.isEqualNow();
//        java.util.Locale locale9 = null;
//        java.util.Calendar calendar10 = dateTime5.toCalendar(locale9);
//        org.joda.time.LocalDateTime localDateTime11 = dateTime5.toLocalDateTime();
//        boolean boolean12 = dateTimeZone1.isLocalDateTimeGap(localDateTime11);
//        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(calendar10);
//        org.junit.Assert.assertNotNull(localDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(copticChronology13);
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.era();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        long long7 = delegatedDateTimeField5.roundHalfEven((long) 'a');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField5, 0);
//        java.lang.String str10 = julianChronology0.toString();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-9223372036825975809L) + "'", long7 == (-9223372036825975809L));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str10.equals("JulianChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-57540000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
        int[] intArray14 = monthDay13.getValues();
        org.joda.time.MonthDay.Property property15 = monthDay13.dayOfMonth();
        java.util.Locale locale17 = null;
        org.joda.time.MonthDay monthDay18 = property15.setCopy("2", locale17);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType20 = monthDay18.getFieldType(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(monthDay18);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
//        int[] intArray14 = monthDay13.getValues();
//        org.joda.time.MonthDay.Property property15 = monthDay13.dayOfMonth();
//        java.util.Locale locale17 = null;
//        org.joda.time.MonthDay monthDay18 = property15.setCopy("2", locale17);
//        java.lang.String str19 = property15.getAsText();
//        int int20 = property15.getMaximumValueOverall();
//        int int21 = property15.getMaximumValue();
//        java.util.Locale locale23 = null;
//        try {
//            org.joda.time.MonthDay monthDay24 = property15.setCopy("CopticChronology[America/Los_Angeles]", locale23);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"CopticChronology[America/Los_Angeles]\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31" + "'", str19.equals("31"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 31 + "'", int20 == 31);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 31 + "'", int21 == 31);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("era");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: era");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: America/Los_Angeles");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((java.lang.Object) dateTime15, chronology20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.MonthDay monthDay24 = monthDay21.withPeriodAdded(readablePeriod22, (int) (byte) 10);
        org.joda.time.MonthDay monthDay26 = monthDay21.minusMonths((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) (byte) 1);
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay();
        int[] intArray38 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int39 = offsetDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) monthDay32, intArray38);
        int int40 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay21, intArray38);
        org.joda.time.DurationField durationField41 = offsetDateTimeField4.getLeapDurationField();
        try {
            long long44 = offsetDateTimeField4.add((-9223372036825975809L), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNull(durationField41);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(1969, 2, 57600001, 0, (int) (byte) 100, chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.Chronology chronology14 = monthDay13.getChronology();
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay13, 0, locale16);
        java.lang.String str19 = delegatedDateTimeField4.getAsShortText((long) (byte) -1);
        int int21 = delegatedDateTimeField4.getMaximumValue((long) 57600);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "BC" + "'", str17.equals("BC"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "AD" + "'", str19.equals("AD"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfDay((int) ' ');
        boolean boolean13 = dateTime10.isEqualNow();
        java.util.Locale locale14 = null;
        java.util.Calendar calendar15 = dateTime10.toCalendar(locale14);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone19 = iSOChronology18.getZone();
        org.joda.time.Chronology chronology20 = gJChronology16.withZone(dateTimeZone19);
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        try {
            org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(2, (int) (short) 10, 1, (int) (short) 10, (int) (byte) 100, (int) 'a', 57600001, dateTimeZone19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(calendar15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(julianChronology22);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        long long4 = dateTimeZone2.convertUTCToLocal((long) 10);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-28799990L) + "'", long4 == (-28799990L));
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay18 = monthDay13.minusMonths((int) (short) -1);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) '#', locale20);
//        int int22 = skipDateTimeField4.getMinimumValue();
//        long long24 = skipDateTimeField4.roundHalfEven((-1L));
//        int int26 = skipDateTimeField4.getMaximumValue((long) '4');
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "35" + "'", str21.equals("35"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1439 + "'", int26 == 1439);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
        java.lang.String str14 = offsetDateTimeField4.getAsShortText((long) 57600);
        java.lang.String str16 = offsetDateTimeField4.getAsText(0L);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.toDateTime(dateTimeZone22);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((java.lang.Object) dateTime19, chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (int) (byte) 10);
        org.joda.time.MonthDay monthDay30 = monthDay25.minusMonths((int) (short) -1);
        org.joda.time.MonthDay monthDay32 = monthDay30.minusDays((int) (short) 10);
        int[] intArray34 = null;
        try {
            int[] intArray36 = offsetDateTimeField4.add((org.joda.time.ReadablePartial) monthDay30, (int) '#', intArray34, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2" + "'", str14.equals("2"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2" + "'", str16.equals("2"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(monthDay32);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        java.lang.String str1 = copticChronology0.toString();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.era();
//        org.joda.time.DurationField durationField5 = julianChronology2.years();
//        boolean boolean6 = copticChronology0.equals((java.lang.Object) julianChronology2);
//        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology0.getZone();
//        long long10 = dateTimeZone7.adjustOffset((-315576000421938L), false);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str1.equals("CopticChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-315576000421938L) + "'", long10 == (-315576000421938L));
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "hi!");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "America/Los_Angeles", "2");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 2, 31);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 62L + "'", long2 == 62L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendSecondOfDay((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay(2, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYear((int) '4', 3);
        boolean boolean7 = dateTimeFormatterBuilder6.canBuildPrinter();
        boolean boolean8 = dateTimeFormatterBuilder6.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("1");
        try {
            org.joda.time.LocalTime localTime3 = dateTimeFormatter1.parseLocalTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = iSOChronology5.getZone();
//        java.lang.String str7 = dateTimeZone6.toString();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfDay((int) ' ');
//        boolean boolean13 = dateTime10.isEqualNow();
//        java.util.Locale locale14 = null;
//        java.util.Calendar calendar15 = dateTime10.toCalendar(locale14);
//        org.joda.time.LocalDateTime localDateTime16 = dateTime10.toLocalDateTime();
//        boolean boolean17 = dateTimeZone6.isLocalDateTimeGap(localDateTime16);
//        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
//        long long21 = dateTimeZone6.adjustOffset((long) 1969, false);
//        try {
//            org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(57600, (int) '#', (int) ' ', (int) (byte) 0, 1970, dateTimeZone6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "America/Los_Angeles" + "'", str7.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(calendar15);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(copticChronology18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1969L + "'", long21 == 1969L);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
//        boolean boolean8 = dateTime7.isEqualNow();
//        int int9 = dateTime7.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime7.minus(readablePeriod10);
//        int int12 = dateTime7.getSecondOfDay();
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime7.getZone();
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, 31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 31");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600001 + "'", int9 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600 + "'", int12 == 57600);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay(2, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYear((int) '4', 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        int int11 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
//        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
//        boolean boolean30 = dateTime29.isEqualNow();
//        int int31 = dateTime29.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
//        int int34 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
//        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
//        int int38 = property37.getMaximumValueOverall();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
//        int int40 = dateTime15.get(dateTimeFieldType39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
//        org.joda.time.DurationField durationField44 = julianChronology42.years();
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
//        org.joda.time.ReadablePeriod readablePeriod46 = null;
//        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
//        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
//        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
//        try {
//            int int56 = unsupportedDateTimeField55.getMaximumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 57600001 + "'", int31 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 57600 + "'", int34 == 57600);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
//        org.junit.Assert.assertNotNull(julianChronology42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        int int11 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
//        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DurationField durationField21 = property12.getDurationField();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(durationField21);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfDay((int) ' ');
        boolean boolean12 = dateTime9.isEqualNow();
        java.util.Locale locale13 = null;
        java.util.Calendar calendar14 = dateTime9.toCalendar(locale13);
        org.joda.time.LocalDateTime localDateTime15 = dateTime9.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.toDateTime(dateTimeZone22);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((java.lang.Object) dateTime19, chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (int) (byte) 10);
        org.joda.time.MonthDay monthDay30 = monthDay25.minusMonths((int) (short) -1);
        int[] intArray31 = monthDay30.getValues();
        try {
            int[] intArray33 = offsetDateTimeField6.addWrapPartial((org.joda.time.ReadablePartial) localDateTime15, 100, intArray31, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(calendar14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) '#', (int) (byte) 1, 1439, (int) (byte) 1, 0, (int) 'a', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("hi!", 2922789, (int) (short) -1, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for hi! must be in the range [-1,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        int int11 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
//        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
//        boolean boolean30 = dateTime29.isEqualNow();
//        int int31 = dateTime29.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
//        int int34 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
//        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
//        int int38 = property37.getMaximumValueOverall();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
//        int int40 = dateTime15.get(dateTimeFieldType39);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType39, 0, 0, (-2));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for centuryOfEra must be in the range [0,-2]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 57600001 + "'", int31 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 57600 + "'", int34 == 57600);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        int int11 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
//        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
//        boolean boolean30 = dateTime29.isEqualNow();
//        int int31 = dateTime29.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
//        int int34 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
//        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
//        int int38 = property37.getMaximumValueOverall();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
//        int int40 = dateTime15.get(dateTimeFieldType39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
//        org.joda.time.DurationField durationField44 = julianChronology42.years();
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
//        org.joda.time.ReadablePeriod readablePeriod46 = null;
//        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
//        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
//        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
//        java.lang.String str56 = unsupportedDateTimeField55.getName();
//        try {
//            int int57 = unsupportedDateTimeField55.getMinimumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 57600001 + "'", int31 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 57600 + "'", int34 == 57600);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
//        org.junit.Assert.assertNotNull(julianChronology42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "centuryOfEra" + "'", str56.equals("centuryOfEra"));
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendTimeZoneOffset("����W���", "PST", true, (int) (short) 10, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology6);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(8, 1, (int) '4', 0, 97, (int) (byte) 10, (org.joda.time.Chronology) julianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTime dateTime6 = dateTime2.withHourOfDay(0);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime2.minus(readableDuration7);
//        int int9 = dateTime8.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
//        int[] intArray14 = monthDay13.getValues();
//        org.joda.time.MonthDay.Property property15 = monthDay13.dayOfMonth();
//        java.util.Locale locale17 = null;
//        org.joda.time.MonthDay monthDay18 = property15.setCopy("2", locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property15.getAsText(locale19);
//        org.joda.time.MonthDay monthDay22 = property15.setCopy(10);
//        org.joda.time.DurationField durationField23 = property15.getDurationField();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31" + "'", str20.equals("31"));
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(durationField23);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
//        java.lang.String str2 = dateTimeZone1.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((int) ' ');
//        boolean boolean8 = dateTime5.isEqualNow();
//        java.util.Locale locale9 = null;
//        java.util.Calendar calendar10 = dateTime5.toCalendar(locale9);
//        org.joda.time.LocalDateTime localDateTime11 = dateTime5.toLocalDateTime();
//        boolean boolean12 = dateTimeZone1.isLocalDateTimeGap(localDateTime11);
//        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfDay((int) ' ');
//        boolean boolean20 = dateTime17.isEqualNow();
//        java.util.Locale locale21 = null;
//        java.util.Calendar calendar22 = dateTime17.toCalendar(locale21);
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.halfdayOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone26 = iSOChronology25.getZone();
//        org.joda.time.Chronology chronology27 = gJChronology23.withZone(dateTimeZone26);
//        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone26);
//        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology13, dateTimeZone26);
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(calendar10);
//        org.junit.Assert.assertNotNull(localDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(copticChronology13);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(calendar22);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(julianChronology28);
//        org.junit.Assert.assertNotNull(zonedChronology29);
//        org.junit.Assert.assertNotNull(gJChronology30);
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        int int11 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime6.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime14 = dateTime6.plusMonths((int) (short) 0);
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
//        int int16 = dateTime14.getYear();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1969 + "'", int16 == 1969);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        int int11 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime6.withEarlierOffsetAtOverlap();
//        boolean boolean13 = dateTime6.isEqualNow();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (-2013900000), (long) 21);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2013900021L) + "'", long2 == (-2013900021L));
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        int int11 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
//        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
//        boolean boolean30 = dateTime29.isEqualNow();
//        int int31 = dateTime29.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
//        int int34 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
//        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
//        int int38 = property37.getMaximumValueOverall();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
//        int int40 = dateTime15.get(dateTimeFieldType39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
//        org.joda.time.DurationField durationField44 = julianChronology42.years();
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
//        org.joda.time.ReadablePeriod readablePeriod46 = null;
//        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
//        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
//        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
//        java.lang.String str56 = unsupportedDateTimeField55.getName();
//        java.util.Locale locale59 = null;
//        try {
//            long long60 = unsupportedDateTimeField55.set(0L, "31", locale59);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 57600001 + "'", int31 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 57600 + "'", int34 == 57600);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
//        org.junit.Assert.assertNotNull(julianChronology42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "centuryOfEra" + "'", str56.equals("centuryOfEra"));
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(chronology1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
//        int[] intArray14 = monthDay13.getValues();
//        org.joda.time.MonthDay.Property property15 = monthDay13.dayOfMonth();
//        java.util.Locale locale17 = null;
//        org.joda.time.MonthDay monthDay18 = property15.setCopy("2", locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property15.getAsText(locale19);
//        try {
//            org.joda.time.MonthDay monthDay22 = property15.setCopy((-2013900000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2013900000 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31" + "'", str20.equals("31"));
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.util.Collection<org.joda.time.DateTimeFieldType> dateTimeFieldTypeCollection0 = null;
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.forFields(dateTimeFieldTypeCollection0, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        int int11 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
//        java.lang.String str13 = property12.getAsString();
//        org.joda.time.DateTime dateTime15 = property12.addToCopy(0);
//        org.joda.time.DurationField durationField16 = property12.getDurationField();
//        org.joda.time.DateTime dateTime18 = property12.addWrapFieldToCopy((-1));
//        boolean boolean19 = property12.isLeap();
//        org.joda.time.DurationField durationField20 = property12.getDurationField();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(durationField20);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay(2, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYear(2922789, 69);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatterBuilder0.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
//        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
//        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((java.lang.Object) dateTime15, chronology20);
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.MonthDay monthDay24 = monthDay21.withPeriodAdded(readablePeriod22, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay26 = monthDay21.minusMonths((int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) (byte) 1);
//        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay();
//        int[] intArray38 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
//        int int39 = offsetDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) monthDay32, intArray38);
//        int int40 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay21, intArray38);
//        int int42 = offsetDateTimeField4.getMinimumValue((long) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone44);
//        org.joda.time.DateTime dateTime47 = dateTime45.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTime dateTime49 = dateTime45.toDateTime(dateTimeZone48);
//        org.joda.time.Chronology chronology50 = null;
//        org.joda.time.MonthDay monthDay51 = new org.joda.time.MonthDay((java.lang.Object) dateTime45, chronology50);
//        org.joda.time.ReadablePeriod readablePeriod52 = null;
//        org.joda.time.MonthDay monthDay54 = monthDay51.withPeriodAdded(readablePeriod52, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay56 = monthDay51.minusMonths((int) (short) -1);
//        int[] intArray57 = monthDay56.getValues();
//        org.joda.time.MonthDay.Property property58 = monthDay56.dayOfMonth();
//        java.util.Locale locale60 = null;
//        org.joda.time.MonthDay monthDay61 = property58.setCopy("2", locale60);
//        java.lang.String str62 = property58.getAsText();
//        int int63 = property58.getMaximumValueOverall();
//        int int64 = property58.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone66 = null;
//        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone66);
//        org.joda.time.DateTime dateTime69 = dateTime67.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone70 = null;
//        org.joda.time.DateTime dateTime71 = dateTime67.toDateTime(dateTimeZone70);
//        org.joda.time.Chronology chronology72 = null;
//        org.joda.time.MonthDay monthDay73 = new org.joda.time.MonthDay((java.lang.Object) dateTime67, chronology72);
//        int int74 = property58.compareTo((org.joda.time.ReadablePartial) monthDay73);
//        java.util.Locale locale76 = null;
//        java.lang.String str77 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay73, 97, locale76);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(monthDay56);
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(monthDay61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "31" + "'", str62.equals("31"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 31 + "'", int63 == 31);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 31 + "'", int64 == 31);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "97" + "'", str77.equals("97"));
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        int int11 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
//        java.lang.String str13 = property12.getAsString();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone15);
//        org.joda.time.DateTime dateTime18 = dateTime16.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime16.toDateTime(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((java.lang.Object) dateTime16, chronology21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.MonthDay monthDay25 = monthDay22.withPeriodAdded(readablePeriod23, (int) (byte) 10);
//        java.lang.String str26 = monthDay22.toString();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone28);
//        org.joda.time.DateTime dateTime31 = dateTime29.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime29.toDateTime(dateTimeZone32);
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay((java.lang.Object) dateTime29, chronology34);
//        org.joda.time.ReadablePeriod readablePeriod36 = null;
//        org.joda.time.MonthDay monthDay38 = monthDay35.withPeriodAdded(readablePeriod36, (int) (byte) 10);
//        boolean boolean39 = monthDay22.isEqual((org.joda.time.ReadablePartial) monthDay38);
//        boolean boolean40 = property12.equals((java.lang.Object) monthDay38);
//        java.lang.Object obj41 = null;
//        boolean boolean42 = property12.equals(obj41);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(monthDay25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "--12-31" + "'", str26.equals("--12-31"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(monthDay38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField3 = julianChronology1.years();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.yearOfEra();
        int int13 = gJChronology10.getMinimumDaysInFirstWeek();
        try {
            long long18 = gJChronology10.getDateTimeMillis(10, 2922789, (int) 'a', 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int0 = org.joda.time.MonthDay.DAY_OF_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        boolean boolean10 = monthDay8.isSupported(dateTimeFieldType9);
//        int int12 = monthDay8.getValue(0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
//    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.shortDate();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant5 = instant2.withDurationAdded((long) (short) 100, (int) (byte) 1);
//        java.lang.String str6 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) instant2);
//        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter1.getParser();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter1.withLocale(locale8);
//        try {
//            org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.parse("centuryOfEra", dateTimeFormatter1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"centuryOfEra\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "6/15/19" + "'", str6.equals("6/15/19"));
//        org.junit.Assert.assertNotNull(dateTimeParser7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay((int) ' ');
        boolean boolean6 = dateTime3.isEqualNow();
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime3.toCalendar(locale7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology11.getZone();
        org.joda.time.Chronology chronology13 = gJChronology9.withZone(dateTimeZone12);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(calendar8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        int int11 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime6.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime14 = dateTime6.plusMonths((int) (short) 0);
//        org.joda.time.DateTime.Property property15 = dateTime6.yearOfCentury();
//        org.joda.time.DateTime dateTime16 = property15.roundCeilingCopy();
//        int int17 = property15.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 99 + "'", int17 == 99);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(1970, 8, (int) (short) -1, 57600001);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1978 + "'", int4 == 1978);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
//        int[] intArray14 = monthDay13.getValues();
//        org.joda.time.MonthDay.Property property15 = monthDay13.dayOfMonth();
//        java.lang.String str16 = property15.getAsText();
//        java.util.Locale locale17 = null;
//        int int18 = property15.getMaximumTextLength(locale17);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property15.getFieldType();
//        int int20 = property15.getMinimumValue();
//        int int21 = property15.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31" + "'", str16.equals("31"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
//        java.lang.String str2 = dateTimeZone1.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((int) ' ');
//        boolean boolean8 = dateTime5.isEqualNow();
//        java.util.Locale locale9 = null;
//        java.util.Calendar calendar10 = dateTime5.toCalendar(locale9);
//        org.joda.time.LocalDateTime localDateTime11 = dateTime5.toLocalDateTime();
//        boolean boolean12 = dateTimeZone1.isLocalDateTimeGap(localDateTime11);
//        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
//        long long16 = dateTimeZone1.adjustOffset((long) 1969, false);
//        int int18 = dateTimeZone1.getOffsetFromLocal((long) 2922789);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(calendar10);
//        org.junit.Assert.assertNotNull(localDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(copticChronology13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1969L + "'", long16 == 1969L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant3 = instant0.withDurationAdded((long) (short) 100, (int) (byte) 1);
        org.joda.time.Instant instant5 = instant0.withMillis((long) 57600);
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        int int11 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTime dateTime13 = dateTime6.minusYears(4);
//        org.joda.time.DateTime.Property property14 = dateTime6.centuryOfEra();
//        org.joda.time.TimeOfDay timeOfDay15 = dateTime6.toTimeOfDay();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(timeOfDay15);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withYear(2922789);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        int int11 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
//        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
//        boolean boolean30 = dateTime29.isEqualNow();
//        int int31 = dateTime29.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
//        int int34 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
//        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
//        int int38 = property37.getMaximumValueOverall();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
//        int int40 = dateTime15.get(dateTimeFieldType39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
//        org.joda.time.DurationField durationField44 = julianChronology42.years();
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
//        org.joda.time.ReadablePeriod readablePeriod46 = null;
//        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
//        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
//        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
//        java.lang.String str56 = unsupportedDateTimeField55.getName();
//        boolean boolean57 = unsupportedDateTimeField55.isSupported();
//        try {
//            long long60 = unsupportedDateTimeField55.set((long) 97, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 57600001 + "'", int31 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 57600 + "'", int34 == 57600);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
//        org.junit.Assert.assertNotNull(julianChronology42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "centuryOfEra" + "'", str56.equals("centuryOfEra"));
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant4 = instant1.withDurationAdded((long) (short) 100, (int) (byte) 1);
//        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter0.getParser();
//        java.util.Locale locale7 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withLocale(locale7);
//        try {
//            org.joda.time.LocalDateTime localDateTime10 = dateTimeFormatter0.parseLocalDateTime("--12-31");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--12-31\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "6/15/19" + "'", str5.equals("6/15/19"));
//        org.junit.Assert.assertNotNull(dateTimeParser6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
        int[] intArray14 = monthDay13.getValues();
        org.joda.time.MonthDay.Property property15 = monthDay13.dayOfMonth();
        java.lang.Object obj16 = null;
        boolean boolean17 = monthDay13.equals(obj16);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology4.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology6.getZone();
        long long9 = dateTimeZone5.getMillisKeepLocal(dateTimeZone7, (-62105328000000L));
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime11 = dateTime2.withZone(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        try {
            long long20 = julianChronology12.getDateTimeMillis((int) (short) -1, (int) '#', 0, 0, (int) (byte) 10, (int) (byte) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62105328000000L) + "'", long9 == (-62105328000000L));
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(julianChronology12);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        int int11 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
//        java.lang.String str13 = property12.getAsString();
//        org.joda.time.DateTime dateTime15 = property12.addToCopy(0);
//        org.joda.time.DurationField durationField16 = property12.getDurationField();
//        org.joda.time.DateTime dateTime18 = property12.addWrapFieldToCopy((-1));
//        boolean boolean19 = property12.isLeap();
//        org.joda.time.DateTime dateTime21 = property12.addToCopy((int) ' ');
//        int int22 = property12.getMinimumValueOverall();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay18 = monthDay13.minusMonths((int) (short) -1);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) '#', locale20);
//        int int22 = skipDateTimeField4.getMinimumValue();
//        long long24 = skipDateTimeField4.roundHalfEven((-1L));
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipDateTimeField4.getAsShortText(57600001, locale26);
//        java.lang.String str29 = skipDateTimeField4.getAsText((long) 2019);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "35" + "'", str21.equals("35"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "57600001" + "'", str27.equals("57600001"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "960" + "'", str29.equals("960"));
//    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        int int11 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
//        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
//        boolean boolean30 = dateTime29.isEqualNow();
//        int int31 = dateTime29.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
//        int int34 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
//        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
//        int int38 = property37.getMaximumValueOverall();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
//        int int40 = dateTime15.get(dateTimeFieldType39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
//        org.joda.time.DurationField durationField44 = julianChronology42.years();
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
//        org.joda.time.ReadablePeriod readablePeriod46 = null;
//        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
//        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
//        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
//        long long58 = unsupportedDateTimeField55.add((long) 3, (int) (short) 10);
//        org.joda.time.DurationField durationField59 = unsupportedDateTimeField55.getRangeDurationField();
//        try {
//            int int60 = unsupportedDateTimeField55.getMaximumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 57600001 + "'", int31 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 57600 + "'", int34 == 57600);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
//        org.junit.Assert.assertNotNull(julianChronology42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 432000003L + "'", long58 == 432000003L);
//        org.junit.Assert.assertNull(durationField59);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        int int8 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        int int11 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
//        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
//        boolean boolean30 = dateTime29.isEqualNow();
//        int int31 = dateTime29.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
//        int int34 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
//        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
//        int int38 = property37.getMaximumValueOverall();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
//        int int40 = dateTime15.get(dateTimeFieldType39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
//        org.joda.time.DurationField durationField44 = julianChronology42.years();
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
//        org.joda.time.ReadablePeriod readablePeriod46 = null;
//        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
//        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
//        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
//        java.lang.String str56 = unsupportedDateTimeField55.getName();
//        java.util.Locale locale58 = null;
//        try {
//            java.lang.String str59 = unsupportedDateTimeField55.getAsShortText(1L, locale58);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600001 + "'", int8 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 57600001 + "'", int31 == 57600001);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 57600 + "'", int34 == 57600);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
//        org.junit.Assert.assertNotNull(julianChronology42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "centuryOfEra" + "'", str56.equals("centuryOfEra"));
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        int int3 = monthDay1.indexOf(dateTimeFieldType2);
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.era();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
//        long long10 = delegatedDateTimeField8.roundHalfEven((long) 'a');
//        long long12 = delegatedDateTimeField8.roundFloor((long) 1);
//        long long14 = delegatedDateTimeField8.roundHalfCeiling(0L);
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int18 = julianChronology17.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology17.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology16, dateTimeField19);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone22);
//        org.joda.time.DateTime dateTime25 = dateTime23.withMillisOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime(dateTimeZone26);
//        org.joda.time.Chronology chronology28 = null;
//        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay((java.lang.Object) dateTime23, chronology28);
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        org.joda.time.MonthDay monthDay32 = monthDay29.withPeriodAdded(readablePeriod30, (int) (byte) 10);
//        org.joda.time.MonthDay monthDay34 = monthDay29.minusMonths((int) (short) -1);
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = skipDateTimeField20.getAsText((org.joda.time.ReadablePartial) monthDay29, (int) '#', locale36);
//        org.joda.time.ReadablePartial readablePartial38 = null;
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone39);
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (byte) 1);
//        org.joda.time.MonthDay monthDay44 = new org.joda.time.MonthDay();
//        int[] intArray50 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
//        int int51 = offsetDateTimeField43.getMaximumValue((org.joda.time.ReadablePartial) monthDay44, intArray50);
//        int int52 = skipDateTimeField20.getMaximumValue(readablePartial38, intArray50);
//        int int53 = delegatedDateTimeField8.getMaximumValue(readablePartial15, intArray50);
//        try {
//            copticChronology0.validate((org.joda.time.ReadablePartial) monthDay1, intArray50);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must not be larger than 12");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-9223372036825975809L) + "'", long10 == (-9223372036825975809L));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62105328000000L) + "'", long12 == (-62105328000000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-9223372036825975809L) + "'", long14 == (-9223372036825975809L));
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "35" + "'", str37.equals("35"));
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1439 + "'", int52 == 1439);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
//        int int6 = offsetDateTimeField4.getLeapAmount((long) 100);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getDurationField();
//        long long9 = offsetDateTimeField4.roundHalfEven((-31557600421999L));
//        try {
//            long long12 = offsetDateTimeField4.add((long) 4, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9223372036826397809L) + "'", long9 == (-9223372036826397809L));
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        org.joda.time.ReadablePartial readablePartial56 = null;
        try {
            int int57 = unsupportedDateTimeField55.getMaximumValue(readablePartial56);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.String str14 = monthDay5.toString(dateTimeFormatter13);
        int int15 = monthDay5.getMonthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "����W���" + "'", str14.equals("����W���"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay((int) ' ');
        boolean boolean6 = dateTime3.isEqualNow();
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime3.toCalendar(locale7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(calendar8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundHalfEven((long) 'a');
        int int8 = delegatedDateTimeField4.get((-315576000421938L));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105356800100L) + "'", long6 == (-62105356800100L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.years();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime3.minusWeeks(2922789);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime10.toDateTime(dateTimeZone13);
        boolean boolean15 = dateTime14.isEqualNow();
        int int16 = dateTime14.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime14.minus(readablePeriod17);
        int int19 = dateTime14.getSecondOfDay();
        org.joda.time.DateTime dateTime21 = dateTime14.minusYears(4);
        org.joda.time.DateTime.Property property22 = dateTime14.centuryOfEra();
        int int23 = property22.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property22.getFieldType();
        int int25 = dateTime3.get(dateTimeFieldType24);
        try {
            org.joda.time.DateTime dateTime27 = dateTime3.withCenturyOfEra((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [1,2922730]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2922789 + "'", int23 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 21 + "'", int25 == 21);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
        java.lang.String str14 = offsetDateTimeField4.getAsShortText((long) 57600);
        long long16 = offsetDateTimeField4.roundHalfEven((long) '#');
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField4.getMaximumShortTextLength(locale17);
        int int19 = offsetDateTimeField4.getMinimumValue();
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField4.getAsShortText(4, locale21);
        try {
            long long25 = offsetDateTimeField4.add((long) (short) 0, 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2" + "'", str14.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62135596800100L) + "'", long16 == (-62135596800100L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "4" + "'", str22.equals("4"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        boolean boolean5 = dateTime2.isEqualNow();
        boolean boolean6 = dateTime2.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DurationField durationField21 = property12.getRangeDurationField();
        int int22 = property12.get();
        int int23 = property12.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 101 + "'", int22 == 101);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        java.lang.String str5 = dateTime3.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-15T21:01:07.991+00:00:00.100" + "'", str5.equals("2019-06-15T21:01:07.991+00:00:00.100"));
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay(2, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYear((int) '4', 3);
        boolean boolean7 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.lang.String str10 = dateTimeFormatter8.print((long) 2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.append(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "004842.889+0000" + "'", str10.equals("004842.889+0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatterBuilder5.toFormatter();
        boolean boolean7 = copticChronology1.equals((java.lang.Object) dateTimeFormatter6);
        try {
            org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.parse("DateTimeField[era]", dateTimeFormatter6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(69);
        java.lang.String str5 = dateTime4.toString();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-01-01T00:00:00.101+00:00:00.100" + "'", str5.equals("1969-01-01T00:00:00.101+00:00:00.100"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
        org.joda.time.MonthDay monthDay18 = monthDay13.minusMonths((int) (short) -1);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) '#', locale20);
        int int22 = skipDateTimeField4.getMinimumValue();
        long long24 = skipDateTimeField4.roundHalfEven((-1L));
        org.joda.time.DurationField durationField25 = skipDateTimeField4.getRangeDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "35" + "'", str21.equals("35"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-100L) + "'", long24 == (-100L));
        org.junit.Assert.assertNotNull(durationField25);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime dateTime13 = dateTime6.minusYears(4);
        java.util.Locale locale14 = null;
        java.util.Calendar calendar15 = dateTime6.toCalendar(locale14);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(calendar15);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
        int[] intArray14 = monthDay13.getValues();
        org.joda.time.MonthDay.Property property15 = monthDay13.dayOfMonth();
        java.util.Locale locale17 = null;
        org.joda.time.MonthDay monthDay18 = property15.setCopy("2", locale17);
        java.lang.String str19 = property15.getAsText();
        int int20 = property15.getMaximumValueOverall();
        int int21 = property15.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone23);
        boolean boolean25 = property15.equals((java.lang.Object) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.minusMillis(1969);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 31 + "'", int20 == 31);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 29 + "'", int21 == 29);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendWeekyear(57600, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField3 = julianChronology1.years();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime12 = dateTime4.minusSeconds((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology13.getZone();
        org.joda.time.DateTime dateTime15 = dateTime4.toDateTime(dateTimeZone14);
        try {
            org.joda.time.DateTime dateTime19 = dateTime4.withDate(6, 1970, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.Chronology chronology14 = monthDay13.getChronology();
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay13, 0, locale16);
        java.lang.String str18 = delegatedDateTimeField4.toString();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology19);
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone25);
        org.joda.time.DateTime dateTime28 = dateTime26.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime26.toDateTime(dateTimeZone29);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay((java.lang.Object) dateTime26, chronology31);
        org.joda.time.Chronology chronology33 = monthDay32.getChronology();
        java.util.Locale locale35 = null;
        java.lang.String str36 = delegatedDateTimeField23.getAsShortText((org.joda.time.ReadablePartial) monthDay32, 0, locale35);
        java.util.Locale locale38 = null;
        java.lang.String str39 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay32, 0, locale38);
        long long41 = delegatedDateTimeField4.roundCeiling((long) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone43);
        org.joda.time.DateTime dateTime46 = dateTime44.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.DateTime dateTime48 = dateTime44.toDateTime(dateTimeZone47);
        boolean boolean49 = dateTime48.isEqualNow();
        int int50 = dateTime48.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        org.joda.time.DateTime dateTime52 = dateTime48.minus(readablePeriod51);
        int int53 = dateTime48.getSecondOfDay();
        org.joda.time.DateTime.Property property54 = dateTime48.millisOfSecond();
        java.lang.String str55 = property54.getAsString();
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone57);
        org.joda.time.DateTime dateTime60 = dateTime58.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.DateTime dateTime62 = dateTime58.toDateTime(dateTimeZone61);
        org.joda.time.Chronology chronology63 = null;
        org.joda.time.MonthDay monthDay64 = new org.joda.time.MonthDay((java.lang.Object) dateTime58, chronology63);
        org.joda.time.ReadablePeriod readablePeriod65 = null;
        org.joda.time.MonthDay monthDay67 = monthDay64.withPeriodAdded(readablePeriod65, (int) (byte) 10);
        java.lang.String str68 = monthDay64.toString();
        org.joda.time.DateTimeZone dateTimeZone70 = null;
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone70);
        org.joda.time.DateTime dateTime73 = dateTime71.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone74 = null;
        org.joda.time.DateTime dateTime75 = dateTime71.toDateTime(dateTimeZone74);
        org.joda.time.Chronology chronology76 = null;
        org.joda.time.MonthDay monthDay77 = new org.joda.time.MonthDay((java.lang.Object) dateTime71, chronology76);
        org.joda.time.ReadablePeriod readablePeriod78 = null;
        org.joda.time.MonthDay monthDay80 = monthDay77.withPeriodAdded(readablePeriod78, (int) (byte) 10);
        boolean boolean81 = monthDay64.isEqual((org.joda.time.ReadablePartial) monthDay80);
        boolean boolean82 = property54.equals((java.lang.Object) monthDay80);
        int int83 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay80);
        org.joda.time.DateTimeField dateTimeField84 = delegatedDateTimeField4.getWrappedField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "BC" + "'", str17.equals("BC"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[era]" + "'", str18.equals("DateTimeField[era]"));
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "BC" + "'", str36.equals("BC"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "BC" + "'", str39.equals("BC"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775707L + "'", long41 == 9223372036854775707L);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 101 + "'", int50 == 101);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "101" + "'", str55.equals("101"));
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(monthDay67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "--01-01" + "'", str68.equals("--01-01"));
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(monthDay80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertNotNull(dateTimeField84);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) 'a', 100, 2, (int) ' ', 29);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.append(dateTimeParser6);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatterBuilder16.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.append(dateTimeParser19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray23 = new org.joda.time.format.DateTimeParser[] { dateTimeParser10, dateTimeParser12, dateTimeParser19, dateTimeParser22 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder7.append(dateTimePrinter8, dateTimeParserArray23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendYearOfCentury(100, 4);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder24.appendYear(0, (-2013900000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeParserArray23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        long long58 = unsupportedDateTimeField55.add((long) 3, (int) (short) 10);
        org.joda.time.DurationField durationField59 = unsupportedDateTimeField55.getRangeDurationField();
        long long62 = unsupportedDateTimeField55.add(1560632441089L, (int) (short) 1);
        java.util.Locale locale63 = null;
        try {
            int int64 = unsupportedDateTimeField55.getMaximumShortTextLength(locale63);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 432000003L + "'", long58 == 432000003L);
        org.junit.Assert.assertNull(durationField59);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560675641089L + "'", long62 == 1560675641089L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (-2042700000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.years();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime3.plusMillis((int) '#');
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundHalfEven((long) 'a');
        long long8 = delegatedDateTimeField4.roundFloor((long) 1);
        long long10 = delegatedDateTimeField4.roundHalfCeiling(0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology13.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology12, dateTimeField15);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.toDateTime(dateTimeZone22);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((java.lang.Object) dateTime19, chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (int) (byte) 10);
        org.joda.time.MonthDay monthDay30 = monthDay25.minusMonths((int) (short) -1);
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipDateTimeField16.getAsText((org.joda.time.ReadablePartial) monthDay25, (int) '#', locale32);
        org.joda.time.ReadablePartial readablePartial34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 1);
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay();
        int[] intArray46 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int47 = offsetDateTimeField39.getMaximumValue((org.joda.time.ReadablePartial) monthDay40, intArray46);
        int int48 = skipDateTimeField16.getMaximumValue(readablePartial34, intArray46);
        int int49 = delegatedDateTimeField4.getMaximumValue(readablePartial11, intArray46);
        try {
            long long52 = delegatedDateTimeField4.set((-62105328000000L), (-2013900000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2013900000 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105356800100L) + "'", long6 == (-62105356800100L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62105356800100L) + "'", long8 == (-62105356800100L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62105356800100L) + "'", long10 == (-62105356800100L));
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "35" + "'", str33.equals("35"));
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1439 + "'", int48 == 1439);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundHalfEven((long) 'a');
        long long8 = delegatedDateTimeField4.roundFloor((long) 1);
        long long10 = delegatedDateTimeField4.roundFloor(1969L);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTime(dateTimeZone16);
        boolean boolean18 = dateTime17.isEqualNow();
        int int19 = dateTime17.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime17.minus(readablePeriod20);
        int int22 = dateTime17.getSecondOfDay();
        org.joda.time.DateTime.Property property23 = dateTime17.millisOfSecond();
        java.lang.String str24 = property23.getAsString();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = dateTime27.toDateTime(dateTimeZone30);
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((java.lang.Object) dateTime27, chronology32);
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay36 = monthDay33.withPeriodAdded(readablePeriod34, (int) (byte) 10);
        java.lang.String str37 = monthDay33.toString();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone39);
        org.joda.time.DateTime dateTime42 = dateTime40.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = dateTime40.toDateTime(dateTimeZone43);
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay((java.lang.Object) dateTime40, chronology45);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.MonthDay monthDay49 = monthDay46.withPeriodAdded(readablePeriod47, (int) (byte) 10);
        boolean boolean50 = monthDay33.isEqual((org.joda.time.ReadablePartial) monthDay49);
        boolean boolean51 = property23.equals((java.lang.Object) monthDay49);
        org.joda.time.DateTimeField[] dateTimeFieldArray52 = monthDay49.getFields();
        java.util.Locale locale53 = null;
        try {
            java.lang.String str54 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay49, locale53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'era' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105356800100L) + "'", long6 == (-62105356800100L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62105356800100L) + "'", long8 == (-62105356800100L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62105356800100L) + "'", long10 == (-62105356800100L));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 101 + "'", int19 == 101);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "101" + "'", str24.equals("101"));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "--01-01" + "'", str37.equals("--01-01"));
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldArray52);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-2042700000L), 432000003L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1610699997L) + "'", long2 == (-1610699997L));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        long long58 = unsupportedDateTimeField55.add((long) 3, (int) (short) 10);
        org.joda.time.DurationField durationField59 = unsupportedDateTimeField55.getRangeDurationField();
        long long62 = unsupportedDateTimeField55.add(1560632441089L, (int) (short) 1);
        try {
            int int63 = unsupportedDateTimeField55.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 432000003L + "'", long58 == 432000003L);
        org.junit.Assert.assertNull(durationField59);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560675641089L + "'", long62 == 1560675641089L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(2019, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(1439);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1439) + "'", int1 == (-1439));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
        try {
            long long15 = offsetDateTimeField4.add((long) 19, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay((int) ' ');
        boolean boolean6 = dateTime3.isEqualNow();
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime3.toCalendar(locale7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(calendar8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.100", "era", (int) 'a', 21);
        long long6 = fixedDateTimeZone4.nextTransition((-2042700000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2042700000L) + "'", long6 == (-2042700000L));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
        int[] intArray14 = monthDay13.getValues();
        org.joda.time.MonthDay.Property property15 = monthDay13.dayOfMonth();
        java.lang.String str16 = property15.getAsText();
        java.util.Locale locale17 = null;
        int int18 = property15.getMaximumTextLength(locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property15.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance();
        int int21 = julianChronology20.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField22 = julianChronology20.weeks();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology25);
        org.joda.time.DurationField durationField27 = julianChronology25.years();
        org.joda.time.DurationField durationField28 = julianChronology25.weeks();
        org.joda.time.DateTimeField dateTimeField29 = julianChronology25.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology24, dateTimeField29);
        int int31 = skipUndoDateTimeField30.getMinimumValue();
        int int32 = skipUndoDateTimeField30.getMinimumValue();
        org.joda.time.DurationField durationField33 = skipUndoDateTimeField30.getDurationField();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField34 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType19, durationField22, durationField33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The effective range must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(durationField33);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 100);
        int int7 = offsetDateTimeField4.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "hi!");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getName(locale6, "2922789", "35");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        int int9 = dateTime6.getYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        java.lang.String str13 = property12.getAsString();
        org.joda.time.DateTime dateTime15 = property12.addToCopy(0);
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTime dateTime18 = property12.addWrapFieldToCopy((-1));
        java.util.Locale locale19 = null;
        int int20 = property12.getMaximumShortTextLength(locale19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "101" + "'", str13.equals("101"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("101");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.weeks();
        org.joda.time.DurationField durationField3 = julianChronology0.centuries();
        org.joda.time.Chronology chronology4 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        long long7 = delegatedDateTimeField5.roundHalfEven((long) 'a');
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField5, 0);
        try {
            long long17 = julianChronology0.getDateTimeMillis((int) 'a', 29, (-2013900000), (int) 'a', (int) 'a', (-1), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62105356800100L) + "'", long7 == (-62105356800100L));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
        org.joda.time.MonthDay monthDay15 = monthDay13.minusDays((int) (short) 10);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType17 = monthDay13.getFieldType((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(monthDay15);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '#');
        java.lang.String str8 = offsetDateTimeField6.getAsShortText((-31557600421999L));
        boolean boolean9 = offsetDateTimeField6.isLenient();
        long long11 = offsetDateTimeField6.roundHalfCeiling(432000003L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "36" + "'", str8.equals("36"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62105356800100L) + "'", long11 == (-62105356800100L));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime2.minus(readableDuration9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime2, dateTimeZone11);
        int int13 = dateTime12.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 101 + "'", int13 == 101);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear(2922789);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime8.toDateTime(dateTimeZone11);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((java.lang.Object) dateTime8, chronology13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay17 = monthDay14.withPeriodAdded(readablePeriod15, (int) (byte) 10);
        org.joda.time.MonthDay monthDay19 = monthDay14.minusMonths((int) (short) -1);
        int[] intArray20 = monthDay19.getValues();
        org.joda.time.MonthDay.Property property21 = monthDay19.dayOfMonth();
        java.lang.String str22 = property21.getAsText();
        java.util.Locale locale23 = null;
        int int24 = property21.getMaximumTextLength(locale23);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property21.getFieldType();
        boolean boolean26 = dateTime3.isSupported(dateTimeFieldType25);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType25, (-1439));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1" + "'", str22.equals("1"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.era();
        org.joda.time.DurationField durationField5 = julianChronology2.years();
        boolean boolean6 = copticChronology0.equals((java.lang.Object) julianChronology2);
        org.joda.time.DurationField durationField7 = copticChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime10.toDateTime(dateTimeZone13);
        boolean boolean15 = dateTime14.isEqualNow();
        int int16 = dateTime14.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime14.minus(readablePeriod17);
        int int19 = dateTime14.getSecondOfDay();
        org.joda.time.DateTime.Property property20 = dateTime14.millisOfSecond();
        boolean boolean21 = copticChronology0.equals((java.lang.Object) dateTime14);
        org.joda.time.DateMidnight dateMidnight22 = dateTime14.toDateMidnight();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[1]" + "'", str1.equals("CopticChronology[1]"));
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateMidnight22);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, (-62105328000000L));
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone3);
        boolean boolean8 = dateTimeZone3.isStandardOffset((long) (-1));
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62105328000000L) + "'", long5 == (-62105328000000L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime2.minus(readableDuration9);
        int int11 = dateTime10.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.append(dateTimeParser6);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatterBuilder16.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.append(dateTimeParser19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray23 = new org.joda.time.format.DateTimeParser[] { dateTimeParser10, dateTimeParser12, dateTimeParser19, dateTimeParser22 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder7.append(dateTimePrinter8, dateTimeParserArray23);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendDayOfMonth((-1439));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeParserArray23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        java.lang.String str13 = property12.getAsString();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone15);
        org.joda.time.DateTime dateTime18 = dateTime16.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateTime16.toDateTime(dateTimeZone19);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((java.lang.Object) dateTime16, chronology21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay25 = monthDay22.withPeriodAdded(readablePeriod23, (int) (byte) 10);
        java.lang.String str26 = monthDay22.toString();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone28);
        org.joda.time.DateTime dateTime31 = dateTime29.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.toDateTime(dateTimeZone32);
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay((java.lang.Object) dateTime29, chronology34);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.MonthDay monthDay38 = monthDay35.withPeriodAdded(readablePeriod36, (int) (byte) 10);
        boolean boolean39 = monthDay22.isEqual((org.joda.time.ReadablePartial) monthDay38);
        boolean boolean40 = property12.equals((java.lang.Object) monthDay38);
        int int41 = property12.getMinimumValue();
        try {
            org.joda.time.DateTime dateTime43 = property12.setCopy((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "101" + "'", str13.equals("101"));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "--01-01" + "'", str26.equals("--01-01"));
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundHalfEven((long) 'a');
        long long8 = delegatedDateTimeField4.roundFloor((long) 1);
        long long10 = delegatedDateTimeField4.roundHalfCeiling(0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology13.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology12, dateTimeField15);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.toDateTime(dateTimeZone22);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((java.lang.Object) dateTime19, chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (int) (byte) 10);
        org.joda.time.MonthDay monthDay30 = monthDay25.minusMonths((int) (short) -1);
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipDateTimeField16.getAsText((org.joda.time.ReadablePartial) monthDay25, (int) '#', locale32);
        org.joda.time.ReadablePartial readablePartial34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 1);
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay();
        int[] intArray46 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int47 = offsetDateTimeField39.getMaximumValue((org.joda.time.ReadablePartial) monthDay40, intArray46);
        int int48 = skipDateTimeField16.getMaximumValue(readablePartial34, intArray46);
        int int49 = delegatedDateTimeField4.getMaximumValue(readablePartial11, intArray46);
        boolean boolean50 = delegatedDateTimeField4.isSupported();
        org.joda.time.DateTimeField dateTimeField51 = delegatedDateTimeField4.getWrappedField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105356800100L) + "'", long6 == (-62105356800100L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62105356800100L) + "'", long8 == (-62105356800100L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62105356800100L) + "'", long10 == (-62105356800100L));
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "35" + "'", str33.equals("35"));
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1439 + "'", int48 == 1439);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(dateTimeField51);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((int) ' ');
        boolean boolean8 = dateTime5.isEqualNow();
        java.util.Locale locale9 = null;
        java.util.Calendar calendar10 = dateTime5.toCalendar(locale9);
        org.joda.time.LocalDateTime localDateTime11 = dateTime5.toLocalDateTime();
        boolean boolean12 = dateTimeZone1.isLocalDateTimeGap(localDateTime11);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfDay((int) ' ');
        boolean boolean20 = dateTime17.isEqualNow();
        java.util.Locale locale21 = null;
        java.util.Calendar calendar22 = dateTime17.toCalendar(locale21);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = iSOChronology25.getZone();
        org.joda.time.Chronology chronology27 = gJChronology23.withZone(dateTimeZone26);
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone26);
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology13, dateTimeZone26);
        org.joda.time.DurationField durationField30 = copticChronology13.weeks();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(calendar10);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(calendar22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime dateTime12 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime6.era();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
        boolean boolean8 = dateTime7.isEqualNow();
        int int9 = dateTime7.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.minus(readablePeriod10);
        int int12 = dateTime7.getSecondOfDay();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime7.getZone();
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone14.getShortName((long) 57600001, locale16);
        java.lang.String str18 = dateTimeZone14.toString();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 101 + "'", int9 == 101);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.100" + "'", str17.equals("+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, (int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTime();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        long long2 = dateTimeFormatter0.parseMillis("2");
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104060800000L) + "'", long2 == (-62104060800000L));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        java.lang.String str13 = property12.getAsString();
        org.joda.time.DateTime dateTime15 = property12.addToCopy(0);
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTime dateTime18 = property12.addWrapFieldToCopy((-1));
        int int19 = dateTime18.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "101" + "'", str13.equals("101"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundHalfEven((long) 'a');
        long long8 = delegatedDateTimeField4.roundFloor((long) 1);
        long long10 = delegatedDateTimeField4.roundHalfCeiling(0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology13.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology12, dateTimeField15);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.toDateTime(dateTimeZone22);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((java.lang.Object) dateTime19, chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (int) (byte) 10);
        org.joda.time.MonthDay monthDay30 = monthDay25.minusMonths((int) (short) -1);
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipDateTimeField16.getAsText((org.joda.time.ReadablePartial) monthDay25, (int) '#', locale32);
        org.joda.time.ReadablePartial readablePartial34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 1);
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay();
        int[] intArray46 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int47 = offsetDateTimeField39.getMaximumValue((org.joda.time.ReadablePartial) monthDay40, intArray46);
        int int48 = skipDateTimeField16.getMaximumValue(readablePartial34, intArray46);
        int int49 = delegatedDateTimeField4.getMaximumValue(readablePartial11, intArray46);
        org.joda.time.chrono.JulianChronology julianChronology50 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology50);
        org.joda.time.DateTimeField dateTimeField52 = julianChronology50.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52, dateTimeFieldType53);
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone56);
        org.joda.time.DateTime dateTime59 = dateTime57.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.DateTime dateTime61 = dateTime57.toDateTime(dateTimeZone60);
        org.joda.time.Chronology chronology62 = null;
        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay((java.lang.Object) dateTime57, chronology62);
        org.joda.time.Chronology chronology64 = monthDay63.getChronology();
        java.util.Locale locale66 = null;
        java.lang.String str67 = delegatedDateTimeField54.getAsShortText((org.joda.time.ReadablePartial) monthDay63, 0, locale66);
        int[] intArray75 = new int[] { 1439, (short) 1, (short) -1, (short) 0, 10, (-2013900000) };
        try {
            int[] intArray77 = delegatedDateTimeField4.add((org.joda.time.ReadablePartial) monthDay63, (int) '4', intArray75, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105356800100L) + "'", long6 == (-62105356800100L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62105356800100L) + "'", long8 == (-62105356800100L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62105356800100L) + "'", long10 == (-62105356800100L));
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "35" + "'", str33.equals("35"));
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1439 + "'", int48 == 1439);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(julianChronology50);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(chronology64);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "BC" + "'", str67.equals("BC"));
        org.junit.Assert.assertNotNull(intArray75);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DurationField durationField4 = julianChronology2.years();
        org.joda.time.DurationField durationField5 = julianChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology2.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField6);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        int int10 = julianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology9.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology8, dateTimeField11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology8);
        boolean boolean15 = dateTime13.isAfter(0L);
        org.joda.time.YearMonthDay yearMonthDay16 = dateTime13.toYearMonthDay();
        int int17 = skipUndoDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay16);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(yearMonthDay16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1439 + "'", int17 == 1439);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
        org.joda.time.MonthDay monthDay18 = monthDay13.minusMonths((int) (short) -1);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) '#', locale20);
        int int22 = skipDateTimeField4.getMinimumValue();
        long long24 = skipDateTimeField4.roundHalfEven((-1L));
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField4.getAsShortText(57600001, locale26);
        long long29 = skipDateTimeField4.roundCeiling((long) 1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "35" + "'", str21.equals("35"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-100L) + "'", long24 == (-100L));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "57600001" + "'", str27.equals("57600001"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 59900L + "'", long29 == 59900L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.Chronology chronology14 = monthDay13.getChronology();
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay13, 0, locale16);
        java.lang.String str18 = delegatedDateTimeField4.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime(dateTimeZone24);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay((java.lang.Object) dateTime21, chronology26);
        java.util.Locale locale29 = null;
        java.lang.String str30 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay27, (int) (byte) 1, locale29);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "BC" + "'", str17.equals("BC"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[era]" + "'", str18.equals("DateTimeField[era]"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "AD" + "'", str30.equals("AD"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
        org.joda.time.MonthDay monthDay18 = monthDay13.minusMonths((int) (short) -1);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) '#', locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime24.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = dateTime24.toDateTime(dateTimeZone27);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((java.lang.Object) dateTime24, chronology29);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.MonthDay monthDay33 = monthDay30.withPeriodAdded(readablePeriod31, (int) (byte) 10);
        org.joda.time.MonthDay monthDay35 = monthDay30.minusMonths((int) (short) -1);
        int[] intArray36 = monthDay35.getValues();
        org.joda.time.MonthDay.Property property37 = monthDay35.dayOfMonth();
        java.util.Locale locale39 = null;
        org.joda.time.MonthDay monthDay40 = property37.setCopy("2", locale39);
        java.util.Locale locale41 = null;
        java.lang.String str42 = property37.getAsText(locale41);
        org.joda.time.MonthDay monthDay44 = property37.setCopy(10);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.MonthDay monthDay46 = monthDay44.minus(readablePeriod45);
        org.joda.time.MonthDay monthDay48 = monthDay46.plusMonths(10);
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.DateTime dateTime56 = dateTime52.toDateTime(dateTimeZone55);
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.MonthDay monthDay58 = new org.joda.time.MonthDay((java.lang.Object) dateTime52, chronology57);
        org.joda.time.ReadablePeriod readablePeriod59 = null;
        org.joda.time.MonthDay monthDay61 = monthDay58.withPeriodAdded(readablePeriod59, (int) (byte) 10);
        org.joda.time.MonthDay monthDay63 = monthDay58.minusMonths((int) (short) -1);
        int[] intArray64 = monthDay63.getValues();
        java.util.Locale locale66 = null;
        try {
            int[] intArray67 = skipDateTimeField4.set((org.joda.time.ReadablePartial) monthDay48, (int) (byte) 10, intArray64, "2922789", locale66);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "35" + "'", str21.equals("35"));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1" + "'", str42.equals("1"));
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(monthDay61);
        org.junit.Assert.assertNotNull(monthDay63);
        org.junit.Assert.assertNotNull(intArray64);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
        boolean boolean8 = dateTime7.isEqualNow();
        int int9 = dateTime7.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.minus(readablePeriod10);
        int int12 = dateTime7.getSecondOfDay();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime7.getZone();
        org.joda.time.DateTime dateTime15 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.toDateTime(dateTimeZone21);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((java.lang.Object) dateTime18, chronology23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.MonthDay monthDay27 = monthDay24.withPeriodAdded(readablePeriod25, (int) (byte) 10);
        org.joda.time.MonthDay monthDay29 = monthDay24.minusMonths((int) (short) -1);
        int[] intArray30 = monthDay29.getValues();
        org.joda.time.MonthDay.Property property31 = monthDay29.dayOfMonth();
        java.lang.String str32 = property31.getAsText();
        java.util.Locale locale33 = null;
        int int34 = property31.getMaximumTextLength(locale33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property31.getFieldType();
        try {
            org.joda.time.DateTime dateTime37 = dateTime7.withField(dateTimeFieldType35, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 101 + "'", int9 == 101);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1" + "'", str32.equals("1"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2 + "'", int34 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 100, dateTimeZone6);
        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime7.getZone();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology10);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology10.secondOfDay();
        org.joda.time.DateTime dateTime13 = dateTime7.withChronology((org.joda.time.Chronology) julianChronology10);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((int) (short) 10, 19, 2, 99, (-28800000), (org.joda.time.Chronology) julianChronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, (int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DurationField durationField4 = julianChronology2.years();
        org.joda.time.DurationField durationField5 = julianChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology2.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField6);
        long long10 = skipUndoDateTimeField7.set((long) (short) 0, (int) (byte) 1);
        try {
            long long13 = skipUndoDateTimeField7.set(62135568000035L, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 60000L + "'", long10 == 60000L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        java.lang.String str13 = property12.getAsString();
        org.joda.time.DateTime dateTime15 = property12.addToCopy(0);
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTime dateTime18 = property12.addWrapFieldToCopy((-1));
        boolean boolean19 = property12.isLeap();
        org.joda.time.DateTime dateTime21 = property12.addToCopy((int) ' ');
        java.util.Locale locale22 = null;
        int int23 = property12.getMaximumShortTextLength(locale22);
        org.joda.time.DateTime dateTime24 = property12.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime25 = property12.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "101" + "'", str13.equals("101"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(69, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 690 + "'", int2 == 690);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DurationField durationField21 = property12.getRangeDurationField();
        int int22 = property12.get();
        java.lang.String str23 = property12.getAsString();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 101 + "'", int22 == 101);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "101" + "'", str23.equals("101"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField3 = julianChronology1.years();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.yearOfEra();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone15);
        org.joda.time.DateTime dateTime18 = dateTime16.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateTime16.toDateTime(dateTimeZone19);
        boolean boolean21 = dateTime20.isEqualNow();
        int int22 = dateTime20.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.minus(readablePeriod23);
        int int25 = dateTime20.getSecondOfDay();
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, (org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime20.getZone();
        boolean boolean28 = gJChronology10.equals((java.lang.Object) dateTime20);
        org.joda.time.LocalDate localDate29 = dateTime20.toLocalDate();
        org.joda.time.DateTime dateTime31 = dateTime20.plusSeconds((-2));
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 101 + "'", int22 == 101);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
        int[] intArray14 = monthDay13.getValues();
        org.joda.time.MonthDay.Property property15 = monthDay13.dayOfMonth();
        java.lang.String str16 = property15.getAsText();
        java.util.Locale locale17 = null;
        int int18 = property15.getMaximumTextLength(locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property15.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField21 = buddhistChronology20.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField21);
        java.lang.String str23 = unsupportedDateTimeField22.toString();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone25);
        org.joda.time.DateTime dateTime28 = dateTime26.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime26.toDateTime(dateTimeZone29);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay((java.lang.Object) dateTime26, chronology31);
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.MonthDay monthDay35 = monthDay32.withPeriodAdded(readablePeriod33, (int) (byte) 10);
        org.joda.time.MonthDay monthDay37 = monthDay32.minusMonths((int) (short) -1);
        int[] intArray38 = monthDay37.getValues();
        org.joda.time.MonthDay.Property property39 = monthDay37.dayOfMonth();
        java.util.Locale locale41 = null;
        org.joda.time.MonthDay monthDay42 = property39.setCopy("2", locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property39.getAsText(locale43);
        org.joda.time.MonthDay monthDay46 = property39.setCopy(10);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.MonthDay monthDay48 = monthDay46.minus(readablePeriod47);
        try {
            int int49 = unsupportedDateTimeField22.getMaximumValue((org.joda.time.ReadablePartial) monthDay46);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UnsupportedDateTimeField" + "'", str23.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1" + "'", str44.equals("1"));
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(monthDay48);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 100);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getDurationField();
        long long9 = offsetDateTimeField4.roundHalfEven((-31557600421999L));
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = dateTime12.toDateTime(dateTimeZone15);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((java.lang.Object) dateTime12, chronology17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, (int) (byte) 10);
        org.joda.time.MonthDay monthDay23 = monthDay18.minusMonths((int) (short) -1);
        int[] intArray24 = monthDay23.getValues();
        org.joda.time.MonthDay.Property property25 = monthDay23.dayOfMonth();
        java.util.Locale locale27 = null;
        org.joda.time.MonthDay monthDay28 = property25.setCopy("2", locale27);
        java.util.Locale locale29 = null;
        java.lang.String str30 = property25.getAsText(locale29);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone32);
        org.joda.time.DateTime dateTime35 = dateTime33.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = dateTime33.toDateTime(dateTimeZone36);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((java.lang.Object) dateTime33, chronology38);
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.MonthDay monthDay42 = monthDay39.withPeriodAdded(readablePeriod40, (int) (byte) 10);
        java.lang.String str43 = monthDay39.toString();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone45);
        org.joda.time.DateTime dateTime48 = dateTime46.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.DateTime dateTime50 = dateTime46.toDateTime(dateTimeZone49);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.MonthDay monthDay52 = new org.joda.time.MonthDay((java.lang.Object) dateTime46, chronology51);
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        org.joda.time.MonthDay monthDay55 = monthDay52.withPeriodAdded(readablePeriod53, (int) (byte) 10);
        boolean boolean56 = monthDay39.isEqual((org.joda.time.ReadablePartial) monthDay55);
        int int57 = property25.compareTo((org.joda.time.ReadablePartial) monthDay39);
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology59 = org.joda.time.chrono.JulianChronology.getInstance();
        int int60 = julianChronology59.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField61 = julianChronology59.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField62 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology58, dateTimeField61);
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone64);
        org.joda.time.DateTime dateTime67 = dateTime65.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.DateTime dateTime69 = dateTime65.toDateTime(dateTimeZone68);
        org.joda.time.Chronology chronology70 = null;
        org.joda.time.MonthDay monthDay71 = new org.joda.time.MonthDay((java.lang.Object) dateTime65, chronology70);
        org.joda.time.ReadablePeriod readablePeriod72 = null;
        org.joda.time.MonthDay monthDay74 = monthDay71.withPeriodAdded(readablePeriod72, (int) (byte) 10);
        org.joda.time.MonthDay monthDay76 = monthDay71.minusMonths((int) (short) -1);
        java.util.Locale locale78 = null;
        java.lang.String str79 = skipDateTimeField62.getAsText((org.joda.time.ReadablePartial) monthDay71, (int) '#', locale78);
        org.joda.time.ReadablePartial readablePartial80 = null;
        org.joda.time.DateTimeZone dateTimeZone81 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology82 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone81);
        org.joda.time.DateTimeField dateTimeField83 = gregorianChronology82.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField85 = new org.joda.time.field.OffsetDateTimeField(dateTimeField83, (int) (byte) 1);
        org.joda.time.MonthDay monthDay86 = new org.joda.time.MonthDay();
        int[] intArray92 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int93 = offsetDateTimeField85.getMaximumValue((org.joda.time.ReadablePartial) monthDay86, intArray92);
        int int94 = skipDateTimeField62.getMaximumValue(readablePartial80, intArray92);
        int int95 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay39, intArray92);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775707L + "'", long9 == 9223372036854775707L);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1" + "'", str30.equals("1"));
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "--01-01" + "'", str43.equals("--01-01"));
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertNotNull(julianChronology59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 4 + "'", int60 == 4);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(monthDay74);
        org.junit.Assert.assertNotNull(monthDay76);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "35" + "'", str79.equals("35"));
        org.junit.Assert.assertNotNull(gregorianChronology82);
        org.junit.Assert.assertNotNull(dateTimeField83);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 2 + "'", int93 == 2);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1439 + "'", int94 == 1439);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1 + "'", int95 == 1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((java.lang.Object) dateTime15, chronology20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.MonthDay monthDay24 = monthDay21.withPeriodAdded(readablePeriod22, (int) (byte) 10);
        org.joda.time.MonthDay monthDay26 = monthDay21.minusMonths((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) (byte) 1);
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay();
        int[] intArray38 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int39 = offsetDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) monthDay32, intArray38);
        int int40 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay21, intArray38);
        org.joda.time.DurationField durationField41 = offsetDateTimeField4.getLeapDurationField();
        boolean boolean42 = offsetDateTimeField4.isLenient();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter43.withOffsetParsed();
        java.lang.Integer int45 = dateTimeFormatter43.getPivotYear();
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone47 = iSOChronology46.getZone();
        java.lang.String str48 = dateTimeZone47.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatter43.withZone(dateTimeZone47);
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.DateTime dateTime56 = dateTime52.toDateTime(dateTimeZone55);
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.MonthDay monthDay58 = new org.joda.time.MonthDay((java.lang.Object) dateTime52, chronology57);
        org.joda.time.ReadablePeriod readablePeriod59 = null;
        org.joda.time.MonthDay monthDay61 = monthDay58.withPeriodAdded(readablePeriod59, (int) (byte) 10);
        java.lang.String str62 = dateTimeFormatter43.print((org.joda.time.ReadablePartial) monthDay58);
        java.util.Locale locale64 = null;
        java.lang.String str65 = offsetDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay58, 57600001, locale64);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNull(durationField41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNull(int45);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(monthDay61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1/1/��" + "'", str62.equals("1/1/��"));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "57600001" + "'", str65.equals("57600001"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.DateTime dateTime1 = instant0.toDateTimeISO();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((int) ' ');
        boolean boolean8 = dateTime5.isEqualNow();
        java.util.Locale locale9 = null;
        java.util.Calendar calendar10 = dateTime5.toCalendar(locale9);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime5);
        boolean boolean12 = dateTime5.isEqualNow();
        org.joda.time.DateTime dateTime14 = dateTime5.plusDays((int) (short) 10);
        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime1, (java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(calendar10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay((int) ' ');
        boolean boolean6 = dateTime3.isEqualNow();
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime3.toCalendar(locale7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime3);
        boolean boolean10 = dateTime3.isEqualNow();
        org.joda.time.DateTime dateTime12 = dateTime3.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks(0);
        int int15 = dateTime12.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(calendar8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 70 + "'", int15 == 70);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        java.lang.String str13 = property12.getAsString();
        org.joda.time.DateTime dateTime15 = property12.addToCopy(0);
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTimeField dateTimeField17 = property12.getField();
        org.joda.time.DateTime dateTime18 = property12.getDateTime();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "101" + "'", str13.equals("101"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology7, dateTimeField10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology7);
        boolean boolean13 = iSOChronology6.equals((java.lang.Object) julianChronology7);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(690, 690, 0, (int) (byte) -1, (int) (short) -1, (org.joda.time.Chronology) julianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-62104060800000L), (java.lang.Number) (-1L), (java.lang.Number) (-2013900000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.weeks();
        org.joda.time.DurationField durationField3 = julianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.year();
        try {
            org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((java.lang.Object) dateTimeField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        long long58 = unsupportedDateTimeField55.add((long) 3, (int) (short) 10);
        org.joda.time.DurationField durationField59 = unsupportedDateTimeField55.getRangeDurationField();
        long long62 = unsupportedDateTimeField55.add(0L, (long) (-28800000));
        try {
            long long64 = unsupportedDateTimeField55.roundCeiling((long) 21);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 432000003L + "'", long58 == 432000003L);
        org.junit.Assert.assertNull(durationField59);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-1244160000000000L) + "'", long62 == (-1244160000000000L));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        long long58 = unsupportedDateTimeField55.add((long) 3, (int) (short) 10);
        org.joda.time.DurationField durationField59 = unsupportedDateTimeField55.getRangeDurationField();
        long long62 = unsupportedDateTimeField55.add(0L, (long) (-28800000));
        try {
            long long64 = unsupportedDateTimeField55.roundCeiling((long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 432000003L + "'", long58 == 432000003L);
        org.junit.Assert.assertNull(durationField59);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-1244160000000000L) + "'", long62 == (-1244160000000000L));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.append(dateTimeParser6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendMillisOfSecond(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMonthOfYear(1439);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap13 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendTimeZoneName(strMap13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.years();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) ' ');
        boolean boolean8 = dateTime6.isBefore((long) (byte) -1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((java.lang.Object) dateTime15, chronology20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.MonthDay monthDay24 = monthDay21.withPeriodAdded(readablePeriod22, (int) (byte) 10);
        org.joda.time.MonthDay monthDay26 = monthDay21.minusMonths((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) (byte) 1);
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay();
        int[] intArray38 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int39 = offsetDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) monthDay32, intArray38);
        int int40 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay21, intArray38);
        org.joda.time.DurationField durationField41 = offsetDateTimeField4.getLeapDurationField();
        boolean boolean42 = offsetDateTimeField4.isLenient();
        long long44 = offsetDateTimeField4.roundHalfEven(0L);
        try {
            long long47 = offsetDateTimeField4.add((long) 690, (-57482400L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNull(durationField41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-62135596800100L) + "'", long44 == (-62135596800100L));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.Chronology chronology14 = monthDay13.getChronology();
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay13, 0, locale16);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime20.withYear(2922789);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((java.lang.Object) dateTime25, chronology30);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.MonthDay monthDay34 = monthDay31.withPeriodAdded(readablePeriod32, (int) (byte) 10);
        org.joda.time.MonthDay monthDay36 = monthDay31.minusMonths((int) (short) -1);
        int[] intArray37 = monthDay36.getValues();
        org.joda.time.MonthDay.Property property38 = monthDay36.dayOfMonth();
        java.lang.String str39 = property38.getAsText();
        java.util.Locale locale40 = null;
        int int41 = property38.getMaximumTextLength(locale40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property38.getFieldType();
        boolean boolean43 = dateTime20.isSupported(dateTimeFieldType42);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType42, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "BC" + "'", str17.equals("BC"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1" + "'", str39.equals("1"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
        try {
            org.joda.time.DateTime dateTime5 = dateTime2.withEra(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        java.lang.String str56 = unsupportedDateTimeField55.getName();
        java.lang.String str57 = unsupportedDateTimeField55.toString();
        try {
            long long59 = unsupportedDateTimeField55.remainder((long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "centuryOfEra" + "'", str56.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "UnsupportedDateTimeField" + "'", str57.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.secondOfMinute();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560632478463L + "'", long0 == 1560632478463L);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
        int[] intArray14 = monthDay13.getValues();
        org.joda.time.MonthDay.Property property15 = monthDay13.dayOfMonth();
        java.lang.String str16 = property15.getAsText();
        java.util.Locale locale17 = null;
        int int18 = property15.getMaximumTextLength(locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property15.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField21 = buddhistChronology20.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField21);
        try {
            int int24 = unsupportedDateTimeField22.getMaximumValue((long) 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        long long6 = offsetDateTimeField4.remainder((long) '#');
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 62135596800135L + "'", long6 == 62135596800135L);
        org.junit.Assert.assertNull(durationField7);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.years();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.withPeriodAdded(readablePeriod6, 57600001);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((int) ' ');
        boolean boolean8 = dateTime5.isEqualNow();
        java.util.Locale locale9 = null;
        java.util.Calendar calendar10 = dateTime5.toCalendar(locale9);
        org.joda.time.LocalDateTime localDateTime11 = dateTime5.toLocalDateTime();
        boolean boolean12 = dateTimeZone1.isLocalDateTimeGap(localDateTime11);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField14 = copticChronology13.weeks();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField16 = new org.joda.time.field.DecoratedDurationField(durationField14, durationFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(calendar10);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendYearOfEra((int) (short) 10, (int) (short) 0);
        boolean boolean7 = dateTimeFormatterBuilder6.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.years();
        org.joda.time.DurationField durationField3 = julianChronology0.weeks();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology4, dateTimeField7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime11.toDateTime(dateTimeZone14);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((java.lang.Object) dateTime11, chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay20 = monthDay17.withPeriodAdded(readablePeriod18, (int) (byte) 10);
        org.joda.time.MonthDay monthDay22 = monthDay17.minusMonths((int) (short) -1);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipDateTimeField8.getAsText((org.joda.time.ReadablePartial) monthDay17, (int) '#', locale24);
        boolean boolean26 = julianChronology0.equals((java.lang.Object) monthDay17);
        org.joda.time.DurationField durationField27 = julianChronology0.minutes();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "35" + "'", str25.equals("35"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(durationField27);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
        boolean boolean8 = dateTime7.isEqualNow();
        int int9 = dateTime7.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.minus(readablePeriod10);
        int int12 = dateTime7.getSecondOfDay();
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone15);
        org.joda.time.DateTime dateTime18 = dateTime16.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateTime16.toDateTime(dateTimeZone19);
        int int21 = property13.compareTo((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime23 = dateTime16.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone25);
        org.joda.time.DateTime dateTime28 = dateTime26.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime26.toDateTime(dateTimeZone29);
        boolean boolean31 = dateTime30.isEqualNow();
        int int32 = dateTime30.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.DateTime dateTime34 = dateTime30.minus(readablePeriod33);
        int int35 = dateTime30.getSecondOfDay();
        org.joda.time.DateTime dateTime37 = dateTime30.minusYears(4);
        org.joda.time.DateTime.Property property38 = dateTime30.centuryOfEra();
        int int39 = property38.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
        int int41 = dateTime16.get(dateTimeFieldType40);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology44 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology43);
        org.joda.time.DurationField durationField45 = julianChronology43.years();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology43);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.DateTime dateTime49 = dateTime46.withPeriodAdded(readablePeriod47, (int) ' ');
        org.joda.time.DateTime dateTime51 = dateTime46.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone42, (org.joda.time.ReadableInstant) dateTime46);
        org.joda.time.DateTimeField dateTimeField53 = gJChronology52.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField54 = gJChronology52.yearOfEra();
        org.joda.time.DurationField durationField55 = gJChronology52.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField56 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType40, durationField55);
        long long59 = unsupportedDateTimeField56.add((long) 3, (int) (short) 10);
        org.joda.time.DurationField durationField60 = unsupportedDateTimeField56.getRangeDurationField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField61 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) unsupportedDateTimeField56);
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField62 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField61);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 101 + "'", int9 == 101);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 101 + "'", int32 == 101);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2922789 + "'", int39 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 19 + "'", int41 == 19);
        org.junit.Assert.assertNotNull(julianChronology43);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(gJChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField56);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 432000003L + "'", long59 == 432000003L);
        org.junit.Assert.assertNull(durationField60);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay(2, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYear((int) '4', 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (byte) 1, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendWeekyear((int) (byte) 100, 57600001);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendYearOfEra((int) 'a', (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "hi!");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getShortName(locale6, "35", "1969-01-01T00:00:00.101+00:00:00.100");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay((int) ' ');
        boolean boolean6 = dateTime3.isEqualNow();
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime3.toCalendar(locale7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology11.getZone();
        org.joda.time.Chronology chronology13 = gJChronology9.withZone(dateTimeZone12);
        java.lang.String str15 = dateTimeZone12.getName((long) (-2));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(calendar8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.100" + "'", str15.equals("+00:00:00.100"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
        org.joda.time.MonthDay monthDay18 = monthDay13.minusMonths((int) (short) -1);
        int[] intArray19 = monthDay18.getValues();
        org.joda.time.MonthDay.Property property20 = monthDay18.dayOfMonth();
        java.util.Locale locale22 = null;
        org.joda.time.MonthDay monthDay23 = property20.setCopy("2", locale22);
        java.lang.String str24 = property20.getAsText();
        int int25 = property20.getMaximumValueOverall();
        int int26 = property20.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType27, 99, (int) (byte) 0, (int) '#');
        long long33 = delegatedDateTimeField4.roundCeiling((-62135596800100L));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 29 + "'", int26 == 29);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775707L + "'", long33 == 9223372036854775707L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, (-62105328000000L));
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62105328000000L) + "'", long5 == (-62105328000000L));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        java.lang.String str13 = property12.getAsString();
        org.joda.time.DateTime dateTime15 = property12.addToCopy(0);
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DurationFieldType durationFieldType17 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField19 = new org.joda.time.field.ScaledDurationField(durationField16, durationFieldType17, (-1439));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "101" + "'", str13.equals("101"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendSecondOfMinute(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendTwoDigitYear(31, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendClockhourOfDay(97);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10, dateTimeFieldType11);
        long long14 = delegatedDateTimeField12.roundHalfEven((long) 'a');
        long long16 = delegatedDateTimeField12.roundFloor((long) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.toDateTime(dateTimeZone22);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((java.lang.Object) dateTime19, chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (int) (byte) 10);
        org.joda.time.MonthDay monthDay30 = monthDay25.minusMonths((int) (short) -1);
        int[] intArray31 = monthDay30.getValues();
        org.joda.time.MonthDay.Property property32 = monthDay30.dayOfMonth();
        java.util.Locale locale34 = null;
        org.joda.time.MonthDay monthDay35 = property32.setCopy("2", locale34);
        java.lang.String str36 = property32.getAsText();
        int int37 = property32.getMaximumValueOverall();
        int int38 = property32.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property32.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField12, dateTimeFieldType39, 31, 0, 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder2.appendSignedDecimal(dateTimeFieldType39, (-1), 101);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62105356800100L) + "'", long14 == (-62105356800100L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62105356800100L) + "'", long16 == (-62105356800100L));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1" + "'", str36.equals("1"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 29 + "'", int38 == 29);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = dateTime12.toDateTime(dateTimeZone15);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((java.lang.Object) dateTime12, chronology17);
        org.joda.time.Chronology chronology19 = monthDay18.getChronology();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) monthDay18, 0, locale21);
        java.lang.String str23 = delegatedDateTimeField9.toString();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone25);
        org.joda.time.DateTime dateTime28 = dateTime26.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime26.toDateTime(dateTimeZone29);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay((java.lang.Object) dateTime26, chronology31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = delegatedDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) monthDay32, (int) (byte) 1, locale34);
        int[] intArray39 = new int[] { 57600, (short) 0 };
        int[] intArray41 = skipDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) monthDay32, 0, intArray39, 57600001);
        java.lang.String str42 = skipDateTimeField4.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "BC" + "'", str22.equals("BC"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "DateTimeField[era]" + "'", str23.equals("DateTimeField[era]"));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "AD" + "'", str35.equals("AD"));
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "DateTimeField[minuteOfDay]" + "'", str42.equals("DateTimeField[minuteOfDay]"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970W014T000000.101+0000" + "'", str2.equals("1970W014T000000.101+0000"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("1");
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter1.printTo(appendable2, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.Chronology chronology14 = monthDay13.getChronology();
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay13, 0, locale16);
        java.lang.String str18 = delegatedDateTimeField4.toString();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology19);
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone25);
        org.joda.time.DateTime dateTime28 = dateTime26.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime26.toDateTime(dateTimeZone29);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay((java.lang.Object) dateTime26, chronology31);
        org.joda.time.Chronology chronology33 = monthDay32.getChronology();
        java.util.Locale locale35 = null;
        java.lang.String str36 = delegatedDateTimeField23.getAsShortText((org.joda.time.ReadablePartial) monthDay32, 0, locale35);
        java.util.Locale locale38 = null;
        java.lang.String str39 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay32, 0, locale38);
        long long41 = delegatedDateTimeField4.roundCeiling((long) (short) 10);
        try {
            long long44 = delegatedDateTimeField4.getDifferenceAsLong((long) 57600001, 1969L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "BC" + "'", str17.equals("BC"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[era]" + "'", str18.equals("DateTimeField[era]"));
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "BC" + "'", str36.equals("BC"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "BC" + "'", str39.equals("BC"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775707L + "'", long41 == 9223372036854775707L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("UnsupportedDateTimeField");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UnsupportedDateTimeField\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField3 = julianChronology1.years();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.yearOfEra();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone15);
        org.joda.time.DateTime dateTime18 = dateTime16.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateTime16.toDateTime(dateTimeZone19);
        boolean boolean21 = dateTime20.isEqualNow();
        int int22 = dateTime20.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.minus(readablePeriod23);
        int int25 = dateTime20.getSecondOfDay();
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, (org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime20.getZone();
        boolean boolean28 = gJChronology10.equals((java.lang.Object) dateTime20);
        org.joda.time.LocalDate localDate29 = dateTime20.toLocalDate();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) 100, dateTimeZone31);
        java.util.Date date33 = dateTime32.toDate();
        org.joda.time.MonthDay monthDay34 = org.joda.time.MonthDay.fromDateFields(date33);
        try {
            boolean boolean35 = localDate29.isEqual((org.joda.time.ReadablePartial) monthDay34);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 101 + "'", int22 == 101);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(monthDay34);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) ' ', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitYear(1969, true);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = iSOChronology10.getZone();
        java.lang.String str12 = dateTimeZone11.toString();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        boolean boolean18 = dateTime15.isEqualNow();
        java.util.Locale locale19 = null;
        java.util.Calendar calendar20 = dateTime15.toCalendar(locale19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime15.toLocalDateTime();
        boolean boolean22 = dateTimeZone11.isLocalDateTimeGap(localDateTime21);
        try {
            org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) 1969, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(calendar20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
        org.joda.time.MonthDay monthDay18 = monthDay13.minusMonths((int) (short) -1);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) '#', locale20);
        int int22 = skipDateTimeField4.getMinimumValue();
        long long24 = skipDateTimeField4.roundHalfEven((-1L));
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField4.getAsShortText(57600001, locale26);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withYear(2922789);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = dateTime35.toDateTime(dateTimeZone38);
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay((java.lang.Object) dateTime35, chronology40);
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.MonthDay monthDay44 = monthDay41.withPeriodAdded(readablePeriod42, (int) (byte) 10);
        org.joda.time.MonthDay monthDay46 = monthDay41.minusMonths((int) (short) -1);
        int[] intArray47 = monthDay46.getValues();
        org.joda.time.MonthDay.Property property48 = monthDay46.dayOfMonth();
        java.lang.String str49 = property48.getAsText();
        java.util.Locale locale50 = null;
        int int51 = property48.getMaximumTextLength(locale50);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property48.getFieldType();
        boolean boolean53 = dateTime30.isSupported(dateTimeFieldType52);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType52);
        long long56 = skipDateTimeField4.roundHalfEven((long) (-2013900000));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "35" + "'", str21.equals("35"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-100L) + "'", long24 == (-100L));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "57600001" + "'", str27.equals("57600001"));
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1" + "'", str49.equals("1"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-2013900100L) + "'", long56 == (-2013900100L));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 100);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = iSOChronology8.getZone();
        java.lang.String str10 = dateTimeZone9.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfDay((int) ' ');
        boolean boolean16 = dateTime13.isEqualNow();
        java.util.Locale locale17 = null;
        java.util.Calendar calendar18 = dateTime13.toCalendar(locale17);
        org.joda.time.LocalDateTime localDateTime19 = dateTime13.toLocalDateTime();
        boolean boolean20 = dateTimeZone9.isLocalDateTimeGap(localDateTime19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDateTime19, (int) (byte) 100, locale22);
        try {
            long long26 = offsetDateTimeField4.add(100L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(calendar18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        try {
            org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("35", dateTimeFormatter5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("4");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime2.minus(readableDuration9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime2, dateTimeZone11);
        try {
            org.joda.time.DateTime dateTime14 = dateTime2.withMonthOfYear(70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(69);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DurationField durationField21 = property12.getRangeDurationField();
        int int22 = property12.get();
        org.joda.time.DateTime dateTime23 = property12.roundHalfCeilingCopy();
        org.joda.time.DurationField durationField24 = property12.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 101 + "'", int22 == 101);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendYearOfEra((int) (short) 10, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(0, false);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime2.withYearOfEra(3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = julianChronology0.get(readablePeriod2, (-2013900100L), 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("����W���", 21, 29, 97, '#', (int) 'a', (int) '4', (int) (byte) 1, false, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        try {
            org.joda.time.MonthDay monthDay13 = monthDay11.withMonthOfYear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(monthDay11);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology4.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology6.getZone();
        long long9 = dateTimeZone5.getMillisKeepLocal(dateTimeZone7, (-62105328000000L));
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime11 = dateTime2.withZone(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.secondOfDay();
        try {
            long long18 = julianChronology12.getDateTimeMillis(97, 1970, 57600, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62105328000000L) + "'", long9 == (-62105328000000L));
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        java.lang.String str56 = unsupportedDateTimeField55.getName();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone58);
        org.joda.time.DateTime dateTime61 = dateTime59.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.DateTime dateTime63 = dateTime59.toDateTime(dateTimeZone62);
        org.joda.time.Chronology chronology64 = null;
        org.joda.time.MonthDay monthDay65 = new org.joda.time.MonthDay((java.lang.Object) dateTime59, chronology64);
        org.joda.time.ReadablePeriod readablePeriod66 = null;
        org.joda.time.MonthDay monthDay68 = monthDay65.withPeriodAdded(readablePeriod66, (int) (byte) 10);
        org.joda.time.MonthDay monthDay70 = monthDay65.minusMonths((int) (short) -1);
        int[] intArray71 = monthDay70.getValues();
        org.joda.time.MonthDay.Property property72 = monthDay70.dayOfMonth();
        java.lang.String str73 = property72.getAsText();
        java.util.Locale locale74 = null;
        int int75 = property72.getMaximumTextLength(locale74);
        org.joda.time.DateTimeFieldType dateTimeFieldType76 = property72.getFieldType();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) unsupportedDateTimeField55, dateTimeFieldType76, 31, 1970, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "centuryOfEra" + "'", str56.equals("centuryOfEra"));
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(monthDay68);
        org.junit.Assert.assertNotNull(monthDay70);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(property72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "1" + "'", str73.equals("1"));
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2 + "'", int75 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType76);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        java.lang.String str56 = unsupportedDateTimeField55.getName();
        java.lang.String str57 = unsupportedDateTimeField55.toString();
        java.util.Locale locale59 = null;
        try {
            java.lang.String str60 = unsupportedDateTimeField55.getAsShortText(86400001L, locale59);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "centuryOfEra" + "'", str56.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "UnsupportedDateTimeField" + "'", str57.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        int int4 = dateTime3.getYearOfEra();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str6 = copticChronology5.toString();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology7);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.era();
        org.joda.time.DurationField durationField10 = julianChronology7.years();
        boolean boolean11 = copticChronology5.equals((java.lang.Object) julianChronology7);
        org.joda.time.DurationField durationField12 = copticChronology5.weeks();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        boolean boolean20 = dateTime19.isEqualNow();
        int int21 = dateTime19.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.minus(readablePeriod22);
        int int24 = dateTime19.getSecondOfDay();
        org.joda.time.DateTime.Property property25 = dateTime19.millisOfSecond();
        boolean boolean26 = copticChronology5.equals((java.lang.Object) dateTime19);
        boolean boolean27 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime19);
        int int28 = dateTime3.getDayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CopticChronology[1]" + "'", str6.equals("CopticChronology[1]"));
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 101 + "'", int21 == 101);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        java.lang.String str13 = property12.getAsString();
        org.joda.time.DateTime dateTime15 = property12.addToCopy(0);
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        try {
            org.joda.time.DateTime dateTime18 = property12.setCopy("6/15/19");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"6/15/19\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "101" + "'", str13.equals("101"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology4.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology6.getZone();
        long long9 = dateTimeZone5.getMillisKeepLocal(dateTimeZone7, (-62105328000000L));
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime11 = dateTime2.withZone(dateTimeZone7);
        long long13 = dateTimeZone7.convertUTCToLocal((long) (-2013900000));
        try {
            org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (long) (byte) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62105328000000L) + "'", long9 == (-62105328000000L));
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2013899900L) + "'", long13 == (-2013899900L));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
        org.joda.time.MonthDay monthDay18 = monthDay13.minusMonths((int) (short) -1);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay13, (int) '#', locale20);
        int int22 = skipDateTimeField4.getMinimumValue();
        boolean boolean24 = skipDateTimeField4.isLeap((long) 19);
        long long27 = skipDateTimeField4.set((long) 1978, (int) (short) 1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "35" + "'", str21.equals("35"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 61978L + "'", long27 == 61978L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        long long6 = offsetDateTimeField4.remainder((long) '#');
        int int7 = offsetDateTimeField4.getMaximumValue();
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField4.getAsText((-2), locale9);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 62135596800135L + "'", long6 == 62135596800135L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-2" + "'", str10.equals("-2"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime dateTime12 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime6.plusMonths((int) (short) 0);
        org.joda.time.DateTime.Property property15 = dateTime6.yearOfCentury();
        org.joda.time.DateTime dateTime16 = property15.roundCeilingCopy();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime16.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, (-62105328000000L));
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.secondOfMinute();
        org.joda.time.DurationField durationField9 = iSOChronology7.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62105328000000L) + "'", long5 == (-62105328000000L));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        try {
            java.lang.String str57 = unsupportedDateTimeField55.getAsShortText((long) 97);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        java.lang.String str13 = property12.getAsString();
        org.joda.time.DateTime dateTime15 = property12.addToCopy(0);
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekyear((int) ' ');
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "101" + "'", str13.equals("101"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        try {
            long long12 = julianChronology0.getDateTimeMillis(57600001, 0, 31, 21, (int) (short) 1, 57600001, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600001 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant3 = instant0.withDurationAdded((long) (short) 100, (int) (byte) 1);
        org.joda.time.Instant instant5 = instant0.withMillis((long) 57600);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant5.minus(readableDuration6);
        org.joda.time.DateTime dateTime8 = instant7.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 100, dateTimeZone3);
        long long5 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTime4.getZone();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology7);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime4.withChronology((org.joda.time.Chronology) julianChronology7);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
        java.lang.String str14 = offsetDateTimeField4.getAsShortText((long) 57600);
        long long16 = offsetDateTimeField4.roundHalfEven((long) '#');
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField4.getMaximumShortTextLength(locale17);
        int int19 = offsetDateTimeField4.getMinimumValue();
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField4.getAsShortText(4, locale21);
        try {
            long long25 = offsetDateTimeField4.getDifferenceAsLong((long) 690, (-31557600421999L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2" + "'", str14.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62135596800100L) + "'", long16 == (-62135596800100L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "4" + "'", str22.equals("4"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) ' ', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral("-07:52:58");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendMonthOfYear((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfHour(6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withMinuteOfHour(69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
        int[] intArray14 = monthDay13.getValues();
        org.joda.time.MonthDay.Property property15 = monthDay13.dayOfMonth();
        java.lang.String str16 = property15.getAsText();
        java.util.Locale locale17 = null;
        int int18 = property15.getMaximumTextLength(locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property15.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField21 = buddhistChronology20.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField21);
        java.lang.String str23 = unsupportedDateTimeField22.toString();
        try {
            long long25 = unsupportedDateTimeField22.roundCeiling((-62135568000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UnsupportedDateTimeField" + "'", str23.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, (-62105328000000L));
        int int7 = dateTimeZone1.getOffsetFromLocal((-1610699997L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62105328000000L) + "'", long5 == (-62105328000000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant3 = instant0.withDurationAdded((long) (short) 100, (int) (byte) 1);
        org.joda.time.Instant instant5 = instant0.withMillis((long) 57600);
        org.joda.time.MutableDateTime mutableDateTime6 = instant0.toMutableDateTimeISO();
        boolean boolean7 = mutableDateTime6.isEqualNow();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField3 = julianChronology1.years();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = dateTime14.toDateTime(dateTimeZone17);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((java.lang.Object) dateTime14, chronology19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay23 = monthDay20.withPeriodAdded(readablePeriod21, (int) (byte) 10);
        org.joda.time.MonthDay monthDay25 = monthDay20.minusMonths((int) (short) -1);
        int[] intArray26 = monthDay25.getValues();
        org.joda.time.MonthDay.Property property27 = monthDay25.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = dateTime30.toDateTime(dateTimeZone33);
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay((java.lang.Object) dateTime30, chronology35);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay39 = monthDay36.withPeriodAdded(readablePeriod37, (int) (byte) 10);
        org.joda.time.MonthDay monthDay41 = monthDay36.minusMonths((int) (short) -1);
        int[] intArray42 = monthDay41.getValues();
        org.joda.time.MonthDay.Property property43 = monthDay41.dayOfMonth();
        java.lang.String str44 = property43.getAsText();
        java.util.Locale locale45 = null;
        int int46 = property43.getMaximumTextLength(locale45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
        int int48 = monthDay25.get(dateTimeFieldType47);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType47, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1" + "'", str44.equals("1"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay(2, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYear((int) '4', 3);
        boolean boolean7 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendTwoDigitYear((-1), true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendHourOfHalfday(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L, dateTimeZone1);
        int int3 = dateTime2.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DurationField durationField4 = julianChronology2.years();
        org.joda.time.DurationField durationField5 = julianChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology2.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField6);
        long long10 = skipUndoDateTimeField7.set((long) (short) 0, (int) (byte) 1);
        java.util.Locale locale13 = null;
        try {
            long long14 = skipUndoDateTimeField7.set((long) 101, "1969-365T16:00:00.097-08:00", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-365T16:00:00.097-08:00\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 60000L + "'", long10 == 60000L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(10, (int) '#', (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DurationField durationField21 = property12.getRangeDurationField();
        org.joda.time.DurationField durationField22 = property12.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNull(durationField22);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime2.withHourOfDay(0);
        org.joda.time.DateTime.Property property7 = dateTime2.millisOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.DateTime dateTime1 = instant0.toDateTimeISO();
        org.joda.time.DateTime dateTime2 = instant0.toDateTime();
        org.joda.time.Instant instant4 = instant0.minus((-28799990L));
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
        org.joda.time.Instant instant4 = instant1.withDurationAdded((long) (short) 100, (int) (byte) 1);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) instant1);
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter0.getParser();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withLocale(locale7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeFormatter8.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/1/70" + "'", str5.equals("1/1/70"));
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNull(dateTimeZone9);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
        java.lang.String str14 = offsetDateTimeField4.getAsShortText((long) 57600);
        long long16 = offsetDateTimeField4.roundHalfEven((long) '#');
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField4.getAsShortText((long) 21, locale18);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2" + "'", str14.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62135596800100L) + "'", long16 == (-62135596800100L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2" + "'", str19.equals("2"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        java.lang.String str56 = unsupportedDateTimeField55.getName();
        java.util.Locale locale59 = null;
        try {
            long long60 = unsupportedDateTimeField55.set((long) 1, "57600001", locale59);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "centuryOfEra" + "'", str56.equals("centuryOfEra"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology7.getZone();
        java.lang.String str9 = dateTimeZone8.toString();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfDay((int) ' ');
        boolean boolean15 = dateTime12.isEqualNow();
        java.util.Locale locale16 = null;
        java.util.Calendar calendar17 = dateTime12.toCalendar(locale16);
        org.joda.time.LocalDateTime localDateTime18 = dateTime12.toLocalDateTime();
        boolean boolean19 = dateTimeZone8.isLocalDateTimeGap(localDateTime18);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(57600001, 0, (int) (short) 10, (int) (byte) 100, 2, 690, (int) (short) 10, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(calendar17);
        org.junit.Assert.assertNotNull(localDateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(copticChronology20);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText((long) (short) 1, locale6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = offsetDateTimeField4.getAsText(readablePartial8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime dateTime13 = dateTime6.minusYears(4);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, 3, (-1), 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfCentury((int) 'a', (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendDayOfMonth(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.DateTime dateTime9 = dateTime2.withLaterOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        java.lang.String str13 = property12.getAsString();
        org.joda.time.DateTime dateTime15 = property12.addToCopy(0);
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTime dateTime18 = property12.addWrapFieldToCopy((-1));
        boolean boolean19 = property12.isLeap();
        org.joda.time.DateTime dateTime21 = property12.addToCopy((int) ' ');
        java.util.Locale locale22 = null;
        int int23 = property12.getMaximumShortTextLength(locale22);
        org.joda.time.DateTime dateTime24 = property12.roundHalfFloorCopy();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = iSOChronology25.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone28 = iSOChronology27.getZone();
        long long30 = dateTimeZone26.getMillisKeepLocal(dateTimeZone28, (-62105328000000L));
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        try {
            org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((java.lang.Object) property12, (org.joda.time.Chronology) iSOChronology31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "101" + "'", str13.equals("101"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-62105328000000L) + "'", long30 == (-62105328000000L));
        org.junit.Assert.assertNotNull(iSOChronology31);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.io.Writer writer2 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.toDateTime(dateTimeZone8);
        boolean boolean10 = dateTime9.isEqualNow();
        int int11 = dateTime9.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.minus(readablePeriod12);
        int int14 = dateTime9.getSecondOfDay();
        org.joda.time.DateTime.Property property15 = dateTime9.millisOfSecond();
        java.lang.String str16 = property15.getAsString();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.toDateTime(dateTimeZone22);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((java.lang.Object) dateTime19, chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (int) (byte) 10);
        java.lang.String str29 = monthDay25.toString();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone31);
        org.joda.time.DateTime dateTime34 = dateTime32.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.DateTime dateTime36 = dateTime32.toDateTime(dateTimeZone35);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((java.lang.Object) dateTime32, chronology37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.MonthDay monthDay41 = monthDay38.withPeriodAdded(readablePeriod39, (int) (byte) 10);
        boolean boolean42 = monthDay25.isEqual((org.joda.time.ReadablePartial) monthDay41);
        boolean boolean43 = property15.equals((java.lang.Object) monthDay41);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.MonthDay monthDay45 = monthDay41.minus(readablePeriod44);
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) monthDay41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "101" + "'", str16.equals("101"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "--01-01" + "'", str29.equals("--01-01"));
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(monthDay45);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        java.lang.String str13 = property12.getAsString();
        org.joda.time.Interval interval14 = property12.toInterval();
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval14);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "101" + "'", str13.equals("101"));
        org.junit.Assert.assertNotNull(interval14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.era();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        boolean boolean7 = property5.equals((java.lang.Object) dateTimeFormatter6);
        int int8 = property5.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) 2922789);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "004842.889+0000" + "'", str2.equals("004842.889+0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField3 = julianChronology1.years();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.yearOfEra();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone15);
        org.joda.time.DateTime dateTime18 = dateTime16.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateTime16.toDateTime(dateTimeZone19);
        boolean boolean21 = dateTime20.isEqualNow();
        int int22 = dateTime20.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.minus(readablePeriod23);
        int int25 = dateTime20.getSecondOfDay();
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, (org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime20.getZone();
        boolean boolean28 = gJChronology10.equals((java.lang.Object) dateTime20);
        org.joda.time.LocalDate localDate29 = dateTime20.toLocalDate();
        try {
            org.joda.time.DateTime dateTime31 = dateTime20.withDayOfMonth((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 101 + "'", int22 == 101);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(localDate29);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((int) ' ');
        boolean boolean8 = dateTime5.isEqualNow();
        java.util.Locale locale9 = null;
        java.util.Calendar calendar10 = dateTime5.toCalendar(locale9);
        org.joda.time.LocalDateTime localDateTime11 = dateTime5.toLocalDateTime();
        boolean boolean12 = dateTimeZone1.isLocalDateTimeGap(localDateTime11);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfDay((int) ' ');
        boolean boolean20 = dateTime17.isEqualNow();
        java.util.Locale locale21 = null;
        java.util.Calendar calendar22 = dateTime17.toCalendar(locale21);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = iSOChronology25.getZone();
        org.joda.time.Chronology chronology27 = gJChronology23.withZone(dateTimeZone26);
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone26);
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology13, dateTimeZone26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        boolean boolean31 = zonedChronology29.equals((java.lang.Object) dateTimeFormatter30);
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str33 = copticChronology32.toString();
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology34);
        org.joda.time.DateTimeField dateTimeField36 = julianChronology34.era();
        org.joda.time.DurationField durationField37 = julianChronology34.years();
        boolean boolean38 = copticChronology32.equals((java.lang.Object) julianChronology34);
        org.joda.time.DurationField durationField39 = copticChronology32.weeks();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone41);
        org.joda.time.DateTime dateTime44 = dateTime42.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.DateTime dateTime46 = dateTime42.toDateTime(dateTimeZone45);
        boolean boolean47 = dateTime46.isEqualNow();
        int int48 = dateTime46.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.DateTime dateTime50 = dateTime46.minus(readablePeriod49);
        int int51 = dateTime46.getSecondOfDay();
        org.joda.time.DateTime.Property property52 = dateTime46.millisOfSecond();
        boolean boolean53 = copticChronology32.equals((java.lang.Object) dateTime46);
        boolean boolean54 = zonedChronology29.equals((java.lang.Object) copticChronology32);
        try {
            long long62 = zonedChronology29.getDateTimeMillis(6, 1978, 0, 1, (int) (short) -1, 31, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(calendar10);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(calendar22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CopticChronology[1]" + "'", str33.equals("CopticChronology[1]"));
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 101 + "'", int48 == 101);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
        int[] intArray14 = monthDay13.getValues();
        org.joda.time.MonthDay.Property property15 = monthDay13.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.toDateTime(dateTimeZone21);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((java.lang.Object) dateTime18, chronology23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.MonthDay monthDay27 = monthDay24.withPeriodAdded(readablePeriod25, (int) (byte) 10);
        org.joda.time.MonthDay monthDay29 = monthDay24.minusMonths((int) (short) -1);
        int[] intArray30 = monthDay29.getValues();
        org.joda.time.MonthDay.Property property31 = monthDay29.dayOfMonth();
        java.lang.String str32 = property31.getAsText();
        java.util.Locale locale33 = null;
        int int34 = property31.getMaximumTextLength(locale33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property31.getFieldType();
        int int36 = monthDay13.get(dateTimeFieldType35);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType35, (int) ' ', (int) (short) 1, 21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,21]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1" + "'", str32.equals("1"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2 + "'", int34 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        java.lang.String str56 = unsupportedDateTimeField55.getName();
        try {
            int int58 = unsupportedDateTimeField55.getMaximumValue((long) 99);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "centuryOfEra" + "'", str56.equals("centuryOfEra"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 57600001);
        boolean boolean3 = dateTimeFormatter2.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((long) 3, (org.joda.time.Chronology) copticChronology1);
        org.junit.Assert.assertNotNull(copticChronology1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.era();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        java.util.Locale locale6 = null;
        int int7 = property5.getMaximumTextLength(locale6);
        boolean boolean8 = property5.isLeap();
        org.joda.time.DateTime dateTime9 = property5.roundFloorCopy();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime dateTime12 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime6.plusMonths((int) (short) 0);
        try {
            org.joda.time.DateTime dateTime16 = dateTime6.withDayOfMonth((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField3 = julianChronology1.years();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4);
        int int11 = gJChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField12 = gJChronology10.minutes();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology15);
        org.joda.time.DurationField durationField17 = julianChronology15.years();
        org.joda.time.DurationField durationField18 = julianChronology15.weeks();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology15.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, dateTimeField19);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField19, 1970);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.100", "era", (int) 'a', 21);
        int int6 = fixedDateTimeZone4.getOffset(1560675641089L);
        java.lang.Object obj7 = null;
        boolean boolean8 = fixedDateTimeZone4.equals(obj7);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.weeks();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DurationField durationField4 = julianChronology2.years();
        org.joda.time.DurationField durationField5 = julianChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology2.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField6);
        int int8 = skipUndoDateTimeField7.getMinimumValue();
        int int9 = skipUndoDateTimeField7.getMinimumValue();
        long long12 = skipUndoDateTimeField7.getDifferenceAsLong((long) 31, (-62135568000000L));
        int int14 = skipUndoDateTimeField7.get((long) (short) 1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1035592800L + "'", long12 == 1035592800L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime13 = property12.roundHalfEvenCopy();
        java.util.Locale locale14 = null;
        int int15 = property12.getMaximumShortTextLength(locale14);
        org.joda.time.DateTime dateTime16 = property12.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.append(dateTimeParser6);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatterBuilder16.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.append(dateTimeParser19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray23 = new org.joda.time.format.DateTimeParser[] { dateTimeParser10, dateTimeParser12, dateTimeParser19, dateTimeParser22 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder7.append(dateTimePrinter8, dateTimeParserArray23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendYearOfCentury(100, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder24.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeParserArray23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.years();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime3.minusWeeks(2922789);
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekOfWeekyear(10);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        java.lang.String str56 = unsupportedDateTimeField55.getName();
        boolean boolean57 = unsupportedDateTimeField55.isSupported();
        try {
            int int59 = unsupportedDateTimeField55.get((long) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "centuryOfEra" + "'", str56.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone7);
        boolean boolean9 = dateTime8.isEqualNow();
        int int10 = dateTime8.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime8.minus(readablePeriod11);
        int int13 = dateTime8.getSecondOfDay();
        org.joda.time.DateTime.Property property14 = dateTime8.millisOfSecond();
        java.lang.String str15 = property14.getAsString();
        org.joda.time.DateTime dateTime17 = property14.addToCopy(0);
        boolean boolean18 = buddhistChronology1.equals((java.lang.Object) dateTime17);
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology1.yearOfEra();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 101 + "'", int10 == 101);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "101" + "'", str15.equals("101"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = dateTime12.toDateTime(dateTimeZone15);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((java.lang.Object) dateTime12, chronology17);
        org.joda.time.Chronology chronology19 = monthDay18.getChronology();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) monthDay18, 0, locale21);
        java.lang.String str23 = delegatedDateTimeField9.toString();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone25);
        org.joda.time.DateTime dateTime28 = dateTime26.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime26.toDateTime(dateTimeZone29);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay((java.lang.Object) dateTime26, chronology31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = delegatedDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) monthDay32, (int) (byte) 1, locale34);
        int[] intArray39 = new int[] { 57600, (short) 0 };
        int[] intArray41 = skipDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) monthDay32, 0, intArray39, 57600001);
        java.lang.String str43 = skipDateTimeField4.getAsText(0L);
        org.joda.time.DurationField durationField44 = skipDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "BC" + "'", str22.equals("BC"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "DateTimeField[era]" + "'", str23.equals("DateTimeField[era]"));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "AD" + "'", str35.equals("AD"));
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "0" + "'", str43.equals("0"));
        org.junit.Assert.assertNull(durationField44);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(69, (int) (short) 10, (int) '#', (int) ' ', 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Instant instant5 = instant2.withDurationAdded((long) (short) 100, (int) (byte) 1);
        java.lang.String str6 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) instant2);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter1.getParser();
        try {
            org.joda.time.Instant instant8 = org.joda.time.Instant.parse("BC", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1/1/70" + "'", str6.equals("1/1/70"));
        org.junit.Assert.assertNotNull(dateTimeParser7);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime13 = property12.roundHalfEvenCopy();
        org.joda.time.DurationField durationField14 = property12.getLeapDurationField();
        org.joda.time.DateTime dateTime16 = property12.addWrapFieldToCopy(2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.era();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        int int6 = dateTime4.getMinuteOfHour();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime(dateTimeZone12);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((java.lang.Object) dateTime9, chronology14);
        org.joda.time.Chronology chronology16 = monthDay15.getChronology();
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) monthDay15, 0, locale18);
        java.lang.String str20 = delegatedDateTimeField6.toString();
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology21);
        org.joda.time.DateTimeField dateTimeField23 = julianChronology21.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23, dateTimeFieldType24);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime28.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = dateTime28.toDateTime(dateTimeZone31);
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay((java.lang.Object) dateTime28, chronology33);
        org.joda.time.Chronology chronology35 = monthDay34.getChronology();
        java.util.Locale locale37 = null;
        java.lang.String str38 = delegatedDateTimeField25.getAsShortText((org.joda.time.ReadablePartial) monthDay34, 0, locale37);
        java.util.Locale locale40 = null;
        java.lang.String str41 = delegatedDateTimeField6.getAsText((org.joda.time.ReadablePartial) monthDay34, 0, locale40);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BC" + "'", str19.equals("BC"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[era]" + "'", str20.equals("DateTimeField[era]"));
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "BC" + "'", str38.equals("BC"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "BC" + "'", str41.equals("BC"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder3.appendTimeZoneOffset("960", "101", false, 6, 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int12 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay5, intArray11);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology13);
        org.joda.time.DurationField durationField15 = julianChronology13.minutes();
        org.joda.time.MonthDay monthDay16 = monthDay5.withChronologyRetainFields((org.joda.time.Chronology) julianChronology13);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.toDateTime(dateTimeZone22);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((java.lang.Object) dateTime19, chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (int) (byte) 10);
        org.joda.time.MonthDay monthDay30 = monthDay25.minusMonths((int) (short) -1);
        int[] intArray31 = monthDay30.getValues();
        org.joda.time.MonthDay.Property property32 = monthDay30.dayOfMonth();
        java.util.Locale locale34 = null;
        org.joda.time.MonthDay monthDay35 = property32.setCopy("2", locale34);
        java.lang.String str36 = property32.getAsText();
        int int37 = property32.getMaximumValueOverall();
        int int38 = property32.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone40);
        org.joda.time.DateTime dateTime43 = dateTime41.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.DateTime dateTime45 = dateTime41.toDateTime(dateTimeZone44);
        org.joda.time.Chronology chronology46 = null;
        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay((java.lang.Object) dateTime41, chronology46);
        int int48 = property32.compareTo((org.joda.time.ReadablePartial) monthDay47);
        boolean boolean49 = monthDay16.isEqual((org.joda.time.ReadablePartial) monthDay47);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1" + "'", str36.equals("1"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 29 + "'", int38 == 29);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DurationField durationField21 = property12.getRangeDurationField();
        int int22 = property12.get();
        org.joda.time.DateTime dateTime23 = property12.roundHalfCeilingCopy();
        java.util.Locale locale24 = null;
        int int25 = property12.getMaximumTextLength(locale24);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 101 + "'", int22 == 101);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime2.minusMonths(21);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        long long58 = unsupportedDateTimeField55.add((long) 3, (int) (short) 10);
        org.joda.time.DurationField durationField59 = unsupportedDateTimeField55.getRangeDurationField();
        java.util.Locale locale61 = null;
        try {
            java.lang.String str62 = unsupportedDateTimeField55.getAsShortText((long) 100, locale61);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 432000003L + "'", long58 == 432000003L);
        org.junit.Assert.assertNull(durationField59);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, (int) (short) 10);
        long long4 = instant3.getMillis();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.Chronology chronology14 = monthDay13.getChronology();
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay13, 0, locale16);
        java.lang.String str18 = delegatedDateTimeField4.toString();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology19);
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone25);
        org.joda.time.DateTime dateTime28 = dateTime26.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime26.toDateTime(dateTimeZone29);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay((java.lang.Object) dateTime26, chronology31);
        org.joda.time.Chronology chronology33 = monthDay32.getChronology();
        java.util.Locale locale35 = null;
        java.lang.String str36 = delegatedDateTimeField23.getAsShortText((org.joda.time.ReadablePartial) monthDay32, 0, locale35);
        java.util.Locale locale38 = null;
        java.lang.String str39 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay32, 0, locale38);
        try {
            long long42 = delegatedDateTimeField4.set((long) 101, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "BC" + "'", str17.equals("BC"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[era]" + "'", str18.equals("DateTimeField[era]"));
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "BC" + "'", str36.equals("BC"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "BC" + "'", str39.equals("BC"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendYearOfEra((int) (short) 10, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMillisOfSecond(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (-57482400L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfMonth(101);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendTwoDigitYear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendSecondOfMinute((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendMillisOfDay((int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime2.withMillis((long) 57600001);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime10.toDateTime(dateTimeZone13);
        boolean boolean15 = dateTime14.isEqualNow();
        int int16 = dateTime14.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime14.minus(readablePeriod17);
        int int19 = dateTime14.getSecondOfDay();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant7, (org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTimeZone dateTimeZone21 = dateTime14.getZone();
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTimeZone21.getShortName((long) 57600001, locale23);
        org.joda.time.DateTime dateTime25 = dateTime6.withZoneRetainFields(dateTimeZone21);
        org.joda.time.DateTime dateTime27 = dateTime25.plusDays((-2));
        try {
            org.joda.time.DateTime dateTime29 = dateTime27.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.100" + "'", str24.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.append(dateTimeParser6);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatterBuilder16.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.append(dateTimeParser19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray23 = new org.joda.time.format.DateTimeParser[] { dateTimeParser10, dateTimeParser12, dateTimeParser19, dateTimeParser22 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder7.append(dateTimePrinter8, dateTimeParserArray23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendTwoDigitWeekyear((int) (byte) 1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder24.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeParserArray23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("1969-01-01T00:00:00.101+00:00:00.100");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-01-01T00:00:00.101+00:00:00.100\" is malformed at \"T00:00:00.101+00:00:00.100\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.Instant instant6 = org.joda.time.Instant.now();
        org.joda.time.Instant instant9 = instant6.withDurationAdded((long) (short) 100, (int) (byte) 1);
        java.lang.String str10 = dateTimeFormatter5.print((org.joda.time.ReadableInstant) instant6);
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatter5.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatterBuilder15.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.append(dateTimeParser18);
        org.joda.time.format.DateTimePrinter dateTimePrinter20 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser24 = dateTimeFormatter23.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendYearOfEra(1439, (int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder28.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder28.append(dateTimeParser31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser34 = dateTimeFormatter33.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray35 = new org.joda.time.format.DateTimeParser[] { dateTimeParser22, dateTimeParser24, dateTimeParser31, dateTimeParser34 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder19.append(dateTimePrinter20, dateTimeParserArray35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder3.append(dateTimePrinter11, dateTimeParserArray35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1/1/70" + "'", str10.equals("1/1/70"));
        org.junit.Assert.assertNotNull(dateTimePrinter11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeParser24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeParser31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeParser34);
        org.junit.Assert.assertNotNull(dateTimeParserArray35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime13 = property12.roundHalfEvenCopy();
        org.joda.time.DurationField durationField14 = property12.getRangeDurationField();
        int int15 = property12.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendYearOfEra((int) (short) 10, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(0, false);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendTimeZoneOffset("", true, 69, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DurationField durationField4 = julianChronology2.years();
        org.joda.time.DurationField durationField5 = julianChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology2.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField6);
        int int8 = skipUndoDateTimeField7.getMinimumValue();
        int int9 = skipUndoDateTimeField7.getMinimumValue();
        long long12 = skipUndoDateTimeField7.getDifferenceAsLong((long) 31, (-62135568000000L));
        int int14 = skipUndoDateTimeField7.get((long) (short) 10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1035592800L + "'", long12 == 1035592800L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, (-62105328000000L));
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        java.lang.String str7 = iSOChronology6.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62105328000000L) + "'", long5 == (-62105328000000L));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[1]" + "'", str7.equals("ISOChronology[1]"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        java.lang.String str56 = unsupportedDateTimeField55.getName();
        java.lang.String str57 = unsupportedDateTimeField55.toString();
        java.util.Locale locale58 = null;
        try {
            int int59 = unsupportedDateTimeField55.getMaximumShortTextLength(locale58);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "centuryOfEra" + "'", str56.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "UnsupportedDateTimeField" + "'", str57.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        long long58 = unsupportedDateTimeField55.add((long) 3, (int) (short) 10);
        org.joda.time.DurationField durationField59 = unsupportedDateTimeField55.getRangeDurationField();
        long long62 = unsupportedDateTimeField55.add(1560632441089L, (int) (short) 1);
        try {
            long long64 = unsupportedDateTimeField55.remainder((-57482400L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 432000003L + "'", long58 == 432000003L);
        org.junit.Assert.assertNull(durationField59);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560675641089L + "'", long62 == 1560675641089L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.Chronology chronology14 = monthDay13.getChronology();
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay13, 0, locale16);
        java.lang.String str18 = delegatedDateTimeField4.toString();
        java.lang.String str20 = delegatedDateTimeField4.getAsText(1978L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "BC" + "'", str17.equals("BC"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[era]" + "'", str18.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AD" + "'", str20.equals("AD"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        int int5 = offsetDateTimeField4.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTime(dateTimeZone16);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((java.lang.Object) dateTime13, chronology18);
        org.joda.time.Chronology chronology20 = monthDay19.getChronology();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) monthDay19, 0, locale22);
        java.lang.String str24 = delegatedDateTimeField10.toString();
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology25);
        org.joda.time.DateTimeField dateTimeField27 = julianChronology25.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27, dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone31);
        org.joda.time.DateTime dateTime34 = dateTime32.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.DateTime dateTime36 = dateTime32.toDateTime(dateTimeZone35);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((java.lang.Object) dateTime32, chronology37);
        org.joda.time.Chronology chronology39 = monthDay38.getChronology();
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) monthDay38, 0, locale41);
        java.util.Locale locale44 = null;
        java.lang.String str45 = delegatedDateTimeField10.getAsText((org.joda.time.ReadablePartial) monthDay38, 0, locale44);
        int[] intArray46 = monthDay38.getValues();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone47);
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, (int) (byte) 1);
        org.joda.time.MonthDay monthDay52 = new org.joda.time.MonthDay();
        int[] intArray58 = new int[] { (byte) 100, (-1), (short) -1, '#', (byte) 100 };
        int int59 = offsetDateTimeField51.getMaximumValue((org.joda.time.ReadablePartial) monthDay52, intArray58);
        boolean boolean60 = monthDay38.isBefore((org.joda.time.ReadablePartial) monthDay52);
        int[] intArray62 = null;
        try {
            int[] intArray64 = offsetDateTimeField4.addWrapField((org.joda.time.ReadablePartial) monthDay52, 1, intArray62, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "BC" + "'", str23.equals("BC"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "DateTimeField[era]" + "'", str24.equals("DateTimeField[era]"));
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "BC" + "'", str42.equals("BC"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "BC" + "'", str45.equals("BC"));
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        org.joda.time.MonthDay monthDay13 = monthDay8.minusMonths((int) (short) -1);
        int[] intArray14 = monthDay13.getValues();
        org.joda.time.MonthDay.Property property15 = monthDay13.dayOfMonth();
        java.util.Locale locale17 = null;
        org.joda.time.MonthDay monthDay18 = property15.setCopy("2", locale17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime(dateTimeZone24);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay((java.lang.Object) dateTime21, chronology26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.MonthDay monthDay30 = monthDay27.withPeriodAdded(readablePeriod28, (int) (byte) 10);
        org.joda.time.MonthDay monthDay32 = monthDay27.minusMonths((int) (short) -1);
        int[] intArray33 = monthDay32.getValues();
        org.joda.time.MonthDay.Property property34 = monthDay32.dayOfMonth();
        java.util.Locale locale36 = null;
        org.joda.time.MonthDay monthDay37 = property34.setCopy("2", locale36);
        java.util.Locale locale38 = null;
        java.lang.String str39 = property34.getAsText(locale38);
        org.joda.time.MonthDay monthDay41 = property34.setCopy(10);
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.MonthDay monthDay43 = monthDay41.minus(readablePeriod42);
        boolean boolean44 = monthDay18.isEqual((org.joda.time.ReadablePartial) monthDay43);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1" + "'", str39.equals("1"));
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DurationField durationField5 = julianChronology3.years();
        org.joda.time.DurationField durationField6 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology3.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField7, 1439);
        long long14 = iSOChronology0.getDateTimeMillis(1, 1, 6, 1970);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62135164798130L) + "'", long14 == (-62135164798130L));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DurationField durationField44 = julianChronology42.years();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology42);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) ' ');
        org.joda.time.DateTime dateTime50 = dateTime45.withDayOfYear((int) '#');
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.yearOfEra();
        org.joda.time.DurationField durationField54 = gJChronology51.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
        long long58 = unsupportedDateTimeField55.add((long) 3, (int) (short) 10);
        org.joda.time.DurationField durationField59 = unsupportedDateTimeField55.getRangeDurationField();
        try {
            long long61 = unsupportedDateTimeField55.roundHalfFloor((long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 432000003L + "'", long58 == 432000003L);
        org.junit.Assert.assertNull(durationField59);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, chronology12);
        org.joda.time.Chronology chronology14 = monthDay13.getChronology();
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay13, 0, locale16);
        java.lang.String str18 = delegatedDateTimeField4.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime(dateTimeZone24);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay((java.lang.Object) dateTime21, chronology26);
        java.util.Locale locale29 = null;
        java.lang.String str30 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay27, (int) (byte) 1, locale29);
        long long32 = delegatedDateTimeField4.roundFloor((long) (byte) 0);
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology33);
        org.joda.time.DateTimeField dateTimeField35 = julianChronology33.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35, dateTimeFieldType36);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone39);
        org.joda.time.DateTime dateTime42 = dateTime40.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = dateTime40.toDateTime(dateTimeZone43);
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay((java.lang.Object) dateTime40, chronology45);
        org.joda.time.Chronology chronology47 = monthDay46.getChronology();
        java.util.Locale locale49 = null;
        java.lang.String str50 = delegatedDateTimeField37.getAsShortText((org.joda.time.ReadablePartial) monthDay46, 0, locale49);
        java.lang.String str51 = delegatedDateTimeField37.toString();
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology53 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology52);
        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField56 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField54, dateTimeFieldType55);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone58);
        org.joda.time.DateTime dateTime61 = dateTime59.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.DateTime dateTime63 = dateTime59.toDateTime(dateTimeZone62);
        org.joda.time.Chronology chronology64 = null;
        org.joda.time.MonthDay monthDay65 = new org.joda.time.MonthDay((java.lang.Object) dateTime59, chronology64);
        org.joda.time.Chronology chronology66 = monthDay65.getChronology();
        java.util.Locale locale68 = null;
        java.lang.String str69 = delegatedDateTimeField56.getAsShortText((org.joda.time.ReadablePartial) monthDay65, 0, locale68);
        java.util.Locale locale71 = null;
        java.lang.String str72 = delegatedDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay65, 0, locale71);
        org.joda.time.DateTimeField dateTimeField74 = monthDay65.getField((int) (short) 0);
        java.util.Locale locale76 = null;
        java.lang.String str77 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay65, (int) (short) 0, locale76);
        java.lang.String str79 = delegatedDateTimeField4.getAsText((-2042700000L));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "BC" + "'", str17.equals("BC"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[era]" + "'", str18.equals("DateTimeField[era]"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "AD" + "'", str30.equals("AD"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62105356800100L) + "'", long32 == (-62105356800100L));
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "BC" + "'", str50.equals("BC"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "DateTimeField[era]" + "'", str51.equals("DateTimeField[era]"));
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(chronology66);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "BC" + "'", str69.equals("BC"));
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "BC" + "'", str72.equals("BC"));
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "BC" + "'", str77.equals("BC"));
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "AD" + "'", str79.equals("AD"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond(100, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfHour((int) '#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        int int20 = property12.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime22 = dateTime15.minusSeconds((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.toDateTime(dateTimeZone28);
        boolean boolean30 = dateTime29.isEqualNow();
        int int31 = dateTime29.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readablePeriod32);
        int int34 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime29.minusYears(4);
        org.joda.time.DateTime.Property property37 = dateTime29.centuryOfEra();
        int int38 = property37.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        int int40 = dateTime15.get(dateTimeFieldType39);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType39, (java.lang.Number) (-1.0d), "004842.889+0000");
        java.lang.Throwable[] throwableArray44 = illegalFieldValueException43.getSuppressed();
        org.joda.time.DurationFieldType durationFieldType45 = illegalFieldValueException43.getDurationFieldType();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 101 + "'", int31 == 101);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNull(durationFieldType45);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        boolean boolean11 = dateTime6.isEqualNow();
        org.joda.time.DateTime.Property property12 = dateTime6.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((int) ' ');
        boolean boolean8 = dateTime5.isEqualNow();
        java.util.Locale locale9 = null;
        java.util.Calendar calendar10 = dateTime5.toCalendar(locale9);
        org.joda.time.LocalDateTime localDateTime11 = dateTime5.toLocalDateTime();
        boolean boolean12 = dateTimeZone1.isLocalDateTimeGap(localDateTime11);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfDay((int) ' ');
        boolean boolean20 = dateTime17.isEqualNow();
        java.util.Locale locale21 = null;
        java.util.Calendar calendar22 = dateTime17.toCalendar(locale21);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = iSOChronology25.getZone();
        org.joda.time.Chronology chronology27 = gJChronology23.withZone(dateTimeZone26);
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone26);
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology13, dateTimeZone26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        boolean boolean31 = zonedChronology29.equals((java.lang.Object) dateTimeFormatter30);
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str33 = copticChronology32.toString();
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology34);
        org.joda.time.DateTimeField dateTimeField36 = julianChronology34.era();
        org.joda.time.DurationField durationField37 = julianChronology34.years();
        boolean boolean38 = copticChronology32.equals((java.lang.Object) julianChronology34);
        org.joda.time.DurationField durationField39 = copticChronology32.weeks();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone41);
        org.joda.time.DateTime dateTime44 = dateTime42.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.DateTime dateTime46 = dateTime42.toDateTime(dateTimeZone45);
        boolean boolean47 = dateTime46.isEqualNow();
        int int48 = dateTime46.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.DateTime dateTime50 = dateTime46.minus(readablePeriod49);
        int int51 = dateTime46.getSecondOfDay();
        org.joda.time.DateTime.Property property52 = dateTime46.millisOfSecond();
        boolean boolean53 = copticChronology32.equals((java.lang.Object) dateTime46);
        boolean boolean54 = zonedChronology29.equals((java.lang.Object) copticChronology32);
        try {
            long long60 = zonedChronology29.getDateTimeMillis((-1244160000000000L), 19, 1969, (int) (byte) 0, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(calendar10);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(calendar22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CopticChronology[1]" + "'", str33.equals("CopticChronology[1]"));
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 101 + "'", int48 == 101);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) 1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 100);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = iSOChronology8.getZone();
        java.lang.String str10 = dateTimeZone9.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfDay((int) ' ');
        boolean boolean16 = dateTime13.isEqualNow();
        java.util.Locale locale17 = null;
        java.util.Calendar calendar18 = dateTime13.toCalendar(locale17);
        org.joda.time.LocalDateTime localDateTime19 = dateTime13.toLocalDateTime();
        boolean boolean20 = dateTimeZone9.isLocalDateTimeGap(localDateTime19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDateTime19, (int) (byte) 100, locale22);
        int int25 = offsetDateTimeField4.getMinimumValue((long) 1970);
        java.lang.String str27 = offsetDateTimeField4.getAsText((long) 101);
        try {
            long long30 = offsetDateTimeField4.getDifferenceAsLong((long) 21, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(calendar18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2" + "'", str27.equals("2"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.era();
        org.joda.time.DurationField durationField5 = julianChronology2.years();
        boolean boolean6 = copticChronology0.equals((java.lang.Object) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(2922789);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone18);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((java.lang.Object) dateTime15, chronology20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.MonthDay monthDay24 = monthDay21.withPeriodAdded(readablePeriod22, (int) (byte) 10);
        org.joda.time.MonthDay monthDay26 = monthDay21.minusMonths((int) (short) -1);
        int[] intArray27 = monthDay26.getValues();
        org.joda.time.MonthDay.Property property28 = monthDay26.dayOfMonth();
        java.lang.String str29 = property28.getAsText();
        java.util.Locale locale30 = null;
        int int31 = property28.getMaximumTextLength(locale30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property28.getFieldType();
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType32);
        int int34 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime36 = dateTime10.withMillisOfDay((int) (short) 0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[1]" + "'", str1.equals("CopticChronology[1]"));
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1" + "'", str29.equals("1"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYear(2922789);
        org.joda.time.LocalDateTime localDateTime5 = dateTime4.toLocalDateTime();
        boolean boolean7 = dateTime4.isBefore((long) 29);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(12, 19, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 26 + "'", int3 == 26);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        int int3 = julianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField4);
        long long8 = skipDateTimeField5.set((long) 57600, 1);
        int int9 = skipDateTimeField5.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipDateTimeField5, (-1));
        boolean boolean13 = skipDateTimeField11.isLeap((-62104060800000L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 117600L + "'", long8 == 117600L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        boolean boolean7 = dateTime6.isEqualNow();
        int int8 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        int int11 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime6.millisOfSecond();
        java.lang.String str13 = property12.getAsString();
        org.joda.time.DateTime dateTime15 = property12.addToCopy((long) 97);
        java.util.Locale locale17 = null;
        org.joda.time.DateTime dateTime18 = property12.setCopy("2", locale17);
        org.joda.time.DurationField durationField19 = property12.getDurationField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 101 + "'", int8 == 101);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "101" + "'", str13.equals("101"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.Chronology chronology1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1969, chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
    }
}

