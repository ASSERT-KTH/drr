import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            long long4 = julianChronology1.set(readablePartial2, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.ReadablePartial readablePartial4 = null;
        int[] intArray10 = new int[] { (short) 0, '4', (byte) -1, (short) 10, 100 };
        try {
            julianChronology2.validate(readablePartial4, intArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(0, (int) '#', (int) (byte) 1, (int) (short) 0, (int) (short) 0, (int) (byte) -1, 999, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 0, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        try {
            long long8 = julianChronology2.getDateTimeMillis((int) (byte) 100, 100, (int) '4', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Float");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 100, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        try {
            org.joda.time.MutableDateTime mutableDateTime13 = property11.set("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField12 = null;
        try {
            int int13 = mutableDateTime3.get(dateTimeField12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeField must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        try {
            mutableDateTime3.setDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        int int4 = mutableDateTime3.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology7);
        mutableDateTime8.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        boolean boolean15 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        int int16 = mutableDateTime14.getMinuteOfHour();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime14);
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = mutableDateTime3.toString("hi!", locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 999 + "'", int4 == 999);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getHourOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = mutableDateTime9.toMutableDateTime((org.joda.time.Chronology) julianChronology13);
        org.joda.time.ReadablePartial readablePartial15 = null;
        try {
            long long17 = julianChronology13.set(readablePartial15, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("Dec");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Dec\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.months();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.months();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) '4', (int) (byte) 1, 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long5 = dateTimeZone3.convertUTCToLocal((long) 10);
        try {
            org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeFormatter0, dateTimeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4320010L + "'", long5 == 4320010L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.MutableDateTime.Property property13 = mutableDateTime9.property(dateTimeFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("Dec", (int) ' ', (int) 'a', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for Dec must be in the range [97,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "BuddhistChronology[UTC]");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology6);
        mutableDateTime7.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology12);
        boolean boolean14 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) mutableDateTime13);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime7.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        mutableDateTime7.setChronology((org.joda.time.Chronology) julianChronology17);
        try {
            org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((java.lang.Object) illegalFieldValueException2, (org.joda.time.Chronology) julianChronology17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.IllegalFieldValueException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(julianChronology17);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getChronology(chronology19);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMinuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology14);
        mutableDateTime15.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology20);
        boolean boolean22 = mutableDateTime15.isEqual((org.joda.time.ReadableInstant) mutableDateTime21);
        int int23 = mutableDateTime21.getHourOfDay();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.MutableDateTime mutableDateTime26 = mutableDateTime21.toMutableDateTime((org.joda.time.Chronology) julianChronology25);
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime9, (org.joda.time.ReadableInstant) mutableDateTime26);
        org.joda.time.DurationFieldType durationFieldType28 = null;
        try {
            mutableDateTime9.add(durationFieldType28, 999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(chronology27);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime6 = dateTime2.plusYears(0);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        org.joda.time.ReadablePartial readablePartial8 = null;
        try {
            int int9 = property7.compareTo(readablePartial8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMinuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology14);
        mutableDateTime15.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology20);
        boolean boolean22 = mutableDateTime15.isEqual((org.joda.time.ReadableInstant) mutableDateTime21);
        int int23 = mutableDateTime21.getHourOfDay();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.MutableDateTime mutableDateTime26 = mutableDateTime21.toMutableDateTime((org.joda.time.Chronology) julianChronology25);
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime9, (org.joda.time.ReadableInstant) mutableDateTime26);
        try {
            mutableDateTime9.setHourOfDay((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(chronology27);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000011576d + "'", double1 == 2440587.5000011576d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 1969);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology2, dateTimeField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        org.joda.time.DurationField durationField13 = property12.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology7);
        mutableDateTime8.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        boolean boolean15 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        int int16 = mutableDateTime14.getHourOfDay();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.MutableDateTime mutableDateTime19 = mutableDateTime14.toMutableDateTime((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTimeField dateTimeField20 = julianChronology18.hourOfDay();
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(12, 1, 4320000, (int) (byte) 1, 1, (org.joda.time.Chronology) julianChronology18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4320000 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long10 = dateTimeZone8.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        mutableDateTime14.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology19);
        boolean boolean21 = mutableDateTime14.isEqual((org.joda.time.ReadableInstant) mutableDateTime20);
        int int22 = mutableDateTime20.getMonthOfYear();
        org.joda.time.Chronology chronology23 = mutableDateTime20.getChronology();
        int int24 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) mutableDateTime20);
        try {
            org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(999, (int) (byte) 10, (int) (short) 100, 15, (int) (short) -1, 4320000, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 4320010L + "'", long10 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4320000 + "'", int24 == 4320000);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter0.printTo(writer2, (long) 999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 1, 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology14);
        mutableDateTime15.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology20);
        boolean boolean22 = mutableDateTime15.isEqual((org.joda.time.ReadableInstant) mutableDateTime21);
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime15.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        mutableDateTime15.setChronology((org.joda.time.Chronology) julianChronology25);
        java.util.Locale locale27 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology25, locale27, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology30 = dateTimeParserBucket29.getChronology();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone31);
        org.joda.time.DurationField durationField33 = julianChronology32.seconds();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
        boolean boolean36 = julianChronology32.equals((java.lang.Object) julianChronology35);
        org.joda.time.DateTimeField dateTimeField37 = julianChronology32.minuteOfHour();
        dateTimeParserBucket29.saveField(dateTimeField37, 1);
        try {
            mutableDateTime3.setRounding(dateTimeField37, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTimeField37);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField12 = julianChronology11.seconds();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        boolean boolean15 = julianChronology11.equals((java.lang.Object) julianChronology14);
        org.joda.time.DateTimeField dateTimeField16 = julianChronology11.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int[] intArray20 = new int[] { 2000 };
        int int21 = delegatedDateTimeField17.getMaximumValue(readablePartial18, intArray20);
        try {
            int[] intArray23 = delegatedDateTimeField7.addWrapField(readablePartial8, 4320000, intArray20, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4320000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField6 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType4, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.yearOfEra();
        try {
            org.joda.time.DateTime dateTime7 = dateTime2.withDayOfWeek((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 100, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 4320000, (java.lang.Number) (short) 100, (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+01:12", "Dec", (int) ' ', (-1));
        try {
            org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 1560343535530L, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 15");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(0L);
        int int2 = mutableDateTime1.getRoundingMode();
        mutableDateTime1.addMinutes(59);
        int int5 = mutableDateTime1.getCenturyOfEra();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("Dec", 16, 1, (int) ' ', 'a', (int) (byte) -1, 4, (int) (byte) 1, false, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendFraction(dateTimeFieldType6, 999, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("Dec");
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime14 = property12.roundHalfFloor();
        org.joda.time.DurationField durationField15 = property12.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withDayOfMonth(12);
        org.joda.time.DateTime dateTime21 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology24);
        int int26 = mutableDateTime25.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology29);
        mutableDateTime30.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology35);
        boolean boolean37 = mutableDateTime30.isEqual((org.joda.time.ReadableInstant) mutableDateTime36);
        int int38 = mutableDateTime36.getMinuteOfHour();
        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime25, (org.joda.time.ReadableInstant) mutableDateTime36);
        boolean boolean40 = dateTime20.isBefore((org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.DateTime dateTime42 = dateTime20.withMillis((long) ' ');
        long long43 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime42);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 999 + "'", int26 == 999);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 59 + "'", int38 == 59);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.minuteOfDay();
        org.joda.time.DateTime.Property property6 = dateTime2.yearOfEra();
        int int7 = property6.get();
        org.joda.time.DateTime dateTime8 = property6.withMaximumValue();
        org.joda.time.DateTime dateTime10 = dateTime8.minusHours((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime8.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("12", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            int int14 = mutableDateTime9.get(dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray10 = new int[] { 2000 };
        int int11 = delegatedDateTimeField7.getMaximumValue(readablePartial8, intArray10);
        java.lang.String str13 = delegatedDateTimeField7.getAsText((long) (short) 0);
        int int15 = delegatedDateTimeField7.getMaximumValue((long) (byte) 100);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 59 + "'", int15 == 59);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("+01:12");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+01:12/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        mutableDateTime9.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology14);
        boolean boolean16 = mutableDateTime9.isEqual((org.joda.time.ReadableInstant) mutableDateTime15);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime9.secondOfMinute();
        java.lang.String str18 = property17.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property17.getFieldType();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType19, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "secondOfMinute" + "'", str18.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        mutableDateTime9.addMinutes((int) (short) -1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime14 = property12.roundHalfFloor();
        org.joda.time.DurationField durationField15 = property12.getLeapDurationField();
        java.lang.Class<?> wildcardClass16 = property12.getClass();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long5 = dateTimeZone3.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        mutableDateTime9.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology14);
        boolean boolean16 = mutableDateTime9.isEqual((org.joda.time.ReadableInstant) mutableDateTime15);
        int int17 = mutableDateTime15.getMonthOfYear();
        org.joda.time.Chronology chronology18 = mutableDateTime15.getChronology();
        int int19 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) mutableDateTime15);
        java.lang.String str21 = dateTimeZone3.getName(0L);
        try {
            org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((java.lang.Object) defaultNameProvider0, dateTimeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.DefaultNameProvider");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4320010L + "'", long5 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4320000 + "'", int19 == 4320000);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+01:12" + "'", str21.equals("+01:12"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime6 = dateTime2.plusYears(0);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.util.Locale locale9 = null;
        try {
            org.joda.time.DateTime dateTime10 = property7.setCopy("JulianChronology[America/Los_Angeles]", locale9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"JulianChronology[America/Los_Angeles]\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        try {
            org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((-1), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "BuddhistChronology[UTC]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("hi!", "BuddhistChronology[UTC]");
        illegalFieldValueException5.prependMessage("");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        try {
            org.joda.time.Instant instant12 = new org.joda.time.Instant((java.lang.Object) int11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        java.lang.Object obj0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology2, locale4, (java.lang.Integer) 1969);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology2);
//        java.lang.String str8 = dateTime7.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019-06-12T12:45:39.995Z" + "'", str8.equals("2019-06-12T12:45:39.995Z"));
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = julianChronology20.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        boolean boolean24 = julianChronology20.equals((java.lang.Object) julianChronology23);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology20.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int[] intArray29 = new int[] { 2000 };
        int int30 = delegatedDateTimeField26.getMaximumValue(readablePartial27, intArray29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField26.getAsText(12, locale32);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology14, (org.joda.time.DateTimeField) delegatedDateTimeField26);
        org.joda.time.ReadablePartial readablePartial35 = null;
        int[] intArray37 = null;
        java.util.Locale locale39 = null;
        try {
            int[] intArray40 = skipDateTimeField34.set(readablePartial35, 3, intArray37, "Dec", locale39);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Dec\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 59 + "'", int30 == 59);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "12" + "'", str33.equals("12"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        try {
            long long8 = julianChronology2.getDateTimeMillis((int) (byte) -1, 0, 59, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray10 = new int[] { 2000 };
        int int11 = delegatedDateTimeField7.getMaximumValue(readablePartial8, intArray10);
        java.util.Locale locale14 = null;
        try {
            long long15 = delegatedDateTimeField7.set(0L, "January", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"January\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime6 = dateTime2.plusYears(0);
        org.joda.time.DateTime dateTime8 = dateTime2.withYearOfEra(12);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = julianChronology6.seconds();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = julianChronology6.equals((java.lang.Object) julianChronology9);
        org.joda.time.DurationField durationField11 = julianChronology9.weekyears();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((int) '4', (int) '4', 999, 12, 3, (org.joda.time.Chronology) julianChronology9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("0", 2, 19, 4320000, ' ', 0, 3, 3, true, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("12");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"12\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.minuteOfDay();
        org.joda.time.DateTime.Property property6 = dateTime2.yearOfEra();
        int int7 = property6.get();
        org.joda.time.ReadablePartial readablePartial8 = null;
        try {
            int int9 = property6.compareTo(readablePartial8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray10 = new int[] { 2000 };
        int int11 = delegatedDateTimeField7.getMaximumValue(readablePartial8, intArray10);
        java.util.Locale locale12 = null;
        int int13 = delegatedDateTimeField7.getMaximumShortTextLength(locale12);
        long long15 = delegatedDateTimeField7.roundFloor((long) (byte) 100);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray10 = new int[] { 2000 };
        int int11 = delegatedDateTimeField7.getMaximumValue(readablePartial8, intArray10);
        java.util.Locale locale12 = null;
        int int13 = delegatedDateTimeField7.getMaximumShortTextLength(locale12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = delegatedDateTimeField7.getMaximumValue(readablePartial14);
        long long18 = delegatedDateTimeField7.add(0L, 0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 59 + "'", int15 == 59);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology1.clockhourOfDay();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray10 = new int[] { 2000 };
        int int11 = delegatedDateTimeField7.getMaximumValue(readablePartial8, intArray10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = delegatedDateTimeField7.getAsText(2000, locale13);
        org.joda.time.DurationField durationField15 = delegatedDateTimeField7.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray20 = new int[] { 59, (short) 10 };
        java.util.Locale locale22 = null;
        try {
            int[] intArray23 = delegatedDateTimeField7.set(readablePartial16, (int) (byte) 10, intArray20, "2000", locale22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2000" + "'", str14.equals("2000"));
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfDay();
        try {
            long long9 = gJChronology0.getDateTimeMillis((int) '#', 12, 100, 0, 4320000, 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4320000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            long long5 = julianChronology1.set(readablePartial3, (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = julianChronology20.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        boolean boolean24 = julianChronology20.equals((java.lang.Object) julianChronology23);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology20.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int[] intArray29 = new int[] { 2000 };
        int int30 = delegatedDateTimeField26.getMaximumValue(readablePartial27, intArray29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField26.getAsText(12, locale32);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology14, (org.joda.time.DateTimeField) delegatedDateTimeField26);
        org.joda.time.ReadablePartial readablePartial35 = null;
        int int36 = skipDateTimeField34.getMinimumValue(readablePartial35);
        int int39 = skipDateTimeField34.getDifference((long) 16, 0L);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 59 + "'", int30 == 59);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "12" + "'", str33.equals("12"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology10);
        mutableDateTime11.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        boolean boolean18 = mutableDateTime11.isEqual((org.joda.time.ReadableInstant) mutableDateTime17);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime11.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        mutableDateTime11.setChronology((org.joda.time.Chronology) julianChronology21);
        java.util.Locale locale23 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology21, locale23, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone26);
        org.joda.time.DurationField durationField28 = julianChronology27.seconds();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        boolean boolean31 = julianChronology27.equals((java.lang.Object) julianChronology30);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology27.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray36 = new int[] { 2000 };
        int int37 = delegatedDateTimeField33.getMaximumValue(readablePartial34, intArray36);
        java.util.Locale locale39 = null;
        java.lang.String str40 = delegatedDateTimeField33.getAsText(12, locale39);
        org.joda.time.field.SkipDateTimeField skipDateTimeField41 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology21, (org.joda.time.DateTimeField) delegatedDateTimeField33);
        try {
            org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime(0, 1, (int) (byte) -1, (int) '4', (int) (short) 10, (int) 'a', (int) '#', (org.joda.time.Chronology) julianChronology21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 59 + "'", int37 == 59);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "12" + "'", str40.equals("12"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology4);
        mutableDateTime5.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology10);
        boolean boolean12 = mutableDateTime5.isEqual((org.joda.time.ReadableInstant) mutableDateTime11);
        int int13 = mutableDateTime11.getMonthOfYear();
        org.joda.time.Chronology chronology14 = mutableDateTime11.getChronology();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime11.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology18);
        mutableDateTime19.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology24);
        boolean boolean26 = mutableDateTime19.isEqual((org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime19.secondOfMinute();
        mutableDateTime11.setTime((org.joda.time.ReadableInstant) mutableDateTime19);
        mutableDateTime19.addYears((int) (byte) -1);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) mutableDateTime19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(property27);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(0, (int) (byte) 1, 100, 999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        try {
            org.joda.time.DateTime dateTime7 = property5.setCopy("+01:12");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+01:12\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.Chronology chronology12 = mutableDateTime9.getChronology();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime9.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        mutableDateTime17.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        boolean boolean24 = mutableDateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime17.secondOfMinute();
        mutableDateTime9.setTime((org.joda.time.ReadableInstant) mutableDateTime17);
        mutableDateTime17.addDays((int) (short) 1);
        org.joda.time.DateTimeField dateTimeField29 = mutableDateTime17.getRoundingField();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNull(dateTimeField29);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray10 = new int[] { 2000 };
        int int11 = delegatedDateTimeField7.getMaximumValue(readablePartial8, intArray10);
        java.util.Locale locale12 = null;
        int int13 = delegatedDateTimeField7.getMaximumShortTextLength(locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField7.getAsText((long) (byte) 100, locale15);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray10 = new int[] { 2000 };
        int int11 = delegatedDateTimeField7.getMaximumValue(readablePartial8, intArray10);
        java.util.Locale locale12 = null;
        int int13 = delegatedDateTimeField7.getMaximumShortTextLength(locale12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = julianChronology17.seconds();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        boolean boolean21 = julianChronology17.equals((java.lang.Object) julianChronology20);
        org.joda.time.DateTimeField dateTimeField22 = julianChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int[] intArray26 = new int[] { 2000 };
        int int27 = delegatedDateTimeField23.getMaximumValue(readablePartial24, intArray26);
        java.util.Locale locale29 = null;
        try {
            int[] intArray30 = delegatedDateTimeField7.set(readablePartial14, (int) (short) 10, intArray26, "hi!", locale29);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 59 + "'", int27 == 59);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        try {
            org.joda.time.LocalDateTime localDateTime3 = dateTimeFormatter0.parseLocalDateTime("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DurationField durationField6 = julianChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology4.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology11);
        mutableDateTime12.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology17);
        boolean boolean19 = mutableDateTime12.isEqual((org.joda.time.ReadableInstant) mutableDateTime18);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime12.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        mutableDateTime12.setChronology((org.joda.time.Chronology) julianChronology22);
        java.util.Locale locale24 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology22, locale24, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone27 = dateTimeParserBucket26.getZone();
        org.joda.time.Chronology chronology28 = julianChronology4.withZone(dateTimeZone27);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(chronology28);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long4 = dateTimeZone2.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology7);
        mutableDateTime8.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        boolean boolean15 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        int int16 = mutableDateTime14.getMonthOfYear();
        org.joda.time.Chronology chronology17 = mutableDateTime14.getChronology();
        int int18 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) mutableDateTime14);
        boolean boolean20 = dateTimeZone2.isStandardOffset((long) 1969);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4320010L + "'", long4 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4320000 + "'", int18 == 4320000);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(4320000, (-1), 10, 7, 2, (int) (short) 100, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        int int10 = mutableDateTime9.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        mutableDateTime14.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology19);
        boolean boolean21 = mutableDateTime14.isEqual((org.joda.time.ReadableInstant) mutableDateTime20);
        int int22 = mutableDateTime20.getMinuteOfHour();
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime9, (org.joda.time.ReadableInstant) mutableDateTime20);
        boolean boolean24 = dateTime4.isBefore((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime26 = dateTime4.withMillis((long) ' ');
        org.joda.time.DurationFieldType durationFieldType27 = null;
        try {
            org.joda.time.DateTime dateTime29 = dateTime26.withFieldAdded(durationFieldType27, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 59 + "'", int22 == 59);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.clockhourOfHalfday();
        int int2 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePartial readablePartial3 = null;
        int[] intArray4 = null;
        try {
            gJChronology0.validate(readablePartial3, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.months();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.withSecondOfMinute(0);
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withSecondOfMinute(999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.Chronology chronology12 = mutableDateTime9.getChronology();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime9.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        mutableDateTime17.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        boolean boolean24 = mutableDateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime17.secondOfMinute();
        mutableDateTime9.setTime((org.joda.time.ReadableInstant) mutableDateTime17);
        mutableDateTime17.setMillisOfDay((int) '4');
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (short) 10);
        int int7 = dateTime2.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.ReadablePartial readablePartial13 = null;
        try {
            int int14 = property11.compareTo(readablePartial13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 100, 7, (int) (byte) 0, 100, 0, 0, 4320000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology1, locale3, (java.lang.Integer) 1969);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.halfdayOfDay();
        try {
            long long14 = gregorianChronology1.getDateTimeMillis((int) (short) -1, (int) (short) 100, 1969, 12, 1969, (int) (short) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = julianChronology1.toString();
        try {
            long long10 = julianChronology1.getDateTimeMillis(999, 2000, (int) '4', (int) ' ', 15, (int) (short) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        org.joda.time.DateTime dateTime8 = property7.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime9 = property7.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime10 = property7.getDateTime();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.yearOfEra();
        java.lang.String str6 = property5.getName();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "yearOfEra" + "'", str6.equals("yearOfEra"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray10 = new int[] { 2000 };
        int int11 = delegatedDateTimeField7.getMaximumValue(readablePartial8, intArray10);
        java.util.Locale locale12 = null;
        int int13 = delegatedDateTimeField7.getMaximumShortTextLength(locale12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = delegatedDateTimeField7.getMaximumValue(readablePartial14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = delegatedDateTimeField7.getAsText(readablePartial16, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 59 + "'", int15 == 59);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("Dec");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Dec\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.Chronology chronology12 = mutableDateTime9.getChronology();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime9.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        mutableDateTime17.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        boolean boolean24 = mutableDateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime17.secondOfMinute();
        mutableDateTime9.setTime((org.joda.time.ReadableInstant) mutableDateTime17);
        try {
            mutableDateTime9.setMonthOfYear(999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime6 = dateTime2.plusYears(0);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTime();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology12);
        int int14 = mutableDateTime13.getMillisOfSecond();
        mutableDateTime13.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long21 = dateTimeZone19.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology24);
        mutableDateTime25.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology30);
        boolean boolean32 = mutableDateTime25.isEqual((org.joda.time.ReadableInstant) mutableDateTime31);
        int int33 = mutableDateTime31.getMonthOfYear();
        org.joda.time.Chronology chronology34 = mutableDateTime31.getChronology();
        int int35 = dateTimeZone19.getOffset((org.joda.time.ReadableInstant) mutableDateTime31);
        mutableDateTime13.setZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTime dateTime37 = dateTime9.withZone(dateTimeZone19);
        try {
            org.joda.time.DateTime dateTime41 = dateTime9.withDate(12, (int) (byte) -1, 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 999 + "'", int14 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 4320010L + "'", long21 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4320000 + "'", int35 == 4320000);
        org.junit.Assert.assertNotNull(dateTime37);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(12, (int) (byte) 1, 2, (int) (byte) 1, 1, 15, 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        int int4 = mutableDateTime3.getMillisOfSecond();
        mutableDateTime3.setSecondOfDay((int) ' ');
        boolean boolean7 = mutableDateTime3.isBeforeNow();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 999 + "'", int4 == 999);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "BuddhistChronology[UTC]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("hi!", "BuddhistChronology[UTC]");
        java.lang.Number number6 = illegalFieldValueException5.getLowerBound();
        java.lang.Number number7 = illegalFieldValueException5.getUpperBound();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.Throwable[] throwableArray9 = illegalFieldValueException5.getSuppressed();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        int int1 = dateTimeFormatter0.getDefaultYear();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        try {
            java.lang.String str7 = dateTime4.toString(dateTimeFormatter6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (byte) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        int int6 = dateTime5.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendHourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTimeZoneName(strMap11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray15 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder9.append(dateTimePrinter14, dateTimeParserArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parsers supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.clockhourOfHalfday();
        org.joda.time.DurationField durationField3 = gJChronology1.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        java.io.Writer writer5 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        mutableDateTime9.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology14);
        boolean boolean16 = mutableDateTime9.isEqual((org.joda.time.ReadableInstant) mutableDateTime15);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime9.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        mutableDateTime9.setChronology((org.joda.time.Chronology) julianChronology19);
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.weekOfWeekyear();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology19);
        try {
            dateTimeFormatter0.printTo(writer5, (org.joda.time.ReadableInstant) dateTime22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 4320000, 12, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = dateTime4.toCalendar(locale5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime4.withPeriodAdded(readablePeriod7, (int) (byte) 1);
        int int10 = dateTime9.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(calendar6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("secondOfMinute");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", "BuddhistChronology[UTC]");
        illegalFieldValueException4.prependMessage("");
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalFieldValueException4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (short) 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minusDays(16);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.DateTime dateTime9 = dateTime2.withFieldAdded(durationFieldType7, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("January");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"January\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime14 = property12.roundHalfFloor();
        org.joda.time.DurationField durationField15 = property12.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType16 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField17 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1L, 59L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        try {
            long long8 = gJChronology0.getDateTimeMillis((int) 'a', 59, (int) '#', (-13), (int) ' ', 4320000, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -13 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePartial readablePartial2 = null;
        int[] intArray4 = new int[] { (-1) };
        try {
            gregorianChronology0.validate(readablePartial2, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("hi!");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendPattern("JulianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        org.joda.time.DateTimeField dateTimeField58 = offsetDateTimeField57.getWrappedField();
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeField58);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
        java.lang.String str6 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        mutableDateTime3.setChronology((org.joda.time.Chronology) julianChronology13);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime3.centuryOfEra();
        org.joda.time.Instant instant16 = mutableDateTime3.toInstant();
        boolean boolean18 = mutableDateTime3.isAfter(1560343537018L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str20 = buddhistChronology19.toString();
        boolean boolean22 = buddhistChronology19.equals((java.lang.Object) (short) 0);
        java.lang.String str23 = buddhistChronology19.toString();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.DurationField durationField26 = julianChronology25.seconds();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        boolean boolean29 = julianChronology25.equals((java.lang.Object) julianChronology28);
        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology25.getZone();
        org.joda.time.Chronology chronology31 = buddhistChronology19.withZone(dateTimeZone30);
        mutableDateTime3.setZone(dateTimeZone30);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "BuddhistChronology[UTC]" + "'", str20.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "BuddhistChronology[UTC]" + "'", str23.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        long long1 = instant0.getMillis();
//        org.joda.time.Instant instant2 = instant0.toInstant();
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        org.joda.time.Instant instant5 = instant0.withDurationAdded(readableDuration3, (int) (byte) -1);
//        org.joda.time.Instant instant7 = instant0.plus(2440588L);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560343547074L + "'", long1 == 1560343547074L);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant7);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(0L);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.millisOfDay();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.millisOfDay();
        org.joda.time.DurationField durationField4 = property3.getLeapDurationField();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNull(durationField4);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField7.getMaximumShortTextLength(locale8);
        org.joda.time.DateTimeField dateTimeField10 = delegatedDateTimeField7.getWrappedField();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(100);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.addCutover((int) (short) 1, ' ', (int) (byte) 0, 15, 4, false, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendHourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTwoDigitYear(15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        long long59 = offsetDateTimeField57.remainder(1560343537018L);
        try {
            long long62 = offsetDateTimeField57.add(1560343546296L, (long) 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2016 for secondOfMinute must be in the range [2000,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 37018L + "'", long59 == 37018L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        long long7 = julianChronology2.add((long) (byte) -1, 1560343546010L, 0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        try {
            long long29 = unsupportedDateTimeField26.set((long) 16, "January");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.DateTimeField dateTimeField12 = mutableDateTime9.getRoundingField();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNull(dateTimeField12);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.plusHours((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.weekOfWeekyear();
        mutableDateTime8.addYears(0);
        mutableDateTime8.addWeeks((int) (short) 1);
        int int16 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime8, "hi!", 12);
        try {
            org.joda.time.LocalDate localDate18 = dateTimeFormatter0.parseLocalDate("12");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"12\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-13) + "'", int16 == (-13));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        org.joda.time.ReadablePartial readablePartial28 = null;
        java.util.Locale locale30 = null;
        try {
            java.lang.String str31 = unsupportedDateTimeField26.getAsText(readablePartial28, 0, locale30);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, 69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology31);
        mutableDateTime32.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology37);
        boolean boolean39 = mutableDateTime32.isEqual((org.joda.time.ReadableInstant) mutableDateTime38);
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime32.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        mutableDateTime32.setChronology((org.joda.time.Chronology) julianChronology42);
        java.util.Locale locale44 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology42, locale44, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.JulianChronology julianChronology49 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone48);
        org.joda.time.MutableDateTime mutableDateTime50 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology49);
        int int51 = mutableDateTime50.getMillisOfSecond();
        mutableDateTime50.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long58 = dateTimeZone56.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone60);
        org.joda.time.MutableDateTime mutableDateTime62 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology61);
        mutableDateTime62.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone66);
        org.joda.time.MutableDateTime mutableDateTime68 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology67);
        boolean boolean69 = mutableDateTime62.isEqual((org.joda.time.ReadableInstant) mutableDateTime68);
        int int70 = mutableDateTime68.getMonthOfYear();
        org.joda.time.Chronology chronology71 = mutableDateTime68.getChronology();
        int int72 = dateTimeZone56.getOffset((org.joda.time.ReadableInstant) mutableDateTime68);
        mutableDateTime50.setZoneRetainFields(dateTimeZone56);
        dateTimeParserBucket46.setZone(dateTimeZone56);
        java.util.Locale locale75 = dateTimeParserBucket46.getLocale();
        try {
            java.lang.String str76 = unsupportedDateTimeField26.getAsShortText(4320000, locale75);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(julianChronology49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 999 + "'", int51 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 4320010L + "'", long58 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 12 + "'", int70 == 12);
        org.junit.Assert.assertNotNull(chronology71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 4320000 + "'", int72 == 4320000);
        org.junit.Assert.assertNotNull(locale75);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int[] intArray29 = null;
        try {
            int[] intArray31 = unsupportedDateTimeField26.addWrapField(readablePartial27, 15, intArray29, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "1969-12-18T14:59:59.999-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        int int10 = mutableDateTime9.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        mutableDateTime14.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology19);
        boolean boolean21 = mutableDateTime14.isEqual((org.joda.time.ReadableInstant) mutableDateTime20);
        int int22 = mutableDateTime20.getMinuteOfHour();
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime9, (org.joda.time.ReadableInstant) mutableDateTime20);
        boolean boolean24 = dateTime4.isBefore((org.joda.time.ReadableInstant) mutableDateTime9);
        mutableDateTime9.addMinutes((int) (byte) 1);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime9.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 59 + "'", int22 == 59);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(property27);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        java.lang.String str14 = property12.getAsShortText();
        int int15 = property12.getLeapAmount();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Dec" + "'", str14.equals("Dec"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset((int) 'a');
        java.io.OutputStream outputStream6 = null;
        try {
            dateTimeZoneBuilder4.writeTo("January", outputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology29);
        mutableDateTime30.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology35);
        boolean boolean37 = mutableDateTime30.isEqual((org.joda.time.ReadableInstant) mutableDateTime36);
        int int38 = mutableDateTime36.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime36.monthOfYear();
        java.lang.String str40 = property39.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime41 = property39.roundHalfFloor();
        org.joda.time.DurationField durationField42 = property39.getLeapDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField42);
        org.joda.time.ReadablePartial readablePartial44 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField48 = julianChronology47.seconds();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.JulianChronology julianChronology50 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone49);
        boolean boolean51 = julianChronology47.equals((java.lang.Object) julianChronology50);
        org.joda.time.DateTimeField dateTimeField52 = julianChronology47.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52);
        org.joda.time.ReadablePartial readablePartial54 = null;
        int[] intArray56 = new int[] { 2000 };
        int int57 = delegatedDateTimeField53.getMaximumValue(readablePartial54, intArray56);
        java.util.Locale locale58 = null;
        int int59 = delegatedDateTimeField53.getMaximumShortTextLength(locale58);
        org.joda.time.ReadablePartial readablePartial60 = null;
        int int61 = delegatedDateTimeField53.getMaximumValue(readablePartial60);
        org.joda.time.ReadablePartial readablePartial62 = null;
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.chrono.JulianChronology julianChronology65 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone64);
        org.joda.time.DurationField durationField66 = julianChronology65.seconds();
        org.joda.time.DateTimeZone dateTimeZone67 = null;
        org.joda.time.chrono.JulianChronology julianChronology68 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone67);
        boolean boolean69 = julianChronology65.equals((java.lang.Object) julianChronology68);
        org.joda.time.DateTimeField dateTimeField70 = julianChronology65.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField71 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField70);
        org.joda.time.ReadablePartial readablePartial72 = null;
        int[] intArray74 = new int[] { 2000 };
        int int75 = delegatedDateTimeField71.getMaximumValue(readablePartial72, intArray74);
        int[] intArray77 = delegatedDateTimeField53.addWrapPartial(readablePartial62, 2000, intArray74, 0);
        try {
            int[] intArray79 = unsupportedDateTimeField43.add(readablePartial44, (int) (short) 100, intArray77, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Dec" + "'", str40.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(julianChronology50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 59 + "'", int57 == 59);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 59 + "'", int61 == 59);
        org.junit.Assert.assertNotNull(julianChronology65);
        org.junit.Assert.assertNotNull(durationField66);
        org.junit.Assert.assertNotNull(julianChronology68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 59 + "'", int75 == 59);
        org.junit.Assert.assertNotNull(intArray77);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter3.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        long long59 = offsetDateTimeField57.remainder(1560343537018L);
        try {
            long long62 = offsetDateTimeField57.set((long) 4320000, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for secondOfMinute must be in the range [2000,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 37018L + "'", long59 == 37018L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = dateTime4.toCalendar(locale5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime4.withPeriodAdded(readablePeriod7, (int) (byte) 1);
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(calendar6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology29);
        mutableDateTime30.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology35);
        boolean boolean37 = mutableDateTime30.isEqual((org.joda.time.ReadableInstant) mutableDateTime36);
        int int38 = mutableDateTime36.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime36.monthOfYear();
        java.lang.String str40 = property39.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime41 = property39.roundHalfFloor();
        org.joda.time.DurationField durationField42 = property39.getLeapDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField42);
        boolean boolean44 = unsupportedDateTimeField43.isSupported();
        try {
            long long46 = unsupportedDateTimeField43.roundCeiling((long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Dec" + "'", str40.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime7 = property5.roundHalfFloorCopy();
//        org.joda.time.Instant instant8 = org.joda.time.Instant.now();
//        long long9 = instant8.getMillis();
//        org.joda.time.Instant instant10 = instant8.toInstant();
//        org.joda.time.Instant instant11 = instant10.toInstant();
//        boolean boolean12 = dateTime7.isBefore((org.joda.time.ReadableInstant) instant11);
//        try {
//            org.joda.time.DateTime dateTime16 = dateTime7.withDate((int) (short) -1, (int) (byte) -1, 7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(instant8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560343550661L + "'", long9 == 1560343550661L);
//        org.junit.Assert.assertNotNull(instant10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = julianChronology20.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        boolean boolean24 = julianChronology20.equals((java.lang.Object) julianChronology23);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology20.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int[] intArray29 = new int[] { 2000 };
        int int30 = delegatedDateTimeField26.getMaximumValue(readablePartial27, intArray29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField26.getAsText(12, locale32);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology14, (org.joda.time.DateTimeField) delegatedDateTimeField26);
        org.joda.time.ReadablePartial readablePartial35 = null;
        int int36 = skipDateTimeField34.getMinimumValue(readablePartial35);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipDateTimeField34.getAsShortText((long) 3, locale38);
        try {
            long long42 = skipDateTimeField34.set((long) (-13), "secondOfMinute");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"secondOfMinute\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 59 + "'", int30 == 59);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "12" + "'", str33.equals("12"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = julianChronology20.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        boolean boolean24 = julianChronology20.equals((java.lang.Object) julianChronology23);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology20.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int[] intArray29 = new int[] { 2000 };
        int int30 = delegatedDateTimeField26.getMaximumValue(readablePartial27, intArray29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField26.getAsText(12, locale32);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology14, (org.joda.time.DateTimeField) delegatedDateTimeField26);
        org.joda.time.ReadablePartial readablePartial35 = null;
        int int36 = skipDateTimeField34.getMinimumValue(readablePartial35);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipDateTimeField34.getAsShortText((long) 3, locale38);
        org.joda.time.DurationField durationField40 = skipDateTimeField34.getDurationField();
        org.joda.time.DurationFieldType durationFieldType41 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField43 = new org.joda.time.field.ScaledDurationField(durationField40, durationFieldType41, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 59 + "'", int30 == 59);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "12" + "'", str33.equals("12"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertNotNull(durationField40);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("2000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2000\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        try {
            java.lang.String str29 = unsupportedDateTimeField26.getAsShortText(28800052L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology2, locale4, (java.lang.Integer) 1969);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.weekyearOfCentury();
        java.lang.String str9 = gregorianChronology2.toString();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[UTC]" + "'", str9.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "BuddhistChronology[UTC]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("hi!", "BuddhistChronology[UTC]");
        java.lang.Number number6 = illegalFieldValueException5.getLowerBound();
        java.lang.Number number7 = illegalFieldValueException5.getUpperBound();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.Number number9 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        int int4 = mutableDateTime3.getMillisOfSecond();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime3.millisOfSecond();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 999 + "'", int4 == 999);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray10 = new int[] { 2000 };
        int int11 = delegatedDateTimeField7.getMaximumValue(readablePartial8, intArray10);
        java.util.Locale locale12 = null;
        int int13 = delegatedDateTimeField7.getMaximumShortTextLength(locale12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = delegatedDateTimeField7.getMaximumValue(readablePartial14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = julianChronology19.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        org.joda.time.ReadablePartial readablePartial26 = null;
        int[] intArray28 = new int[] { 2000 };
        int int29 = delegatedDateTimeField25.getMaximumValue(readablePartial26, intArray28);
        int[] intArray31 = delegatedDateTimeField7.addWrapPartial(readablePartial16, 2000, intArray28, 0);
        org.joda.time.ReadablePartial readablePartial32 = null;
        int int33 = delegatedDateTimeField7.getMinimumValue(readablePartial32);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 59 + "'", int15 == 59);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        mutableDateTime3.setChronology((org.joda.time.Chronology) julianChronology13);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime3.centuryOfEra();
        org.joda.time.Instant instant16 = mutableDateTime3.toInstant();
        try {
            mutableDateTime3.setDayOfYear((-13));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -13 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(instant16);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (byte) 0);
        int int7 = dateTime6.getDayOfYear();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.minus(readableDuration8);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 59 + "'", int7 == 59);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = julianChronology2.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        boolean boolean6 = julianChronology2.equals((java.lang.Object) julianChronology5);
        org.joda.time.DurationField durationField7 = julianChronology5.weekyears();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology5.dayOfYear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology12);
        mutableDateTime13.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology18);
        boolean boolean20 = mutableDateTime13.isEqual((org.joda.time.ReadableInstant) mutableDateTime19);
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime13.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        mutableDateTime13.setChronology((org.joda.time.Chronology) julianChronology23);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime13.centuryOfEra();
        org.joda.time.Instant instant26 = mutableDateTime13.toInstant();
        boolean boolean28 = mutableDateTime13.isAfter(1560343537018L);
        int int29 = mutableDateTime13.getYear();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone31);
        org.joda.time.MutableDateTime mutableDateTime33 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology32);
        mutableDateTime33.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone37);
        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology38);
        boolean boolean40 = mutableDateTime33.isEqual((org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.MutableDateTime.Property property41 = mutableDateTime33.secondOfMinute();
        try {
            org.joda.time.chrono.LimitChronology limitChronology42 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology5, (org.joda.time.ReadableDateTime) mutableDateTime13, (org.joda.time.ReadableDateTime) mutableDateTime33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(instant26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(property41);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        int int30 = unsupportedDateTimeField26.getDifference((long) 15, (long) 100);
        try {
            int int32 = unsupportedDateTimeField26.getMinimumValue((long) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology4);
        mutableDateTime5.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology10);
        boolean boolean12 = mutableDateTime5.isEqual((org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime5.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        mutableDateTime5.setChronology((org.joda.time.Chronology) julianChronology15);
        java.util.Locale locale17 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket19 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology15, locale17, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        int int24 = mutableDateTime23.getMillisOfSecond();
        mutableDateTime23.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long31 = dateTimeZone29.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone33);
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology34);
        mutableDateTime35.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.JulianChronology julianChronology40 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone39);
        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology40);
        boolean boolean42 = mutableDateTime35.isEqual((org.joda.time.ReadableInstant) mutableDateTime41);
        int int43 = mutableDateTime41.getMonthOfYear();
        org.joda.time.Chronology chronology44 = mutableDateTime41.getChronology();
        int int45 = dateTimeZone29.getOffset((org.joda.time.ReadableInstant) mutableDateTime41);
        mutableDateTime23.setZoneRetainFields(dateTimeZone29);
        dateTimeParserBucket19.setZone(dateTimeZone29);
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(59L, dateTimeZone29);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 999 + "'", int24 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 4320010L + "'", long31 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(julianChronology40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4320000 + "'", int45 == 4320000);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendHourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray13 = new org.joda.time.format.DateTimeParser[] {};
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.append(dateTimePrinter12, dateTimeParserArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeParserArray13);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendHourOfHalfday(4);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFixedSignedDecimal(dateTimeFieldType10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-1), 4320010L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-4320010) + "'", int2 == (-4320010));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.minuteOfDay();
        org.joda.time.DateTime.Property property6 = dateTime2.yearOfEra();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime2.withDurationAdded(readableDuration7, (int) '4');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("+01:12", "Dec", (int) ' ', (-1));
        org.joda.time.DateTime dateTime15 = dateTime9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.minusWeeks(0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 1, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatterBuilder5.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendClockhourOfDay(2000);
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTimeISO();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime6.withFieldAdded(durationFieldType8, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = julianChronology20.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        boolean boolean24 = julianChronology20.equals((java.lang.Object) julianChronology23);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology20.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int[] intArray29 = new int[] { 2000 };
        int int30 = delegatedDateTimeField26.getMaximumValue(readablePartial27, intArray29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField26.getAsText(12, locale32);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology14, (org.joda.time.DateTimeField) delegatedDateTimeField26);
        org.joda.time.ReadablePartial readablePartial35 = null;
        int int36 = skipDateTimeField34.getMinimumValue(readablePartial35);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone40);
        org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology41);
        mutableDateTime42.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        org.joda.time.MutableDateTime mutableDateTime48 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology47);
        boolean boolean49 = mutableDateTime42.isEqual((org.joda.time.ReadableInstant) mutableDateTime48);
        org.joda.time.MutableDateTime.Property property50 = mutableDateTime42.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone51);
        mutableDateTime42.setChronology((org.joda.time.Chronology) julianChronology52);
        java.util.Locale locale54 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology52, locale54, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.JulianChronology julianChronology59 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone58);
        org.joda.time.MutableDateTime mutableDateTime60 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology59);
        int int61 = mutableDateTime60.getMillisOfSecond();
        mutableDateTime60.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long68 = dateTimeZone66.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone70 = null;
        org.joda.time.chrono.JulianChronology julianChronology71 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone70);
        org.joda.time.MutableDateTime mutableDateTime72 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology71);
        mutableDateTime72.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone76 = null;
        org.joda.time.chrono.JulianChronology julianChronology77 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone76);
        org.joda.time.MutableDateTime mutableDateTime78 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology77);
        boolean boolean79 = mutableDateTime72.isEqual((org.joda.time.ReadableInstant) mutableDateTime78);
        int int80 = mutableDateTime78.getMonthOfYear();
        org.joda.time.Chronology chronology81 = mutableDateTime78.getChronology();
        int int82 = dateTimeZone66.getOffset((org.joda.time.ReadableInstant) mutableDateTime78);
        mutableDateTime60.setZoneRetainFields(dateTimeZone66);
        dateTimeParserBucket56.setZone(dateTimeZone66);
        java.util.Locale locale85 = dateTimeParserBucket56.getLocale();
        java.lang.String str86 = skipDateTimeField34.getAsShortText((long) 4, locale85);
        long long89 = skipDateTimeField34.set((long) (-1), (int) (short) 1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 59 + "'", int30 == 59);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "12" + "'", str33.equals("12"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(julianChronology41);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(julianChronology59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 999 + "'", int61 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 4320010L + "'", long68 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology71);
        org.junit.Assert.assertNotNull(julianChronology77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 12 + "'", int80 == 12);
        org.junit.Assert.assertNotNull(chronology81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 4320000 + "'", int82 == 4320000);
        org.junit.Assert.assertNotNull(locale85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "0" + "'", str86.equals("0"));
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + (-3480001L) + "'", long89 == (-3480001L));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(15);
        java.lang.Appendable appendable4 = null;
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            dateTimeFormatter0.printTo(appendable4, readablePartial5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime0.toMutableDateTime(dateTimeZone2);
//        java.lang.String str5 = mutableDateTime4.toString();
//        try {
//            mutableDateTime4.setMinuteOfHour(999);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-12T05:45:53.548-07:00" + "'", str5.equals("2019-06-12T05:45:53.548-07:00"));
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime14 = property12.roundHalfFloor();
        org.joda.time.DurationField durationField15 = property12.getLeapDurationField();
        org.joda.time.MutableDateTime mutableDateTime17 = property12.addWrapField(3);
        try {
            org.joda.time.MutableDateTime mutableDateTime19 = property12.add(1560343552844L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Magnitude of add amount is too large: 1560343552844");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(mutableDateTime17);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setFixedSavings("January", 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder5.addCutover(0, '#', (int) (byte) 10, (int) (short) 10, 4320000, true, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(1560343546010L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2458647L + "'", long1 == 2458647L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(4320000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfSecond(19);
        boolean boolean6 = dateTimeFormatterBuilder3.canBuildFormatter();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        mutableDateTime10.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology15);
        boolean boolean17 = mutableDateTime10.isEqual((org.joda.time.ReadableInstant) mutableDateTime16);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime10.secondOfMinute();
        java.lang.String str19 = property18.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType20, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType20, (int) ' ');
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder2.appendShortText(dateTimeFieldType20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendPattern("");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "secondOfMinute" + "'", str19.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        int int4 = mutableDateTime3.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology7);
        mutableDateTime8.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        boolean boolean15 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        int int16 = mutableDateTime14.getMinuteOfHour();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime3.era();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        mutableDateTime3.add(readablePeriod19, 4);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 999 + "'", int4 == 999);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getHourOfDay();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.year();
        int int13 = property12.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 292272992 + "'", int13 == 292272992);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (byte) 0);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.minus(readablePeriod7);
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withEra(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long4 = dateTimeZone2.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology7);
        mutableDateTime8.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        boolean boolean15 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        int int16 = mutableDateTime14.getMonthOfYear();
        org.joda.time.Chronology chronology17 = mutableDateTime14.getChronology();
        int int18 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int21 = gregorianChronology20.getMinimumDaysInFirstWeek();
        java.util.Locale locale22 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket24 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology20, locale22, (java.lang.Integer) 1969);
        java.util.TimeZone timeZone25 = null;
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forTimeZone(timeZone25);
        org.joda.time.Chronology chronology27 = gregorianChronology20.withZone(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology20.weekyear();
        mutableDateTime14.setRounding(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4320010L + "'", long4 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4320000 + "'", int18 == 4320000);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendWeekOfWeekyear((int) (byte) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendFractionOfMinute((-100), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        mutableDateTime3.setChronology((org.joda.time.Chronology) julianChronology13);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime3.centuryOfEra();
        org.joda.time.Instant instant16 = mutableDateTime3.toInstant();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime23 = dateTime21.plusHours((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime23.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime24.weekOfWeekyear();
        boolean boolean26 = mutableDateTime3.equals((java.lang.Object) property25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone28);
        org.joda.time.DateTime dateTime31 = dateTime29.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime33 = dateTime31.plusHours((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime34 = dateTime33.toMutableDateTimeISO();
        java.lang.String str35 = mutableDateTime34.toString();
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime34);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1969-02-28T16:00:00.100-08:00" + "'", str35.equals("1969-02-28T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(chronology36);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology29);
        mutableDateTime30.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology35);
        boolean boolean37 = mutableDateTime30.isEqual((org.joda.time.ReadableInstant) mutableDateTime36);
        int int38 = mutableDateTime36.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime36.monthOfYear();
        java.lang.String str40 = property39.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime41 = property39.roundHalfFloor();
        org.joda.time.DurationField durationField42 = property39.getLeapDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField42);
        boolean boolean44 = unsupportedDateTimeField43.isSupported();
        try {
            long long46 = unsupportedDateTimeField43.roundHalfFloor(100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Dec" + "'", str40.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumDate();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("1969", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology1, locale3, (java.lang.Integer) 1969);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        mutableDateTime9.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology14);
        boolean boolean16 = mutableDateTime9.isEqual((org.joda.time.ReadableInstant) mutableDateTime15);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime9.secondOfMinute();
        java.lang.String str18 = property17.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property17.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType19, (int) (short) 10, 1, 999);
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 1560343540608L, "secondOfMinute");
        dateTimeParserBucket5.saveField(dateTimeFieldType19, (int) (byte) 1);
        org.joda.time.Chronology chronology29 = dateTimeParserBucket5.getChronology();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "secondOfMinute" + "'", str18.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(chronology29);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2019-06-12T12:45:39.995Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(0L);
        int int2 = mutableDateTime1.getRoundingMode();
        mutableDateTime1.addMinutes(59);
        int int5 = mutableDateTime1.getYearOfCentury();
        mutableDateTime1.setMillis((long) 999);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology10);
        mutableDateTime11.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        boolean boolean18 = mutableDateTime11.isEqual((org.joda.time.ReadableInstant) mutableDateTime17);
        int int19 = mutableDateTime17.getMinuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        mutableDateTime23.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology28);
        boolean boolean30 = mutableDateTime23.isEqual((org.joda.time.ReadableInstant) mutableDateTime29);
        int int31 = mutableDateTime29.getHourOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone32);
        org.joda.time.MutableDateTime mutableDateTime34 = mutableDateTime29.toMutableDateTime((org.joda.time.Chronology) julianChronology33);
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime17, (org.joda.time.ReadableInstant) mutableDateTime34);
        mutableDateTime34.addMonths(0);
        boolean boolean38 = mutableDateTime1.isBefore((org.joda.time.ReadableInstant) mutableDateTime34);
        mutableDateTime34.setMillisOfSecond(2);
        boolean boolean41 = mutableDateTime34.isBeforeNow();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 59 + "'", int19 == 59);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(4320010L, 1560343535530L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560347855540L + "'", long2 == 1560347855540L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        int int4 = mutableDateTime3.getMillisOfSecond();
        mutableDateTime3.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long11 = dateTimeZone9.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology14);
        mutableDateTime15.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology20);
        boolean boolean22 = mutableDateTime15.isEqual((org.joda.time.ReadableInstant) mutableDateTime21);
        int int23 = mutableDateTime21.getMonthOfYear();
        org.joda.time.Chronology chronology24 = mutableDateTime21.getChronology();
        int int25 = dateTimeZone9.getOffset((org.joda.time.ReadableInstant) mutableDateTime21);
        mutableDateTime3.setZoneRetainFields(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 999 + "'", int4 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4320010L + "'", long11 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 12 + "'", int23 == 12);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4320000 + "'", int25 == 4320000);
        org.junit.Assert.assertNotNull(dateTimeZone27);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        long long7 = julianChronology2.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology2.minuteOfHour();
        try {
            long long16 = julianChronology2.getDateTimeMillis(4, 100, (-4320010), (int) (short) -1, 12, (-13), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField2 = gJChronology0.halfdays();
        long long5 = durationField2.subtract(2440588L, (int) ' ');
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1379959412L) + "'", long5 == (-1379959412L));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.yearOfEra();
        java.lang.String str6 = property5.getAsText();
        org.joda.time.DateTime dateTime7 = property5.roundHalfFloorCopy();
        int int8 = property5.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
        try {
            org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 16");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(4320000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-13));
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYearOfEra((-4320010), 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology4);
        mutableDateTime5.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology10);
        boolean boolean12 = mutableDateTime5.isEqual((org.joda.time.ReadableInstant) mutableDateTime11);
        int int13 = mutableDateTime11.getMonthOfYear();
        org.joda.time.Chronology chronology14 = mutableDateTime11.getChronology();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime11.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology18);
        mutableDateTime19.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology24);
        boolean boolean26 = mutableDateTime19.isEqual((org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime19.secondOfMinute();
        mutableDateTime11.setTime((org.joda.time.ReadableInstant) mutableDateTime19);
        mutableDateTime19.addDays((int) (short) 1);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime19.millisOfSecond();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) mutableDateTime19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(property31);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 100);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatterBuilder7.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimePrinter8);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("2019-06-12T12:45:39.995Z");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-06-12T12:45:39.995Z/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.halfdayOfDay();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis(0, 0, (-292275054), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime6 = dateTime2.plusMonths((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime2.hourOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("JulianChronology[America/Los_Angeles]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: JulianChronology[America/Los_Angeles]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendWeekOfWeekyear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendCenturyOfEra((int) ' ', (int) (short) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMinuteOfHour((-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        try {
            int[] intArray9 = julianChronology1.get(readablePeriod6, (long) '#', 28800052L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        boolean boolean6 = property5.isLeap();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime14 = property12.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime16 = property12.set(1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(mutableDateTime16);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        long long59 = offsetDateTimeField57.remainder(1560343537018L);
        org.joda.time.DateTimeField dateTimeField60 = offsetDateTimeField57.getWrappedField();
        org.joda.time.ReadablePartial readablePartial61 = null;
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.chrono.JulianChronology julianChronology63 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone62);
        org.joda.time.DurationField durationField64 = julianChronology63.seconds();
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.chrono.JulianChronology julianChronology66 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone65);
        boolean boolean67 = julianChronology63.equals((java.lang.Object) julianChronology66);
        org.joda.time.DateTimeField dateTimeField68 = julianChronology63.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField69 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField68);
        org.joda.time.ReadablePartial readablePartial70 = null;
        int[] intArray72 = new int[] { 2000 };
        int int73 = delegatedDateTimeField69.getMaximumValue(readablePartial70, intArray72);
        java.util.Locale locale74 = null;
        int int75 = delegatedDateTimeField69.getMaximumShortTextLength(locale74);
        org.joda.time.ReadablePartial readablePartial76 = null;
        int int77 = delegatedDateTimeField69.getMaximumValue(readablePartial76);
        org.joda.time.ReadablePartial readablePartial78 = null;
        org.joda.time.DateTimeZone dateTimeZone80 = null;
        org.joda.time.chrono.JulianChronology julianChronology81 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone80);
        org.joda.time.DurationField durationField82 = julianChronology81.seconds();
        org.joda.time.DateTimeZone dateTimeZone83 = null;
        org.joda.time.chrono.JulianChronology julianChronology84 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone83);
        boolean boolean85 = julianChronology81.equals((java.lang.Object) julianChronology84);
        org.joda.time.DateTimeField dateTimeField86 = julianChronology81.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField87 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField86);
        org.joda.time.ReadablePartial readablePartial88 = null;
        int[] intArray90 = new int[] { 2000 };
        int int91 = delegatedDateTimeField87.getMaximumValue(readablePartial88, intArray90);
        int[] intArray93 = delegatedDateTimeField69.addWrapPartial(readablePartial78, 2000, intArray90, 0);
        int int94 = offsetDateTimeField57.getMinimumValue(readablePartial61, intArray93);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 37018L + "'", long59 == 37018L);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(julianChronology63);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertNotNull(julianChronology66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 59 + "'", int73 == 59);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2 + "'", int75 == 2);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 59 + "'", int77 == 59);
        org.junit.Assert.assertNotNull(julianChronology81);
        org.junit.Assert.assertNotNull(durationField82);
        org.junit.Assert.assertNotNull(julianChronology84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(dateTimeField86);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 59 + "'", int91 == 59);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 2000 + "'", int94 == 2000);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendPattern("BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: B");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDate();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("GregorianChronology[UTC]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.minuteOfDay();
        org.joda.time.DateTime.Property property6 = dateTime2.yearOfEra();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime2.withDurationAdded(readableDuration7, (int) '4');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("+01:12", "Dec", (int) ' ', (-1));
        org.joda.time.DateTime dateTime15 = dateTime9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        try {
            org.joda.time.DateTime dateTime17 = dateTime9.withMonthOfYear((-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.Chronology chronology12 = mutableDateTime9.getChronology();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime9.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        mutableDateTime17.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        boolean boolean24 = mutableDateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime17.secondOfMinute();
        mutableDateTime9.setTime((org.joda.time.ReadableInstant) mutableDateTime17);
        mutableDateTime17.addDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology31);
        mutableDateTime32.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology37);
        boolean boolean39 = mutableDateTime32.isEqual((org.joda.time.ReadableInstant) mutableDateTime38);
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime32.secondOfMinute();
        java.lang.String str41 = property40.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property40.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType42, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.chrono.JulianChronology julianChronology48 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone47);
        org.joda.time.DurationField durationField49 = julianChronology48.seconds();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone50);
        boolean boolean52 = julianChronology48.equals((java.lang.Object) julianChronology51);
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology48.getZone();
        org.joda.time.DurationField durationField54 = julianChronology48.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField54);
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = unsupportedDateTimeField55.getType();
        org.joda.time.MutableDateTime.Property property57 = mutableDateTime17.property(dateTimeFieldType56);
        mutableDateTime17.addMinutes(16);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "secondOfMinute" + "'", str41.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(julianChronology48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertNotNull(property57);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        int int4 = mutableDateTime3.getMillisOfSecond();
        mutableDateTime3.setSecondOfDay((int) ' ');
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime3.secondOfMinute();
        org.joda.time.ReadableInstant readableInstant8 = null;
        try {
            int int9 = property7.compareTo(readableInstant8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 999 + "'", int4 == 999);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        int int30 = unsupportedDateTimeField26.getDifference(1560343535530L, (long) (short) 100);
        try {
            int int31 = unsupportedDateTimeField26.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 18059 + "'", int30 == 18059);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        try {
            long long8 = gJChronology0.getDateTimeMillis((int) (byte) 10, 1969, 4, 0, (int) (byte) 0, (-13), 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -13 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField7.getMaximumShortTextLength(locale8);
        org.joda.time.DateTimeField dateTimeField10 = delegatedDateTimeField7.getWrappedField();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider12 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        mutableDateTime17.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        boolean boolean24 = mutableDateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime17.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone26);
        mutableDateTime17.setChronology((org.joda.time.Chronology) julianChronology27);
        java.util.Locale locale29 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology27, locale29, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone33);
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology34);
        int int36 = mutableDateTime35.getMillisOfSecond();
        mutableDateTime35.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long43 = dateTimeZone41.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone45);
        org.joda.time.MutableDateTime mutableDateTime47 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology46);
        mutableDateTime47.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone51);
        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology52);
        boolean boolean54 = mutableDateTime47.isEqual((org.joda.time.ReadableInstant) mutableDateTime53);
        int int55 = mutableDateTime53.getMonthOfYear();
        org.joda.time.Chronology chronology56 = mutableDateTime53.getChronology();
        int int57 = dateTimeZone41.getOffset((org.joda.time.ReadableInstant) mutableDateTime53);
        mutableDateTime35.setZoneRetainFields(dateTimeZone41);
        dateTimeParserBucket31.setZone(dateTimeZone41);
        java.util.Locale locale60 = dateTimeParserBucket31.getLocale();
        java.lang.String str63 = defaultNameProvider12.getName(locale60, "JulianChronology[America/Los_Angeles]", "yearOfEra");
        java.lang.String str64 = delegatedDateTimeField7.getAsText(1560343546296L, locale60);
        org.joda.time.ReadablePartial readablePartial65 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone66);
        org.joda.time.DurationField durationField68 = julianChronology67.seconds();
        org.joda.time.DateTimeZone dateTimeZone69 = null;
        org.joda.time.chrono.JulianChronology julianChronology70 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone69);
        boolean boolean71 = julianChronology67.equals((java.lang.Object) julianChronology70);
        org.joda.time.DateTimeField dateTimeField72 = julianChronology67.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField73 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField72);
        org.joda.time.ReadablePartial readablePartial74 = null;
        int[] intArray76 = new int[] { 2000 };
        int int77 = delegatedDateTimeField73.getMaximumValue(readablePartial74, intArray76);
        int int78 = delegatedDateTimeField7.getMaximumValue(readablePartial65, intArray76);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 999 + "'", int36 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 4320010L + "'", long43 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology46);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 12 + "'", int55 == 12);
        org.junit.Assert.assertNotNull(chronology56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4320000 + "'", int57 == 4320000);
        org.junit.Assert.assertNotNull(locale60);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "45" + "'", str64.equals("45"));
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(julianChronology70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 59 + "'", int77 == 59);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 59 + "'", int78 == 59);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(352, 69, 12, 1969);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 421 + "'", int4 == 421);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        int int12 = mutableDateTime10.getMonthOfYear();
        org.joda.time.Chronology chronology13 = mutableDateTime10.getChronology();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime10.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology17);
        mutableDateTime18.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology23);
        boolean boolean25 = mutableDateTime18.isEqual((org.joda.time.ReadableInstant) mutableDateTime24);
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime18.secondOfMinute();
        mutableDateTime10.setTime((org.joda.time.ReadableInstant) mutableDateTime18);
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime10.weekOfWeekyear();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime10.secondOfDay();
        int int32 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "2019-06-12T05:45:39.578-07:00", 4320000);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-4320001) + "'", int32 == (-4320001));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime7 = property5.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime8 = property5.getDateTime();
        try {
            org.joda.time.DateTime dateTime10 = property5.setCopy("yearOfEra");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"yearOfEra\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        long long30 = unsupportedDateTimeField26.add((long) 5, (long) (short) 1);
        try {
            int int32 = unsupportedDateTimeField26.getMaximumValue(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 86400005L + "'", long30 == 86400005L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long4 = dateTimeZone2.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology7);
        mutableDateTime8.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        boolean boolean15 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        int int16 = mutableDateTime14.getMonthOfYear();
        org.joda.time.Chronology chronology17 = mutableDateTime14.getChronology();
        int int18 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime14.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        mutableDateTime23.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology28);
        boolean boolean30 = mutableDateTime23.isEqual((org.joda.time.ReadableInstant) mutableDateTime29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime23.secondOfMinute();
        java.lang.String str32 = property31.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property31.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType33, (int) (short) 10, 1, 999);
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 1560343540608L, "secondOfMinute");
        org.joda.time.MutableDateTime.Property property41 = mutableDateTime14.property(dateTimeFieldType33);
        mutableDateTime14.addMillis(45);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4320010L + "'", long4 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4320000 + "'", int18 == 4320000);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "secondOfMinute" + "'", str32.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property41);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        mutableDateTime3.setChronology((org.joda.time.Chronology) julianChronology13);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime3.centuryOfEra();
        org.joda.time.Instant instant16 = mutableDateTime3.toInstant();
        boolean boolean18 = mutableDateTime3.isAfter(1560343537018L);
        try {
            mutableDateTime3.setDate(59, 18059, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 18059 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (-4320010));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.4499998842d + "'", double1 == 2440587.4499998842d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        try {
            long long29 = unsupportedDateTimeField26.roundFloor(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = julianChronology20.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        boolean boolean24 = julianChronology20.equals((java.lang.Object) julianChronology23);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology20.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int[] intArray29 = new int[] { 2000 };
        int int30 = delegatedDateTimeField26.getMaximumValue(readablePartial27, intArray29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField26.getAsText(12, locale32);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology14, (org.joda.time.DateTimeField) delegatedDateTimeField26);
        try {
            long long37 = delegatedDateTimeField26.set((long) (byte) 1, (-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 59 + "'", int30 == 59);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "12" + "'", str33.equals("12"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            java.lang.String str3 = dateTimeFormatter0.print(readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        int int30 = unsupportedDateTimeField26.getDifference(1560343535530L, (long) (short) 100);
        try {
            long long33 = unsupportedDateTimeField26.set(0L, 999);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 18059 + "'", int30 == 18059);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMinuteOfHour();
        try {
            mutableDateTime9.setDayOfMonth(3600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3600000 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long11 = dateTimeZone9.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology14);
        mutableDateTime15.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology20);
        boolean boolean22 = mutableDateTime15.isEqual((org.joda.time.ReadableInstant) mutableDateTime21);
        int int23 = mutableDateTime21.getMonthOfYear();
        org.joda.time.Chronology chronology24 = mutableDateTime21.getChronology();
        int int25 = dateTimeZone9.getOffset((org.joda.time.ReadableInstant) mutableDateTime21);
        java.lang.String str27 = dateTimeZone9.getName(0L);
        try {
            org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime(3600000, 18059, (int) (byte) 0, 59, (int) (byte) -1, 0, 19, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4320010L + "'", long11 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 12 + "'", int23 == 12);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4320000 + "'", int25 == 4320000);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+01:12" + "'", str27.equals("+01:12"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(4320000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfSecond(19);
        boolean boolean6 = dateTimeFormatterBuilder3.canBuildFormatter();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        mutableDateTime10.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology15);
        boolean boolean17 = mutableDateTime10.isEqual((org.joda.time.ReadableInstant) mutableDateTime16);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime10.secondOfMinute();
        java.lang.String str19 = property18.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType20, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType20, (int) ' ');
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder2.appendShortText(dateTimeFieldType20);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendDayOfYear((-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "secondOfMinute" + "'", str19.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        java.lang.String str14 = property12.getAsShortText();
        org.joda.time.DurationField durationField15 = property12.getRangeDurationField();
        int int16 = property12.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Dec" + "'", str14.equals("Dec"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology1.year();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-1), (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime6 = dateTime2.plusMonths((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(readableDuration7, 10);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTimeZoneName(strMap8);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendPattern("yearOfEra");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(0L);
        mutableDateTime1.setMillis((long) (byte) 10);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.millisOfDay();
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology21);
        int int23 = mutableDateTime22.getMillisOfSecond();
        mutableDateTime22.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long30 = dateTimeZone28.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone32);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology33);
        mutableDateTime34.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38);
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology39);
        boolean boolean41 = mutableDateTime34.isEqual((org.joda.time.ReadableInstant) mutableDateTime40);
        int int42 = mutableDateTime40.getMonthOfYear();
        org.joda.time.Chronology chronology43 = mutableDateTime40.getChronology();
        int int44 = dateTimeZone28.getOffset((org.joda.time.ReadableInstant) mutableDateTime40);
        mutableDateTime22.setZoneRetainFields(dateTimeZone28);
        dateTimeParserBucket18.setZone(dateTimeZone28);
        java.util.Locale locale47 = dateTimeParserBucket18.getLocale();
        java.lang.Integer int48 = dateTimeParserBucket18.getOffsetInteger();
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 999 + "'", int23 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 4320010L + "'", long30 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 12 + "'", int42 == 12);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4320000 + "'", int44 == 4320000);
        org.junit.Assert.assertNotNull(locale47);
        org.junit.Assert.assertNull(int48);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        long long30 = unsupportedDateTimeField26.add((long) 5, (long) (short) 1);
        try {
            int int32 = unsupportedDateTimeField26.getLeapAmount(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 86400005L + "'", long30 == 86400005L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(4320000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay(1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendClockhourOfHalfday((int) '4');
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatterBuilder9.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        long long1 = instant0.getMillis();
        org.joda.time.Instant instant2 = instant0.toInstant();
        org.joda.time.Instant instant3 = instant2.toInstant();
        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTime();
        mutableDateTime4.addDays((int) (short) 100);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider8 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property14 = dateTime13.year();
        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField16 = property14.getField();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology20);
        mutableDateTime21.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone25);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology26);
        boolean boolean28 = mutableDateTime21.isEqual((org.joda.time.ReadableInstant) mutableDateTime27);
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime21.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        mutableDateTime21.setChronology((org.joda.time.Chronology) julianChronology31);
        java.util.Locale locale33 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology31, locale33, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone37);
        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology38);
        int int40 = mutableDateTime39.getMillisOfSecond();
        mutableDateTime39.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long47 = dateTimeZone45.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.JulianChronology julianChronology50 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone49);
        org.joda.time.MutableDateTime mutableDateTime51 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology50);
        mutableDateTime51.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.chrono.JulianChronology julianChronology56 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone55);
        org.joda.time.MutableDateTime mutableDateTime57 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology56);
        boolean boolean58 = mutableDateTime51.isEqual((org.joda.time.ReadableInstant) mutableDateTime57);
        int int59 = mutableDateTime57.getMonthOfYear();
        org.joda.time.Chronology chronology60 = mutableDateTime57.getChronology();
        int int61 = dateTimeZone45.getOffset((org.joda.time.ReadableInstant) mutableDateTime57);
        mutableDateTime39.setZoneRetainFields(dateTimeZone45);
        dateTimeParserBucket35.setZone(dateTimeZone45);
        java.util.Locale locale64 = dateTimeParserBucket35.getLocale();
        java.lang.String str65 = property14.getAsText(locale64);
        java.lang.String str68 = defaultNameProvider8.getName(locale64, "", "2019-06-12T05:45:50.230-07:00");
        try {
            java.lang.String str69 = mutableDateTime4.toString("January", locale64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 999 + "'", int40 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 4320010L + "'", long47 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology50);
        org.junit.Assert.assertNotNull(julianChronology56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 12 + "'", int59 == 12);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 4320000 + "'", int61 == 4320000);
        org.junit.Assert.assertNotNull(locale64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "1969" + "'", str65.equals("1969"));
        org.junit.Assert.assertNull(str68);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology29);
        mutableDateTime30.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology35);
        boolean boolean37 = mutableDateTime30.isEqual((org.joda.time.ReadableInstant) mutableDateTime36);
        int int38 = mutableDateTime36.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime36.monthOfYear();
        java.lang.String str40 = property39.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime41 = property39.roundHalfFloor();
        org.joda.time.DurationField durationField42 = property39.getLeapDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField42);
        try {
            long long45 = unsupportedDateTimeField43.roundHalfCeiling((long) (-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Dec" + "'", str40.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "BuddhistChronology[UTC]");
        illegalFieldValueException2.prependMessage("");
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.year();
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean11 = gregorianChronology7.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology7.getZone();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) (short) 1, 10, (int) (byte) 10, 1969, 2000, (int) 'a', (int) (byte) 0, dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology1.getZone();
        org.joda.time.DurationField durationField7 = julianChronology1.days();
        org.joda.time.Chronology chronology8 = julianChronology1.withUTC();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+01:12", "Dec", (int) ' ', (-1));
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 16);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey(1560343538891L);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Dec" + "'", str8.equals("Dec"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime6 = dateTime2.plusYears(0);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTime();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology12);
        int int14 = mutableDateTime13.getMillisOfSecond();
        mutableDateTime13.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long21 = dateTimeZone19.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology24);
        mutableDateTime25.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology30);
        boolean boolean32 = mutableDateTime25.isEqual((org.joda.time.ReadableInstant) mutableDateTime31);
        int int33 = mutableDateTime31.getMonthOfYear();
        org.joda.time.Chronology chronology34 = mutableDateTime31.getChronology();
        int int35 = dateTimeZone19.getOffset((org.joda.time.ReadableInstant) mutableDateTime31);
        mutableDateTime13.setZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTime dateTime37 = dateTime9.withZone(dateTimeZone19);
        try {
            org.joda.time.DateTime dateTime41 = dateTime9.withDate(292272992, 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 999 + "'", int14 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 4320010L + "'", long21 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4320000 + "'", int35 == 4320000);
        org.junit.Assert.assertNotNull(dateTime37);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.months();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        boolean boolean7 = dateTime5.isAfter(1560343538891L);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.minus(readablePeriod8);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(1560343537018L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getHourOfDay();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.year();
        mutableDateTime9.setYear(5);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        int int30 = unsupportedDateTimeField26.getDifference(1560343535530L, (long) (short) 100);
        org.joda.time.DurationField durationField31 = unsupportedDateTimeField26.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial32 = null;
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone33);
        org.joda.time.DurationField durationField35 = julianChronology34.seconds();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        boolean boolean38 = julianChronology34.equals((java.lang.Object) julianChronology37);
        org.joda.time.DateTimeField dateTimeField39 = julianChronology34.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39);
        java.util.Locale locale41 = null;
        int int42 = delegatedDateTimeField40.getMaximumShortTextLength(locale41);
        long long44 = delegatedDateTimeField40.roundFloor(1560343540608L);
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField48 = julianChronology47.seconds();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.JulianChronology julianChronology50 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone49);
        boolean boolean51 = julianChronology47.equals((java.lang.Object) julianChronology50);
        org.joda.time.DateTimeField dateTimeField52 = julianChronology47.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52);
        org.joda.time.ReadablePartial readablePartial54 = null;
        int[] intArray56 = new int[] { 2000 };
        int int57 = delegatedDateTimeField53.getMaximumValue(readablePartial54, intArray56);
        int int58 = delegatedDateTimeField40.getMinimumValue(readablePartial45, intArray56);
        try {
            int int59 = unsupportedDateTimeField26.getMinimumValue(readablePartial32, intArray56);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 18059 + "'", int30 == 18059);
        org.junit.Assert.assertNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560343500000L + "'", long44 == 1560343500000L);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(julianChronology50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 59 + "'", int57 == 59);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime0.toMutableDateTime(dateTimeZone2);
        boolean boolean5 = mutableDateTime4.isEqualNow();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 18059);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DurationField durationField6 = julianChronology4.millis();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology4.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology4.weekOfWeekyear();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long4 = dateTimeZone2.convertUTCToLocal((long) 10);
        int int6 = dateTimeZone2.getOffsetFromLocal((-26005725L));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4320010L + "'", long4 == 4320010L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4320000 + "'", int6 == 4320000);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        int int3 = dateTime2.getSecondOfMinute();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays(1969);
        java.lang.Object obj6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int9 = gregorianChronology8.getMinimumDaysInFirstWeek();
        java.util.Locale locale10 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology8, locale10, (java.lang.Integer) 1969);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(obj6, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology8.weekyearOfCentury();
        try {
            org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((java.lang.Object) 1969, (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        int int30 = unsupportedDateTimeField26.getDifference((long) 15, (long) 100);
        try {
            int int31 = unsupportedDateTimeField26.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DurationField durationField4 = julianChronology2.millis();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter0.getPrinter();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology6);
        mutableDateTime7.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology12);
        boolean boolean14 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) mutableDateTime13);
        int int15 = mutableDateTime13.getHourOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MutableDateTime mutableDateTime18 = mutableDateTime13.toMutableDateTime((org.joda.time.Chronology) julianChronology17);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime13.secondOfMinute();
        java.lang.String str20 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime13);
        java.lang.String str21 = mutableDateTime13.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "155959-0800" + "'", str20.equals("155959-0800"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1969-12-18T15:59:59.999-08:00" + "'", str21.equals("1969-12-18T15:59:59.999-08:00"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        try {
            int int29 = unsupportedDateTimeField26.getMaximumValue((long) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        long long1 = instant0.getMillis();
        org.joda.time.Instant instant2 = instant0.toInstant();
        org.joda.time.Instant instant4 = instant2.plus((long) (byte) -1);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.months();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        boolean boolean7 = dateTime5.isAfter(1560343538891L);
        try {
            org.joda.time.DateTime dateTime9 = dateTime5.withYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        boolean boolean3 = buddhistChronology0.equals((java.lang.Object) (short) 0);
        java.lang.String str4 = buddhistChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = julianChronology6.seconds();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = julianChronology6.equals((java.lang.Object) julianChronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology6.getZone();
        org.joda.time.Chronology chronology12 = buddhistChronology0.withZone(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = buddhistChronology0.withZone(dateTimeZone13);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BuddhistChronology[UTC]" + "'", str4.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.halfdayOfDay();
        java.lang.String str7 = gregorianChronology0.toString();
        int int8 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 4320000);
        long long15 = skipUndoDateTimeField12.set(1560343544324L, 3);
        try {
            long long18 = skipUndoDateTimeField12.set((-33119999L), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfDay must be in the range [1,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[UTC]" + "'", str7.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560297600002L + "'", long15 == 1560297600002L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology1, locale3, (java.lang.Integer) 1969);
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology1.weekyear();
        int int10 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology1.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-100), 15, 5, 3, 19, (int) (byte) 0, 45);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray10 = new int[] { 2000 };
        int int11 = delegatedDateTimeField7.getMaximumValue(readablePartial8, intArray10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = delegatedDateTimeField7.getAsText(2000, locale13);
        org.joda.time.DurationField durationField15 = delegatedDateTimeField7.getLeapDurationField();
        java.lang.String str16 = delegatedDateTimeField7.toString();
        int int17 = delegatedDateTimeField7.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2000" + "'", str14.equals("2000"));
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str16.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("1969-12-31T16:00:00.100-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T16:00:00.100-08:00\" is malformed at \"-12-31T16:00:00.100-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long4 = dateTimeZone2.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology7);
        mutableDateTime8.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        boolean boolean15 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        int int16 = mutableDateTime14.getMonthOfYear();
        org.joda.time.Chronology chronology17 = mutableDateTime14.getChronology();
        int int18 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) mutableDateTime14);
        java.lang.String str20 = dateTimeZone2.getName(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        java.lang.Object obj22 = null;
        boolean boolean23 = cachedDateTimeZone21.equals(obj22);
        int int25 = cachedDateTimeZone21.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology28);
        mutableDateTime29.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone33);
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology34);
        boolean boolean36 = mutableDateTime29.isEqual((org.joda.time.ReadableInstant) mutableDateTime35);
        int int37 = mutableDateTime35.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property38 = mutableDateTime35.monthOfYear();
        java.lang.String str39 = property38.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime40 = property38.roundHalfFloor();
        org.joda.time.DurationField durationField41 = property38.getLeapDurationField();
        boolean boolean42 = cachedDateTimeZone21.equals((java.lang.Object) durationField41);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4320010L + "'", long4 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4320000 + "'", int18 == 4320000);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+01:12" + "'", str20.equals("+01:12"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4320000 + "'", int25 == 4320000);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 12 + "'", int37 == 12);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Dec" + "'", str39.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        long long59 = offsetDateTimeField57.remainder(1560343537018L);
        long long61 = offsetDateTimeField57.roundHalfFloor((long) 59);
        int int63 = offsetDateTimeField57.getMinimumValue((long) (byte) 10);
        try {
            long long66 = offsetDateTimeField57.add((long) 292272992, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1984 for secondOfMinute must be in the range [2000,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 37018L + "'", long59 == 37018L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2000 + "'", int63 == 2000);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField7.getMaximumShortTextLength(locale8);
        org.joda.time.DateTimeField dateTimeField10 = delegatedDateTimeField7.getWrappedField();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider11 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology15);
        mutableDateTime16.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology21);
        boolean boolean23 = mutableDateTime16.isEqual((org.joda.time.ReadableInstant) mutableDateTime22);
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime16.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone25);
        mutableDateTime16.setChronology((org.joda.time.Chronology) julianChronology26);
        java.util.Locale locale28 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket30 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology26, locale28, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone32);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology33);
        int int35 = mutableDateTime34.getMillisOfSecond();
        mutableDateTime34.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long42 = dateTimeZone40.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.JulianChronology julianChronology45 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone44);
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology45);
        mutableDateTime46.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone50);
        org.joda.time.MutableDateTime mutableDateTime52 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology51);
        boolean boolean53 = mutableDateTime46.isEqual((org.joda.time.ReadableInstant) mutableDateTime52);
        int int54 = mutableDateTime52.getMonthOfYear();
        org.joda.time.Chronology chronology55 = mutableDateTime52.getChronology();
        int int56 = dateTimeZone40.getOffset((org.joda.time.ReadableInstant) mutableDateTime52);
        mutableDateTime34.setZoneRetainFields(dateTimeZone40);
        dateTimeParserBucket30.setZone(dateTimeZone40);
        java.util.Locale locale59 = dateTimeParserBucket30.getLocale();
        java.lang.String str62 = defaultNameProvider11.getName(locale59, "JulianChronology[America/Los_Angeles]", "yearOfEra");
        int int63 = delegatedDateTimeField7.getMaximumTextLength(locale59);
        java.lang.String str65 = delegatedDateTimeField7.getAsShortText((long) (byte) 0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 999 + "'", int35 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 4320010L + "'", long42 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology45);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 12 + "'", int54 == 12);
        org.junit.Assert.assertNotNull(chronology55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4320000 + "'", int56 == 4320000);
        org.junit.Assert.assertNotNull(locale59);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "0" + "'", str65.equals("0"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(2458647L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5284565627d + "'", double1 == 2440587.5284565627d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        long long1 = instant0.getMillis();
        org.joda.time.Instant instant2 = instant0.toInstant();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant5 = instant0.withDurationAdded(readableDuration3, (int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant5.minus(readableDuration6);
        org.joda.time.MutableDateTime mutableDateTime8 = instant7.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfMinute();
        try {
            org.joda.time.MutableDateTime mutableDateTime11 = property9.set(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "BuddhistChronology[UTC]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("hi!", "BuddhistChronology[UTC]");
        java.lang.Number number6 = illegalFieldValueException5.getLowerBound();
        java.lang.Number number7 = illegalFieldValueException5.getUpperBound();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.String str9 = illegalFieldValueException5.getIllegalStringValue();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BuddhistChronology[UTC]" + "'", str9.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.halfdayOfDay();
        java.lang.String str7 = gregorianChronology0.toString();
        int int8 = gregorianChronology0.getMinimumDaysInFirstWeek();
        try {
            long long13 = gregorianChronology0.getDateTimeMillis(2000, 4, 1969, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[UTC]" + "'", str7.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        int int12 = mutableDateTime10.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime10.monthOfYear();
        java.lang.String str14 = property13.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime15 = property13.roundHalfFloor();
        mutableDateTime15.setTime((long) 12);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology20);
        mutableDateTime21.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone25);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology26);
        boolean boolean28 = mutableDateTime21.isEqual((org.joda.time.ReadableInstant) mutableDateTime27);
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime21.secondOfMinute();
        java.lang.String str30 = property29.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property29.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType31, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        org.joda.time.DurationField durationField38 = julianChronology37.seconds();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.JulianChronology julianChronology40 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone39);
        boolean boolean41 = julianChronology37.equals((java.lang.Object) julianChronology40);
        org.joda.time.DateTimeZone dateTimeZone42 = julianChronology37.getZone();
        org.joda.time.DurationField durationField43 = julianChronology37.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType31, durationField43);
        int int45 = mutableDateTime15.get(dateTimeFieldType31);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField46 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Dec" + "'", str14.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "secondOfMinute" + "'", str30.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(julianChronology40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField7.getMaximumShortTextLength(locale8);
        long long11 = delegatedDateTimeField7.roundFloor(1560343540608L);
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = julianChronology14.seconds();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        boolean boolean18 = julianChronology14.equals((java.lang.Object) julianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology14.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int[] intArray23 = new int[] { 2000 };
        int int24 = delegatedDateTimeField20.getMaximumValue(readablePartial21, intArray23);
        int int25 = delegatedDateTimeField7.getMinimumValue(readablePartial12, intArray23);
        long long28 = delegatedDateTimeField7.add(1560343555771L, 45);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560343500000L + "'", long11 == 1560343500000L);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 59 + "'", int24 == 59);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560346255771L + "'", long28 == 1560346255771L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("2019-06-12T05:45:50.230-07:00", 999, (int) (byte) 0, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for 2019-06-12T05:45:50.230-07:00 must be in the range [0,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfDay();
        try {
            long long7 = gJChronology0.getDateTimeMillis((long) (short) 10, (int) '#', 0, (int) 'a', (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-52) + "'", int1 == (-52));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        int int3 = dateTime2.getSecondOfMinute();
        org.joda.time.DateTime dateTime5 = dateTime2.plusDays(3600000);
        org.joda.time.DateTime dateTime6 = dateTime2.withTimeAtStartOfDay();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatterBuilder5.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendTwoDigitYear(7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.halfdayOfDay();
        java.lang.String str7 = gregorianChronology0.toString();
        int int8 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 4320000);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = julianChronology16.seconds();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        boolean boolean20 = julianChronology16.equals((java.lang.Object) julianChronology19);
        org.joda.time.DateTimeField dateTimeField21 = julianChronology16.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int[] intArray25 = new int[] { 2000 };
        int int26 = delegatedDateTimeField22.getMaximumValue(readablePartial23, intArray25);
        try {
            int[] intArray28 = skipUndoDateTimeField12.addWrapField(readablePartial13, (int) (byte) -1, intArray25, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[UTC]" + "'", str7.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 59 + "'", int26 == 59);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.minuteOfDay();
        org.joda.time.DateTime.Property property6 = dateTime2.yearOfEra();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime2.withDurationAdded(readableDuration7, (int) '4');
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str11 = buddhistChronology10.toString();
        boolean boolean13 = buddhistChronology10.equals((java.lang.Object) (short) 0);
        java.lang.String str14 = buddhistChronology10.toString();
        boolean boolean15 = dateTime2.equals((java.lang.Object) buddhistChronology10);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime(0L);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.millisOfDay();
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime17.millisOfDay();
        boolean boolean20 = buddhistChronology10.equals((java.lang.Object) property19);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("2000", "Dec", 19, (int) (byte) 0);
        java.util.TimeZone timeZone26 = fixedDateTimeZone25.toTimeZone();
        java.lang.String str28 = fixedDateTimeZone25.getNameKey((long) ' ');
        org.joda.time.Chronology chronology29 = buddhistChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology10.minuteOfDay();
        java.lang.Object obj31 = null;
        boolean boolean32 = buddhistChronology10.equals(obj31);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BuddhistChronology[UTC]" + "'", str11.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "BuddhistChronology[UTC]" + "'", str14.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Dec" + "'", str28.equals("Dec"));
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        long long30 = unsupportedDateTimeField26.add((long) 5, (long) (short) 1);
        org.joda.time.ReadablePartial readablePartial31 = null;
        try {
            int int32 = unsupportedDateTimeField26.getMinimumValue(readablePartial31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 86400005L + "'", long30 == 86400005L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.DurationField durationField3 = buddhistChronology1.minutes();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField4 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfDay();
        try {
            long long9 = gJChronology0.getDateTimeMillis((int) (byte) 10, (int) (byte) -1, 32, 3, (-1), (int) (byte) 10, 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(4320000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+01:12", "Dec", (int) ' ', (-1));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str7 = fixedDateTimeZone4.getNameKey((long) 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Dec" + "'", str7.equals("Dec"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+01:12", "Dec", (int) ' ', (-1));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        int int30 = unsupportedDateTimeField26.getDifference((long) 15, (long) 100);
        try {
            long long33 = unsupportedDateTimeField26.addWrapField((long) 2, 421);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        long long59 = offsetDateTimeField57.remainder(1560343537018L);
        int int60 = offsetDateTimeField57.getMaximumValue();
        int int62 = offsetDateTimeField57.getMinimumValue((long) 7);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 37018L + "'", long59 == 37018L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 12 + "'", int60 == 12);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2000 + "'", int62 == 2000);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendHourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology5);
        mutableDateTime6.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology11);
        boolean boolean13 = mutableDateTime6.isEqual((org.joda.time.ReadableInstant) mutableDateTime12);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime6.secondOfMinute();
        java.lang.String str15 = property14.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType16, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType16, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendEraText();
        org.joda.time.format.DateTimePrinter dateTimePrinter24 = dateTimeFormatterBuilder23.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "secondOfMinute" + "'", str15.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimePrinter24);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        mutableDateTime3.setChronology((org.joda.time.Chronology) julianChronology13);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime3.centuryOfEra();
        org.joda.time.Instant instant16 = mutableDateTime3.toInstant();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime23 = dateTime21.plusHours((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime23.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime24.weekOfWeekyear();
        boolean boolean26 = mutableDateTime3.equals((java.lang.Object) property25);
        org.joda.time.ReadablePartial readablePartial27 = null;
        try {
            int int28 = property25.compareTo(readablePartial27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
//        mutableDateTime3.addHours((-1));
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
//        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
//        java.lang.String str12 = property11.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
//        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
//        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
//        org.joda.time.DurationField durationField25 = julianChronology19.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
//        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology31);
//        mutableDateTime32.addHours((-1));
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
//        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology37);
//        boolean boolean39 = mutableDateTime32.isEqual((org.joda.time.ReadableInstant) mutableDateTime38);
//        int int40 = mutableDateTime38.getMonthOfYear();
//        org.joda.time.MutableDateTime.Property property41 = mutableDateTime38.monthOfYear();
//        java.lang.String str42 = property41.getAsShortText();
//        java.lang.String str43 = property41.getAsShortText();
//        org.joda.time.DurationField durationField44 = property41.getRangeDurationField();
//        java.lang.String str45 = property41.getAsString();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.chrono.JulianChronology julianChronology49 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone48);
//        org.joda.time.MutableDateTime mutableDateTime50 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology49);
//        mutableDateTime50.addHours((-1));
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone54);
//        org.joda.time.MutableDateTime mutableDateTime56 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology55);
//        boolean boolean57 = mutableDateTime50.isEqual((org.joda.time.ReadableInstant) mutableDateTime56);
//        org.joda.time.MutableDateTime.Property property58 = mutableDateTime50.secondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone59 = null;
//        org.joda.time.chrono.JulianChronology julianChronology60 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone59);
//        mutableDateTime50.setChronology((org.joda.time.Chronology) julianChronology60);
//        java.util.Locale locale62 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket64 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology60, locale62, (java.lang.Integer) 59);
//        org.joda.time.DateTimeZone dateTimeZone66 = null;
//        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone66);
//        org.joda.time.MutableDateTime mutableDateTime68 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology67);
//        int int69 = mutableDateTime68.getMillisOfSecond();
//        mutableDateTime68.setSecondOfDay((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone74 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
//        long long76 = dateTimeZone74.convertUTCToLocal((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone78 = null;
//        org.joda.time.chrono.JulianChronology julianChronology79 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone78);
//        org.joda.time.MutableDateTime mutableDateTime80 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology79);
//        mutableDateTime80.addHours((-1));
//        org.joda.time.DateTimeZone dateTimeZone84 = null;
//        org.joda.time.chrono.JulianChronology julianChronology85 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone84);
//        org.joda.time.MutableDateTime mutableDateTime86 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology85);
//        boolean boolean87 = mutableDateTime80.isEqual((org.joda.time.ReadableInstant) mutableDateTime86);
//        int int88 = mutableDateTime86.getMonthOfYear();
//        org.joda.time.Chronology chronology89 = mutableDateTime86.getChronology();
//        int int90 = dateTimeZone74.getOffset((org.joda.time.ReadableInstant) mutableDateTime86);
//        mutableDateTime68.setZoneRetainFields(dateTimeZone74);
//        dateTimeParserBucket64.setZone(dateTimeZone74);
//        java.util.Locale locale93 = dateTimeParserBucket64.getLocale();
//        java.lang.String str94 = property41.getAsShortText(locale93);
//        java.lang.String str95 = dateTimeZone27.getName(0L, locale93);
//        try {
//            int int96 = unsupportedDateTimeField26.getMaximumShortTextLength(locale93);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(julianChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(julianChronology31);
//        org.junit.Assert.assertNotNull(julianChronology37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 12 + "'", int40 == 12);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Dec" + "'", str42.equals("Dec"));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Dec" + "'", str43.equals("Dec"));
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "12" + "'", str45.equals("12"));
//        org.junit.Assert.assertNotNull(julianChronology49);
//        org.junit.Assert.assertNotNull(julianChronology55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(julianChronology60);
//        org.junit.Assert.assertNotNull(julianChronology67);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 999 + "'", int69 == 999);
//        org.junit.Assert.assertNotNull(dateTimeZone74);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 4320010L + "'", long76 == 4320010L);
//        org.junit.Assert.assertNotNull(julianChronology79);
//        org.junit.Assert.assertNotNull(julianChronology85);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 12 + "'", int88 == 12);
//        org.junit.Assert.assertNotNull(chronology89);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 4320000 + "'", int90 == 4320000);
//        org.junit.Assert.assertNotNull(locale93);
//        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "Dec" + "'", str94.equals("Dec"));
//        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "Coordinated Universal Time" + "'", str95.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        int int4 = mutableDateTime3.getMillisOfSecond();
        mutableDateTime3.setSecondOfDay((int) ' ');
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime3.secondOfMinute();
        int int8 = mutableDateTime3.getMinuteOfHour();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 999 + "'", int4 == 999);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560343555771L, (long) 59);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 92060269790489L + "'", long2 == 92060269790489L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DurationField durationField6 = julianChronology4.weekyears();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField9 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType7, (-33));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        java.lang.String str1 = mutableDateTime0.toString();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.dayOfMonth();
        try {
            mutableDateTime0.setSecondOfMinute((-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str1.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime6 = dateTime2.plusYears(0);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        int int8 = dateTime6.getHourOfDay();
        org.joda.time.DateTime dateTime9 = dateTime6.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime11 = dateTime6.minus(9L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(53999);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology29);
        mutableDateTime30.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology35);
        boolean boolean37 = mutableDateTime30.isEqual((org.joda.time.ReadableInstant) mutableDateTime36);
        int int38 = mutableDateTime36.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime36.monthOfYear();
        java.lang.String str40 = property39.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime41 = property39.roundHalfFloor();
        org.joda.time.DurationField durationField42 = property39.getLeapDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField42);
        try {
            boolean boolean45 = unsupportedDateTimeField43.isLeap((long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Dec" + "'", str40.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setFixedSavings("January", 0);
        java.io.OutputStream outputStream7 = null;
        try {
            dateTimeZoneBuilder0.writeTo("DateTimeField[secondOfMinute]", outputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter0.getPrinter();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology6);
        mutableDateTime7.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology12);
        boolean boolean14 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) mutableDateTime13);
        int int15 = mutableDateTime13.getHourOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MutableDateTime mutableDateTime18 = mutableDateTime13.toMutableDateTime((org.joda.time.Chronology) julianChronology17);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime13.secondOfMinute();
        java.lang.String str20 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 57600100);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "155959-0800" + "'", str20.equals("155959-0800"));
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        long long59 = offsetDateTimeField57.remainder(1560343537018L);
        long long61 = offsetDateTimeField57.roundHalfFloor((long) 59);
        long long63 = offsetDateTimeField57.roundHalfCeiling((long) 53999);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 37018L + "'", long59 == 37018L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 60000L + "'", long63 == 60000L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(421);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.months();
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            long long5 = julianChronology1.set(readablePartial3, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(4320000, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 4320000");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        long long59 = offsetDateTimeField57.remainder(1560343537018L);
        org.joda.time.DateTimeField dateTimeField60 = offsetDateTimeField57.getWrappedField();
        long long62 = offsetDateTimeField57.roundCeiling((long) 7);
        int int64 = offsetDateTimeField57.get(31507200100L);
        org.joda.time.ReadablePartial readablePartial65 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone66);
        org.joda.time.DurationField durationField68 = julianChronology67.seconds();
        org.joda.time.DateTimeZone dateTimeZone69 = null;
        org.joda.time.chrono.JulianChronology julianChronology70 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone69);
        boolean boolean71 = julianChronology67.equals((java.lang.Object) julianChronology70);
        org.joda.time.DateTimeField dateTimeField72 = julianChronology67.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField73 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField72);
        org.joda.time.ReadablePartial readablePartial74 = null;
        int[] intArray76 = new int[] { 2000 };
        int int77 = delegatedDateTimeField73.getMaximumValue(readablePartial74, intArray76);
        java.util.Locale locale78 = null;
        int int79 = delegatedDateTimeField73.getMaximumShortTextLength(locale78);
        org.joda.time.ReadablePartial readablePartial80 = null;
        int int81 = delegatedDateTimeField73.getMaximumValue(readablePartial80);
        org.joda.time.ReadablePartial readablePartial82 = null;
        org.joda.time.DateTimeZone dateTimeZone84 = null;
        org.joda.time.chrono.JulianChronology julianChronology85 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone84);
        org.joda.time.DurationField durationField86 = julianChronology85.seconds();
        org.joda.time.DateTimeZone dateTimeZone87 = null;
        org.joda.time.chrono.JulianChronology julianChronology88 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone87);
        boolean boolean89 = julianChronology85.equals((java.lang.Object) julianChronology88);
        org.joda.time.DateTimeField dateTimeField90 = julianChronology85.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField91 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField90);
        org.joda.time.ReadablePartial readablePartial92 = null;
        int[] intArray94 = new int[] { 2000 };
        int int95 = delegatedDateTimeField91.getMaximumValue(readablePartial92, intArray94);
        int[] intArray97 = delegatedDateTimeField73.addWrapPartial(readablePartial82, 2000, intArray94, 0);
        int int98 = offsetDateTimeField57.getMinimumValue(readablePartial65, intArray97);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 37018L + "'", long59 == 37018L);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 60000L + "'", long62 == 60000L);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1969 + "'", int64 == 1969);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(julianChronology70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 59 + "'", int77 == 59);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2 + "'", int79 == 2);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 59 + "'", int81 == 59);
        org.junit.Assert.assertNotNull(julianChronology85);
        org.junit.Assert.assertNotNull(durationField86);
        org.junit.Assert.assertNotNull(julianChronology88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertNotNull(dateTimeField90);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 59 + "'", int95 == 59);
        org.junit.Assert.assertNotNull(intArray97);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 2000 + "'", int98 == 2000);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (-292275054));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.Chronology chronology12 = mutableDateTime9.getChronology();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime9.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        mutableDateTime17.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        boolean boolean24 = mutableDateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime17.secondOfMinute();
        mutableDateTime9.setTime((org.joda.time.ReadableInstant) mutableDateTime17);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime17.weekyear();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime17.centuryOfEra();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(property28);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.halfdayOfDay();
        java.lang.String str7 = gregorianChronology0.toString();
        int int8 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 4320000);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[UTC]" + "'", str7.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        long long59 = offsetDateTimeField57.remainder(1560343537018L);
        int int60 = offsetDateTimeField57.getMaximumValue();
        boolean boolean62 = offsetDateTimeField57.isLeap((long) 69);
        org.joda.time.DateTimeField dateTimeField63 = offsetDateTimeField57.getWrappedField();
        int int65 = offsetDateTimeField57.getLeapAmount(86400005L);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 37018L + "'", long59 == 37018L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 12 + "'", int60 == 12);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        long long59 = offsetDateTimeField57.remainder(1560343537018L);
        int int60 = offsetDateTimeField57.getMaximumValue();
        boolean boolean62 = offsetDateTimeField57.isLeap((long) 69);
        org.joda.time.DurationField durationField63 = offsetDateTimeField57.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 37018L + "'", long59 == 37018L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 12 + "'", int60 == 12);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(durationField63);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology4);
        mutableDateTime5.addHours((-1));
        org.joda.time.DateTimeField dateTimeField8 = mutableDateTime5.getRoundingField();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) mutableDateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNull(dateTimeField8);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        org.joda.time.ReadablePartial readablePartial58 = null;
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone60);
        org.joda.time.DurationField durationField62 = julianChronology61.seconds();
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.chrono.JulianChronology julianChronology64 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone63);
        boolean boolean65 = julianChronology61.equals((java.lang.Object) julianChronology64);
        org.joda.time.DateTimeField dateTimeField66 = julianChronology61.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField67 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField66);
        org.joda.time.ReadablePartial readablePartial68 = null;
        int[] intArray70 = new int[] { 2000 };
        int int71 = delegatedDateTimeField67.getMaximumValue(readablePartial68, intArray70);
        java.util.Locale locale72 = null;
        int int73 = delegatedDateTimeField67.getMaximumShortTextLength(locale72);
        org.joda.time.ReadablePartial readablePartial74 = null;
        int int75 = delegatedDateTimeField67.getMaximumValue(readablePartial74);
        org.joda.time.ReadablePartial readablePartial76 = null;
        org.joda.time.DateTimeZone dateTimeZone78 = null;
        org.joda.time.chrono.JulianChronology julianChronology79 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone78);
        org.joda.time.DurationField durationField80 = julianChronology79.seconds();
        org.joda.time.DateTimeZone dateTimeZone81 = null;
        org.joda.time.chrono.JulianChronology julianChronology82 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone81);
        boolean boolean83 = julianChronology79.equals((java.lang.Object) julianChronology82);
        org.joda.time.DateTimeField dateTimeField84 = julianChronology79.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField85 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField84);
        org.joda.time.ReadablePartial readablePartial86 = null;
        int[] intArray88 = new int[] { 2000 };
        int int89 = delegatedDateTimeField85.getMaximumValue(readablePartial86, intArray88);
        int[] intArray91 = delegatedDateTimeField67.addWrapPartial(readablePartial76, 2000, intArray88, 0);
        try {
            int[] intArray93 = offsetDateTimeField57.add(readablePartial58, (-4320010), intArray91, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -4320010");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(julianChronology64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 59 + "'", int71 == 59);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2 + "'", int73 == 2);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 59 + "'", int75 == 59);
        org.junit.Assert.assertNotNull(julianChronology79);
        org.junit.Assert.assertNotNull(durationField80);
        org.junit.Assert.assertNotNull(julianChronology82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(dateTimeField84);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 59 + "'", int89 == 59);
        org.junit.Assert.assertNotNull(intArray91);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getHourOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = mutableDateTime9.toMutableDateTime((org.joda.time.Chronology) julianChronology13);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime9.secondOfMinute();
        try {
            org.joda.time.MutableDateTime mutableDateTime17 = property15.set((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        mutableDateTime3.setChronology((org.joda.time.Chronology) julianChronology13);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime3.centuryOfEra();
        org.joda.time.Instant instant16 = mutableDateTime3.toInstant();
        boolean boolean18 = mutableDateTime3.isAfter(1560343537018L);
        org.joda.time.DateTimeField dateTimeField19 = mutableDateTime3.getRoundingField();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(dateTimeField19);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology1.hourOfDay();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        try {
            int[] intArray10 = julianChronology1.get(readablePeriod8, 2458647L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology29);
        mutableDateTime30.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology35);
        boolean boolean37 = mutableDateTime30.isEqual((org.joda.time.ReadableInstant) mutableDateTime36);
        int int38 = mutableDateTime36.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime36.monthOfYear();
        java.lang.String str40 = property39.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime41 = property39.roundHalfFloor();
        org.joda.time.DurationField durationField42 = property39.getLeapDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField42);
        boolean boolean44 = unsupportedDateTimeField43.isSupported();
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField48 = julianChronology47.seconds();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.JulianChronology julianChronology50 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone49);
        boolean boolean51 = julianChronology47.equals((java.lang.Object) julianChronology50);
        org.joda.time.DateTimeField dateTimeField52 = julianChronology47.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52);
        java.util.Locale locale54 = null;
        int int55 = delegatedDateTimeField53.getMaximumShortTextLength(locale54);
        long long57 = delegatedDateTimeField53.roundFloor(1560343540608L);
        org.joda.time.ReadablePartial readablePartial58 = null;
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.chrono.JulianChronology julianChronology60 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone59);
        org.joda.time.DurationField durationField61 = julianChronology60.seconds();
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.chrono.JulianChronology julianChronology63 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone62);
        boolean boolean64 = julianChronology60.equals((java.lang.Object) julianChronology63);
        org.joda.time.DateTimeField dateTimeField65 = julianChronology60.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField66 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField65);
        org.joda.time.ReadablePartial readablePartial67 = null;
        int[] intArray69 = new int[] { 2000 };
        int int70 = delegatedDateTimeField66.getMaximumValue(readablePartial67, intArray69);
        int int71 = delegatedDateTimeField53.getMinimumValue(readablePartial58, intArray69);
        try {
            int int72 = unsupportedDateTimeField43.getMinimumValue(readablePartial45, intArray69);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Dec" + "'", str40.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(julianChronology50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560343500000L + "'", long57 == 1560343500000L);
        org.junit.Assert.assertNotNull(julianChronology60);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(julianChronology63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 59 + "'", int70 == 59);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("+01:12");
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter1.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNull(dateTimeZone3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        mutableDateTime3.setChronology((org.joda.time.Chronology) julianChronology13);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime3.centuryOfEra();
        org.joda.time.Instant instant16 = mutableDateTime3.toInstant();
        try {
            mutableDateTime3.setDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(instant16);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        java.lang.Integer int20 = dateTimeParserBucket18.getOffsetInteger();
        long long22 = dateTimeParserBucket18.computeMillis(false);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNull(int20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28800052L + "'", long22 == 28800052L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-100), 352, (int) (short) 1, 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.lang.String str2 = dateTimeFormatter0.print((long) '4');
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter0.printTo(writer3, 1560343555771L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "16:00:00" + "'", str2.equals("16:00:00"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = julianChronology20.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        boolean boolean24 = julianChronology20.equals((java.lang.Object) julianChronology23);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology20.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int[] intArray29 = new int[] { 2000 };
        int int30 = delegatedDateTimeField26.getMaximumValue(readablePartial27, intArray29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField26.getAsText(12, locale32);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology14, (org.joda.time.DateTimeField) delegatedDateTimeField26);
        org.joda.time.ReadablePartial readablePartial35 = null;
        int int36 = skipDateTimeField34.getMinimumValue(readablePartial35);
        int int38 = skipDateTimeField34.get(1560343554170L);
        long long41 = skipDateTimeField34.getDifferenceAsLong((long) 10, 1560343537018L);
        try {
            long long44 = skipDateTimeField34.set((long) 32, (-4320001));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -4320001 for minuteOfHour must be in the range [1,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 59 + "'", int30 == 59);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "12" + "'", str33.equals("12"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 45 + "'", int38 == 45);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-26005725L) + "'", long41 == (-26005725L));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(100);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder2.addCutover(18059, '4', (int) (short) 1, (int) (byte) 0, (int) (byte) 10, false, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("UnsupportedDateTimeField", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UnsupportedDateTimeField\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DurationField durationField6 = julianChronology4.weekyears();
        org.joda.time.DurationField durationField7 = julianChronology4.halfdays();
        long long10 = durationField7.subtract((long) 3600000, (int) (short) 0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600000L + "'", long10 == 3600000L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "BuddhistChronology[UTC]");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        illegalFieldValueException2.prependMessage("0");
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField7.getMaximumShortTextLength(locale8);
        long long11 = delegatedDateTimeField7.roundFloor(1560343540608L);
        boolean boolean12 = delegatedDateTimeField7.isLenient();
        long long15 = delegatedDateTimeField7.add(0L, (int) (short) 1);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560343500000L + "'", long11 == 1560343500000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 60000L + "'", long15 == 60000L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(0L);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.millisOfDay();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime4 = property3.roundHalfEven();
        long long5 = property3.remainder();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField7.getMaximumShortTextLength(locale8);
        long long11 = delegatedDateTimeField7.roundFloor(1560343540608L);
        java.lang.String str13 = delegatedDateTimeField7.getAsText(86400005L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560343500000L + "'", long11 == 1560343500000L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getHourOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = mutableDateTime9.toMutableDateTime((org.joda.time.Chronology) julianChronology13);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.monthOfYear();
        int int16 = mutableDateTime14.getDayOfWeek();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(4320000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfHour(16, (-292275054));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime4.centuryOfEra();
        java.util.Locale locale6 = null;
        int int7 = property5.getMaximumShortTextLength(locale6);
        org.joda.time.DurationField durationField8 = property5.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
        org.junit.Assert.assertNull(durationField8);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.minuteOfDay();
        try {
            org.joda.time.Instant instant2 = new org.joda.time.Instant((java.lang.Object) dateTimeField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.LimitChronology$LimitDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime14 = property12.roundHalfFloor();
        org.joda.time.DurationField durationField15 = property12.getLeapDurationField();
        org.joda.time.MutableDateTime mutableDateTime17 = property12.addWrapField(3);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.dayOfWeek();
        try {
            mutableDateTime17.setMinuteOfDay(3600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3600000 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone3);
        int int5 = dateTime4.getSecondOfMinute();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1969);
        org.joda.time.DateTime dateTime9 = dateTime7.withDayOfYear(19);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        mutableDateTime14.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology19);
        boolean boolean21 = mutableDateTime14.isEqual((org.joda.time.ReadableInstant) mutableDateTime20);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime14.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        mutableDateTime14.setChronology((org.joda.time.Chronology) julianChronology24);
        java.util.Locale locale26 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket28 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology24, locale26, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology31);
        int int33 = mutableDateTime32.getMillisOfSecond();
        mutableDateTime32.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long40 = dateTimeZone38.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone42);
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology43);
        mutableDateTime44.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.JulianChronology julianChronology49 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone48);
        org.joda.time.MutableDateTime mutableDateTime50 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology49);
        boolean boolean51 = mutableDateTime44.isEqual((org.joda.time.ReadableInstant) mutableDateTime50);
        int int52 = mutableDateTime50.getMonthOfYear();
        org.joda.time.Chronology chronology53 = mutableDateTime50.getChronology();
        int int54 = dateTimeZone38.getOffset((org.joda.time.ReadableInstant) mutableDateTime50);
        mutableDateTime32.setZoneRetainFields(dateTimeZone38);
        dateTimeParserBucket28.setZone(dateTimeZone38);
        org.joda.time.DateTime dateTime57 = dateTime9.withZoneRetainFields(dateTimeZone38);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 999 + "'", int33 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 4320010L + "'", long40 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology43);
        org.junit.Assert.assertNotNull(julianChronology49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 12 + "'", int52 == 12);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 4320000 + "'", int54 == 4320000);
        org.junit.Assert.assertNotNull(dateTime57);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long6 = dateTimeZone4.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        mutableDateTime10.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology15);
        boolean boolean17 = mutableDateTime10.isEqual((org.joda.time.ReadableInstant) mutableDateTime16);
        int int18 = mutableDateTime16.getMonthOfYear();
        org.joda.time.Chronology chronology19 = mutableDateTime16.getChronology();
        int int20 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) mutableDateTime16);
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime16.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology24);
        mutableDateTime25.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology30);
        boolean boolean32 = mutableDateTime25.isEqual((org.joda.time.ReadableInstant) mutableDateTime31);
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime25.secondOfMinute();
        java.lang.String str34 = property33.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType35, (int) (short) 10, 1, 999);
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, (java.lang.Number) 1560343540608L, "secondOfMinute");
        org.joda.time.MutableDateTime.Property property43 = mutableDateTime16.property(dateTimeFieldType35);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider44 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.chrono.JulianChronology julianChronology48 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone47);
        org.joda.time.MutableDateTime mutableDateTime49 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology48);
        mutableDateTime49.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.chrono.JulianChronology julianChronology54 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone53);
        org.joda.time.MutableDateTime mutableDateTime55 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology54);
        boolean boolean56 = mutableDateTime49.isEqual((org.joda.time.ReadableInstant) mutableDateTime55);
        org.joda.time.MutableDateTime.Property property57 = mutableDateTime49.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.JulianChronology julianChronology59 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone58);
        mutableDateTime49.setChronology((org.joda.time.Chronology) julianChronology59);
        java.util.Locale locale61 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket63 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology59, locale61, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.chrono.JulianChronology julianChronology66 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone65);
        org.joda.time.MutableDateTime mutableDateTime67 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology66);
        int int68 = mutableDateTime67.getMillisOfSecond();
        mutableDateTime67.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long75 = dateTimeZone73.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone77 = null;
        org.joda.time.chrono.JulianChronology julianChronology78 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone77);
        org.joda.time.MutableDateTime mutableDateTime79 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology78);
        mutableDateTime79.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone83 = null;
        org.joda.time.chrono.JulianChronology julianChronology84 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone83);
        org.joda.time.MutableDateTime mutableDateTime85 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology84);
        boolean boolean86 = mutableDateTime79.isEqual((org.joda.time.ReadableInstant) mutableDateTime85);
        int int87 = mutableDateTime85.getMonthOfYear();
        org.joda.time.Chronology chronology88 = mutableDateTime85.getChronology();
        int int89 = dateTimeZone73.getOffset((org.joda.time.ReadableInstant) mutableDateTime85);
        mutableDateTime67.setZoneRetainFields(dateTimeZone73);
        dateTimeParserBucket63.setZone(dateTimeZone73);
        java.util.Locale locale92 = dateTimeParserBucket63.getLocale();
        java.lang.String str95 = defaultNameProvider44.getName(locale92, "JulianChronology[America/Los_Angeles]", "yearOfEra");
        int int96 = property43.getMaximumTextLength(locale92);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket99 = new org.joda.time.format.DateTimeParserBucket((long) 3, chronology1, locale92, (java.lang.Integer) 0, 421);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4320010L + "'", long6 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4320000 + "'", int20 == 4320000);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "secondOfMinute" + "'", str34.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(julianChronology48);
        org.junit.Assert.assertNotNull(julianChronology54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(julianChronology59);
        org.junit.Assert.assertNotNull(julianChronology66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 999 + "'", int68 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone73);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 4320010L + "'", long75 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology78);
        org.junit.Assert.assertNotNull(julianChronology84);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 12 + "'", int87 == 12);
        org.junit.Assert.assertNotNull(chronology88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 4320000 + "'", int89 == 4320000);
        org.junit.Assert.assertNotNull(locale92);
        org.junit.Assert.assertNull(str95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 2 + "'", int96 == 2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DurationField durationField6 = julianChronology4.millis();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField9 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType7, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        dateTimeFormatterBuilder2.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        int int10 = mutableDateTime9.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        mutableDateTime14.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology19);
        boolean boolean21 = mutableDateTime14.isEqual((org.joda.time.ReadableInstant) mutableDateTime20);
        int int22 = mutableDateTime20.getMinuteOfHour();
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime9, (org.joda.time.ReadableInstant) mutableDateTime20);
        boolean boolean24 = dateTime4.isBefore((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime26 = dateTime4.withMillis((long) ' ');
        org.joda.time.DateTime.Property property27 = dateTime4.year();
        org.joda.time.DateTime dateTime29 = dateTime4.minusSeconds(59);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 59 + "'", int22 == 59);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatterBuilder5.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendClockhourOfDay(2000);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        mutableDateTime14.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology19);
        boolean boolean21 = mutableDateTime14.isEqual((org.joda.time.ReadableInstant) mutableDateTime20);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime14.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        mutableDateTime14.setChronology((org.joda.time.Chronology) julianChronology24);
        java.util.Locale locale26 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket28 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology24, locale26, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology29 = dateTimeParserBucket28.getChronology();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone31);
        org.joda.time.MutableDateTime mutableDateTime33 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology32);
        long long37 = julianChronology32.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField38 = julianChronology32.minuteOfHour();
        dateTimeParserBucket28.saveField(dateTimeField38, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder41.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone45);
        org.joda.time.MutableDateTime mutableDateTime47 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology46);
        mutableDateTime47.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone51);
        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology52);
        boolean boolean54 = mutableDateTime47.isEqual((org.joda.time.ReadableInstant) mutableDateTime53);
        org.joda.time.MutableDateTime.Property property55 = mutableDateTime47.secondOfMinute();
        java.lang.String str56 = property55.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property55.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType57, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder43.appendFixedDecimal(dateTimeFieldType57, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, dateTimeFieldType57, 1969, 2000, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType57, 53999, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(julianChronology46);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "secondOfMinute" + "'", str56.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder70);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        org.joda.time.DurationField durationField58 = offsetDateTimeField57.getLeapDurationField();
        java.lang.String str59 = offsetDateTimeField57.toString();
        long long61 = offsetDateTimeField57.roundHalfEven((long) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder62.appendSecondOfMinute(4320000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder65.appendMillisOfSecond(19);
        boolean boolean68 = dateTimeFormatterBuilder65.canBuildFormatter();
        org.joda.time.DateTimeZone dateTimeZone70 = null;
        org.joda.time.chrono.JulianChronology julianChronology71 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone70);
        org.joda.time.MutableDateTime mutableDateTime72 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology71);
        mutableDateTime72.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone76 = null;
        org.joda.time.chrono.JulianChronology julianChronology77 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone76);
        org.joda.time.MutableDateTime mutableDateTime78 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology77);
        boolean boolean79 = mutableDateTime72.isEqual((org.joda.time.ReadableInstant) mutableDateTime78);
        org.joda.time.MutableDateTime.Property property80 = mutableDateTime72.secondOfMinute();
        java.lang.String str81 = property80.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType82 = property80.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType82, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder88 = dateTimeFormatterBuilder65.appendFixedDecimal(dateTimeFieldType82, (int) ' ');
        org.joda.time.IllegalFieldValueException illegalFieldValueException90 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType82, "0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder91 = dateTimeFormatterBuilder64.appendShortText(dateTimeFieldType82);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField93 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField57, dateTimeFieldType82, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str59.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(julianChronology71);
        org.junit.Assert.assertNotNull(julianChronology77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(property80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "secondOfMinute" + "'", str81.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType82);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder88);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder91);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        try {
            java.lang.String str28 = unsupportedDateTimeField26.getAsShortText(864000045L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.setDayOfMonth(3);
        org.junit.Assert.assertNotNull(julianChronology2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        long long1 = instant0.getMillis();
        org.joda.time.Instant instant2 = instant0.toInstant();
        org.joda.time.Instant instant3 = instant2.toInstant();
        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTime();
        mutableDateTime4.addDays((int) (short) 100);
        int int7 = mutableDateTime4.getRoundingMode();
        int int8 = mutableDateTime4.getSecondOfMinute();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology5);
        mutableDateTime6.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology11);
        boolean boolean13 = mutableDateTime6.isEqual((org.joda.time.ReadableInstant) mutableDateTime12);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime6.secondOfMinute();
        java.lang.String str15 = property14.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType16, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType16, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendSecondOfMinute(4320000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendMillisOfSecond(19);
        boolean boolean30 = dateTimeFormatterBuilder27.canBuildFormatter();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone32);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology33);
        mutableDateTime34.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38);
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology39);
        boolean boolean41 = mutableDateTime34.isEqual((org.joda.time.ReadableInstant) mutableDateTime40);
        org.joda.time.MutableDateTime.Property property42 = mutableDateTime34.secondOfMinute();
        java.lang.String str43 = property42.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property42.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType44, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder27.appendFixedDecimal(dateTimeFieldType44, (int) ' ');
        org.joda.time.IllegalFieldValueException illegalFieldValueException52 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType44, "0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder26.appendShortText(dateTimeFieldType44);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder22.appendFixedSignedDecimal(dateTimeFieldType44, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "secondOfMinute" + "'", str15.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "secondOfMinute" + "'", str43.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getHourOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = mutableDateTime9.toMutableDateTime((org.joda.time.Chronology) julianChronology13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        java.util.TimeZone timeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now(dateTimeZone17);
        org.joda.time.MutableDateTime mutableDateTime19 = dateTime15.toMutableDateTime(dateTimeZone17);
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime14.toMutableDateTime(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean7 = dateTimeFormatterBuilder6.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray10 = new int[] { 2000 };
        int int11 = delegatedDateTimeField7.getMaximumValue(readablePartial8, intArray10);
        java.lang.String str13 = delegatedDateTimeField7.getAsText((long) (short) 0);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField7.getLeapDurationField();
        org.joda.time.DateTimeField dateTimeField15 = delegatedDateTimeField7.getWrappedField();
        long long18 = delegatedDateTimeField7.add((long) (byte) 100, 15);
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = julianChronology21.seconds();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        boolean boolean25 = julianChronology21.equals((java.lang.Object) julianChronology24);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology21.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26);
        java.util.Locale locale28 = null;
        int int29 = delegatedDateTimeField27.getMaximumShortTextLength(locale28);
        long long31 = delegatedDateTimeField27.roundFloor(1560343540608L);
        org.joda.time.ReadablePartial readablePartial32 = null;
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone33);
        org.joda.time.DurationField durationField35 = julianChronology34.seconds();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        boolean boolean38 = julianChronology34.equals((java.lang.Object) julianChronology37);
        org.joda.time.DateTimeField dateTimeField39 = julianChronology34.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39);
        org.joda.time.ReadablePartial readablePartial41 = null;
        int[] intArray43 = new int[] { 2000 };
        int int44 = delegatedDateTimeField40.getMaximumValue(readablePartial41, intArray43);
        int int45 = delegatedDateTimeField27.getMinimumValue(readablePartial32, intArray43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder46.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone50);
        org.joda.time.MutableDateTime mutableDateTime52 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology51);
        mutableDateTime52.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone56);
        org.joda.time.MutableDateTime mutableDateTime58 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology57);
        boolean boolean59 = mutableDateTime52.isEqual((org.joda.time.ReadableInstant) mutableDateTime58);
        org.joda.time.MutableDateTime.Property property60 = mutableDateTime52.secondOfMinute();
        java.lang.String str61 = property60.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property60.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType62, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder48.appendFixedDecimal(dateTimeFieldType62, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField27, dateTimeFieldType62, 1969);
        mutableDateTime19.set(dateTimeFieldType62, 59);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType62, (int) (byte) 10, 4, 1969);
        int int78 = offsetDateTimeField76.getLeapAmount((long) 292272992);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 900100L + "'", long18 == 900100L);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560343500000L + "'", long31 == 1560343500000L);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 59 + "'", int44 == 59);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(julianChronology57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "secondOfMinute" + "'", str61.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology5);
        mutableDateTime6.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology11);
        boolean boolean13 = mutableDateTime6.isEqual((org.joda.time.ReadableInstant) mutableDateTime12);
        int int14 = mutableDateTime12.getMinuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology17);
        mutableDateTime18.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology23);
        boolean boolean25 = mutableDateTime18.isEqual((org.joda.time.ReadableInstant) mutableDateTime24);
        int int26 = mutableDateTime24.getHourOfDay();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime29 = mutableDateTime24.toMutableDateTime((org.joda.time.Chronology) julianChronology28);
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime12, (org.joda.time.ReadableInstant) mutableDateTime29);
        try {
            org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((java.lang.Object) julianChronology1, chronology30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.JulianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(chronology30);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime6 = dateTime2.plusMonths((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology10);
        mutableDateTime11.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        boolean boolean18 = mutableDateTime11.isEqual((org.joda.time.ReadableInstant) mutableDateTime17);
        int int19 = mutableDateTime17.getMonthOfYear();
        org.joda.time.Chronology chronology20 = mutableDateTime17.getChronology();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime17.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology24);
        mutableDateTime25.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology30);
        boolean boolean32 = mutableDateTime25.isEqual((org.joda.time.ReadableInstant) mutableDateTime31);
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime25.secondOfMinute();
        mutableDateTime17.setTime((org.joda.time.ReadableInstant) mutableDateTime25);
        mutableDateTime25.addYears((int) (byte) -1);
        int int37 = property7.getDifference((org.joda.time.ReadableInstant) mutableDateTime25);
        int int38 = property7.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922789 + "'", int38 == 2922789);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property14 = dateTime13.year();
        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField16 = property14.getField();
        org.joda.time.DateTime dateTime17 = property14.roundCeilingCopy();
        mutableDateTime7.setMillis((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime19 = dateTime17.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime19.plusMillis(19);
        org.joda.time.DateTime.Property property22 = dateTime19.hourOfDay();
        int int23 = dateTime19.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 70 + "'", int23 == 70);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = julianChronology2.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        boolean boolean6 = julianChronology2.equals((java.lang.Object) julianChronology5);
        org.joda.time.DurationField durationField7 = julianChronology5.weekyears();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology5.dayOfYear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        mutableDateTime14.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology19);
        boolean boolean21 = mutableDateTime14.isEqual((org.joda.time.ReadableInstant) mutableDateTime20);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime14.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        mutableDateTime14.setChronology((org.joda.time.Chronology) julianChronology24);
        java.util.Locale locale26 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket28 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology24, locale26, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology31);
        int int33 = mutableDateTime32.getMillisOfSecond();
        mutableDateTime32.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long40 = dateTimeZone38.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone42);
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology43);
        mutableDateTime44.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.JulianChronology julianChronology49 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone48);
        org.joda.time.MutableDateTime mutableDateTime50 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology49);
        boolean boolean51 = mutableDateTime44.isEqual((org.joda.time.ReadableInstant) mutableDateTime50);
        int int52 = mutableDateTime50.getMonthOfYear();
        org.joda.time.Chronology chronology53 = mutableDateTime50.getChronology();
        int int54 = dateTimeZone38.getOffset((org.joda.time.ReadableInstant) mutableDateTime50);
        mutableDateTime32.setZoneRetainFields(dateTimeZone38);
        dateTimeParserBucket28.setZone(dateTimeZone38);
        org.joda.time.Chronology chronology57 = julianChronology5.withZone(dateTimeZone38);
        org.joda.time.MutableDateTime mutableDateTime58 = org.joda.time.MutableDateTime.now(chronology57);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 999 + "'", int33 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 4320010L + "'", long40 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology43);
        org.junit.Assert.assertNotNull(julianChronology49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 12 + "'", int52 == 12);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 4320000 + "'", int54 == 4320000);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(mutableDateTime58);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("JulianChronology[America/Los_Angeles]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"JulianChronology[America/Los_Angeles]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2000", "Dec", 19, (int) (byte) 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        mutableDateTime3.setChronology((org.joda.time.Chronology) julianChronology13);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int17 = gregorianChronology16.getMinimumDaysInFirstWeek();
        java.util.Locale locale18 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology16, locale18, (java.lang.Integer) 1969);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology23);
        mutableDateTime24.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology29);
        boolean boolean31 = mutableDateTime24.isEqual((org.joda.time.ReadableInstant) mutableDateTime30);
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime24.secondOfMinute();
        java.lang.String str33 = property32.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property32.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType34, (int) (short) 10, 1, 999);
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1560343540608L, "secondOfMinute");
        dateTimeParserBucket20.saveField(dateTimeFieldType34, (int) (byte) 1);
        boolean boolean44 = mutableDateTime3.isSupported(dateTimeFieldType34);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime3.millisOfDay();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "secondOfMinute" + "'", str33.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(property45);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology5);
        mutableDateTime6.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology11);
        boolean boolean13 = mutableDateTime6.isEqual((org.joda.time.ReadableInstant) mutableDateTime12);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime6.secondOfMinute();
        java.lang.String str15 = property14.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType16, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType16, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendEraText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendCenturyOfEra((-13), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "secondOfMinute" + "'", str15.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (byte) 0);
        int int7 = dateTime6.getDayOfYear();
        boolean boolean8 = dateTime6.isBeforeNow();
        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfDay();
        org.joda.time.DateTime dateTime10 = property9.roundHalfFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology15);
        mutableDateTime16.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology21);
        boolean boolean23 = mutableDateTime16.isEqual((org.joda.time.ReadableInstant) mutableDateTime22);
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime16.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone25);
        mutableDateTime16.setChronology((org.joda.time.Chronology) julianChronology26);
        java.util.Locale locale28 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket30 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology26, locale28, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology31 = dateTimeParserBucket30.getChronology();
        java.lang.Object obj32 = dateTimeParserBucket30.saveState();
        java.util.Locale locale33 = dateTimeParserBucket30.getLocale();
        try {
            org.joda.time.DateTime dateTime34 = property9.setCopy("2019-06-12T05:45:50.230-07:00", locale33);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T05:45:50.230-07:00\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 59 + "'", int7 == 59);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(locale33);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfEra();
        java.lang.String str12 = property11.getAsText();
        org.joda.time.DateTime dateTime13 = property11.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime15 = dateTime13.minusMonths(10);
        int int16 = property5.compareTo((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime18 = property5.addToCopy((long) 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendMillisOfSecond(19);
        boolean boolean22 = dateTimeFormatterBuilder19.canBuildFormatter();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology25);
        mutableDateTime26.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology31);
        boolean boolean33 = mutableDateTime26.isEqual((org.joda.time.ReadableInstant) mutableDateTime32);
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime26.secondOfMinute();
        java.lang.String str35 = property34.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property34.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder19.appendFixedDecimal(dateTimeFieldType36, (int) ' ');
        boolean boolean43 = dateTime18.equals((java.lang.Object) dateTimeFormatterBuilder42);
        org.joda.time.DateTime.Property property44 = dateTime18.minuteOfDay();
        org.joda.time.DateTime dateTime45 = property44.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "secondOfMinute" + "'", str35.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime45);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology5);
        mutableDateTime6.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology11);
        boolean boolean13 = mutableDateTime6.isEqual((org.joda.time.ReadableInstant) mutableDateTime12);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime6.secondOfMinute();
        java.lang.String str15 = property14.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType16, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType16, (int) (short) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder2.appendTimeZoneOffset("155959-0800", false, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "secondOfMinute" + "'", str15.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        long long59 = offsetDateTimeField57.remainder(1560343537018L);
        try {
            long long62 = offsetDateTimeField57.addWrapField(1560343556595L, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 37018L + "'", long59 == 37018L);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        java.lang.String str4 = julianChronology2.toString();
        org.joda.time.DurationField durationField5 = julianChronology2.eras();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str4.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 352);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology4);
        mutableDateTime5.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology10);
        boolean boolean12 = mutableDateTime5.isEqual((org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime5.secondOfMinute();
        java.lang.String str14 = property13.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property13.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = julianChronology21.seconds();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        boolean boolean25 = julianChronology21.equals((java.lang.Object) julianChronology24);
        org.joda.time.DateTimeZone dateTimeZone26 = julianChronology21.getZone();
        org.joda.time.DurationField durationField27 = julianChronology21.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField27);
        boolean boolean29 = instant1.isSupported(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "secondOfMinute" + "'", str14.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset((int) 'a');
        java.io.DataOutput dataOutput6 = null;
        try {
            dateTimeZoneBuilder0.writeTo("DateTimeField[minuteOfHour]", dataOutput6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        int int3 = dateTime2.getSecondOfMinute();
        org.joda.time.DateTime.Property property4 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.getDateTime();
        try {
            org.joda.time.DateTime dateTime7 = property4.setCopy("1969-12-18T15:59:59.999-08:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-18T15:59:59.999-08:00\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime6 = dateTime2.plusYears(0);
        org.joda.time.DateTime dateTime8 = dateTime2.withMillisOfSecond(4);
        org.joda.time.DateTime dateTime10 = dateTime2.minusYears(2922789);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField7.getMaximumShortTextLength(locale8);
        long long11 = delegatedDateTimeField7.roundFloor(1560343540608L);
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = julianChronology14.seconds();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        boolean boolean18 = julianChronology14.equals((java.lang.Object) julianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology14.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int[] intArray23 = new int[] { 2000 };
        int int24 = delegatedDateTimeField20.getMaximumValue(readablePartial21, intArray23);
        int int25 = delegatedDateTimeField7.getMinimumValue(readablePartial12, intArray23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology31);
        mutableDateTime32.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology37);
        boolean boolean39 = mutableDateTime32.isEqual((org.joda.time.ReadableInstant) mutableDateTime38);
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime32.secondOfMinute();
        java.lang.String str41 = property40.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property40.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType42, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder28.appendFixedDecimal(dateTimeFieldType42, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType42, 1969);
        long long52 = delegatedDateTimeField7.roundCeiling(0L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560343500000L + "'", long11 == 1560343500000L);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 59 + "'", int24 == 59);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "secondOfMinute" + "'", str41.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (byte) 0);
        int int7 = dateTime6.getDayOfYear();
        boolean boolean8 = dateTime6.isBeforeNow();
        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfDay();
        org.joda.time.DateTime dateTime10 = property9.withMaximumValue();
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 59 + "'", int7 == 59);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField7.getMaximumShortTextLength(locale8);
        long long11 = delegatedDateTimeField7.roundFloor(1560343540608L);
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField16 = julianChronology15.seconds();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        boolean boolean19 = julianChronology15.equals((java.lang.Object) julianChronology18);
        org.joda.time.DateTimeField dateTimeField20 = julianChronology15.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int[] intArray24 = new int[] { 2000 };
        int int25 = delegatedDateTimeField21.getMaximumValue(readablePartial22, intArray24);
        java.util.Locale locale26 = null;
        int int27 = delegatedDateTimeField21.getMaximumShortTextLength(locale26);
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = delegatedDateTimeField21.getMaximumValue(readablePartial28);
        org.joda.time.ReadablePartial readablePartial30 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = julianChronology33.seconds();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        boolean boolean37 = julianChronology33.equals((java.lang.Object) julianChronology36);
        org.joda.time.DateTimeField dateTimeField38 = julianChronology33.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField38);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray42 = new int[] { 2000 };
        int int43 = delegatedDateTimeField39.getMaximumValue(readablePartial40, intArray42);
        int[] intArray45 = delegatedDateTimeField21.addWrapPartial(readablePartial30, 2000, intArray42, 0);
        try {
            int[] intArray47 = delegatedDateTimeField7.add(readablePartial12, 0, intArray42, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560343500000L + "'", long11 == 1560343500000L);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 59 + "'", int25 == 59);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 59 + "'", int43 == 59);
        org.junit.Assert.assertNotNull(intArray45);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(28800052L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28800052 + "'", int1 == 28800052);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        long long7 = julianChronology2.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology2.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        mutableDateTime14.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology19);
        boolean boolean21 = mutableDateTime14.isEqual((org.joda.time.ReadableInstant) mutableDateTime20);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime14.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        mutableDateTime14.setChronology((org.joda.time.Chronology) julianChronology24);
        java.util.Locale locale26 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket28 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology24, locale26, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology29 = dateTimeParserBucket28.getChronology();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone31);
        org.joda.time.MutableDateTime mutableDateTime33 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology32);
        long long37 = julianChronology32.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField38 = julianChronology32.minuteOfHour();
        dateTimeParserBucket28.saveField(dateTimeField38, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder41.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone45);
        org.joda.time.MutableDateTime mutableDateTime47 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology46);
        mutableDateTime47.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone51);
        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology52);
        boolean boolean54 = mutableDateTime47.isEqual((org.joda.time.ReadableInstant) mutableDateTime53);
        org.joda.time.MutableDateTime.Property property55 = mutableDateTime47.secondOfMinute();
        java.lang.String str56 = property55.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property55.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType57, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder43.appendFixedDecimal(dateTimeFieldType57, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, dateTimeFieldType57, 1969, 2000, 12);
        long long69 = offsetDateTimeField67.remainder(1560343537018L);
        long long71 = offsetDateTimeField67.roundHalfFloor((long) 59);
        int int73 = offsetDateTimeField67.getLeapAmount(59L);
        int int75 = offsetDateTimeField67.getMinimumValue(31507200100L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField77 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology2, (org.joda.time.DateTimeField) offsetDateTimeField67, 4320000);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(julianChronology46);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "secondOfMinute" + "'", str56.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 37018L + "'", long69 == 37018L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 0L + "'", long71 == 0L);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2000 + "'", int75 == 2000);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getEra();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder1.appendHourOfHalfday(4);
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatterBuilder10.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter12.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatter14.getPrinter();
        boolean boolean16 = dateTimeFormatter14.isPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder10.append(dateTimePrinter13, dateTimeParserArray18);
        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 100L, (java.lang.Object) dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimePrinter15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(2440588L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2440588 + "'", int1 == 2440588);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = julianChronology20.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        boolean boolean24 = julianChronology20.equals((java.lang.Object) julianChronology23);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology20.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int[] intArray29 = new int[] { 2000 };
        int int30 = delegatedDateTimeField26.getMaximumValue(readablePartial27, intArray29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField26.getAsText(12, locale32);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology14, (org.joda.time.DateTimeField) delegatedDateTimeField26);
        org.joda.time.ReadablePartial readablePartial35 = null;
        int int36 = skipDateTimeField34.getMinimumValue(readablePartial35);
        int int38 = skipDateTimeField34.get(1560343554170L);
        long long41 = skipDateTimeField34.getDifferenceAsLong((long) 10, 1560343537018L);
        long long43 = skipDateTimeField34.remainder(0L);
        int int46 = skipDateTimeField34.getDifference(1560343546010L, (long) 69);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipDateTimeField34.getType();
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 59 + "'", int30 == 59);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "12" + "'", str33.equals("12"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 45 + "'", int38 == 45);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-26005725L) + "'", long41 == (-26005725L));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 26005725 + "'", int46 == 26005725);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        boolean boolean3 = dateTime2.isEqualNow();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(0L);
        mutableDateTime1.setMillis((long) (byte) 10);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.yearOfEra();
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(0L);
        int int2 = mutableDateTime1.getRoundingMode();
        mutableDateTime1.addMinutes(59);
        int int5 = mutableDateTime1.getYearOfCentury();
        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3540000L + "'", long6 == 3540000L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(16);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime6 = dateTime2.plusYears(0);
        org.joda.time.DateTime dateTime8 = dateTime2.withMillisOfSecond(4);
        org.joda.time.DateTime dateTime9 = dateTime2.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        int int30 = unsupportedDateTimeField26.getDifference(1560343535530L, (long) (short) 100);
        try {
            long long33 = unsupportedDateTimeField26.addWrapField((long) 4, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 18059 + "'", int30 == 18059);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2000", "Dec", 19, (int) (byte) 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getNameKey((long) ' ');
        org.joda.time.LocalDateTime localDateTime8 = null;
        boolean boolean9 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime8);
        int int11 = fixedDateTimeZone4.getStandardOffset((-3480000L));
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Dec" + "'", str7.equals("Dec"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        mutableDateTime3.setChronology((org.joda.time.Chronology) julianChronology13);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime3.centuryOfEra();
        org.joda.time.Instant instant16 = mutableDateTime3.toInstant();
        long long17 = instant16.getMillis();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-3600001L) + "'", long17 == (-3600001L));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.Chronology chronology12 = mutableDateTime9.getChronology();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime9.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        mutableDateTime17.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        boolean boolean24 = mutableDateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime17.secondOfMinute();
        mutableDateTime9.setTime((org.joda.time.ReadableInstant) mutableDateTime17);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime9.weekOfWeekyear();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime9.secondOfDay();
        try {
            mutableDateTime9.setMonthOfYear(19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(property28);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitYear(28800052);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.Chronology chronology12 = mutableDateTime9.getChronology();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime9.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        mutableDateTime17.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        boolean boolean24 = mutableDateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime17.secondOfMinute();
        mutableDateTime9.setTime((org.joda.time.ReadableInstant) mutableDateTime17);
        mutableDateTime17.addDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology31);
        mutableDateTime32.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology37);
        boolean boolean39 = mutableDateTime32.isEqual((org.joda.time.ReadableInstant) mutableDateTime38);
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime32.secondOfMinute();
        java.lang.String str41 = property40.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property40.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType42, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.chrono.JulianChronology julianChronology48 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone47);
        org.joda.time.DurationField durationField49 = julianChronology48.seconds();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone50);
        boolean boolean52 = julianChronology48.equals((java.lang.Object) julianChronology51);
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology48.getZone();
        org.joda.time.DurationField durationField54 = julianChronology48.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField54);
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = unsupportedDateTimeField55.getType();
        org.joda.time.MutableDateTime.Property property57 = mutableDateTime17.property(dateTimeFieldType56);
        mutableDateTime17.addMonths(421);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "secondOfMinute" + "'", str41.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(julianChronology48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertNotNull(property57);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        int int4 = mutableDateTime3.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology7);
        mutableDateTime8.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        boolean boolean15 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        int int16 = mutableDateTime14.getMinuteOfHour();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime3.era();
        mutableDateTime3.setDayOfYear(12);
        mutableDateTime3.setMonthOfYear(4);
        mutableDateTime3.addWeekyears(421);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 999 + "'", int4 == 999);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long4 = dateTimeZone2.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology7);
        mutableDateTime8.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        boolean boolean15 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        int int16 = mutableDateTime14.getMonthOfYear();
        org.joda.time.Chronology chronology17 = mutableDateTime14.getChronology();
        int int18 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) mutableDateTime14);
        java.lang.String str20 = dateTimeZone2.getName(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        java.lang.Object obj22 = null;
        boolean boolean23 = cachedDateTimeZone21.equals(obj22);
        int int25 = cachedDateTimeZone21.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime28.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime32 = dateTime30.plusHours((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime33 = dateTime32.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime33.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property40 = dateTime39.year();
        org.joda.time.DateTime dateTime41 = property40.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField42 = property40.getField();
        org.joda.time.DateTime dateTime43 = property40.roundCeilingCopy();
        mutableDateTime33.setMillis((org.joda.time.ReadableInstant) dateTime43);
        org.joda.time.DateTime dateTime46 = dateTime43.plusHours(59);
        boolean boolean47 = cachedDateTimeZone21.equals((java.lang.Object) dateTime46);
        long long50 = cachedDateTimeZone21.adjustOffset((long) (-13), true);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4320010L + "'", long4 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4320000 + "'", int18 == 4320000);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+01:12" + "'", str20.equals("+01:12"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4320000 + "'", int25 == 4320000);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-13L) + "'", long50 == (-13L));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.months();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField4 = julianChronology1.centuries();
        long long7 = durationField4.subtract((long) 0, (int) (short) 1);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3155760422000L) + "'", long7 == (-3155760422000L));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-13), 10, 0, 0, 2000, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        java.lang.String str14 = property12.getAsShortText();
        org.joda.time.DurationField durationField15 = property12.getRangeDurationField();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider16 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology20);
        mutableDateTime21.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone25);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology26);
        boolean boolean28 = mutableDateTime21.isEqual((org.joda.time.ReadableInstant) mutableDateTime27);
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime21.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        mutableDateTime21.setChronology((org.joda.time.Chronology) julianChronology31);
        java.util.Locale locale33 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology31, locale33, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone37);
        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology38);
        int int40 = mutableDateTime39.getMillisOfSecond();
        mutableDateTime39.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long47 = dateTimeZone45.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.JulianChronology julianChronology50 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone49);
        org.joda.time.MutableDateTime mutableDateTime51 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology50);
        mutableDateTime51.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.chrono.JulianChronology julianChronology56 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone55);
        org.joda.time.MutableDateTime mutableDateTime57 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology56);
        boolean boolean58 = mutableDateTime51.isEqual((org.joda.time.ReadableInstant) mutableDateTime57);
        int int59 = mutableDateTime57.getMonthOfYear();
        org.joda.time.Chronology chronology60 = mutableDateTime57.getChronology();
        int int61 = dateTimeZone45.getOffset((org.joda.time.ReadableInstant) mutableDateTime57);
        mutableDateTime39.setZoneRetainFields(dateTimeZone45);
        dateTimeParserBucket35.setZone(dateTimeZone45);
        java.util.Locale locale64 = dateTimeParserBucket35.getLocale();
        java.lang.String str67 = defaultNameProvider16.getName(locale64, "JulianChronology[America/Los_Angeles]", "yearOfEra");
        java.lang.String str68 = property12.getAsShortText(locale64);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Dec" + "'", str14.equals("Dec"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 999 + "'", int40 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 4320010L + "'", long47 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology50);
        org.junit.Assert.assertNotNull(julianChronology56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 12 + "'", int59 == 12);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 4320000 + "'", int61 == 4320000);
        org.junit.Assert.assertNotNull(locale64);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Dec" + "'", str68.equals("Dec"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime6 = dateTime2.plusMonths((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property14 = dateTime13.year();
        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField16 = property14.getField();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology20);
        mutableDateTime21.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone25);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology26);
        boolean boolean28 = mutableDateTime21.isEqual((org.joda.time.ReadableInstant) mutableDateTime27);
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime21.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        mutableDateTime21.setChronology((org.joda.time.Chronology) julianChronology31);
        java.util.Locale locale33 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology31, locale33, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone37);
        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology38);
        int int40 = mutableDateTime39.getMillisOfSecond();
        mutableDateTime39.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long47 = dateTimeZone45.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.JulianChronology julianChronology50 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone49);
        org.joda.time.MutableDateTime mutableDateTime51 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology50);
        mutableDateTime51.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.chrono.JulianChronology julianChronology56 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone55);
        org.joda.time.MutableDateTime mutableDateTime57 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology56);
        boolean boolean58 = mutableDateTime51.isEqual((org.joda.time.ReadableInstant) mutableDateTime57);
        int int59 = mutableDateTime57.getMonthOfYear();
        org.joda.time.Chronology chronology60 = mutableDateTime57.getChronology();
        int int61 = dateTimeZone45.getOffset((org.joda.time.ReadableInstant) mutableDateTime57);
        mutableDateTime39.setZoneRetainFields(dateTimeZone45);
        dateTimeParserBucket35.setZone(dateTimeZone45);
        java.util.Locale locale64 = dateTimeParserBucket35.getLocale();
        java.lang.String str65 = property14.getAsText(locale64);
        try {
            org.joda.time.DateTime dateTime66 = property7.setCopy("Dec", locale64);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Dec\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 999 + "'", int40 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 4320010L + "'", long47 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology50);
        org.junit.Assert.assertNotNull(julianChronology56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 12 + "'", int59 == 12);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 4320000 + "'", int61 == 4320000);
        org.junit.Assert.assertNotNull(locale64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "1969" + "'", str65.equals("1969"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-33119999L), (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-33120000L) + "'", long2 == (-33120000L));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendHourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTimeZoneName(strMap11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.append(dateTimeFormatter13);
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatterBuilder14.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimePrinter15);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-33119999L));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = gJChronology0.halfdays();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isPrinter();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendWeekOfWeekyear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendCenturyOfEra((int) ' ', (int) (short) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendTimeZoneOffset("DateTimeField[secondOfMinute]", false, (int) (byte) 0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "BuddhistChronology[UTC]");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        java.lang.Number number6 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        long long59 = offsetDateTimeField57.remainder(1560343537018L);
        int int60 = offsetDateTimeField57.getMaximumValue();
        int int62 = offsetDateTimeField57.getMaximumValue(28800052L);
        boolean boolean64 = offsetDateTimeField57.isLeap(0L);
        java.lang.String str66 = offsetDateTimeField57.getAsText((long) (byte) 0);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 37018L + "'", long59 == 37018L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 12 + "'", int60 == 12);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 12 + "'", int62 == 12);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "1969" + "'", str66.equals("1969"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) -1, chronology1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTime dateTime5 = dateTime2.withZoneRetainFields(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        java.lang.String str1 = mutableDateTime0.toString();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.getMutableDateTime();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str1.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        try {
            int int27 = unsupportedDateTimeField26.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.minuteOfDay();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        java.lang.String str7 = property5.toString();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[minuteOfDay]" + "'", str7.equals("Property[minuteOfDay]"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        java.lang.Object obj20 = dateTimeParserBucket18.saveState();
        java.util.Locale locale21 = dateTimeParserBucket18.getLocale();
        dateTimeParserBucket18.setOffset((int) (short) 10);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(locale21);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(12, (-33), 1, (int) '4', (-13));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        long long59 = offsetDateTimeField57.remainder(1560343537018L);
        org.joda.time.DateTimeField dateTimeField60 = offsetDateTimeField57.getWrappedField();
        long long62 = offsetDateTimeField57.roundHalfFloor(1560343546010L);
        try {
            long long65 = offsetDateTimeField57.set((long) 26005725, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [2000,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 37018L + "'", long59 == 37018L);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560343560000L + "'", long62 == 1560343560000L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = julianChronology2.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        boolean boolean6 = julianChronology2.equals((java.lang.Object) julianChronology5);
        org.joda.time.DurationField durationField7 = julianChronology5.weekyears();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology5.dayOfYear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) -1, (org.joda.time.Chronology) julianChronology5);
        org.joda.time.DurationField durationField10 = julianChronology5.minutes();
        org.joda.time.DurationField durationField11 = julianChronology5.hours();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.yearOfEra();
        long long6 = property5.remainder();
        org.joda.time.DateTime dateTime8 = property5.addToCopy(4);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 31507200100L + "'", long6 == 31507200100L);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = julianChronology2.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        boolean boolean6 = julianChronology2.equals((java.lang.Object) julianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology2.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField8.getMaximumShortTextLength(locale9);
        long long12 = delegatedDateTimeField8.roundFloor(1560343540608L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField16 = julianChronology15.seconds();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        boolean boolean19 = julianChronology15.equals((java.lang.Object) julianChronology18);
        org.joda.time.DateTimeField dateTimeField20 = julianChronology15.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int[] intArray24 = new int[] { 2000 };
        int int25 = delegatedDateTimeField21.getMaximumValue(readablePartial22, intArray24);
        int int26 = delegatedDateTimeField8.getMinimumValue(readablePartial13, intArray24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone31);
        org.joda.time.MutableDateTime mutableDateTime33 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology32);
        mutableDateTime33.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone37);
        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology38);
        boolean boolean40 = mutableDateTime33.isEqual((org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.MutableDateTime.Property property41 = mutableDateTime33.secondOfMinute();
        java.lang.String str42 = property41.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property41.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType43, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder29.appendFixedDecimal(dateTimeFieldType43, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField8, dateTimeFieldType43, 1969);
        mutableDateTime0.set(dateTimeFieldType43, 59);
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone54);
        org.joda.time.DurationField durationField56 = julianChronology55.seconds();
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone57);
        boolean boolean59 = julianChronology55.equals((java.lang.Object) julianChronology58);
        org.joda.time.DateTimeField dateTimeField60 = julianChronology55.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField61 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField60);
        org.joda.time.ReadablePartial readablePartial62 = null;
        int[] intArray64 = new int[] { 2000 };
        int int65 = delegatedDateTimeField61.getMaximumValue(readablePartial62, intArray64);
        java.util.Locale locale67 = null;
        java.lang.String str68 = delegatedDateTimeField61.getAsText(12, locale67);
        try {
            mutableDateTime0.setRounding((org.joda.time.DateTimeField) delegatedDateTimeField61, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560343500000L + "'", long12 == 1560343500000L);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 59 + "'", int25 == 59);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "secondOfMinute" + "'", str42.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 59 + "'", int65 == 59);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "12" + "'", str68.equals("12"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology29);
        mutableDateTime30.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology35);
        boolean boolean37 = mutableDateTime30.isEqual((org.joda.time.ReadableInstant) mutableDateTime36);
        int int38 = mutableDateTime36.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime36.monthOfYear();
        java.lang.String str40 = property39.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime41 = property39.roundHalfFloor();
        org.joda.time.DurationField durationField42 = property39.getLeapDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField42);
        java.lang.String str44 = unsupportedDateTimeField43.getName();
        java.util.Locale locale46 = null;
        try {
            java.lang.String str47 = unsupportedDateTimeField43.getAsShortText(0, locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Dec" + "'", str40.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "secondOfMinute" + "'", str44.equals("secondOfMinute"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology29);
        mutableDateTime30.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology35);
        boolean boolean37 = mutableDateTime30.isEqual((org.joda.time.ReadableInstant) mutableDateTime36);
        int int38 = mutableDateTime36.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime36.monthOfYear();
        java.lang.String str40 = property39.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime41 = property39.roundHalfFloor();
        org.joda.time.DurationField durationField42 = property39.getLeapDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField42);
        java.lang.String str44 = unsupportedDateTimeField43.getName();
        try {
            long long47 = unsupportedDateTimeField43.set(1560343546296L, "ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Dec" + "'", str40.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "secondOfMinute" + "'", str44.equals("secondOfMinute"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        long long7 = julianChronology2.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology2.minuteOfHour();
        long long12 = julianChronology2.add((long) 59, 10L, (int) (byte) 0);
        int int13 = julianChronology2.getMinimumDaysInFirstWeek();
        java.lang.String str14 = julianChronology2.toString();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 59L + "'", long12 == 59L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str14.equals("JulianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.Chronology chronology12 = mutableDateTime9.getChronology();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime9.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        mutableDateTime17.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        boolean boolean24 = mutableDateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime17.secondOfMinute();
        mutableDateTime9.setTime((org.joda.time.ReadableInstant) mutableDateTime17);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime9.weekOfWeekyear();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField29 = property28.getField();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology4);
        mutableDateTime5.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology10);
        boolean boolean12 = mutableDateTime5.isEqual((org.joda.time.ReadableInstant) mutableDateTime11);
        int int13 = mutableDateTime11.getMonthOfYear();
        org.joda.time.Chronology chronology14 = mutableDateTime11.getChronology();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime11.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology18);
        mutableDateTime19.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology24);
        boolean boolean26 = mutableDateTime19.isEqual((org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime19.secondOfMinute();
        mutableDateTime11.setTime((org.joda.time.ReadableInstant) mutableDateTime19);
        mutableDateTime19.addDays((int) (short) 1);
        int int33 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime19, "2019-06-12T12:45:39.995Z", (int) ' ');
        try {
            org.joda.time.LocalDate localDate35 = dateTimeFormatter0.parseLocalDate("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-33) + "'", int33 == (-33));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatterBuilder5.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendClockhourOfDay(2000);
        boolean boolean10 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.minuteOfDay();
        java.lang.String str6 = property5.getName();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfDay" + "'", str6.equals("minuteOfDay"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime14 = property12.roundHalfFloor();
        org.joda.time.DurationField durationField15 = property12.getRangeDurationField();
        long long16 = property12.remainder();
        java.lang.String str17 = property12.getName();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "monthOfYear" + "'", str17.equals("monthOfYear"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime14 = property12.roundHalfFloor();
        org.joda.time.DurationField durationField15 = property12.getLeapDurationField();
        org.joda.time.MutableDateTime mutableDateTime17 = property12.addWrapField(3);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime19 = mutableDateTime17.copy();
        try {
            mutableDateTime19.setSecondOfDay((-4320001));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -4320001 for secondOfDay must be in the range [0,86399]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        int int30 = unsupportedDateTimeField26.getDifference(1560343535530L, (long) (short) 100);
        org.joda.time.DurationField durationField31 = unsupportedDateTimeField26.getRangeDurationField();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider32 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        mutableDateTime37.setChronology((org.joda.time.Chronology) julianChronology47);
        java.util.Locale locale49 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket51 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology47, locale49, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.chrono.JulianChronology julianChronology54 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone53);
        org.joda.time.MutableDateTime mutableDateTime55 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology54);
        int int56 = mutableDateTime55.getMillisOfSecond();
        mutableDateTime55.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long63 = dateTimeZone61.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.chrono.JulianChronology julianChronology66 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone65);
        org.joda.time.MutableDateTime mutableDateTime67 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology66);
        mutableDateTime67.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.chrono.JulianChronology julianChronology72 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone71);
        org.joda.time.MutableDateTime mutableDateTime73 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology72);
        boolean boolean74 = mutableDateTime67.isEqual((org.joda.time.ReadableInstant) mutableDateTime73);
        int int75 = mutableDateTime73.getMonthOfYear();
        org.joda.time.Chronology chronology76 = mutableDateTime73.getChronology();
        int int77 = dateTimeZone61.getOffset((org.joda.time.ReadableInstant) mutableDateTime73);
        mutableDateTime55.setZoneRetainFields(dateTimeZone61);
        dateTimeParserBucket51.setZone(dateTimeZone61);
        java.util.Locale locale80 = dateTimeParserBucket51.getLocale();
        java.lang.String str83 = defaultNameProvider32.getName(locale80, "JulianChronology[America/Los_Angeles]", "yearOfEra");
        try {
            int int84 = unsupportedDateTimeField26.getMaximumTextLength(locale80);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 18059 + "'", int30 == 18059);
        org.junit.Assert.assertNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertNotNull(julianChronology54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 999 + "'", int56 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 4320010L + "'", long63 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology66);
        org.junit.Assert.assertNotNull(julianChronology72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 12 + "'", int75 == 12);
        org.junit.Assert.assertNotNull(chronology76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 4320000 + "'", int77 == 4320000);
        org.junit.Assert.assertNotNull(locale80);
        org.junit.Assert.assertNull(str83);
    }
}

