import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeParserBucket18.getZone();
        dateTimeParserBucket18.setOffset((java.lang.Integer) 4);
        org.joda.time.Chronology chronology22 = dateTimeParserBucket18.getChronology();
        long long25 = dateTimeParserBucket18.computeMillis(true, "2019-06-12T05:45:50.230-07:00");
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology29);
        mutableDateTime30.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology35);
        boolean boolean37 = mutableDateTime30.isEqual((org.joda.time.ReadableInstant) mutableDateTime36);
        org.joda.time.MutableDateTime.Property property38 = mutableDateTime30.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.JulianChronology julianChronology40 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone39);
        mutableDateTime30.setChronology((org.joda.time.Chronology) julianChronology40);
        java.util.Locale locale42 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket44 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology40, locale42, (java.lang.Integer) 59);
        java.lang.String str45 = julianChronology40.toString();
        boolean boolean46 = dateTimeParserBucket18.restoreState((java.lang.Object) julianChronology40);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 48L + "'", long25 == 48L);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(julianChronology40);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str45.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = julianChronology20.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        boolean boolean24 = julianChronology20.equals((java.lang.Object) julianChronology23);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology20.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int[] intArray29 = new int[] { 2000 };
        int int30 = delegatedDateTimeField26.getMaximumValue(readablePartial27, intArray29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField26.getAsText(12, locale32);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology14, (org.joda.time.DateTimeField) delegatedDateTimeField26);
        org.joda.time.ReadablePartial readablePartial35 = null;
        int int36 = skipDateTimeField34.getMinimumValue(readablePartial35);
        int int38 = skipDateTimeField34.get(1560343554170L);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.JulianChronology julianChronology40 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = julianChronology40.seconds();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone42);
        boolean boolean44 = julianChronology40.equals((java.lang.Object) julianChronology43);
        org.joda.time.DurationField durationField45 = julianChronology43.weekyears();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.JulianChronology julianChronology49 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone48);
        org.joda.time.MutableDateTime mutableDateTime50 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology49);
        mutableDateTime50.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone54);
        org.joda.time.MutableDateTime mutableDateTime56 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology55);
        boolean boolean57 = mutableDateTime50.isEqual((org.joda.time.ReadableInstant) mutableDateTime56);
        org.joda.time.MutableDateTime.Property property58 = mutableDateTime50.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.chrono.JulianChronology julianChronology60 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone59);
        mutableDateTime50.setChronology((org.joda.time.Chronology) julianChronology60);
        java.util.Locale locale62 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket64 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology60, locale62, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.chrono.JulianChronology julianChronology66 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone65);
        org.joda.time.DurationField durationField67 = julianChronology66.seconds();
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.chrono.JulianChronology julianChronology69 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone68);
        boolean boolean70 = julianChronology66.equals((java.lang.Object) julianChronology69);
        org.joda.time.DateTimeField dateTimeField71 = julianChronology66.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField71);
        org.joda.time.ReadablePartial readablePartial73 = null;
        int[] intArray75 = new int[] { 2000 };
        int int76 = delegatedDateTimeField72.getMaximumValue(readablePartial73, intArray75);
        java.util.Locale locale78 = null;
        java.lang.String str79 = delegatedDateTimeField72.getAsText(12, locale78);
        org.joda.time.field.SkipDateTimeField skipDateTimeField80 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology60, (org.joda.time.DateTimeField) delegatedDateTimeField72);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField82 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology43, (org.joda.time.DateTimeField) skipDateTimeField80, (int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone84 = null;
        org.joda.time.DateTime dateTime85 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone84);
        int int86 = dateTime85.getSecondOfMinute();
        org.joda.time.DateTime.Property property87 = dateTime85.monthOfYear();
        org.joda.time.DateTime dateTime88 = property87.getDateTime();
        org.joda.time.LocalDateTime localDateTime89 = dateTime88.toLocalDateTime();
        int int90 = skipDateTimeField80.getMaximumValue((org.joda.time.ReadablePartial) localDateTime89);
        int int91 = skipDateTimeField34.getMinimumValue((org.joda.time.ReadablePartial) localDateTime89);
        long long93 = skipDateTimeField34.remainder((long) (byte) 10);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 59 + "'", int30 == 59);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "12" + "'", str33.equals("12"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 45 + "'", int38 == 45);
        org.junit.Assert.assertNotNull(julianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(julianChronology43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(julianChronology49);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(julianChronology60);
        org.junit.Assert.assertNotNull(julianChronology66);
        org.junit.Assert.assertNotNull(durationField67);
        org.junit.Assert.assertNotNull(julianChronology69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 59 + "'", int76 == 59);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "12" + "'", str79.equals("12"));
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertNotNull(property87);
        org.junit.Assert.assertNotNull(dateTime88);
        org.junit.Assert.assertNotNull(localDateTime89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 59 + "'", int90 == 59);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 10L + "'", long93 == 10L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendHourOfHalfday(4);
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatterBuilder9.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
        boolean boolean15 = dateTimeFormatter13.isPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray17 = new org.joda.time.format.DateTimeParser[] { dateTimeParser16 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder9.append(dateTimePrinter12, dateTimeParserArray17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeParserArray17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        mutableDateTime3.addHours(9);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime3.secondOfDay();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        mutableDateTime3.setChronology((org.joda.time.Chronology) julianChronology13);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime3.centuryOfEra();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime3.yearOfEra();
        int int17 = mutableDateTime3.getMinuteOfHour();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 59 + "'", int17 == 59);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendWeekOfWeekyear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(4, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        int int10 = mutableDateTime9.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        mutableDateTime14.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology19);
        boolean boolean21 = mutableDateTime14.isEqual((org.joda.time.ReadableInstant) mutableDateTime20);
        int int22 = mutableDateTime20.getMinuteOfHour();
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime9, (org.joda.time.ReadableInstant) mutableDateTime20);
        boolean boolean24 = dateTime4.isBefore((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime26 = dateTime4.withMillis((long) ' ');
        org.joda.time.DateTime.Property property27 = dateTime4.year();
        org.joda.time.DateTime dateTime29 = dateTime4.minus((long) 69);
        org.joda.time.ReadableInstant readableInstant30 = null;
        boolean boolean31 = dateTime29.isBefore(readableInstant30);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 59 + "'", int22 == 59);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.clockhourOfHalfday();
        org.joda.time.DurationField durationField3 = gJChronology1.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = julianChronology7.seconds();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        boolean boolean11 = julianChronology7.equals((java.lang.Object) julianChronology10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology14 = julianChronology7.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(1560343500000L, dateTimeZone13);
        org.joda.time.Chronology chronology17 = gJChronology1.withZone(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-4320010), (-33119999L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 143078726879990L + "'", long2 == 143078726879990L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        int int4 = mutableDateTime3.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology7);
        mutableDateTime8.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        boolean boolean15 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        int int16 = mutableDateTime14.getMinuteOfHour();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime3.era();
        mutableDateTime3.setDayOfYear(12);
        mutableDateTime3.setMonthOfYear(4);
        int int23 = mutableDateTime3.getRoundingMode();
        mutableDateTime3.addMonths((int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int28 = gregorianChronology27.getMinimumDaysInFirstWeek();
        java.util.Locale locale29 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology27, locale29, (java.lang.Integer) 1969);
        java.util.TimeZone timeZone32 = null;
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forTimeZone(timeZone32);
        org.joda.time.Chronology chronology34 = gregorianChronology27.withZone(dateTimeZone33);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology27.weekyear();
        int int36 = gregorianChronology27.getMinimumDaysInFirstWeek();
        mutableDateTime3.setChronology((org.joda.time.Chronology) gregorianChronology27);
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology27.year();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 999 + "'", int4 == 999);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(dateTimeField38);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime7 = property5.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime8 = property5.getDateTime();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("2000", "secondOfMinute", 1969, 16);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime8.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime6 = dateTime2.plusYears(0);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTime();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology12);
        int int14 = mutableDateTime13.getMillisOfSecond();
        mutableDateTime13.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long21 = dateTimeZone19.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology24);
        mutableDateTime25.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology30);
        boolean boolean32 = mutableDateTime25.isEqual((org.joda.time.ReadableInstant) mutableDateTime31);
        int int33 = mutableDateTime31.getMonthOfYear();
        org.joda.time.Chronology chronology34 = mutableDateTime31.getChronology();
        int int35 = dateTimeZone19.getOffset((org.joda.time.ReadableInstant) mutableDateTime31);
        mutableDateTime13.setZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTime dateTime37 = dateTime9.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMinutes(1969);
        java.util.Date date40 = dateTime37.toDate();
        int int41 = dateTime37.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone43);
        org.joda.time.DateTime dateTime46 = dateTime44.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property47 = dateTime44.minuteOfDay();
        org.joda.time.DateTime.Property property48 = dateTime44.yearOfEra();
        org.joda.time.ReadableDuration readableDuration49 = null;
        org.joda.time.DateTime dateTime51 = dateTime44.withDurationAdded(readableDuration49, (int) '4');
        org.joda.time.chrono.BuddhistChronology buddhistChronology52 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str53 = buddhistChronology52.toString();
        boolean boolean55 = buddhistChronology52.equals((java.lang.Object) (short) 0);
        java.lang.String str56 = buddhistChronology52.toString();
        boolean boolean57 = dateTime44.equals((java.lang.Object) buddhistChronology52);
        org.joda.time.MutableDateTime mutableDateTime59 = new org.joda.time.MutableDateTime(0L);
        org.joda.time.MutableDateTime.Property property60 = mutableDateTime59.millisOfDay();
        org.joda.time.MutableDateTime.Property property61 = mutableDateTime59.millisOfDay();
        boolean boolean62 = buddhistChronology52.equals((java.lang.Object) property61);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone67 = new org.joda.time.tz.FixedDateTimeZone("2000", "Dec", 19, (int) (byte) 0);
        java.util.TimeZone timeZone68 = fixedDateTimeZone67.toTimeZone();
        java.lang.String str70 = fixedDateTimeZone67.getNameKey((long) ' ');
        org.joda.time.Chronology chronology71 = buddhistChronology52.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone67);
        long long73 = fixedDateTimeZone67.previousTransition((long) (byte) 0);
        org.joda.time.DateTime dateTime74 = dateTime37.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone67);
        try {
            org.joda.time.DateTime dateTime76 = dateTime37.withHourOfDay(45);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 45 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 999 + "'", int14 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 4320010L + "'", long21 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4320000 + "'", int35 == 4320000);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(buddhistChronology52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "BuddhistChronology[UTC]" + "'", str53.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "BuddhistChronology[UTC]" + "'", str56.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Dec" + "'", str70.equals("Dec"));
        org.junit.Assert.assertNotNull(chronology71);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
        org.junit.Assert.assertNotNull(dateTime74);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DurationField durationField6 = julianChronology4.weekyears();
        org.joda.time.DurationField durationField7 = julianChronology4.halfdays();
        java.lang.String str8 = julianChronology4.toString();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str8.equals("JulianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long6 = dateTimeZone4.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        mutableDateTime10.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology15);
        boolean boolean17 = mutableDateTime10.isEqual((org.joda.time.ReadableInstant) mutableDateTime16);
        int int18 = mutableDateTime16.getMonthOfYear();
        org.joda.time.Chronology chronology19 = mutableDateTime16.getChronology();
        int int20 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) mutableDateTime16);
        java.lang.String str22 = dateTimeZone4.getName(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone23 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        java.lang.Object obj24 = null;
        boolean boolean25 = cachedDateTimeZone23.equals(obj24);
        org.joda.time.Chronology chronology26 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        boolean boolean28 = dateTimeFormatter27.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4320010L + "'", long6 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4320000 + "'", int20 == 4320000);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+01:12" + "'", str22.equals("+01:12"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.halfdayOfDay();
        java.lang.String str7 = gregorianChronology0.toString();
        int int8 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 4320000);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[UTC]" + "'", str7.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime14 = property12.roundHalfFloor();
        mutableDateTime14.setTime((long) 12);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology19);
        mutableDateTime20.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology25);
        boolean boolean27 = mutableDateTime20.isEqual((org.joda.time.ReadableInstant) mutableDateTime26);
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime20.secondOfMinute();
        java.lang.String str29 = property28.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property28.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType30, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.DurationField durationField37 = julianChronology36.seconds();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38);
        boolean boolean40 = julianChronology36.equals((java.lang.Object) julianChronology39);
        org.joda.time.DateTimeZone dateTimeZone41 = julianChronology36.getZone();
        org.joda.time.DurationField durationField42 = julianChronology36.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType30, durationField42);
        int int44 = mutableDateTime14.get(dateTimeFieldType30);
        mutableDateTime14.setSecondOfDay(0);
        try {
            mutableDateTime14.setDayOfMonth(1964);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1964 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "secondOfMinute" + "'", str29.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("2019-06-12T05:45:50.230-07:00", "160000-0800");
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long4 = dateTimeZone2.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology7);
        mutableDateTime8.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        boolean boolean15 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        int int16 = mutableDateTime14.getMonthOfYear();
        org.joda.time.Chronology chronology17 = mutableDateTime14.getChronology();
        int int18 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) mutableDateTime14);
        java.lang.String str20 = dateTimeZone2.getName(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        java.lang.Object obj22 = null;
        boolean boolean23 = cachedDateTimeZone21.equals(obj22);
        int int25 = cachedDateTimeZone21.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime28.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime32 = dateTime30.plusHours((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime33 = dateTime32.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime33.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property40 = dateTime39.year();
        org.joda.time.DateTime dateTime41 = property40.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField42 = property40.getField();
        org.joda.time.DateTime dateTime43 = property40.roundCeilingCopy();
        mutableDateTime33.setMillis((org.joda.time.ReadableInstant) dateTime43);
        org.joda.time.DateTime dateTime46 = dateTime43.plusHours(59);
        boolean boolean47 = cachedDateTimeZone21.equals((java.lang.Object) dateTime46);
        org.joda.time.DateTime dateTime49 = dateTime46.plusHours((int) (byte) -1);
        org.joda.time.YearMonthDay yearMonthDay50 = dateTime49.toYearMonthDay();
        org.joda.time.DateTime dateTime52 = dateTime49.plus(1560343546010L);
        org.joda.time.DateTime dateTime53 = dateTime49.toDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4320010L + "'", long4 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4320000 + "'", int18 == 4320000);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+01:12" + "'", str20.equals("+01:12"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4320000 + "'", int25 == 4320000);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(yearMonthDay50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime53);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        java.lang.String str14 = property12.getAsShortText();
        boolean boolean15 = property12.isLeap();
        org.joda.time.MutableDateTime mutableDateTime17 = property12.set(7);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Dec" + "'", str14.equals("Dec"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(mutableDateTime17);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("+01:12", "Dec", (int) ' ', (-1));
        long long11 = fixedDateTimeZone9.nextTransition(0L);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((-100), (int) (short) 0, (-33), (int) (byte) 1, (int) (byte) 10, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTwoDigitYear(19, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((-4320010));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfEra();
        java.lang.String str12 = property11.getAsText();
        org.joda.time.DateTime dateTime13 = property11.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime15 = dateTime13.minusMonths(10);
        int int16 = property5.compareTo((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime18 = property5.addToCopy((long) 2000);
        int int19 = property5.get();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 960 + "'", int19 == 960);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = julianChronology2.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        boolean boolean6 = julianChronology2.equals((java.lang.Object) julianChronology5);
        org.joda.time.DurationField durationField7 = julianChronology5.weekyears();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology11);
        mutableDateTime12.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology17);
        boolean boolean19 = mutableDateTime12.isEqual((org.joda.time.ReadableInstant) mutableDateTime18);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime12.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        mutableDateTime12.setChronology((org.joda.time.Chronology) julianChronology22);
        java.util.Locale locale24 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology22, locale24, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        org.joda.time.DurationField durationField29 = julianChronology28.seconds();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        boolean boolean32 = julianChronology28.equals((java.lang.Object) julianChronology31);
        org.joda.time.DateTimeField dateTimeField33 = julianChronology28.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        int[] intArray37 = new int[] { 2000 };
        int int38 = delegatedDateTimeField34.getMaximumValue(readablePartial35, intArray37);
        java.util.Locale locale40 = null;
        java.lang.String str41 = delegatedDateTimeField34.getAsText(12, locale40);
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology22, (org.joda.time.DateTimeField) delegatedDateTimeField34);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology5, (org.joda.time.DateTimeField) skipDateTimeField42, (int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone46);
        int int48 = dateTime47.getSecondOfMinute();
        org.joda.time.DateTime.Property property49 = dateTime47.monthOfYear();
        org.joda.time.DateTime dateTime50 = property49.getDateTime();
        org.joda.time.LocalDateTime localDateTime51 = dateTime50.toLocalDateTime();
        int int52 = skipDateTimeField42.getMaximumValue((org.joda.time.ReadablePartial) localDateTime51);
        java.lang.String str53 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime51);
        java.io.Writer writer54 = null;
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone56);
        org.joda.time.DateTime dateTime59 = dateTime57.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime dateTime61 = dateTime57.withMonthOfYear((int) (short) 10);
        org.joda.time.TimeOfDay timeOfDay62 = dateTime61.toTimeOfDay();
        try {
            dateTimeFormatter0.printTo(writer54, (org.joda.time.ReadablePartial) timeOfDay62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 59 + "'", int38 == 59);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "12" + "'", str41.equals("12"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(localDateTime51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 59 + "'", int52 == 59);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "T160000.100" + "'", str53.equals("T160000.100"));
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(timeOfDay62);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        org.joda.time.DurationField durationField58 = offsetDateTimeField57.getLeapDurationField();
        boolean boolean60 = offsetDateTimeField57.isLeap(92060269790489L);
        boolean boolean61 = offsetDateTimeField57.isSupported();
        long long63 = offsetDateTimeField57.roundHalfFloor((long) (byte) -1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeParserBucket18.getZone();
        dateTimeParserBucket18.setOffset((java.lang.Integer) 4);
        org.joda.time.Chronology chronology22 = dateTimeParserBucket18.getChronology();
        long long25 = dateTimeParserBucket18.computeMillis(true, "2019-06-12T05:45:50.230-07:00");
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime28.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property31 = dateTime28.minuteOfDay();
        org.joda.time.DateTime.Property property32 = dateTime28.yearOfEra();
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.DateTime dateTime35 = dateTime28.withDurationAdded(readableDuration33, (int) '4');
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str37 = buddhistChronology36.toString();
        boolean boolean39 = buddhistChronology36.equals((java.lang.Object) (short) 0);
        java.lang.String str40 = buddhistChronology36.toString();
        boolean boolean41 = dateTime28.equals((java.lang.Object) buddhistChronology36);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime(0L);
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime43.millisOfDay();
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime43.millisOfDay();
        boolean boolean46 = buddhistChronology36.equals((java.lang.Object) property45);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone51 = new org.joda.time.tz.FixedDateTimeZone("2000", "Dec", 19, (int) (byte) 0);
        java.util.TimeZone timeZone52 = fixedDateTimeZone51.toTimeZone();
        java.lang.String str54 = fixedDateTimeZone51.getNameKey((long) ' ');
        org.joda.time.Chronology chronology55 = buddhistChronology36.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone51);
        long long57 = fixedDateTimeZone51.previousTransition((long) (byte) 0);
        dateTimeParserBucket18.setZone((org.joda.time.DateTimeZone) fixedDateTimeZone51);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 48L + "'", long25 == 48L);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "BuddhistChronology[UTC]" + "'", str37.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "BuddhistChronology[UTC]" + "'", str40.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Dec" + "'", str54.equals("Dec"));
        org.junit.Assert.assertNotNull(chronology55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute(999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.halfdayOfDay();
        java.lang.String str7 = gregorianChronology0.toString();
        int int8 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 4320000);
        long long15 = skipUndoDateTimeField12.set(1560343544324L, 3);
        int int16 = skipUndoDateTimeField12.getMinimumValue();
        int int18 = skipUndoDateTimeField12.get((long) 999);
        int int19 = skipUndoDateTimeField12.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[UTC]" + "'", str7.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560297600002L + "'", long15 == 1560297600002L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1000 + "'", int18 == 1000);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property14 = dateTime13.year();
        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField16 = property14.getField();
        org.joda.time.DateTime dateTime17 = property14.roundCeilingCopy();
        mutableDateTime7.setMillis((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime19 = dateTime17.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime19.plusMonths((int) (byte) 1);
        boolean boolean23 = dateTime19.isEqual(864000045L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfHalfday(2922730);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test032");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        long long1 = instant0.getMillis();
//        org.joda.time.Instant instant2 = instant0.toInstant();
//        org.joda.time.Instant instant3 = instant2.toInstant();
//        org.joda.time.Instant instant5 = instant3.withMillis((long) 1);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.Instant instant7 = instant5.minus(readableDuration6);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 352L + "'", long1 == 352L);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant7);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("2000", "secondOfMinute", 1969, 16);
        java.util.TimeZone timeZone12 = fixedDateTimeZone11.toTimeZone();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(0, 8, 26005725, 0, 0, 16, 0, (org.joda.time.Chronology) julianChronology13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(julianChronology13);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.withYearOfCentury(45);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        org.joda.time.DurationField durationField58 = offsetDateTimeField57.getLeapDurationField();
        boolean boolean60 = offsetDateTimeField57.isLeap(92060269790489L);
        boolean boolean61 = offsetDateTimeField57.isSupported();
        org.joda.time.DurationField durationField62 = offsetDateTimeField57.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNull(durationField62);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.months();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfSecond(0);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, (int) '4');
        org.joda.time.DateTime dateTime12 = dateTime5.withZoneRetainFields(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = julianChronology16.seconds();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        boolean boolean20 = julianChronology16.equals((java.lang.Object) julianChronology19);
        org.joda.time.DurationField durationField21 = julianChronology19.weekyears();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology25);
        mutableDateTime26.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology31);
        boolean boolean33 = mutableDateTime26.isEqual((org.joda.time.ReadableInstant) mutableDateTime32);
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime26.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        mutableDateTime26.setChronology((org.joda.time.Chronology) julianChronology36);
        java.util.Locale locale38 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket40 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology36, locale38, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.DurationField durationField43 = julianChronology42.seconds();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.JulianChronology julianChronology45 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone44);
        boolean boolean46 = julianChronology42.equals((java.lang.Object) julianChronology45);
        org.joda.time.DateTimeField dateTimeField47 = julianChronology42.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField47);
        org.joda.time.ReadablePartial readablePartial49 = null;
        int[] intArray51 = new int[] { 2000 };
        int int52 = delegatedDateTimeField48.getMaximumValue(readablePartial49, intArray51);
        java.util.Locale locale54 = null;
        java.lang.String str55 = delegatedDateTimeField48.getAsText(12, locale54);
        org.joda.time.field.SkipDateTimeField skipDateTimeField56 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology36, (org.joda.time.DateTimeField) delegatedDateTimeField48);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField58 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology19, (org.joda.time.DateTimeField) skipDateTimeField56, (int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone60);
        int int62 = dateTime61.getSecondOfMinute();
        org.joda.time.DateTime.Property property63 = dateTime61.monthOfYear();
        org.joda.time.DateTime dateTime64 = property63.getDateTime();
        org.joda.time.LocalDateTime localDateTime65 = dateTime64.toLocalDateTime();
        int int66 = skipDateTimeField56.getMaximumValue((org.joda.time.ReadablePartial) localDateTime65);
        int[] intArray68 = gregorianChronology13.get((org.joda.time.ReadablePartial) localDateTime65, 1560343544324L);
        boolean boolean69 = dateTimeZone11.isLocalDateTimeGap(localDateTime65);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(julianChronology45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 59 + "'", int52 == 59);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "12" + "'", str55.equals("12"));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(localDateTime65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 59 + "'", int66 == 59);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        java.lang.String str14 = property12.getAsShortText();
        org.joda.time.DurationField durationField15 = property12.getRangeDurationField();
        java.lang.String str16 = property12.getAsString();
        int int17 = property12.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Dec" + "'", str14.equals("Dec"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "12" + "'", str16.equals("12"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 352);
        org.joda.time.Instant instant3 = instant1.plus(1560343538891L);
        org.joda.time.Instant instant5 = instant3.withMillis(52L);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.minuteOfDay();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) 69);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = julianChronology9.seconds();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        boolean boolean13 = julianChronology9.equals((java.lang.Object) julianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = julianChronology9.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.util.Locale locale16 = null;
        int int17 = delegatedDateTimeField15.getMaximumShortTextLength(locale16);
        org.joda.time.DateTimeField dateTimeField18 = delegatedDateTimeField15.getWrappedField();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider20 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology24);
        mutableDateTime25.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology30);
        boolean boolean32 = mutableDateTime25.isEqual((org.joda.time.ReadableInstant) mutableDateTime31);
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime25.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
        mutableDateTime25.setChronology((org.joda.time.Chronology) julianChronology35);
        java.util.Locale locale37 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket39 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology35, locale37, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        int int44 = mutableDateTime43.getMillisOfSecond();
        mutableDateTime43.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long51 = dateTimeZone49.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.chrono.JulianChronology julianChronology54 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone53);
        org.joda.time.MutableDateTime mutableDateTime55 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology54);
        mutableDateTime55.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.chrono.JulianChronology julianChronology60 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone59);
        org.joda.time.MutableDateTime mutableDateTime61 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology60);
        boolean boolean62 = mutableDateTime55.isEqual((org.joda.time.ReadableInstant) mutableDateTime61);
        int int63 = mutableDateTime61.getMonthOfYear();
        org.joda.time.Chronology chronology64 = mutableDateTime61.getChronology();
        int int65 = dateTimeZone49.getOffset((org.joda.time.ReadableInstant) mutableDateTime61);
        mutableDateTime43.setZoneRetainFields(dateTimeZone49);
        dateTimeParserBucket39.setZone(dateTimeZone49);
        java.util.Locale locale68 = dateTimeParserBucket39.getLocale();
        java.lang.String str71 = defaultNameProvider20.getName(locale68, "JulianChronology[America/Los_Angeles]", "yearOfEra");
        java.lang.String str72 = delegatedDateTimeField15.getAsText(1560343546296L, locale68);
        long long74 = delegatedDateTimeField15.roundCeiling((long) (byte) 1);
        int int75 = dateTime7.get((org.joda.time.DateTimeField) delegatedDateTimeField15);
        long long77 = delegatedDateTimeField15.roundFloor(0L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 999 + "'", int44 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 4320010L + "'", long51 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology54);
        org.junit.Assert.assertNotNull(julianChronology60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 12 + "'", int63 == 12);
        org.junit.Assert.assertNotNull(chronology64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 4320000 + "'", int65 == 4320000);
        org.junit.Assert.assertNotNull(locale68);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "45" + "'", str72.equals("45"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 60000L + "'", long74 == 60000L);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 9 + "'", int75 == 9);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 0L + "'", long77 == 0L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(3540000L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        int int3 = dateTime2.getSecondOfMinute();
        org.joda.time.DateTime.Property property4 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime5 = property4.getDateTime();
        org.joda.time.DateTime dateTime6 = property4.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfEra(6);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekyear((int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfMonth(12);
        org.joda.time.DateTime dateTime8 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        mutableDateTime17.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        boolean boolean24 = mutableDateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime23);
        int int25 = mutableDateTime23.getMinuteOfHour();
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime12, (org.joda.time.ReadableInstant) mutableDateTime23);
        boolean boolean27 = dateTime7.isBefore((org.joda.time.ReadableInstant) mutableDateTime12);
        mutableDateTime12.addMinutes((int) (byte) 1);
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime12.millisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        mutableDateTime12.add(readablePeriod31);
        mutableDateTime12.setMillisOfDay((int) (short) 1);
        int int35 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) mutableDateTime12);
        org.joda.time.ReadableDuration readableDuration36 = null;
        mutableDateTime12.add(readableDuration36, (int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 59 + "'", int25 == 59);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3600000 + "'", int35 == 3600000);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField7 = property5.getField();
        org.joda.time.DateTime dateTime8 = property5.roundCeilingCopy();
        org.joda.time.DateTime.Property property9 = dateTime8.hourOfDay();
        org.joda.time.Interval interval10 = property9.toInterval();
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval10);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(interval10);
        org.junit.Assert.assertNotNull(readableInterval11);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray10 = new int[] { 2000 };
        int int11 = delegatedDateTimeField7.getMaximumValue(readablePartial8, intArray10);
        java.lang.String str13 = delegatedDateTimeField7.getAsText((long) (short) 0);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField7.getLeapDurationField();
        org.joda.time.DateTimeField dateTimeField15 = delegatedDateTimeField7.getWrappedField();
        long long18 = delegatedDateTimeField7.add((long) (byte) 100, 15);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone20);
        int int22 = dateTime21.getSecondOfMinute();
        org.joda.time.DateTime.Property property23 = dateTime21.monthOfYear();
        org.joda.time.DateTime dateTime24 = property23.getDateTime();
        org.joda.time.LocalDateTime localDateTime25 = dateTime24.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime28.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property31 = dateTime30.year();
        org.joda.time.DateTime dateTime32 = property31.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField33 = property31.getField();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology37);
        mutableDateTime38.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone42);
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology43);
        boolean boolean45 = mutableDateTime38.isEqual((org.joda.time.ReadableInstant) mutableDateTime44);
        org.joda.time.MutableDateTime.Property property46 = mutableDateTime38.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.chrono.JulianChronology julianChronology48 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone47);
        mutableDateTime38.setChronology((org.joda.time.Chronology) julianChronology48);
        java.util.Locale locale50 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket52 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology48, locale50, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone54);
        org.joda.time.MutableDateTime mutableDateTime56 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology55);
        int int57 = mutableDateTime56.getMillisOfSecond();
        mutableDateTime56.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long64 = dateTimeZone62.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone66);
        org.joda.time.MutableDateTime mutableDateTime68 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology67);
        mutableDateTime68.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone72 = null;
        org.joda.time.chrono.JulianChronology julianChronology73 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone72);
        org.joda.time.MutableDateTime mutableDateTime74 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology73);
        boolean boolean75 = mutableDateTime68.isEqual((org.joda.time.ReadableInstant) mutableDateTime74);
        int int76 = mutableDateTime74.getMonthOfYear();
        org.joda.time.Chronology chronology77 = mutableDateTime74.getChronology();
        int int78 = dateTimeZone62.getOffset((org.joda.time.ReadableInstant) mutableDateTime74);
        mutableDateTime56.setZoneRetainFields(dateTimeZone62);
        dateTimeParserBucket52.setZone(dateTimeZone62);
        java.util.Locale locale81 = dateTimeParserBucket52.getLocale();
        java.lang.String str82 = property31.getAsText(locale81);
        java.lang.String str83 = delegatedDateTimeField7.getAsText((org.joda.time.ReadablePartial) localDateTime25, locale81);
        java.lang.String str85 = delegatedDateTimeField7.getAsShortText((long) 4320000);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 900100L + "'", long18 == 900100L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(julianChronology43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(julianChronology48);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 999 + "'", int57 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 4320010L + "'", long64 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(julianChronology73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 12 + "'", int76 == 12);
        org.junit.Assert.assertNotNull(chronology77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 4320000 + "'", int78 == 4320000);
        org.junit.Assert.assertNotNull(locale81);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "1969" + "'", str82.equals("1969"));
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "0" + "'", str83.equals("0"));
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "12" + "'", str85.equals("12"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology1, locale3, (java.lang.Integer) 1969);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        mutableDateTime9.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology14);
        boolean boolean16 = mutableDateTime9.isEqual((org.joda.time.ReadableInstant) mutableDateTime15);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime9.secondOfMinute();
        java.lang.String str18 = property17.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property17.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType19, (int) (short) 10, 1, 999);
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 1560343540608L, "secondOfMinute");
        dateTimeParserBucket5.saveField(dateTimeFieldType19, (int) (byte) 1);
        dateTimeParserBucket5.setOffset((-100));
        long long33 = dateTimeParserBucket5.computeMillis(false, "0");
        org.joda.time.Chronology chronology34 = dateTimeParserBucket5.getChronology();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "secondOfMinute" + "'", str18.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2401688L + "'", long33 == 2401688L);
        org.junit.Assert.assertNotNull(chronology34);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.minuteOfDay();
        org.joda.time.DateTime.Property property6 = dateTime2.yearOfEra();
        int int7 = property6.get();
        org.joda.time.DateTime dateTime8 = property6.withMaximumValue();
        org.joda.time.DateTime dateTime10 = dateTime8.minusHours((int) '4');
        org.joda.time.DateTime dateTime12 = dateTime8.plusMonths((int) '#');
        boolean boolean14 = dateTime8.isAfter(0L);
        int int15 = dateTime8.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 57600100 + "'", int15 == 57600100);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        org.joda.time.DurationField durationField58 = offsetDateTimeField57.getLeapDurationField();
        java.lang.String str59 = offsetDateTimeField57.toString();
        org.joda.time.DurationField durationField60 = offsetDateTimeField57.getLeapDurationField();
        boolean boolean61 = offsetDateTimeField57.isSupported();
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str59.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertNull(durationField60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField7.getMaximumShortTextLength(locale8);
        long long11 = delegatedDateTimeField7.roundFloor(1560343540608L);
        long long14 = delegatedDateTimeField7.getDifferenceAsLong((-13L), (long) (byte) 10);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560343500000L + "'", long11 == 1560343500000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology1, locale3, (java.lang.Integer) 1969);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        mutableDateTime9.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology14);
        boolean boolean16 = mutableDateTime9.isEqual((org.joda.time.ReadableInstant) mutableDateTime15);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime9.secondOfMinute();
        java.lang.String str18 = property17.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property17.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType19, (int) (short) 10, 1, 999);
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 1560343540608L, "secondOfMinute");
        dateTimeParserBucket5.saveField(dateTimeFieldType19, (int) (byte) 1);
        dateTimeParserBucket5.setOffset((-100));
        long long33 = dateTimeParserBucket5.computeMillis(false, "0");
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        int int45 = mutableDateTime43.getMonthOfYear();
        org.joda.time.Chronology chronology46 = mutableDateTime43.getChronology();
        org.joda.time.MutableDateTime.Property property47 = mutableDateTime43.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.JulianChronology julianChronology50 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone49);
        org.joda.time.MutableDateTime mutableDateTime51 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology50);
        mutableDateTime51.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.chrono.JulianChronology julianChronology56 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone55);
        org.joda.time.MutableDateTime mutableDateTime57 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology56);
        boolean boolean58 = mutableDateTime51.isEqual((org.joda.time.ReadableInstant) mutableDateTime57);
        org.joda.time.MutableDateTime.Property property59 = mutableDateTime51.secondOfMinute();
        mutableDateTime43.setTime((org.joda.time.ReadableInstant) mutableDateTime51);
        mutableDateTime51.addYears((int) (byte) -1);
        boolean boolean63 = dateTimeParserBucket5.restoreState((java.lang.Object) (byte) -1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "secondOfMinute" + "'", str18.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2401688L + "'", long33 == 2401688L);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(julianChronology50);
        org.junit.Assert.assertNotNull(julianChronology56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfMonth(12);
        org.joda.time.DateTime dateTime7 = dateTime6.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology10);
        int int12 = mutableDateTime11.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology15);
        mutableDateTime16.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology21);
        boolean boolean23 = mutableDateTime16.isEqual((org.joda.time.ReadableInstant) mutableDateTime22);
        int int24 = mutableDateTime22.getMinuteOfHour();
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime11, (org.joda.time.ReadableInstant) mutableDateTime22);
        boolean boolean26 = dateTime6.isBefore((org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.DateTime dateTime28 = dateTime6.withMillis((long) ' ');
        org.joda.time.DateTime.Property property29 = dateTime6.year();
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime31 = dateTime6.plus(readableDuration30);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone33);
        org.joda.time.DateTime dateTime36 = dateTime34.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime dateTime38 = dateTime34.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTime.Property property39 = dateTime34.monthOfYear();
        org.joda.time.chrono.LimitChronology limitChronology40 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.ReadableDateTime) dateTime6, (org.joda.time.ReadableDateTime) dateTime34);
        org.joda.time.DateTime dateTime42 = dateTime6.minusSeconds(2440588);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 999 + "'", int12 == 999);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 59 + "'", int24 == 59);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(limitChronology40);
        org.junit.Assert.assertNotNull(dateTime42);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology5);
        mutableDateTime6.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology11);
        boolean boolean13 = mutableDateTime6.isEqual((org.joda.time.ReadableInstant) mutableDateTime12);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime6.secondOfMinute();
        java.lang.String str15 = property14.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType16, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType16, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "secondOfMinute" + "'", str15.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        java.lang.String str14 = property12.getAsShortText();
        boolean boolean15 = property12.isLeap();
        org.joda.time.MutableDateTime mutableDateTime16 = property12.getMutableDateTime();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Dec" + "'", str14.equals("Dec"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(mutableDateTime16);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology1, locale3, (java.lang.Integer) 1969);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.halfdayOfDay();
        org.joda.time.Chronology chronology7 = gregorianChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property14 = dateTime13.year();
        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField16 = property14.getField();
        org.joda.time.DateTime dateTime17 = property14.roundCeilingCopy();
        mutableDateTime7.setMillis((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime19 = dateTime17.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime19.plusMillis(19);
        org.joda.time.DateTime dateTime22 = dateTime19.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime24 = dateTime19.plusYears(0);
        org.joda.time.DateTime dateTime25 = dateTime24.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.yearOfEra();
        java.lang.String str6 = property5.getAsText();
        org.joda.time.DateTime dateTime7 = property5.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(10);
        org.joda.time.DateTime.Property property10 = dateTime7.era();
        org.joda.time.DateTime.Property property11 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime13 = property11.addToCopy((long) (-100));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test060");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        long long1 = instant0.getMillis();
//        org.joda.time.Instant instant2 = instant0.toInstant();
//        org.joda.time.Instant instant3 = instant2.toInstant();
//        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTime();
//        java.lang.Object obj5 = mutableDateTime4.clone();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560347164095L + "'", long1 == 1560347164095L);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(obj5);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.minuteOfDay();
        int int6 = dateTime2.getMonthOfYear();
        org.joda.time.DateTime.Property property7 = dateTime2.era();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        java.lang.String str12 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = julianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = julianChronology19.equals((java.lang.Object) julianChronology22);
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology19.getZone();
        org.joda.time.DurationField durationField25 = julianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
        int int30 = unsupportedDateTimeField26.getDifference(1560343535530L, (long) (short) 100);
        org.joda.time.DurationField durationField31 = unsupportedDateTimeField26.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = unsupportedDateTimeField26.getType();
        try {
            long long34 = unsupportedDateTimeField26.roundCeiling(1560343537018L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfMinute" + "'", str12.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 18059 + "'", int30 == 18059);
        org.junit.Assert.assertNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long4 = dateTimeZone2.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology7);
        mutableDateTime8.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        boolean boolean15 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        int int16 = mutableDateTime14.getMonthOfYear();
        org.joda.time.Chronology chronology17 = mutableDateTime14.getChronology();
        int int18 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime14.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime21 = property19.add((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.year();
        org.joda.time.IllegalInstantException illegalInstantException25 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean26 = gregorianChronology22.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology22.getZone();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology22.halfdayOfDay();
        java.lang.String str29 = gregorianChronology22.toString();
        int int30 = gregorianChronology22.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology31.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, dateTimeField32, 4320000);
        long long37 = skipUndoDateTimeField34.set(1560343544324L, 3);
        int int38 = skipUndoDateTimeField34.getMinimumValue();
        int int40 = skipUndoDateTimeField34.get((long) 999);
        mutableDateTime21.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField34);
        int int43 = skipUndoDateTimeField34.getLeapAmount(0L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4320010L + "'", long4 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4320000 + "'", int18 == 4320000);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "GregorianChronology[UTC]" + "'", str29.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560297600002L + "'", long37 == 1560297600002L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1000 + "'", int40 == 1000);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("(\"org.joda.time.JodaTimePermission\" \"BuddhistChronology[UTC]\")", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"(\"org.joda.time.JodaTimePermission\" \"BuddhistChronology[UTC]\")/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfMonth(12);
        org.joda.time.DateTime dateTime7 = dateTime6.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology10);
        int int12 = mutableDateTime11.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology15);
        mutableDateTime16.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology21);
        boolean boolean23 = mutableDateTime16.isEqual((org.joda.time.ReadableInstant) mutableDateTime22);
        int int24 = mutableDateTime22.getMinuteOfHour();
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime11, (org.joda.time.ReadableInstant) mutableDateTime22);
        boolean boolean26 = dateTime6.isBefore((org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.DateTime dateTime28 = dateTime6.withMillis((long) ' ');
        org.joda.time.DateTime.Property property29 = dateTime6.year();
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime31 = dateTime6.plus(readableDuration30);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone33);
        org.joda.time.DateTime dateTime36 = dateTime34.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime dateTime38 = dateTime34.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTime.Property property39 = dateTime34.monthOfYear();
        org.joda.time.chrono.LimitChronology limitChronology40 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.ReadableDateTime) dateTime6, (org.joda.time.ReadableDateTime) dateTime34);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.year();
        org.joda.time.IllegalInstantException illegalInstantException44 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean45 = gregorianChronology41.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology41.getZone();
        org.joda.time.Chronology chronology47 = limitChronology40.withZone(dateTimeZone46);
        org.joda.time.DateTime dateTime48 = limitChronology40.getUpperLimit();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone53 = new org.joda.time.tz.FixedDateTimeZone("2000", "Dec", 19, (int) (byte) 0);
        java.util.TimeZone timeZone54 = fixedDateTimeZone53.toTimeZone();
        java.lang.String str56 = fixedDateTimeZone53.getNameKey((long) ' ');
        org.joda.time.LocalDateTime localDateTime57 = null;
        boolean boolean58 = fixedDateTimeZone53.isLocalDateTimeGap(localDateTime57);
        long long61 = fixedDateTimeZone53.adjustOffset((long) 26005725, false);
        int int63 = fixedDateTimeZone53.getStandardOffset(0L);
        org.joda.time.Chronology chronology64 = limitChronology40.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone53);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 999 + "'", int12 == 999);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 59 + "'", int24 == 59);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(limitChronology40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Dec" + "'", str56.equals("Dec"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 26005725L + "'", long61 == 26005725L);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(chronology64);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(421);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder3.appendHourOfHalfday(4);
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatterBuilder12.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatter14.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatter16.getPrinter();
        boolean boolean18 = dateTimeFormatter16.isPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray20 = new org.joda.time.format.DateTimeParser[] { dateTimeParser19 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder12.append(dateTimePrinter15, dateTimeParserArray20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder22.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder22.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder22.appendHourOfHalfday(4);
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatterBuilder31.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter34 = dateTimeFormatter33.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter36 = dateTimeFormatter35.getPrinter();
        boolean boolean37 = dateTimeFormatter35.isPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser38 = dateTimeFormatter35.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray39 = new org.joda.time.format.DateTimeParser[] { dateTimeParser38 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder31.append(dateTimePrinter34, dateTimeParserArray39);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder2.append(dateTimePrinter15, dateTimeParserArray39);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimePrinter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimePrinter17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeParserArray20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimePrinter34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimePrinter36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(dateTimeParser38);
        org.junit.Assert.assertNotNull(dateTimeParserArray39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.append(dateTimeFormatter1);
        java.lang.Appendable appendable3 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology6);
        mutableDateTime7.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology12);
        boolean boolean14 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) mutableDateTime13);
        int int15 = mutableDateTime13.getMinuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology18);
        long long23 = julianChronology18.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField24 = julianChronology18.minuteOfHour();
        long long28 = julianChronology18.add((long) 59, 10L, (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long33 = dateTimeZone31.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        int int45 = mutableDateTime43.getMonthOfYear();
        org.joda.time.Chronology chronology46 = mutableDateTime43.getChronology();
        int int47 = dateTimeZone31.getOffset((org.joda.time.ReadableInstant) mutableDateTime43);
        java.lang.String str49 = dateTimeZone31.getName(0L);
        org.joda.time.Chronology chronology50 = julianChronology18.withZone(dateTimeZone31);
        org.joda.time.MutableDateTime mutableDateTime51 = mutableDateTime13.toMutableDateTime(dateTimeZone31);
        try {
            dateTimeFormatter1.printTo(appendable3, (org.joda.time.ReadableInstant) mutableDateTime51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 59 + "'", int15 == 59);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 59L + "'", long28 == 59L);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 4320010L + "'", long33 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4320000 + "'", int47 == 4320000);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "+01:12" + "'", str49.equals("+01:12"));
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(mutableDateTime51);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property14 = dateTime13.year();
        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField16 = property14.getField();
        org.joda.time.DateTime dateTime17 = property14.roundCeilingCopy();
        mutableDateTime7.setMillis((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime19 = dateTime17.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime19.plusMillis(19);
        org.joda.time.DateTime.Property property22 = dateTime19.hourOfDay();
        int int23 = property22.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 23 + "'", int23 == 23);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendHourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTimeZoneName(strMap11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendSecondOfDay(2000);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.append(dateTimeFormatter15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField19 = julianChronology18.seconds();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        boolean boolean22 = julianChronology18.equals((java.lang.Object) julianChronology21);
        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology18.getZone();
        org.joda.time.DurationField durationField24 = julianChronology18.days();
        org.joda.time.DateTimeField dateTimeField25 = julianChronology18.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        mutableDateTime3.setChronology((org.joda.time.Chronology) julianChronology13);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int17 = gregorianChronology16.getMinimumDaysInFirstWeek();
        java.util.Locale locale18 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology16, locale18, (java.lang.Integer) 1969);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology23);
        mutableDateTime24.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology29);
        boolean boolean31 = mutableDateTime24.isEqual((org.joda.time.ReadableInstant) mutableDateTime30);
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime24.secondOfMinute();
        java.lang.String str33 = property32.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property32.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType34, (int) (short) 10, 1, 999);
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1560343540608L, "secondOfMinute");
        dateTimeParserBucket20.saveField(dateTimeFieldType34, (int) (byte) 1);
        boolean boolean44 = mutableDateTime3.isSupported(dateTimeFieldType34);
        try {
            mutableDateTime3.setDate(14, (int) (byte) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "secondOfMinute" + "'", str33.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.yearOfEra();
        java.lang.String str6 = property5.getAsText();
        org.joda.time.DateTime dateTime7 = property5.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(10);
        int int10 = dateTime7.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = dateTime4.toCalendar(locale5);
        org.joda.time.DateTime dateTime8 = dateTime4.withCenturyOfEra(0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(calendar6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        int int4 = mutableDateTime3.getMillisOfSecond();
        mutableDateTime3.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long11 = dateTimeZone9.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology14);
        mutableDateTime15.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology20);
        boolean boolean22 = mutableDateTime15.isEqual((org.joda.time.ReadableInstant) mutableDateTime21);
        int int23 = mutableDateTime21.getMonthOfYear();
        org.joda.time.Chronology chronology24 = mutableDateTime21.getChronology();
        int int25 = dateTimeZone9.getOffset((org.joda.time.ReadableInstant) mutableDateTime21);
        mutableDateTime3.setZoneRetainFields(dateTimeZone9);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime3.dayOfYear();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 999 + "'", int4 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4320010L + "'", long11 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 12 + "'", int23 == 12);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4320000 + "'", int25 == 4320000);
        org.junit.Assert.assertNotNull(property27);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        int int4 = mutableDateTime3.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology7);
        mutableDateTime8.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        boolean boolean15 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        int int16 = mutableDateTime14.getMinuteOfHour();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime3.era();
        org.joda.time.MutableDateTime mutableDateTime19 = property18.getMutableDateTime();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 999 + "'", int4 == 999);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder1.appendHourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatterBuilder11.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime3.getYear();
        mutableDateTime3.addSeconds(4);
        int int14 = mutableDateTime3.getRoundingMode();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.halfdayOfDay();
        java.lang.String str7 = gregorianChronology0.toString();
        int int8 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField10, 4320000);
        long long15 = skipUndoDateTimeField12.set(1560343544324L, 3);
        int int16 = skipUndoDateTimeField12.getMinimumValue();
        int int18 = skipUndoDateTimeField12.get((long) 5);
        int int19 = skipUndoDateTimeField12.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[UTC]" + "'", str7.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560297600002L + "'", long15 == 1560297600002L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        java.io.Writer writer4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = julianChronology6.seconds();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = julianChronology6.equals((java.lang.Object) julianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = julianChronology6.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray15 = new int[] { 2000 };
        int int16 = delegatedDateTimeField12.getMaximumValue(readablePartial13, intArray15);
        java.lang.String str18 = delegatedDateTimeField12.getAsText((long) (short) 0);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField12.getLeapDurationField();
        org.joda.time.DateTimeField dateTimeField20 = delegatedDateTimeField12.getWrappedField();
        long long23 = delegatedDateTimeField12.add((long) (byte) 100, 15);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone25);
        int int27 = dateTime26.getSecondOfMinute();
        org.joda.time.DateTime.Property property28 = dateTime26.monthOfYear();
        org.joda.time.DateTime dateTime29 = property28.getDateTime();
        org.joda.time.LocalDateTime localDateTime30 = dateTime29.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone32);
        org.joda.time.DateTime dateTime35 = dateTime33.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property36 = dateTime35.year();
        org.joda.time.DateTime dateTime37 = property36.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField38 = property36.getField();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        mutableDateTime43.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.chrono.JulianChronology julianChronology48 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone47);
        org.joda.time.MutableDateTime mutableDateTime49 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology48);
        boolean boolean50 = mutableDateTime43.isEqual((org.joda.time.ReadableInstant) mutableDateTime49);
        org.joda.time.MutableDateTime.Property property51 = mutableDateTime43.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.JulianChronology julianChronology53 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone52);
        mutableDateTime43.setChronology((org.joda.time.Chronology) julianChronology53);
        java.util.Locale locale55 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket57 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology53, locale55, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.chrono.JulianChronology julianChronology60 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone59);
        org.joda.time.MutableDateTime mutableDateTime61 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology60);
        int int62 = mutableDateTime61.getMillisOfSecond();
        mutableDateTime61.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone67 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long69 = dateTimeZone67.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.chrono.JulianChronology julianChronology72 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone71);
        org.joda.time.MutableDateTime mutableDateTime73 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology72);
        mutableDateTime73.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone77 = null;
        org.joda.time.chrono.JulianChronology julianChronology78 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone77);
        org.joda.time.MutableDateTime mutableDateTime79 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology78);
        boolean boolean80 = mutableDateTime73.isEqual((org.joda.time.ReadableInstant) mutableDateTime79);
        int int81 = mutableDateTime79.getMonthOfYear();
        org.joda.time.Chronology chronology82 = mutableDateTime79.getChronology();
        int int83 = dateTimeZone67.getOffset((org.joda.time.ReadableInstant) mutableDateTime79);
        mutableDateTime61.setZoneRetainFields(dateTimeZone67);
        dateTimeParserBucket57.setZone(dateTimeZone67);
        java.util.Locale locale86 = dateTimeParserBucket57.getLocale();
        java.lang.String str87 = property36.getAsText(locale86);
        java.lang.String str88 = delegatedDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDateTime30, locale86);
        try {
            dateTimeFormatter0.printTo(writer4, (org.joda.time.ReadablePartial) localDateTime30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 900100L + "'", long23 == 900100L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localDateTime30);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(julianChronology48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(julianChronology53);
        org.junit.Assert.assertNotNull(julianChronology60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 999 + "'", int62 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 4320010L + "'", long69 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology72);
        org.junit.Assert.assertNotNull(julianChronology78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 12 + "'", int81 == 12);
        org.junit.Assert.assertNotNull(chronology82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 4320000 + "'", int83 == 4320000);
        org.junit.Assert.assertNotNull(locale86);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "1969" + "'", str87.equals("1969"));
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "0" + "'", str88.equals("0"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.minuteOfDay();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.withEra((int) (short) 1);
        org.joda.time.DateTime dateTime10 = dateTime6.withEra(0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(12);
        org.joda.time.DateTime dateTime6 = dateTime2.plusMonths((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology10);
        mutableDateTime11.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        boolean boolean18 = mutableDateTime11.isEqual((org.joda.time.ReadableInstant) mutableDateTime17);
        int int19 = mutableDateTime17.getMonthOfYear();
        org.joda.time.Chronology chronology20 = mutableDateTime17.getChronology();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime17.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology24);
        mutableDateTime25.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology30);
        boolean boolean32 = mutableDateTime25.isEqual((org.joda.time.ReadableInstant) mutableDateTime31);
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime25.secondOfMinute();
        mutableDateTime17.setTime((org.joda.time.ReadableInstant) mutableDateTime25);
        mutableDateTime25.addYears((int) (byte) -1);
        int int37 = property7.getDifference((org.joda.time.ReadableInstant) mutableDateTime25);
        int int38 = mutableDateTime25.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 353 + "'", int38 == 353);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (byte) 0);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.minus(readablePeriod7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.minus(readablePeriod9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded(readableDuration11, 14);
        org.joda.time.DateTime dateTime15 = dateTime10.minusSeconds((int) (byte) 0);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology4);
        mutableDateTime5.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology10);
        boolean boolean12 = mutableDateTime5.isEqual((org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime5.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        mutableDateTime5.setChronology((org.joda.time.Chronology) julianChronology15);
        java.util.Locale locale17 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket19 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology15, locale17, (java.lang.Integer) 59);
        java.lang.String str20 = julianChronology15.toString();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology15.hourOfDay();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(1560343556595L, (org.joda.time.Chronology) julianChronology15);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str20.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        mutableDateTime0.add(readablePeriod1, 100);
        mutableDateTime0.addDays(53999);
        org.junit.Assert.assertNotNull(mutableDateTime0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.Chronology chronology12 = mutableDateTime9.getChronology();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime9.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        mutableDateTime17.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        boolean boolean24 = mutableDateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime17.secondOfMinute();
        mutableDateTime9.setTime((org.joda.time.ReadableInstant) mutableDateTime17);
        mutableDateTime17.addDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology31);
        mutableDateTime32.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology37);
        boolean boolean39 = mutableDateTime32.isEqual((org.joda.time.ReadableInstant) mutableDateTime38);
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime32.secondOfMinute();
        java.lang.String str41 = property40.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property40.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType42, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.chrono.JulianChronology julianChronology48 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone47);
        org.joda.time.DurationField durationField49 = julianChronology48.seconds();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone50);
        boolean boolean52 = julianChronology48.equals((java.lang.Object) julianChronology51);
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology48.getZone();
        org.joda.time.DurationField durationField54 = julianChronology48.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField54);
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = unsupportedDateTimeField55.getType();
        org.joda.time.MutableDateTime.Property property57 = mutableDateTime17.property(dateTimeFieldType56);
        org.joda.time.IllegalFieldValueException illegalFieldValueException61 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType56, (java.lang.Number) 26006929, (java.lang.Number) (byte) 100, (java.lang.Number) (-1));
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "secondOfMinute" + "'", str41.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(julianChronology48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertNotNull(property57);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("BuddhistChronology[UTC]");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = julianChronology5.seconds();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        boolean boolean9 = julianChronology5.equals((java.lang.Object) julianChronology8);
        org.joda.time.DurationField durationField10 = julianChronology8.weekyears();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology8.dayOfYear();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology8.weekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        long long16 = julianChronology8.add(readablePeriod13, 60000L, 1969);
        boolean boolean17 = jodaTimePermission1.equals((java.lang.Object) long16);
        java.lang.String str18 = jodaTimePermission1.getActions();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = julianChronology20.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        boolean boolean24 = julianChronology20.equals((java.lang.Object) julianChronology23);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology20.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        java.util.Locale locale27 = null;
        int int28 = delegatedDateTimeField26.getMaximumShortTextLength(locale27);
        org.joda.time.DateTimeField dateTimeField29 = delegatedDateTimeField26.getWrappedField();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider31 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology35);
        mutableDateTime36.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone40);
        org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology41);
        boolean boolean43 = mutableDateTime36.isEqual((org.joda.time.ReadableInstant) mutableDateTime42);
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime36.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone45);
        mutableDateTime36.setChronology((org.joda.time.Chronology) julianChronology46);
        java.util.Locale locale48 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket50 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology46, locale48, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.JulianChronology julianChronology53 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone52);
        org.joda.time.MutableDateTime mutableDateTime54 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology53);
        int int55 = mutableDateTime54.getMillisOfSecond();
        mutableDateTime54.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long62 = dateTimeZone60.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.chrono.JulianChronology julianChronology65 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone64);
        org.joda.time.MutableDateTime mutableDateTime66 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology65);
        mutableDateTime66.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone70 = null;
        org.joda.time.chrono.JulianChronology julianChronology71 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone70);
        org.joda.time.MutableDateTime mutableDateTime72 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology71);
        boolean boolean73 = mutableDateTime66.isEqual((org.joda.time.ReadableInstant) mutableDateTime72);
        int int74 = mutableDateTime72.getMonthOfYear();
        org.joda.time.Chronology chronology75 = mutableDateTime72.getChronology();
        int int76 = dateTimeZone60.getOffset((org.joda.time.ReadableInstant) mutableDateTime72);
        mutableDateTime54.setZoneRetainFields(dateTimeZone60);
        dateTimeParserBucket50.setZone(dateTimeZone60);
        java.util.Locale locale79 = dateTimeParserBucket50.getLocale();
        java.lang.String str82 = defaultNameProvider31.getName(locale79, "JulianChronology[America/Los_Angeles]", "yearOfEra");
        java.lang.String str83 = delegatedDateTimeField26.getAsText(1560343546296L, locale79);
        int int85 = delegatedDateTimeField26.getLeapAmount((long) 2000);
        jodaTimePermission1.checkGuard((java.lang.Object) 2000);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[UTC]" + "'", str3.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 60000L + "'", long16 == 60000L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(julianChronology41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(julianChronology46);
        org.junit.Assert.assertNotNull(julianChronology53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 999 + "'", int55 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 4320010L + "'", long62 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology65);
        org.junit.Assert.assertNotNull(julianChronology71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 12 + "'", int74 == 12);
        org.junit.Assert.assertNotNull(chronology75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 4320000 + "'", int76 == 4320000);
        org.junit.Assert.assertNotNull(locale79);
        org.junit.Assert.assertNull(str82);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "45" + "'", str83.equals("45"));
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long6 = dateTimeZone4.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        mutableDateTime10.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology15);
        boolean boolean17 = mutableDateTime10.isEqual((org.joda.time.ReadableInstant) mutableDateTime16);
        int int18 = mutableDateTime16.getMonthOfYear();
        org.joda.time.Chronology chronology19 = mutableDateTime16.getChronology();
        int int20 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) mutableDateTime16);
        java.lang.String str22 = dateTimeZone4.getName(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone23 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        java.lang.Object obj24 = null;
        boolean boolean25 = cachedDateTimeZone23.equals(obj24);
        org.joda.time.Chronology chronology26 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DurationField durationField28 = iSOChronology1.halfdays();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4320010L + "'", long6 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4320000 + "'", int20 == 4320000);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+01:12" + "'", str22.equals("+01:12"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.months();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField4 = julianChronology1.centuries();
        int int5 = julianChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2000", "secondOfMinute", 1969, 16);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (-292275054));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        mutableDateTime10.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology15);
        boolean boolean17 = mutableDateTime10.isEqual((org.joda.time.ReadableInstant) mutableDateTime16);
        int int18 = mutableDateTime16.getMonthOfYear();
        org.joda.time.Chronology chronology19 = mutableDateTime16.getChronology();
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime16.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology23);
        mutableDateTime24.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology29);
        boolean boolean31 = mutableDateTime24.isEqual((org.joda.time.ReadableInstant) mutableDateTime30);
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime24.secondOfMinute();
        mutableDateTime16.setTime((org.joda.time.ReadableInstant) mutableDateTime24);
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime16.weekOfWeekyear();
        mutableDateTime16.setDate((long) 53999);
        int int37 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) mutableDateTime16);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1969 + "'", int37 == 1969);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfMonth(12);
        org.joda.time.DateTime dateTime7 = dateTime6.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology10);
        int int12 = mutableDateTime11.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology15);
        mutableDateTime16.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology21);
        boolean boolean23 = mutableDateTime16.isEqual((org.joda.time.ReadableInstant) mutableDateTime22);
        int int24 = mutableDateTime22.getMinuteOfHour();
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime11, (org.joda.time.ReadableInstant) mutableDateTime22);
        boolean boolean26 = dateTime6.isBefore((org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.DateTime dateTime28 = dateTime6.withMillis((long) ' ');
        org.joda.time.DateTime.Property property29 = dateTime6.year();
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime31 = dateTime6.plus(readableDuration30);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone33);
        org.joda.time.DateTime dateTime36 = dateTime34.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime dateTime38 = dateTime34.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTime.Property property39 = dateTime34.monthOfYear();
        org.joda.time.chrono.LimitChronology limitChronology40 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.ReadableDateTime) dateTime6, (org.joda.time.ReadableDateTime) dateTime34);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.year();
        org.joda.time.IllegalInstantException illegalInstantException44 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean45 = gregorianChronology41.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology41.getZone();
        org.joda.time.Chronology chronology47 = limitChronology40.withZone(dateTimeZone46);
        org.joda.time.DateTime dateTime48 = limitChronology40.getUpperLimit();
        org.joda.time.DateTime dateTime49 = limitChronology40.getLowerLimit();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 999 + "'", int12 == 999);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 59 + "'", int24 == 59);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(limitChronology40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime49);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendHourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTimeZoneName(strMap11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendSecondOfDay(2000);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.append(dateTimeFormatter15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(0L);
        int int2 = mutableDateTime1.getRoundingMode();
        mutableDateTime1.addMinutes(59);
        int int5 = mutableDateTime1.getYearOfCentury();
        mutableDateTime1.setMillis((long) 999);
        int int8 = mutableDateTime1.getWeekOfWeekyear();
        mutableDateTime1.setDayOfYear(51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.year();
        org.joda.time.IllegalInstantException illegalInstantException4 = new org.joda.time.IllegalInstantException("secondOfMinute");
        boolean boolean5 = gregorianChronology1.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.halfdayOfDay();
        java.lang.Class<?> wildcardClass8 = gregorianChronology1.getClass();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = julianChronology10.seconds();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        boolean boolean14 = julianChronology10.equals((java.lang.Object) julianChronology13);
        org.joda.time.DateTimeField dateTimeField15 = julianChronology10.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.util.Locale locale17 = null;
        int int18 = delegatedDateTimeField16.getMaximumShortTextLength(locale17);
        org.joda.time.DateTimeField dateTimeField19 = delegatedDateTimeField16.getWrappedField();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider21 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology25);
        mutableDateTime26.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology31);
        boolean boolean33 = mutableDateTime26.isEqual((org.joda.time.ReadableInstant) mutableDateTime32);
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime26.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        mutableDateTime26.setChronology((org.joda.time.Chronology) julianChronology36);
        java.util.Locale locale38 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket40 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology36, locale38, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone42);
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology43);
        int int45 = mutableDateTime44.getMillisOfSecond();
        mutableDateTime44.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long52 = dateTimeZone50.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone54);
        org.joda.time.MutableDateTime mutableDateTime56 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology55);
        mutableDateTime56.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone60);
        org.joda.time.MutableDateTime mutableDateTime62 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology61);
        boolean boolean63 = mutableDateTime56.isEqual((org.joda.time.ReadableInstant) mutableDateTime62);
        int int64 = mutableDateTime62.getMonthOfYear();
        org.joda.time.Chronology chronology65 = mutableDateTime62.getChronology();
        int int66 = dateTimeZone50.getOffset((org.joda.time.ReadableInstant) mutableDateTime62);
        mutableDateTime44.setZoneRetainFields(dateTimeZone50);
        dateTimeParserBucket40.setZone(dateTimeZone50);
        java.util.Locale locale69 = dateTimeParserBucket40.getLocale();
        java.lang.String str72 = defaultNameProvider21.getName(locale69, "JulianChronology[America/Los_Angeles]", "yearOfEra");
        java.lang.String str73 = delegatedDateTimeField16.getAsText(1560343546296L, locale69);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket76 = new org.joda.time.format.DateTimeParserBucket((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1, locale69, (java.lang.Integer) 26006929, 2922789);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 999 + "'", int45 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 4320010L + "'", long52 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 12 + "'", int64 == 12);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 4320000 + "'", int66 == 4320000);
        org.junit.Assert.assertNotNull(locale69);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "45" + "'", str73.equals("45"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        java.lang.String str13 = property12.getAsShortText();
        org.joda.time.MutableDateTime mutableDateTime14 = property12.roundHalfFloor();
        mutableDateTime14.setTime((long) 12);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology19);
        mutableDateTime20.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology25);
        boolean boolean27 = mutableDateTime20.isEqual((org.joda.time.ReadableInstant) mutableDateTime26);
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime20.secondOfMinute();
        java.lang.String str29 = property28.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property28.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType30, (int) (short) 10, 1, 999);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.DurationField durationField37 = julianChronology36.seconds();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38);
        boolean boolean40 = julianChronology36.equals((java.lang.Object) julianChronology39);
        org.joda.time.DateTimeZone dateTimeZone41 = julianChronology36.getZone();
        org.joda.time.DurationField durationField42 = julianChronology36.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType30, durationField42);
        int int44 = mutableDateTime14.get(dateTimeFieldType30);
        org.joda.time.IllegalInstantException illegalInstantException47 = new org.joda.time.IllegalInstantException((long) 15, "");
        boolean boolean48 = mutableDateTime14.equals((java.lang.Object) 15);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Dec" + "'", str13.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "secondOfMinute" + "'", str29.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        int int3 = dateTime2.getSecondOfMinute();
        org.joda.time.DateTime dateTime5 = dateTime2.plusDays(3600000);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMillis((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime3.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        boolean boolean10 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = mutableDateTime9.getMonthOfYear();
        org.joda.time.Chronology chronology12 = mutableDateTime9.getChronology();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime9.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        mutableDateTime17.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        boolean boolean24 = mutableDateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime17.secondOfMinute();
        mutableDateTime9.setTime((org.joda.time.ReadableInstant) mutableDateTime17);
        boolean boolean27 = mutableDateTime9.isEqualNow();
        mutableDateTime9.addWeeks(5);
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime9.era();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(property30);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        long long7 = julianChronology2.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.Chronology chronology8 = julianChronology2.withUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, (int) '4');
        org.joda.time.Chronology chronology12 = julianChronology2.withZone(dateTimeZone11);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, 45955771);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 45955771");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("BuddhistChronology[UTC]");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = julianChronology5.seconds();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        boolean boolean9 = julianChronology5.equals((java.lang.Object) julianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = julianChronology5.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        java.util.Locale locale12 = null;
        int int13 = delegatedDateTimeField11.getMaximumShortTextLength(locale12);
        org.joda.time.DateTimeField dateTimeField14 = delegatedDateTimeField11.getWrappedField();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider15 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology19);
        mutableDateTime20.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology25);
        boolean boolean27 = mutableDateTime20.isEqual((org.joda.time.ReadableInstant) mutableDateTime26);
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime20.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        mutableDateTime20.setChronology((org.joda.time.Chronology) julianChronology30);
        java.util.Locale locale32 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket34 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology30, locale32, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology37);
        int int39 = mutableDateTime38.getMillisOfSecond();
        mutableDateTime38.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long46 = dateTimeZone44.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.JulianChronology julianChronology49 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone48);
        org.joda.time.MutableDateTime mutableDateTime50 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology49);
        mutableDateTime50.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone54);
        org.joda.time.MutableDateTime mutableDateTime56 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology55);
        boolean boolean57 = mutableDateTime50.isEqual((org.joda.time.ReadableInstant) mutableDateTime56);
        int int58 = mutableDateTime56.getMonthOfYear();
        org.joda.time.Chronology chronology59 = mutableDateTime56.getChronology();
        int int60 = dateTimeZone44.getOffset((org.joda.time.ReadableInstant) mutableDateTime56);
        mutableDateTime38.setZoneRetainFields(dateTimeZone44);
        dateTimeParserBucket34.setZone(dateTimeZone44);
        java.util.Locale locale63 = dateTimeParserBucket34.getLocale();
        java.lang.String str66 = defaultNameProvider15.getName(locale63, "JulianChronology[America/Los_Angeles]", "yearOfEra");
        int int67 = delegatedDateTimeField11.getMaximumTextLength(locale63);
        org.joda.time.ReadablePartial readablePartial68 = null;
        int int69 = delegatedDateTimeField11.getMaximumValue(readablePartial68);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = delegatedDateTimeField11.getType();
        long long72 = delegatedDateTimeField11.roundHalfCeiling((long) 7);
        boolean boolean73 = jodaTimePermission1.equals((java.lang.Object) 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[UTC]" + "'", str3.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 999 + "'", int39 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 4320010L + "'", long46 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology49);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 12 + "'", int58 == 12);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 4320000 + "'", int60 == 4320000);
        org.junit.Assert.assertNotNull(locale63);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2 + "'", int67 == 2);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 59 + "'", int69 == 59);
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        long long59 = offsetDateTimeField57.remainder(1560343537018L);
        org.joda.time.DateTimeField dateTimeField60 = offsetDateTimeField57.getWrappedField();
        long long62 = offsetDateTimeField57.roundCeiling((long) 7);
        java.lang.Class<?> wildcardClass63 = offsetDateTimeField57.getClass();
        org.joda.time.DurationField durationField64 = offsetDateTimeField57.getLeapDurationField();
        int int66 = offsetDateTimeField57.getMinimumValue(0L);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 37018L + "'", long59 == 37018L);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 60000L + "'", long62 == 60000L);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNull(durationField64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2000 + "'", int66 == 2000);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        long long59 = offsetDateTimeField57.remainder(1560343537018L);
        org.joda.time.DateTimeField dateTimeField60 = offsetDateTimeField57.getWrappedField();
        long long62 = offsetDateTimeField57.roundCeiling((long) 7);
        int int64 = offsetDateTimeField57.get(31507200100L);
        java.lang.String str65 = offsetDateTimeField57.getName();
        boolean boolean67 = offsetDateTimeField57.isLeap(0L);
        long long69 = offsetDateTimeField57.roundHalfCeiling(1560368755771L);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 37018L + "'", long59 == 37018L);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 60000L + "'", long62 == 60000L);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1969 + "'", int64 == 1969);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "secondOfMinute" + "'", str65.equals("secondOfMinute"));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560368760000L + "'", long69 == 1560368760000L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology2);
        int int4 = mutableDateTime3.getMillisOfSecond();
        int int5 = mutableDateTime3.getYearOfCentury();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 999 + "'", int4 == 999);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2000", "secondOfMinute", 1969, 16);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 2922730);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        try {
            mutableDateTime2.setDateTime((-33), 0, (int) (byte) 10, 0, 352, (-4320001), 14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 352 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long4 = dateTimeZone2.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology7);
        mutableDateTime8.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        boolean boolean15 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        int int16 = mutableDateTime14.getMonthOfYear();
        org.joda.time.Chronology chronology17 = mutableDateTime14.getChronology();
        int int18 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime14.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime20 = property19.roundCeiling();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4320010L + "'", long4 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4320000 + "'", int18 == 4320000);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long5 = dateTimeZone3.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology8);
        mutableDateTime9.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology14);
        boolean boolean16 = mutableDateTime9.isEqual((org.joda.time.ReadableInstant) mutableDateTime15);
        int int17 = mutableDateTime15.getMonthOfYear();
        org.joda.time.Chronology chronology18 = mutableDateTime15.getChronology();
        int int19 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) mutableDateTime15);
        java.lang.String str21 = dateTimeZone3.getName(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.lang.Object obj23 = null;
        boolean boolean24 = cachedDateTimeZone22.equals(obj23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone22, 3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4320010L + "'", long5 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4320000 + "'", int19 == 4320000);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+01:12" + "'", str21.equals("+01:12"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(julianChronology27);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField7 = property5.getField();
        org.joda.time.DateTime dateTime8 = property5.roundCeilingCopy();
        org.joda.time.DurationField durationField9 = property5.getDurationField();
        org.joda.time.DateTimeField dateTimeField10 = property5.getField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.yearOfEra();
        java.lang.String str6 = property5.getAsText();
        org.joda.time.DateTime dateTime7 = property5.getDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology2, locale4, (java.lang.Integer) 1969);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.Chronology chronology11 = gregorianChronology2.withZone(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DurationField durationField14 = julianChronology13.seconds();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology13.dayOfYear();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology13.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField16, (-876825162));
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology3);
        mutableDateTime4.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology9);
        boolean boolean11 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology14, locale16, (java.lang.Integer) 59);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        long long27 = julianChronology22.add((long) 100, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology22.minuteOfHour();
        dateTimeParserBucket18.saveField(dateTimeField28, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        mutableDateTime37.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        boolean boolean44 = mutableDateTime37.isEqual((org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime37.secondOfMinute();
        java.lang.String str46 = property45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType47, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType47, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType47, 1969, 2000, 12);
        org.joda.time.DurationField durationField58 = offsetDateTimeField57.getLeapDurationField();
        org.joda.time.DurationField durationField59 = offsetDateTimeField57.getRangeDurationField();
        long long61 = offsetDateTimeField57.roundHalfEven((long) (-4320001));
        java.lang.String str63 = offsetDateTimeField57.getAsShortText(0L);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfMinute" + "'", str46.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-4320000L) + "'", long61 == (-4320000L));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "1969" + "'", str63.equals("1969"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.dayOfMonth();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.minus(readableDuration6);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology2, locale4, (java.lang.Integer) 1969);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) 'a');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) zonedChronology11);
        org.joda.time.Chronology chronology13 = zonedChronology11.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DurationField durationField6 = julianChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology4.dayOfYear();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology4.weekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = julianChronology4.add(readablePeriod9, 60000L, 1969);
        org.joda.time.DateTimeField dateTimeField13 = julianChronology4.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("2000", "secondOfMinute", 1969, 16);
        java.util.TimeZone timeZone19 = fixedDateTimeZone18.toTimeZone();
        org.joda.time.Chronology chronology20 = julianChronology4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        long long22 = fixedDateTimeZone18.previousTransition((long) (-33));
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60000L + "'", long12 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-33L) + "'", long22 == (-33L));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter1.getPrinter();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = julianChronology6.seconds();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = julianChronology6.equals((java.lang.Object) julianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = julianChronology6.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        java.util.Locale locale13 = null;
        int int14 = delegatedDateTimeField12.getMaximumShortTextLength(locale13);
        org.joda.time.DateTimeField dateTimeField15 = delegatedDateTimeField12.getWrappedField();
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = delegatedDateTimeField12.getMaximumValue(readablePartial16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.tz.DefaultNameProvider defaultNameProvider20 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology24);
        mutableDateTime25.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology30);
        boolean boolean32 = mutableDateTime25.isEqual((org.joda.time.ReadableInstant) mutableDateTime31);
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime25.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
        mutableDateTime25.setChronology((org.joda.time.Chronology) julianChronology35);
        java.util.Locale locale37 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket39 = new org.joda.time.format.DateTimeParserBucket(52L, (org.joda.time.Chronology) julianChronology35, locale37, (java.lang.Integer) 59);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology42);
        int int44 = mutableDateTime43.getMillisOfSecond();
        mutableDateTime43.setSecondOfDay((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long51 = dateTimeZone49.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.chrono.JulianChronology julianChronology54 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone53);
        org.joda.time.MutableDateTime mutableDateTime55 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology54);
        mutableDateTime55.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.chrono.JulianChronology julianChronology60 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone59);
        org.joda.time.MutableDateTime mutableDateTime61 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology60);
        boolean boolean62 = mutableDateTime55.isEqual((org.joda.time.ReadableInstant) mutableDateTime61);
        int int63 = mutableDateTime61.getMonthOfYear();
        org.joda.time.Chronology chronology64 = mutableDateTime61.getChronology();
        int int65 = dateTimeZone49.getOffset((org.joda.time.ReadableInstant) mutableDateTime61);
        mutableDateTime43.setZoneRetainFields(dateTimeZone49);
        dateTimeParserBucket39.setZone(dateTimeZone49);
        java.util.Locale locale68 = dateTimeParserBucket39.getLocale();
        java.lang.String str71 = defaultNameProvider20.getName(locale68, "JulianChronology[America/Los_Angeles]", "yearOfEra");
        java.lang.String str72 = delegatedDateTimeField12.getAsText(readablePartial18, 59, locale68);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = dateTimeFormatter1.withLocale(locale68);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter74 = dateTimeFormatter0.withLocale(locale68);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 59 + "'", int17 == 59);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 999 + "'", int44 == 999);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 4320010L + "'", long51 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology54);
        org.junit.Assert.assertNotNull(julianChronology60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 12 + "'", int63 == 12);
        org.junit.Assert.assertNotNull(chronology64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 4320000 + "'", int65 == 4320000);
        org.junit.Assert.assertNotNull(locale68);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "59" + "'", str72.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFormatter73);
        org.junit.Assert.assertNotNull(dateTimeFormatter74);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray10 = new int[] { 2000 };
        int int11 = delegatedDateTimeField7.getMaximumValue(readablePartial8, intArray10);
        java.lang.String str13 = delegatedDateTimeField7.getAsText((long) (short) 0);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField7.getLeapDurationField();
        org.joda.time.DateTimeField dateTimeField15 = delegatedDateTimeField7.getWrappedField();
        long long18 = delegatedDateTimeField7.add((long) (byte) 100, 15);
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = julianChronology21.seconds();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        boolean boolean25 = julianChronology21.equals((java.lang.Object) julianChronology24);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology21.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26);
        java.util.Locale locale28 = null;
        int int29 = delegatedDateTimeField27.getMaximumShortTextLength(locale28);
        long long31 = delegatedDateTimeField27.roundFloor(1560343540608L);
        org.joda.time.ReadablePartial readablePartial32 = null;
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone33);
        org.joda.time.DurationField durationField35 = julianChronology34.seconds();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        boolean boolean38 = julianChronology34.equals((java.lang.Object) julianChronology37);
        org.joda.time.DateTimeField dateTimeField39 = julianChronology34.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39);
        org.joda.time.ReadablePartial readablePartial41 = null;
        int[] intArray43 = new int[] { 2000 };
        int int44 = delegatedDateTimeField40.getMaximumValue(readablePartial41, intArray43);
        int int45 = delegatedDateTimeField27.getMinimumValue(readablePartial32, intArray43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder46.appendMillisOfSecond(19);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone50);
        org.joda.time.MutableDateTime mutableDateTime52 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology51);
        mutableDateTime52.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone56);
        org.joda.time.MutableDateTime mutableDateTime58 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology57);
        boolean boolean59 = mutableDateTime52.isEqual((org.joda.time.ReadableInstant) mutableDateTime58);
        org.joda.time.MutableDateTime.Property property60 = mutableDateTime52.secondOfMinute();
        java.lang.String str61 = property60.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property60.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType62, (int) (short) 10, 1, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder48.appendFixedDecimal(dateTimeFieldType62, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField27, dateTimeFieldType62, 1969);
        mutableDateTime19.set(dateTimeFieldType62, 59);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType62, (int) (byte) 10, 4, 1969);
        long long79 = delegatedDateTimeField7.add(1L, (long) (short) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType80 = delegatedDateTimeField7.getType();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 900100L + "'", long18 == 900100L);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560343500000L + "'", long31 == 1560343500000L);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 59 + "'", int44 == 59);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(julianChronology57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "secondOfMinute" + "'", str61.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1L + "'", long79 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType80);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.withDayOfMonth(12);
        org.joda.time.DateTime dateTime13 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        int int18 = mutableDateTime17.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology21);
        mutableDateTime22.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone26);
        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology27);
        boolean boolean29 = mutableDateTime22.isEqual((org.joda.time.ReadableInstant) mutableDateTime28);
        int int30 = mutableDateTime28.getMinuteOfHour();
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime17, (org.joda.time.ReadableInstant) mutableDateTime28);
        boolean boolean32 = dateTime12.isBefore((org.joda.time.ReadableInstant) mutableDateTime17);
        mutableDateTime17.addMinutes((int) (byte) 1);
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime17.millisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        mutableDateTime17.add(readablePeriod36);
        mutableDateTime17.setMillisOfDay((int) (short) 1);
        int int40 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) mutableDateTime17);
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(26004960, 57600100, 14, (int) (short) 0, 57600100, (org.joda.time.Chronology) julianChronology41);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 999 + "'", int18 == 999);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 59 + "'", int30 == 59);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3600000 + "'", int40 == 3600000);
        org.junit.Assert.assertNotNull(julianChronology41);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.weekOfWeekyear();
        mutableDateTime7.addYears(0);
        int int11 = mutableDateTime7.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        int int7 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology1.millisOfDay();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1969");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1969' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(2440588L, (org.joda.time.Chronology) gregorianChronology2, locale4, (java.lang.Integer) 1969);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) 'a');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField7 = property5.getField();
        org.joda.time.DateTime dateTime8 = property5.roundCeilingCopy();
        org.joda.time.DurationField durationField9 = property5.getDurationField();
        org.joda.time.DateTime dateTime11 = property5.addToCopy(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        boolean boolean13 = dateTimeFormatter12.isPrinter();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology16);
        mutableDateTime17.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology22);
        boolean boolean24 = mutableDateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime23);
        int int25 = mutableDateTime23.getMonthOfYear();
        org.joda.time.Chronology chronology26 = mutableDateTime23.getChronology();
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime23.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology30);
        mutableDateTime31.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone35);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology36);
        boolean boolean38 = mutableDateTime31.isEqual((org.joda.time.ReadableInstant) mutableDateTime37);
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime31.secondOfMinute();
        mutableDateTime23.setTime((org.joda.time.ReadableInstant) mutableDateTime31);
        mutableDateTime31.addDays((int) (short) 1);
        int int45 = dateTimeFormatter12.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime31, "2019-06-12T12:45:39.995Z", (int) ' ');
        mutableDateTime31.add(1560343547074L);
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime31.dayOfYear();
        long long49 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime31);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-33) + "'", int45 == (-33));
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-49L) + "'", long49 == (-49L));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DurationField durationField6 = julianChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology4.dayOfYear();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology4.clockhourOfDay();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology4);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        int int7 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = julianChronology1.add(readablePeriod8, 0L, (int) '#');
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = julianChronology1.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology1.getZone();
        org.joda.time.DurationField durationField7 = julianChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology1.weekOfWeekyear();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minusDays(16);
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
        org.joda.time.DurationField durationField8 = property7.getDurationField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 12);
        long long4 = dateTimeZone2.convertUTCToLocal((long) 10);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology7);
        mutableDateTime8.addHours((-1));
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) -1, (org.joda.time.Chronology) julianChronology13);
        boolean boolean15 = mutableDateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        int int16 = mutableDateTime14.getMonthOfYear();
        org.joda.time.Chronology chronology17 = mutableDateTime14.getChronology();
        int int18 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) mutableDateTime14);
        java.lang.String str20 = dateTimeZone2.getName(0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        java.lang.Object obj22 = null;
        boolean boolean23 = cachedDateTimeZone21.equals(obj22);
        int int25 = cachedDateTimeZone21.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime28.minusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime32 = dateTime30.plusHours((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime33 = dateTime32.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime33.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (byte) 100, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime.Property property40 = dateTime39.year();
        org.joda.time.DateTime dateTime41 = property40.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField42 = property40.getField();
        org.joda.time.DateTime dateTime43 = property40.roundCeilingCopy();
        mutableDateTime33.setMillis((org.joda.time.ReadableInstant) dateTime43);
        org.joda.time.DateTime dateTime46 = dateTime43.plusHours(59);
        boolean boolean47 = cachedDateTimeZone21.equals((java.lang.Object) dateTime46);
        org.joda.time.DateTime dateTime49 = dateTime46.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime51 = dateTime49.plusMonths(86399999);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4320010L + "'", long4 == 4320010L);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4320000 + "'", int18 == 4320000);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+01:12" + "'", str20.equals("+01:12"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4320000 + "'", int25 == 4320000);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
    }
}

