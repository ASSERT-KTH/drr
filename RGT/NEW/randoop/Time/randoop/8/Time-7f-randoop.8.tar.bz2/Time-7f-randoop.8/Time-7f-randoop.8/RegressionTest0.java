import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DurationField durationField2 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(100, (int) (short) 0, (int) (short) 0, (int) '#', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 'a', (long) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9409 + "'", int2 == 9409);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        try {
            mutableDateTime0.setSecondOfMinute((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 10, (int) (byte) -1, (int) ' ', 100, 2019, 12, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test008");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
//        boolean boolean3 = property1.isLeap();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property1.getAsShortText(locale4);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12" + "'", str5.equals("12"));
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            long long7 = gJChronology3.set(readablePartial5, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 0.0d, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundHalfEven((long) 2019);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray18 = new int[] { (byte) 10, (byte) 10, ' ', '4', 2019 };
        try {
            int[] intArray20 = skipUndoDateTimeField8.set(readablePartial11, 10, intArray18, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime2.withFieldAdded(durationFieldType5, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        mutableDateTime1.setWeekyear(0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
        try {
            mutableDateTime4.setMillisOfDay((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withField(dateTimeFieldType6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Throwable throwable0 = null;
        try {
            boolean boolean1 = org.joda.time.IllegalInstantException.isIllegalInstant(throwable0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
        try {
            org.joda.time.Instant instant4 = org.joda.time.Instant.parse("hi!", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.DurationField durationField5 = gJChronology3.years();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((java.lang.Object) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
        org.joda.time.DurationField durationField6 = gJChronology4.months();
        org.joda.time.DurationField durationField7 = gJChronology4.halfdays();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField8 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 100);
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField11 = new org.joda.time.field.RemainderDateTimeField(dateTimeField8, dateTimeFieldType9, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 2000, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2000L + "'", long2 == 2000L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        java.util.Locale locale3 = dateTimeFormatter2.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = buddhistChronology1.withZone(dateTimeZone2);
        org.joda.time.Chronology chronology4 = buddhistChronology1.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMonthOfYear(1);
        org.joda.time.DateTime dateTime8 = dateTime6.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate9 = dateTime6.toLocalDate();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 2000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (short) 100, 'a', (int) '#', 10, (int) (short) 100, true, (int) (short) 10);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder8.addCutover((int) (short) 0, ' ', 0, (int) '#', (-1), true, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter0.printTo(writer3, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        java.lang.Appendable appendable3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime5);
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField10, 0);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = skipUndoDateTimeField12.getMinimumValue(readablePartial13);
        long long16 = skipUndoDateTimeField12.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 1, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withMonthOfYear(1);
        org.joda.time.DateTime dateTime23 = dateTime21.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate24, (int) (byte) 0, locale26);
        try {
            dateTimeFormatter2.printTo(appendable3, (org.joda.time.ReadablePartial) localDate24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        java.util.Locale locale26 = null;
        try {
            long long27 = skipUndoDateTimeField8.set(1L, "2000", locale26);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withMonthOfYear(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) '#', (long) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3395 + "'", int2 == 3395);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 1, dateTimeZone25);
        org.joda.time.DateTime dateTime28 = dateTime26.withMonthOfYear(1);
        org.joda.time.DateTime dateTime30 = dateTime28.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate31 = dateTime28.toLocalDate();
        int int32 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate31);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        int int7 = mutableDateTime4.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DurationField durationField9 = gJChronology8.weeks();
        org.joda.time.Instant instant10 = gJChronology8.getGregorianCutover();
        org.joda.time.Instant instant13 = instant10.withDurationAdded((long) (short) 1, (int) (short) 1);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) instant10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant13);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 30, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3000L + "'", long2 == 3000L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 3395, (int) (byte) 10, (-1), (-1), (org.joda.time.Chronology) gJChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology5);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        long long2 = mutableDateTime0.getMillis();
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        mutableDateTime0.add(readablePeriod3, 0);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) readablePeriod3);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560342590826L + "'", long2 == 1560342590826L);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (short) 100, 'a', (int) '#', 10, (int) (short) 100, true, (int) (short) 10);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder8.addCutover(30, ' ', (int) (byte) 1, 9409, 9409, false, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: hi!");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 1);
        long long5 = dateTimeParserBucket4.computeMillis();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28800100L + "'", long5 == 28800100L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        mutableDateTime4.addMinutes((int) (short) 10);
        try {
            mutableDateTime4.setDate(10, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.secondOfMinute();
        mutableDateTime0.addMinutes((int) 'a');
        try {
            mutableDateTime0.setMinuteOfDay(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 1, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear(1);
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
        org.joda.time.DateTime.Property property9 = dateTime5.millisOfDay();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        try {
            org.joda.time.chrono.LimitChronology limitChronology11 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, (org.joda.time.ReadableDateTime) dateTime5, readableDateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100.0f, "2000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        mutableDateTime4.setMinuteOfDay((int) (byte) 0);
        try {
            mutableDateTime4.setDateTime((int) '#', 2000, (int) (short) 0, 5, (int) (short) 100, (int) (byte) 100, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
//        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
//        mutableDateTime4.addMinutes((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
//        mutableDateTime4.setMillis((org.joda.time.ReadableInstant) mutableDateTime7);
//        java.lang.String str9 = mutableDateTime4.toString();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019-06-12T05:29:51.291-07:00" + "'", str9.equals("2019-06-12T05:29:51.291-07:00"));
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField8.getAsText((int) (short) 1, locale14);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, (org.joda.time.ReadableInstant) mutableDateTime17);
        org.joda.time.MutableDateTime mutableDateTime20 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField22 = property21.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField22, 0);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int int26 = skipUndoDateTimeField24.getMinimumValue(readablePartial25);
        long long28 = skipUndoDateTimeField24.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) 1, dateTimeZone30);
        org.joda.time.DateTime dateTime33 = dateTime31.withMonthOfYear(1);
        org.joda.time.DateTime dateTime35 = dateTime33.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate36 = dateTime33.toLocalDate();
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDate36, (int) (byte) 0, locale38);
        int[] intArray45 = new int[] { 31, (short) 10, (short) 1, 'a' };
        try {
            int[] intArray47 = skipUndoDateTimeField8.add((org.joda.time.ReadablePartial) localDate36, (int) '4', intArray45, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 28800000L + "'", long28 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertNotNull(intArray45);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate7 = dateTime4.toLocalDate();
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withCenturyOfEra((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfEra(1);
        try {
            org.joda.time.DateTime dateTime12 = dateTime5.withTime(9409, (int) (byte) 1, 5, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9409 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withEra(5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
        int int5 = property1.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long5 = julianChronology0.getDateTimeMillis((int) (byte) -1, (int) '#', 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        int int10 = skipUndoDateTimeField8.getMaximumValue(0L);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866846400000L) + "'", long1 == (-210866846400000L));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.DurationField durationField5 = gJChronology3.months();
        long long8 = durationField5.subtract((-210866846400000L), (long) (short) 0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-210866846400000L) + "'", long8 == (-210866846400000L));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, (long) 9409);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNull(dateTimePrinter2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.Chronology chronology10 = buddhistChronology8.withZone(dateTimeZone9);
        try {
            org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(2000, 30, 10, (int) (byte) 1, 1, 0, (int) 'a', (org.joda.time.Chronology) buddhistChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 0, "2000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfWeek();
        try {
            long long9 = gJChronology0.getDateTimeMillis((int) '4', (int) (byte) 100, 3395, (int) (byte) 10, 1, (int) (byte) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj6 = mutableDateTime5.clone();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 1, dateTimeZone8);
        int int10 = mutableDateTime5.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime12 = dateTime9.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property13 = dateTime9.era();
        try {
            org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime9, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime2.minusSeconds((int) ' ');
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = dateTime2.toString("GregorianChronology[UTC]", locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.secondOfMinute();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        int int9 = dateTime8.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) 0, 3395);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 3395");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) gJChronology3, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getYearOfEra();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.MutableDateTime mutableDateTime6 = property3.addWrapField((int) 'a');
        mutableDateTime0.setTime((org.joda.time.ReadableInstant) mutableDateTime6);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology8.getZone();
        mutableDateTime0.setZoneRetainFields(dateTimeZone9);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        int int6 = dateTime4.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 100);
        java.lang.Object obj8 = dateTimeParserBucket7.saveState();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfYear();
        org.joda.time.DurationField durationField13 = gJChronology11.months();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
        boolean boolean17 = property15.isLeap();
        org.joda.time.MutableDateTime mutableDateTime18 = property15.getMutableDateTime();
        boolean boolean19 = gJChronology11.equals((java.lang.Object) mutableDateTime18);
        mutableDateTime2.setChronology((org.joda.time.Chronology) gJChronology11);
        try {
            mutableDateTime2.setDate(12, 9409, 3395);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9409 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long8 = julianChronology0.getDateTimeMillis(30, (int) (short) 1, (int) '4', (int) (byte) 10, 0, 59, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.MutableDateTime mutableDateTime9 = property6.addWrapField((int) 'a');
        int int10 = property1.compareTo((org.joda.time.ReadableInstant) mutableDateTime9);
        int int11 = property1.getMinimumValue();
        java.lang.String str12 = property1.getName();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "dayOfMonth" + "'", str12.equals("dayOfMonth"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField13, 0);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = skipUndoDateTimeField15.getMinimumValue(readablePartial16);
        long long19 = skipUndoDateTimeField15.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 1, dateTimeZone21);
        org.joda.time.DateTime dateTime24 = dateTime22.withMonthOfYear(1);
        org.joda.time.DateTime dateTime26 = dateTime24.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate27 = dateTime24.toLocalDate();
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipUndoDateTimeField15.getAsText((org.joda.time.ReadablePartial) localDate27, (int) (byte) 0, locale29);
        java.lang.String str31 = skipUndoDateTimeField15.toString();
        try {
            mutableDateTime2.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800000L + "'", long19 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0" + "'", str30.equals("0"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str31.equals("DateTimeField[dayOfMonth]"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfYear();
        org.joda.time.DurationField durationField13 = gJChronology11.months();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
        boolean boolean17 = property15.isLeap();
        org.joda.time.MutableDateTime mutableDateTime18 = property15.getMutableDateTime();
        boolean boolean19 = gJChronology11.equals((java.lang.Object) mutableDateTime18);
        mutableDateTime2.setChronology((org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 1, dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.minusMillis((int) '#');
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 1, dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime28.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime30.toDateTimeISO();
        try {
            org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology11, (org.joda.time.ReadableDateTime) dateTime25, (org.joda.time.ReadableDateTime) dateTime30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getYearOfEra();
        mutableDateTime0.setWeekyear(10);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime5);
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField10, 0);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = skipUndoDateTimeField12.getMinimumValue(readablePartial13);
        long long16 = skipUndoDateTimeField12.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 1, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withMonthOfYear(1);
        org.joda.time.DateTime dateTime23 = dateTime21.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate24, (int) (byte) 0, locale26);
        long long29 = skipUndoDateTimeField12.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField12.getType();
        try {
            mutableDateTime0.set(dateTimeFieldType30, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 28800000L + "'", long29 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        java.io.Writer writer3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        int int5 = mutableDateTime4.getYearOfEra();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime4.getRoundingField();
        try {
            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadableInstant) mutableDateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNull(dateTimeField7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) '#');
        try {
            java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis((int) (byte) 0);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime2.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime6.withMillis((long) (short) -1);
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMillis(1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("2019-06-12T05:29:51.291-07:00", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 2019-06-12T05:29:51.291-07:00");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipUndoDateTimeField8.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType26, 30, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for dayOfMonth must be in the range [35,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("31", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"31\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2000", false);
        long long7 = dateTimeZone3.convertLocalToUTC((-210866760000000L), true, 2000L);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-210866760000000L) + "'", long7 == (-210866760000000L));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("0");
        org.joda.time.ReadableInstant readableInstant3 = null;
        mutableDateTime2.setMillis(readableInstant3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 100);
        java.lang.Integer int8 = dateTimeParserBucket7.getPivotYear();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8.equals(100));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter0.parseLocalDate("DateTimeField[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[dayOfMonth]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNull(dateTimePrinter2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 59);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210861662400000L) + "'", long1 == (-210861662400000L));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        mutableDateTime1.setYear((int) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        int int6 = dateTime4.getDayOfYear();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 365 + "'", int6 == 365);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime.Property property6 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        java.util.Locale locale9 = null;
        try {
            org.joda.time.DateTime dateTime10 = property6.setCopy("2000", locale9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) '#');
        org.joda.time.DateTime dateTime8 = dateTime4.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear(31);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gJChronology11);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("1");
        try {
            mutableDateTime1.setDate((int) (byte) 100, 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 1);
        java.lang.Object obj5 = dateTimeParserBucket4.saveState();
        long long6 = dateTimeParserBucket4.computeMillis();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28800100L + "'", long6 == 28800100L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(28800100L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        java.lang.String str3 = property1.getName();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        boolean boolean7 = property1.equals((java.lang.Object) dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfMonth" + "'", str3.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        java.lang.String str8 = dateTimeZone7.getID();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj10 = mutableDateTime9.clone();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 1, dateTimeZone12);
        int int14 = mutableDateTime9.compareTo((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay17 = dateTime16.toTimeOfDay();
        try {
            org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime16, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(timeOfDay17);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        try {
            org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.MutableDateTime mutableDateTime46 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property47 = mutableDateTime46.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone45, (org.joda.time.ReadableInstant) mutableDateTime46);
        org.joda.time.MutableDateTime mutableDateTime49 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property50 = mutableDateTime49.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField51 = property50.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology48, dateTimeField51, 0);
        org.joda.time.ReadablePartial readablePartial54 = null;
        int int55 = skipUndoDateTimeField53.getMinimumValue(readablePartial54);
        long long57 = skipUndoDateTimeField53.roundHalfFloor((long) (short) -1);
        long long60 = skipUndoDateTimeField53.add(1560342585128L, 1);
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) 1, dateTimeZone62);
        org.joda.time.DateTime dateTime65 = dateTime63.withMonthOfYear(1);
        org.joda.time.DateTime dateTime67 = dateTime65.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate68 = dateTime65.toLocalDate();
        java.util.Locale locale69 = null;
        java.lang.String str70 = skipUndoDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate68, locale69);
        java.util.Locale locale72 = null;
        try {
            java.lang.String str73 = unsupportedDateTimeField44.getAsText((org.joda.time.ReadablePartial) localDate68, 57600001, locale72);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertNotNull(mutableDateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 28800000L + "'", long57 == 28800000L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560428985128L + "'", long60 == 1560428985128L);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "31" + "'", str70.equals("31"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        try {
            long long46 = unsupportedDateTimeField44.roundFloor((long) 9409);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long5 = julianChronology0.getDateTimeMillis((int) ' ', (-100), (int) ' ', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = property5.roundHalfFloorCopy();
        try {
            org.joda.time.DateTime dateTime8 = property5.addToCopy(0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfEra(1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMonths(10);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readableDuration10);
        try {
            org.joda.time.DateTime dateTime16 = dateTime9.withTime(3395, (int) (short) 1, (int) (short) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3395 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime2.minusSeconds((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = gregorianChronology8.withUTC();
        java.lang.String str10 = gregorianChronology8.toString();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gregorianChronology8, locale11);
        boolean boolean13 = dateTime6.equals((java.lang.Object) locale11);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[UTC]" + "'", str10.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property8 = dateTime4.era();
        org.joda.time.DateTime dateTime10 = dateTime4.minusMinutes(1);
        org.joda.time.DateTime dateTime12 = dateTime4.withDayOfMonth((int) (short) 1);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipUndoDateTimeField8.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8);
        org.joda.time.DateTimeField dateTimeField28 = delegatedDateTimeField27.getWrappedField();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = property5.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.plusWeeks((int) (byte) 10);
        org.joda.time.Instant instant9 = dateTime8.toInstant();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime3);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = property7.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField8, 0);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int int12 = skipUndoDateTimeField10.getMinimumValue(readablePartial11);
        long long14 = skipUndoDateTimeField10.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 1, dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withMonthOfYear(1);
        org.joda.time.DateTime dateTime21 = dateTime19.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate22 = dateTime19.toLocalDate();
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField10.getAsText((org.joda.time.ReadablePartial) localDate22, (int) (byte) 0, locale24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, (org.joda.time.ReadableInstant) mutableDateTime27);
        org.joda.time.MutableDateTime mutableDateTime30 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology29, dateTimeField32, 0);
        org.joda.time.ReadablePartial readablePartial35 = null;
        int int36 = skipUndoDateTimeField34.getMinimumValue(readablePartial35);
        long long38 = skipUndoDateTimeField34.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) 1, dateTimeZone40);
        org.joda.time.DateTime dateTime43 = dateTime41.withMonthOfYear(1);
        org.joda.time.DateTime dateTime45 = dateTime43.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate46 = dateTime43.toLocalDate();
        java.util.Locale locale48 = null;
        java.lang.String str49 = skipUndoDateTimeField34.getAsText((org.joda.time.ReadablePartial) localDate46, (int) (byte) 0, locale48);
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 1, dateTimeZone52);
        org.joda.time.DateTime dateTime55 = dateTime53.withMonthOfYear(1);
        org.joda.time.DateTime dateTime57 = dateTime55.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate58 = dateTime55.toLocalDate();
        long long60 = gJChronology50.set((org.joda.time.ReadablePartial) localDate58, (long) (short) 1);
        java.util.Locale locale61 = null;
        java.lang.String str62 = skipUndoDateTimeField34.getAsText((org.joda.time.ReadablePartial) localDate58, locale61);
        java.util.Locale locale63 = null;
        java.lang.String str64 = skipUndoDateTimeField10.getAsText((org.joda.time.ReadablePartial) localDate58, locale63);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate58);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800000L + "'", long14 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 28800000L + "'", long38 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "0" + "'", str49.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-28857599999L) + "'", long60 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "31" + "'", str62.equals("31"));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "31" + "'", str64.equals("31"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getYearOfEra();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.MutableDateTime mutableDateTime6 = property3.addWrapField((int) 'a');
        mutableDateTime0.setTime((org.joda.time.ReadableInstant) mutableDateTime6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.centuryOfEra();
        int int9 = mutableDateTime0.getHourOfDay();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1970 + "'", int1 == 1970);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 100);
        dateTimeParserBucket7.setOffset(59);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((java.lang.Object) gJChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis(2000, 0, (int) (short) 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime3);
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology5, locale6, (java.lang.Integer) 100);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology5.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology5.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 1, dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.withMonthOfYear(1);
        org.joda.time.DateTime dateTime18 = dateTime16.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate19 = dateTime16.toLocalDate();
        long long21 = gJChronology11.set((org.joda.time.ReadablePartial) localDate19, (long) (short) 1);
        int[] intArray23 = gJChronology5.get((org.joda.time.ReadablePartial) localDate19, (long) 100);
        try {
            java.lang.String str24 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-28857599999L) + "'", long21 == (-28857599999L));
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.MutableDateTime mutableDateTime9 = property6.addWrapField((int) 'a');
        int int10 = property1.compareTo((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime9.minuteOfDay();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        java.util.TimeZone timeZone4 = dateTimeZone1.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        java.lang.String str4 = dateTimeZone2.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0L, dateTimeZone2);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        int int43 = dividedDateTimeField42.getDivisor();
        int int46 = dividedDateTimeField42.getDifference((long) (-100), (long) 0);
        java.util.Locale locale48 = null;
        java.lang.String str49 = dividedDateTimeField42.getAsShortText((long) (-1), locale48);
        long long51 = dividedDateTimeField42.roundHalfCeiling((-210861662400000L));
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2" + "'", str49.equals("2"));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-210861504422000L) + "'", long51 == (-210861504422000L));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology47 = gregorianChronology46.withUTC();
        java.lang.String str48 = gregorianChronology46.toString();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50);
        java.util.Locale locale52 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket55 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology51, locale52, (java.lang.Integer) 12, (int) (short) 1);
        long long58 = dateTimeParserBucket55.computeMillis(false, "");
        java.util.Locale locale59 = dateTimeParserBucket55.getLocale();
        boolean boolean60 = gregorianChronology46.equals((java.lang.Object) locale59);
        try {
            java.lang.String str61 = unsupportedDateTimeField44.getAsShortText((long) (-100), locale59);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "GregorianChronology[UTC]" + "'", str48.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 28800000L + "'", long58 == 28800000L);
        org.junit.Assert.assertNotNull(locale59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.secondOfMinute();
        mutableDateTime0.setTime(2440588L);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        try {
            org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2019");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        try {
            long long46 = unsupportedDateTimeField44.remainder((long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("JulianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"JulianChronology[America/Los_Ang...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.MutableDateTime mutableDateTime49 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property50 = mutableDateTime49.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone48, (org.joda.time.ReadableInstant) mutableDateTime49);
        java.util.Locale locale52 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket54 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology51, locale52, (java.lang.Integer) 100);
        org.joda.time.DateTimeField dateTimeField55 = gJChronology51.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField56 = gJChronology51.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) 1, dateTimeZone59);
        org.joda.time.DateTime dateTime62 = dateTime60.withMonthOfYear(1);
        org.joda.time.DateTime dateTime64 = dateTime62.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate65 = dateTime62.toLocalDate();
        long long67 = gJChronology57.set((org.joda.time.ReadablePartial) localDate65, (long) (short) 1);
        int[] intArray69 = gJChronology51.get((org.joda.time.ReadablePartial) localDate65, (long) 100);
        try {
            int[] intArray71 = unsupportedDateTimeField44.add(readablePartial45, (int) ' ', intArray69, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(localDate65);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-28857599999L) + "'", long67 == (-28857599999L));
        org.junit.Assert.assertNotNull(intArray69);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("2");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) ' ', 57600001, 12, 59, 2019, 365, 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        mutableDateTime4.setMinuteOfDay((int) (byte) 0);
        int int7 = mutableDateTime4.getYearOfEra();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        org.joda.time.ReadablePartial readablePartial45 = null;
        try {
            int int46 = unsupportedDateTimeField44.getMaximumValue(readablePartial45);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        try {
            long long46 = unsupportedDateTimeField44.roundFloor(28800100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        java.lang.String str10 = dateTimeZone8.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((-1), 9409, 2019, 12, 0, 12, 5, (org.joda.time.Chronology) gregorianChronology11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9409 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology11);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("AD", "12", (-100), 12);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        try {
            long long46 = unsupportedDateTimeField44.roundHalfCeiling(28800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        try {
            long long46 = unsupportedDateTimeField44.remainder((long) 9409);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology47 = gregorianChronology46.withUTC();
        java.lang.String str48 = gregorianChronology46.toString();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50);
        java.util.Locale locale52 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket55 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology51, locale52, (java.lang.Integer) 12, (int) (short) 1);
        long long58 = dateTimeParserBucket55.computeMillis(false, "");
        java.util.Locale locale59 = dateTimeParserBucket55.getLocale();
        boolean boolean60 = gregorianChronology46.equals((java.lang.Object) locale59);
        try {
            java.lang.String str61 = unsupportedDateTimeField44.getAsShortText((-1L), locale59);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "GregorianChronology[UTC]" + "'", str48.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 28800000L + "'", long58 == 28800000L);
        org.junit.Assert.assertNotNull(locale59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getYearOfEra();
        mutableDateTime0.setWeekyear(10);
        mutableDateTime0.setWeekyear(0);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1970 + "'", int1 == 1970);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2000", false);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("1969-365T16:00:00.000-08:00", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        mutableDateTime0.setMillisOfSecond((int) (byte) 0);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "160000.010-0800" + "'", str2.equals("160000.010-0800"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology6.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfDay();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) dateTimeField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology$ImpreciseCutoverField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DurationField durationField7 = gJChronology6.weeks();
        org.joda.time.Instant instant8 = gJChronology6.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Instant instant11 = instant8.withDurationAdded(readableDuration9, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            int int13 = instant11.get(dateTimeFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.dayOfWeek();
        int int8 = property7.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipUndoDateTimeField32.getMinimumValue(readablePartial33);
        long long36 = skipUndoDateTimeField32.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear(1);
        org.joda.time.DateTime dateTime43 = dateTime41.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime41.toLocalDate();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale46);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        long long58 = gJChronology48.set((org.joda.time.ReadablePartial) localDate56, (long) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate56, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipUndoDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType61);
        long long64 = skipUndoDateTimeField8.roundHalfFloor((long) 'a');
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28857599999L) + "'", long58 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 28800000L + "'", long64 == 28800000L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        java.lang.String str3 = property1.getName();
        org.joda.time.MutableDateTime mutableDateTime5 = property1.add((long) 9409);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfMonth" + "'", str3.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.ReadablePartial readablePartial37 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.MutableDateTime mutableDateTime40 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property41 = mutableDateTime40.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone39, (org.joda.time.ReadableInstant) mutableDateTime40);
        org.joda.time.MutableDateTime mutableDateTime43 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime43.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField45 = property44.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology42, dateTimeField45, 0);
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.MutableDateTime mutableDateTime49 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property50 = mutableDateTime49.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone48, (org.joda.time.ReadableInstant) mutableDateTime49);
        org.joda.time.MutableDateTime mutableDateTime52 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property53 = mutableDateTime52.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField54 = property53.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology51, dateTimeField54, 0);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int int58 = skipUndoDateTimeField56.getMinimumValue(readablePartial57);
        long long60 = skipUndoDateTimeField56.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) 1, dateTimeZone62);
        org.joda.time.DateTime dateTime65 = dateTime63.withMonthOfYear(1);
        org.joda.time.DateTime dateTime67 = dateTime65.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate68 = dateTime65.toLocalDate();
        java.util.Locale locale70 = null;
        java.lang.String str71 = skipUndoDateTimeField56.getAsText((org.joda.time.ReadablePartial) localDate68, (int) (byte) 0, locale70);
        org.joda.time.DateTimeZone dateTimeZone73 = null;
        org.joda.time.MutableDateTime mutableDateTime74 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property75 = mutableDateTime74.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology76 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone73, (org.joda.time.ReadableInstant) mutableDateTime74);
        java.util.Locale locale77 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket79 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology76, locale77, (java.lang.Integer) 100);
        org.joda.time.DateTimeField dateTimeField80 = gJChronology76.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField81 = gJChronology76.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology82 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone84 = null;
        org.joda.time.DateTime dateTime85 = new org.joda.time.DateTime((long) 1, dateTimeZone84);
        org.joda.time.DateTime dateTime87 = dateTime85.withMonthOfYear(1);
        org.joda.time.DateTime dateTime89 = dateTime87.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate90 = dateTime87.toLocalDate();
        long long92 = gJChronology82.set((org.joda.time.ReadablePartial) localDate90, (long) (short) 1);
        int[] intArray94 = gJChronology76.get((org.joda.time.ReadablePartial) localDate90, (long) 100);
        int int95 = skipUndoDateTimeField47.getMaximumValue((org.joda.time.ReadablePartial) localDate68, intArray94);
        try {
            int[] intArray97 = skipUndoDateTimeField8.add(readablePartial37, 0, intArray94, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(mutableDateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(mutableDateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 28800000L + "'", long60 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime74);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertNotNull(gJChronology76);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(gJChronology82);
        org.junit.Assert.assertNotNull(dateTime87);
        org.junit.Assert.assertNotNull(dateTime89);
        org.junit.Assert.assertNotNull(localDate90);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + (-28857599999L) + "'", long92 == (-28857599999L));
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 31 + "'", int95 == 31);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone3);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withEra(57600001);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600001 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField8.getAsShortText(2000, locale27);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.Chronology chronology32 = buddhistChronology30.withZone(dateTimeZone31);
        try {
            org.joda.time.MutableDateTime mutableDateTime33 = new org.joda.time.MutableDateTime((java.lang.Object) skipUndoDateTimeField8, (org.joda.time.Chronology) buddhistChronology30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.SkipUndoDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2000" + "'", str28.equals("2000"));
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(chronology32);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTimeFormatter9.parseMutableDateTime("0");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) mutableDateTime13);
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = property17.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField18, 0);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int int22 = skipUndoDateTimeField20.getMinimumValue(readablePartial21);
        long long24 = skipUndoDateTimeField20.roundHalfFloor((long) (short) -1);
        long long27 = skipUndoDateTimeField20.add(1560342585128L, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology30 = gregorianChronology29.withUTC();
        java.lang.String str31 = gregorianChronology29.toString();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33);
        java.util.Locale locale35 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket38 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology34, locale35, (java.lang.Integer) 12, (int) (short) 1);
        long long41 = dateTimeParserBucket38.computeMillis(false, "");
        java.util.Locale locale42 = dateTimeParserBucket38.getLocale();
        boolean boolean43 = gregorianChronology29.equals((java.lang.Object) locale42);
        java.lang.String str44 = skipUndoDateTimeField20.getAsShortText((-1L), locale42);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = dateTimeFormatter9.withLocale(locale42);
        try {
            org.joda.time.DateTime dateTime46 = property7.setCopy("57600001", locale42);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600001 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28800000L + "'", long24 == 28800000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560428985128L + "'", long27 == 1560428985128L);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "GregorianChronology[UTC]" + "'", str31.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 28800000L + "'", long41 == 28800000L);
        org.junit.Assert.assertNotNull(locale42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology6.secondOfMinute();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime7 = property5.withMinimumValue();
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
        int int5 = mutableDateTime4.getRoundingMode();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.centuryOfEra();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.centuryOfEra();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNull(durationField8);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfEra(1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMonths(10);
        org.joda.time.DateTime dateTime11 = dateTime5.withHourOfDay((int) (short) 10);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        java.io.Writer writer2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = gregorianChronology3.withUTC();
        java.lang.String str5 = gregorianChronology3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = skipUndoDateTimeField14.getMinimumValue(readablePartial15);
        long long18 = skipUndoDateTimeField14.roundHalfFloor((long) (short) -1);
        java.lang.String str19 = skipUndoDateTimeField14.toString();
        long long21 = skipUndoDateTimeField14.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeField) skipUndoDateTimeField14, (int) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime24 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj25 = mutableDateTime24.clone();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 1, dateTimeZone27);
        int int29 = mutableDateTime24.compareTo((org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.DateTime dateTime31 = dateTime28.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay32 = dateTime31.toTimeOfDay();
        int int33 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay32);
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) timeOfDay32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[UTC]" + "'", str5.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str19.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800000L + "'", long21 == 28800000L);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(timeOfDay32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        long long47 = unsupportedDateTimeField44.add(0L, (long) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology49 = gregorianChronology48.withUTC();
        java.lang.String str50 = gregorianChronology48.toString();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone52);
        java.util.Locale locale54 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket57 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology53, locale54, (java.lang.Integer) 12, (int) (short) 1);
        long long60 = dateTimeParserBucket57.computeMillis(false, "");
        java.util.Locale locale61 = dateTimeParserBucket57.getLocale();
        boolean boolean62 = gregorianChronology48.equals((java.lang.Object) locale61);
        try {
            int int63 = unsupportedDateTimeField44.getMaximumTextLength(locale61);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 135558000000L + "'", long47 == 135558000000L);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "GregorianChronology[UTC]" + "'", str50.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology53);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 28800000L + "'", long60 == 28800000L);
        org.junit.Assert.assertNotNull(locale61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "2");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-210861662400000L));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getYearOfEra();
        org.joda.time.Chronology chronology3 = null;
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(100L, chronology3, locale4, (java.lang.Integer) 1);
        java.lang.Object obj7 = dateTimeParserBucket6.saveState();
        java.util.Locale locale8 = dateTimeParserBucket6.getLocale();
        java.util.Calendar calendar9 = mutableDateTime0.toCalendar(locale8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime0.millisOfSecond();
        org.joda.time.Interval interval11 = property10.toInterval();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4664 + "'", int1 == 4664);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(locale8);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(interval11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime2.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekOfWeekyear(31);
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withMonthOfYear(57600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        try {
            mutableDateTime1.setMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        long long47 = unsupportedDateTimeField44.add(0L, (long) '4');
        try {
            long long49 = unsupportedDateTimeField44.roundFloor((long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 136594800000L + "'", long47 == 136594800000L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(4664, 57600001);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 4664");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        org.joda.time.ReadableInstant readableInstant6 = null;
        try {
            int int7 = dateTime4.compareTo(readableInstant6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray27 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType26 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList28 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList28, dateTimeFieldTypeArray27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList28, true, false);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList28, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.months();
        long long5 = gJChronology0.add((long) 1, (long) (byte) 100, 2000);
        try {
            long long11 = gJChronology0.getDateTimeMillis((-28857599999L), 31, 0, 12, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200001L + "'", long5 == 200001L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj3 = mutableDateTime2.clone();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 1, dateTimeZone5);
        int int7 = mutableDateTime2.compareTo((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime9 = dateTime6.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) timeOfDay10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(timeOfDay10);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
        org.joda.time.format.DateTimeParser dateTimeParser8 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter7, dateTimeParser8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("AD", "12", (-100), 12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        int int17 = fixedDateTimeZone14.getOffset(0L);
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(57600, (-2), 2, 365, 12, (-4663), (int) (byte) 1, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-100) + "'", int17 == (-100));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        int int7 = dateTime6.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getYearOfEra();
        org.joda.time.Chronology chronology3 = null;
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(100L, chronology3, locale4, (java.lang.Integer) 1);
        java.lang.Object obj7 = dateTimeParserBucket6.saveState();
        java.util.Locale locale8 = dateTimeParserBucket6.getLocale();
        java.util.Calendar calendar9 = mutableDateTime0.toCalendar(locale8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology13 = gregorianChronology12.withUTC();
        java.lang.String str14 = gregorianChronology12.toString();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        java.util.Locale locale18 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology17, locale18, (java.lang.Integer) 12, (int) (short) 1);
        long long24 = dateTimeParserBucket21.computeMillis(false, "");
        java.util.Locale locale25 = dateTimeParserBucket21.getLocale();
        boolean boolean26 = gregorianChronology12.equals((java.lang.Object) locale25);
        try {
            org.joda.time.MutableDateTime mutableDateTime27 = property10.set("hi!", locale25);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4664 + "'", int1 == 4664);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(locale8);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GregorianChronology[UTC]" + "'", str14.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28800000L + "'", long24 == 28800000L);
        org.junit.Assert.assertNotNull(locale25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        java.lang.String str43 = dividedDateTimeField42.toString();
        long long45 = dividedDateTimeField42.roundHalfFloor((long) 1970);
        long long48 = dividedDateTimeField42.addWrapField((-28857599999L), (int) '4');
        long long51 = dividedDateTimeField42.add((long) (byte) -1, (-2));
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str43.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 374400000L + "'", long45 == 374400000L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-30931199999L) + "'", long48 == (-30931199999L));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-2073600001L) + "'", long51 == (-2073600001L));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DurationField durationField6 = property5.getDurationField();
        try {
            org.joda.time.DateTime dateTime8 = property5.setCopy(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate7 = dateTime4.toLocalDate();
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        java.lang.String str9 = property8.getAsShortText();
        org.joda.time.DateTime dateTime10 = property8.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime11 = property8.roundFloorCopy();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        boolean boolean15 = dateTime13.isEqual((long) (-100));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "57600001" + "'", str9.equals("57600001"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (short) 100, 'a', (int) '#', 10, (int) (short) 100, true, (int) (short) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder8.setStandardOffset(2);
        java.io.OutputStream outputStream12 = null;
        try {
            dateTimeZoneBuilder8.writeTo("America/Los_Angeles", outputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology3);
        mutableDateTime4.addWeeks((int) ' ');
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        java.lang.String str43 = dividedDateTimeField42.toString();
        java.util.Locale locale45 = null;
        java.lang.String str46 = dividedDateTimeField42.getAsShortText((-2), locale45);
        java.util.Locale locale48 = null;
        java.lang.String str49 = dividedDateTimeField42.getAsText((long) 9409, locale48);
        int int50 = dividedDateTimeField42.getMaximumValue();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str43.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-2" + "'", str46.equals("-2"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2" + "'", str49.equals("2"));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfWeek();
        org.joda.time.DurationField durationField8 = gJChronology6.months();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4663) + "'", int5 == (-4663));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        try {
            int int46 = unsupportedDateTimeField44.getMaximumValue(10400111L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.months();
        org.joda.time.DateTimeField dateTimeField2 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        mutableDateTime4.addMinutes((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        mutableDateTime4.setMillis((org.joda.time.ReadableInstant) mutableDateTime7);
        mutableDateTime4.setTime((long) 2019);
        int int11 = mutableDateTime4.getHourOfDay();
        boolean boolean12 = mutableDateTime4.isEqualNow();
        mutableDateTime4.addHours((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime4.toMutableDateTime();
        org.joda.time.DateTimeField dateTimeField16 = mutableDateTime15.getRoundingField();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNull(dateTimeField16);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DurationField durationField7 = gJChronology6.seconds();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4663) + "'", int5 == (-4663));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000000116d + "'", double1 == 2440587.5000000116d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 1, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.withMonthOfYear(1);
        org.joda.time.DateTime dateTime12 = dateTime10.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate13 = dateTime10.toLocalDate();
        org.joda.time.DateTime.Property property14 = dateTime10.millisOfDay();
        org.joda.time.DateTime dateTime16 = dateTime10.withYearOfCentury(0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("2", "hi!", 0, (-100));
        org.joda.time.DateTime dateTime22 = dateTime10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.weekOfWeekyear();
        org.joda.time.MutableDateTime mutableDateTime25 = dateTime10.toMutableDateTime((org.joda.time.Chronology) iSOChronology23);
        try {
            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((int) (byte) -1, 4664, (-1), (-4663), 31, 100, (org.joda.time.Chronology) iSOChronology23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -4663 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 5);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime7 = property5.withMinimumValue();
        java.lang.String str8 = property5.getAsText();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AD" + "'", str8.equals("AD"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        int int3 = property1.getMinimumValue();
        java.util.Locale locale4 = null;
        int int5 = property1.getMaximumTextLength(locale4);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone1);
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withTime(12, (int) (byte) 100, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        long long2 = mutableDateTime0.getMillis();
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        mutableDateTime0.add(readablePeriod3, 0);
//        boolean boolean7 = mutableDateTime0.isEqual(135558000000L);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560342618736L + "'", long2 == 1560342618736L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipUndoDateTimeField8.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8);
        int int29 = skipUndoDateTimeField8.getMaximumValue(62135568000001L);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        try {
            long long9 = gJChronology1.getDateTimeMillis((int) (short) 10, 0, (int) '#', (-28800000), 5, (-4663), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        java.lang.String str16 = skipUndoDateTimeField11.toString();
        long long18 = skipUndoDateTimeField11.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, (int) (byte) -1);
        try {
            long long25 = gregorianChronology0.getDateTimeMillis(0, (int) (byte) 0, 0, 30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str16.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long5 = julianChronology0.getDateTimeMillis((int) (short) 10, (int) ' ', (-1), (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate7 = dateTime4.toLocalDate();
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        java.lang.String str9 = property8.getAsShortText();
        org.joda.time.DateTime dateTime10 = property8.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime11 = property8.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 1, dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusMillis((int) '#');
        org.joda.time.DateTime dateTime18 = dateTime14.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime20 = dateTime18.withWeekOfWeekyear(31);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime23.withZone(dateTimeZone24);
        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
        org.joda.time.DateTime dateTime28 = dateTime18.withFields((org.joda.time.ReadablePartial) localTime27);
        try {
            int int29 = property8.getDifference((org.joda.time.ReadableInstant) dateTime18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -28857568000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "57600001" + "'", str9.equals("57600001"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localTime27);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        try {
            org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, 100L, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
//        int int3 = property1.get();
//        org.joda.time.DurationField durationField4 = property1.getLeapDurationField();
//        int int5 = property1.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
//        org.junit.Assert.assertNull(durationField4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 2019);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DurationField durationField6 = property5.getDurationField();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField8 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (-4663));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = property2.getField();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime5);
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField10, 0);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = skipUndoDateTimeField12.getMinimumValue(readablePartial13);
        long long16 = skipUndoDateTimeField12.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 1, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withMonthOfYear(1);
        org.joda.time.DateTime dateTime23 = dateTime21.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate24, (int) (byte) 0, locale26);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) 1, dateTimeZone30);
        org.joda.time.DateTime dateTime33 = dateTime31.withMonthOfYear(1);
        org.joda.time.DateTime dateTime35 = dateTime33.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate36 = dateTime33.toLocalDate();
        long long38 = gJChronology28.set((org.joda.time.ReadablePartial) localDate36, (long) (short) 1);
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate36, locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipUndoDateTimeField12.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField43 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType41, 12);
        boolean boolean44 = gregorianChronology0.equals((java.lang.Object) dividedDateTimeField43);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-28857599999L) + "'", long38 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "31" + "'", str40.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("0");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        long long18 = skipUndoDateTimeField11.add(1560342585128L, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology21 = gregorianChronology20.withUTC();
        java.lang.String str22 = gregorianChronology20.toString();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
        java.util.Locale locale26 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology25, locale26, (java.lang.Integer) 12, (int) (short) 1);
        long long32 = dateTimeParserBucket29.computeMillis(false, "");
        java.util.Locale locale33 = dateTimeParserBucket29.getLocale();
        boolean boolean34 = gregorianChronology20.equals((java.lang.Object) locale33);
        java.lang.String str35 = skipUndoDateTimeField11.getAsShortText((-1L), locale33);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter0.withLocale(locale33);
        try {
            java.lang.String str38 = dateTimeFormatter36.print((long) 3395);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560428985128L + "'", long18 == 1560428985128L);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GregorianChronology[UTC]" + "'", str22.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 28800000L + "'", long32 == 28800000L);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "31" + "'", str35.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.MutableDateTime mutableDateTime9 = property6.addWrapField((int) 'a');
        int int10 = property1.compareTo((org.joda.time.ReadableInstant) mutableDateTime9);
        try {
            org.joda.time.MutableDateTime mutableDateTime12 = property1.set(59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 1);
        org.joda.time.DateTimeField dateTimeField5 = null;
        dateTimeParserBucket4.saveField(dateTimeField5, (int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField14, 0);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = skipUndoDateTimeField16.getMinimumValue(readablePartial17);
        long long20 = skipUndoDateTimeField16.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 1, dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.withMonthOfYear(1);
        org.joda.time.DateTime dateTime27 = dateTime25.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate28 = dateTime25.toLocalDate();
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate28, (int) (byte) 0, locale30);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.MutableDateTime mutableDateTime33 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime33.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, (org.joda.time.ReadableInstant) mutableDateTime33);
        org.joda.time.MutableDateTime mutableDateTime36 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property37 = mutableDateTime36.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField38 = property37.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology35, dateTimeField38, 0);
        org.joda.time.ReadablePartial readablePartial41 = null;
        int int42 = skipUndoDateTimeField40.getMinimumValue(readablePartial41);
        long long44 = skipUndoDateTimeField40.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 1, dateTimeZone46);
        org.joda.time.DateTime dateTime49 = dateTime47.withMonthOfYear(1);
        org.joda.time.DateTime dateTime51 = dateTime49.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate52 = dateTime49.toLocalDate();
        java.util.Locale locale54 = null;
        java.lang.String str55 = skipUndoDateTimeField40.getAsText((org.joda.time.ReadablePartial) localDate52, (int) (byte) 0, locale54);
        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) 1, dateTimeZone58);
        org.joda.time.DateTime dateTime61 = dateTime59.withMonthOfYear(1);
        org.joda.time.DateTime dateTime63 = dateTime61.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate64 = dateTime61.toLocalDate();
        long long66 = gJChronology56.set((org.joda.time.ReadablePartial) localDate64, (long) (short) 1);
        java.util.Locale locale67 = null;
        java.lang.String str68 = skipUndoDateTimeField40.getAsText((org.joda.time.ReadablePartial) localDate64, locale67);
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = skipUndoDateTimeField40.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField70 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType69);
        dateTimeParserBucket4.saveField(dateTimeFieldType69, 57600001);
        org.joda.time.DateTimeZone dateTimeZone73 = null;
        org.joda.time.MutableDateTime mutableDateTime74 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property75 = mutableDateTime74.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology76 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone73, (org.joda.time.ReadableInstant) mutableDateTime74);
        org.joda.time.DateTimeField dateTimeField77 = gJChronology76.dayOfYear();
        org.joda.time.DurationField durationField78 = gJChronology76.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType69, durationField78);
        try {
            long long81 = unsupportedDateTimeField79.roundCeiling(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28800000L + "'", long20 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(mutableDateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 28800000L + "'", long44 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0" + "'", str55.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology56);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-28857599999L) + "'", long66 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "31" + "'", str68.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertNotNull(mutableDateTime74);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertNotNull(gJChronology76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int5 = gregorianChronology4.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 1970);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 1, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear(1);
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
        long long10 = gJChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) (short) 1);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) mutableDateTime13);
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = property17.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField18, 0);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int int22 = skipUndoDateTimeField20.getMinimumValue(readablePartial21);
        long long24 = skipUndoDateTimeField20.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        java.util.Locale locale34 = null;
        java.lang.String str35 = skipUndoDateTimeField20.getAsText((org.joda.time.ReadablePartial) localDate32, (int) (byte) 0, locale34);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.MutableDateTime mutableDateTime37 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property38 = mutableDateTime37.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone36, (org.joda.time.ReadableInstant) mutableDateTime37);
        org.joda.time.MutableDateTime mutableDateTime40 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property41 = mutableDateTime40.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField42 = property41.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField42, 0);
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipUndoDateTimeField44.getMinimumValue(readablePartial45);
        long long48 = skipUndoDateTimeField44.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        java.util.Locale locale58 = null;
        java.lang.String str59 = skipUndoDateTimeField44.getAsText((org.joda.time.ReadablePartial) localDate56, (int) (byte) 0, locale58);
        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) 1, dateTimeZone62);
        org.joda.time.DateTime dateTime65 = dateTime63.withMonthOfYear(1);
        org.joda.time.DateTime dateTime67 = dateTime65.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate68 = dateTime65.toLocalDate();
        long long70 = gJChronology60.set((org.joda.time.ReadablePartial) localDate68, (long) (short) 1);
        java.util.Locale locale71 = null;
        java.lang.String str72 = skipUndoDateTimeField44.getAsText((org.joda.time.ReadablePartial) localDate68, locale71);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = skipUndoDateTimeField44.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField74 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, dateTimeFieldType73);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField76 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType73, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-28857599999L) + "'", long10 == (-28857599999L));
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28800000L + "'", long24 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 28800000L + "'", long48 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "0" + "'", str59.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology60);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-28857599999L) + "'", long70 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "31" + "'", str72.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        try {
            long long46 = unsupportedDateTimeField44.roundHalfFloor((-210866846400000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime2.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekOfWeekyear(31);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime11.withZone(dateTimeZone12);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime16 = dateTime6.withFields((org.joda.time.ReadablePartial) localTime15);
        org.joda.time.DateTime dateTime18 = dateTime16.withCenturyOfEra(9409);
        org.joda.time.DateTime dateTime20 = dateTime18.withWeekyear((int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        mutableDateTime1.addDays(365);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime2.minusSeconds((int) ' ');
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withEra(10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology3 = gregorianChronology2.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        java.lang.String str6 = dateTimeZone4.getName(10L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
//        org.joda.time.Chronology chronology8 = julianChronology0.withZone(dateTimeZone4);
//        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        org.joda.time.MutableDateTime mutableDateTime13 = property10.addWrapField((int) 'a');
//        int int14 = mutableDateTime13.getRoundingMode();
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime13);
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getChronology(chronology15);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((java.lang.Object) julianChronology0, chronology16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.JulianChronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology2, locale3, (java.lang.Integer) 12, (int) (short) 1);
        long long9 = dateTimeParserBucket6.computeMillis(false, "");
        long long10 = dateTimeParserBucket6.computeMillis();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        java.lang.String str4 = dateTimeZone2.getName(10L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        long long7 = cachedDateTimeZone5.nextTransition((-1L));
//        long long9 = cachedDateTimeZone5.previousTransition(1560342590826L);
//        int int11 = cachedDateTimeZone5.getStandardOffset((long) (byte) -1);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560342590826L + "'", long9 == 1560342590826L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 1, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis((int) '#');
        org.joda.time.DateTime dateTime10 = dateTime6.minusSeconds((int) ' ');
        boolean boolean11 = mutableDateTime1.isBefore((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime1.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField19 = property18.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField19, 0);
        mutableDateTime1.setRounding(dateTimeField19);
        try {
            org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeField19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfWeek();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (short) 100, 'a', (int) '#', 10, (int) (short) 100, true, (int) (short) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder8.setStandardOffset(2);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder8.setFixedSavings("", (-2));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate7 = dateTime4.toLocalDate();
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        org.joda.time.DateTime dateTime10 = dateTime4.withYearOfCentury(0);
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        org.joda.time.MutableDateTime mutableDateTime45 = org.joda.time.MutableDateTime.now();
        int int46 = mutableDateTime45.getYearOfEra();
        org.joda.time.Chronology chronology48 = null;
        java.util.Locale locale49 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket51 = new org.joda.time.format.DateTimeParserBucket(100L, chronology48, locale49, (java.lang.Integer) 1);
        java.lang.Object obj52 = dateTimeParserBucket51.saveState();
        java.util.Locale locale53 = dateTimeParserBucket51.getLocale();
        java.util.Calendar calendar54 = mutableDateTime45.toCalendar(locale53);
        try {
            int int55 = unsupportedDateTimeField44.getMaximumTextLength(locale53);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertNotNull(mutableDateTime45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(locale53);
        org.junit.Assert.assertNotNull(calendar54);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 100);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology4);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        java.lang.String str16 = skipUndoDateTimeField11.toString();
        long long18 = skipUndoDateTimeField11.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, (int) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj22 = mutableDateTime21.clone();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 1, dateTimeZone24);
        int int26 = mutableDateTime21.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay29 = dateTime28.toTimeOfDay();
        int int30 = skipUndoDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay29);
        org.joda.time.DurationField durationField31 = skipUndoDateTimeField11.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str16.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(timeOfDay29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(durationField31);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("AD", "12", (-100), 12);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(1560342585128L);
        int int8 = fixedDateTimeZone4.getOffset(100L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-100) + "'", int6 == (-100));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-100) + "'", int8 == (-100));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = property5.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.plusWeeks((int) (byte) 10);
        int int9 = dateTime6.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-4663), 5, (int) (short) -1, (int) (short) 100, 0, 9409, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundHalfEven((long) 2019);
        int int12 = skipUndoDateTimeField8.get((long) ' ');
        boolean boolean14 = skipUndoDateTimeField8.isLeap((long) 2019);
        java.lang.String str15 = skipUndoDateTimeField8.toString();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str15.equals("DateTimeField[dayOfMonth]"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField8.getAsShortText(2000, locale27);
        int int30 = skipUndoDateTimeField8.get((long) (byte) -1);
        java.util.Locale locale31 = null;
        int int32 = skipUndoDateTimeField8.getMaximumShortTextLength(locale31);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2000" + "'", str28.equals("2000"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.String str2 = julianChronology0.toString();
        long long6 = julianChronology0.add((long) (byte) 0, 0L, (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        long long12 = dateTimeZone8.getMillisKeepLocal(dateTimeZone10, (long) (short) 100);
        org.joda.time.Chronology chronology13 = julianChronology0.withZone(dateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime6);
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField11, 0);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = skipUndoDateTimeField13.getMinimumValue(readablePartial14);
        long long17 = skipUndoDateTimeField13.roundHalfFloor((long) (short) -1);
        long long20 = skipUndoDateTimeField13.add(1560342585128L, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology23 = gregorianChronology22.withUTC();
        java.lang.String str24 = gregorianChronology22.toString();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26);
        java.util.Locale locale28 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology27, locale28, (java.lang.Integer) 12, (int) (short) 1);
        long long34 = dateTimeParserBucket31.computeMillis(false, "");
        java.util.Locale locale35 = dateTimeParserBucket31.getLocale();
        boolean boolean36 = gregorianChronology22.equals((java.lang.Object) locale35);
        java.lang.String str37 = skipUndoDateTimeField13.getAsShortText((-1L), locale35);
        int int38 = property1.getMaximumTextLength(locale35);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560428985128L + "'", long20 == 1560428985128L);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "GregorianChronology[UTC]" + "'", str24.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 28800000L + "'", long34 == 28800000L);
        org.junit.Assert.assertNotNull(locale35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "31" + "'", str37.equals("31"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        java.lang.Object obj1 = mutableDateTime0.clone();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
//        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) ' ');
//        org.joda.time.DateTime.Property property8 = dateTime4.era();
//        org.joda.time.DateTime dateTime10 = dateTime4.minusMinutes(1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology12 = gregorianChronology11.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology11.getZone();
//        java.lang.String str15 = dateTimeZone13.getName(10L);
//        org.joda.time.DateTime dateTime16 = dateTime4.toDateTime(dateTimeZone13);
//        try {
//            org.joda.time.DateTime dateTime18 = dateTime4.withDayOfWeek(3395);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3395 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(obj1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime5 = property1.roundCeiling();
        int int6 = mutableDateTime5.getMillisOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = dateTime9.withZone(dateTimeZone10);
        org.joda.time.LocalTime localTime13 = dateTime12.toLocalTime();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime5, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) mutableDateTime16);
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField21 = property20.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField21, 0);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = skipUndoDateTimeField23.getMinimumValue(readablePartial24);
        long long27 = skipUndoDateTimeField23.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipUndoDateTimeField23.getAsText((org.joda.time.ReadablePartial) localDate35, (int) (byte) 0, locale37);
        long long40 = skipUndoDateTimeField23.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipUndoDateTimeField23.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType41, "");
        try {
            org.joda.time.DateTime dateTime45 = dateTime12.withField(dateTimeFieldType41, (-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localTime13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28800000L + "'", long27 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 28800000L + "'", long40 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime8 = dateTime4.withMillis((long) (byte) 1);
        org.joda.time.DateTime dateTime10 = dateTime4.withMillis((long) (-100));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getYearOfEra();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.dayOfWeek();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.secondOfMinute();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.minuteOfDay();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1969 + "'", int1 == 1969);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMonthOfYear(1);
        org.joda.time.DateTime dateTime8 = dateTime6.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate9 = dateTime6.toLocalDate();
        long long11 = gJChronology1.set((org.joda.time.ReadablePartial) localDate9, (long) (short) 1);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (-28800000), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology1.getZone();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28857599999L) + "'", long11 == (-28857599999L));
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 1, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis((int) '#');
        org.joda.time.DateTime dateTime10 = dateTime6.minusSeconds((int) ' ');
        boolean boolean11 = mutableDateTime1.isBefore((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime1.minuteOfHour();
        try {
            mutableDateTime1.setTime(1969, (int) (byte) 100, (int) (byte) 1, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipUndoDateTimeField32.getMinimumValue(readablePartial33);
        long long36 = skipUndoDateTimeField32.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear(1);
        org.joda.time.DateTime dateTime43 = dateTime41.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime41.toLocalDate();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale46);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        long long58 = gJChronology48.set((org.joda.time.ReadablePartial) localDate56, (long) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate56, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipUndoDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType61);
        long long65 = zeroIsMaxDateTimeField62.getDifferenceAsLong(1560342585128L, (long) 0);
        int int67 = zeroIsMaxDateTimeField62.getMaximumValue((long) (byte) 100);
        try {
            long long70 = zeroIsMaxDateTimeField62.set((long) 31, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for dayOfMonth must be in the range [1,32]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28857599999L) + "'", long58 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 18059L + "'", long65 == 18059L);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 32 + "'", int67 == 32);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        java.lang.String str16 = skipUndoDateTimeField11.toString();
        long long18 = skipUndoDateTimeField11.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, (int) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj22 = mutableDateTime21.clone();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 1, dateTimeZone24);
        int int26 = mutableDateTime21.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay29 = dateTime28.toTimeOfDay();
        int int30 = skipUndoDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay29);
        long long32 = skipUndoDateTimeField11.roundFloor((long) 7);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str16.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(timeOfDay29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-57600000L) + "'", long32 == (-57600000L));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology11);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) (byte) 100, 10, (int) (byte) 10, (-100), 30, 0, 16, (org.joda.time.Chronology) gJChronology11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        int int8 = mutableDateTime7.getYearOfEra();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.MutableDateTime mutableDateTime13 = property10.addWrapField((int) 'a');
        mutableDateTime7.setTime((org.joda.time.ReadableInstant) mutableDateTime13);
        org.joda.time.Chronology chronology15 = mutableDateTime7.getChronology();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime6, chronology15);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipUndoDateTimeField32.getMinimumValue(readablePartial33);
        long long36 = skipUndoDateTimeField32.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear(1);
        org.joda.time.DateTime dateTime43 = dateTime41.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime41.toLocalDate();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale46);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        long long58 = gJChronology48.set((org.joda.time.ReadablePartial) localDate56, (long) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate56, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipUndoDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType61);
        long long65 = zeroIsMaxDateTimeField62.getDifferenceAsLong(1560342585128L, (long) 0);
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.MutableDateTime mutableDateTime67 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property68 = mutableDateTime67.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone66, (org.joda.time.ReadableInstant) mutableDateTime67);
        org.joda.time.MutableDateTime mutableDateTime70 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property71 = mutableDateTime70.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField72 = property71.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField74 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology69, dateTimeField72, 0);
        org.joda.time.ReadablePartial readablePartial75 = null;
        int int76 = skipUndoDateTimeField74.getMinimumValue(readablePartial75);
        long long78 = skipUndoDateTimeField74.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone80 = null;
        org.joda.time.DateTime dateTime81 = new org.joda.time.DateTime((long) 1, dateTimeZone80);
        org.joda.time.DateTime dateTime83 = dateTime81.withMonthOfYear(1);
        org.joda.time.DateTime dateTime85 = dateTime83.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate86 = dateTime83.toLocalDate();
        java.util.Locale locale88 = null;
        java.lang.String str89 = skipUndoDateTimeField74.getAsText((org.joda.time.ReadablePartial) localDate86, (int) (byte) 0, locale88);
        org.joda.time.Chronology chronology92 = null;
        java.util.Locale locale93 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket95 = new org.joda.time.format.DateTimeParserBucket(100L, chronology92, locale93, (java.lang.Integer) 1);
        java.lang.Object obj96 = dateTimeParserBucket95.saveState();
        java.util.Locale locale97 = dateTimeParserBucket95.getLocale();
        java.lang.String str98 = zeroIsMaxDateTimeField62.getAsShortText((org.joda.time.ReadablePartial) localDate86, (int) (byte) 10, locale97);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28857599999L) + "'", long58 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 18059L + "'", long65 == 18059L);
        org.junit.Assert.assertNotNull(mutableDateTime67);
        org.junit.Assert.assertNotNull(property68);
        org.junit.Assert.assertNotNull(gJChronology69);
        org.junit.Assert.assertNotNull(mutableDateTime70);
        org.junit.Assert.assertNotNull(property71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 28800000L + "'", long78 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(dateTime85);
        org.junit.Assert.assertNotNull(localDate86);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "0" + "'", str89.equals("0"));
        org.junit.Assert.assertNotNull(obj96);
        org.junit.Assert.assertNotNull(locale97);
        org.junit.Assert.assertTrue("'" + str98 + "' != '" + "10" + "'", str98.equals("10"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("0");
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("AD", "12", (-100), 12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter2, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime dateTime7 = dateTime4.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        org.joda.time.DateTime dateTime9 = property8.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval4);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        java.lang.String str2 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("AD", "12", (-100), 12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        try {
            org.joda.time.LocalTime localTime10 = dateTimeFormatter2.parseLocalTime("2019-06-12T00:00:00-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField7, 0);
        long long11 = skipUndoDateTimeField9.roundHalfEven((long) 2019);
        int int13 = skipUndoDateTimeField9.get((long) ' ');
        boolean boolean15 = skipUndoDateTimeField9.isLeap((long) 2019);
        int int16 = mutableDateTime0.get((org.joda.time.DateTimeField) skipUndoDateTimeField9);
        org.joda.time.DurationField durationField17 = skipUndoDateTimeField9.getRangeDurationField();
        long long20 = durationField17.subtract((long) (byte) -1, (long) 4);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-10544400001L) + "'", long20 == (-10544400001L));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime.Property property6 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.withMinimumValue();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        java.lang.Class<?> wildcardClass9 = property8.getClass();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 3395, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        try {
            mutableDateTime0.setDate(5, 16, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 16 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate7 = dateTime4.toLocalDate();
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 1, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMonthOfYear(1);
        int int14 = property8.getDifference((org.joda.time.ReadableInstant) dateTime13);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        org.joda.time.Chronology chronology6 = gJChronology4.withUTC();
        try {
            long long14 = gJChronology4.getDateTimeMillis(59, 0, (int) '#', 0, (int) '4', 7, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        boolean boolean45 = unsupportedDateTimeField44.isSupported();
        try {
            long long48 = unsupportedDateTimeField44.set(100L, "12");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundHalfEven((long) 2019);
        int int12 = skipUndoDateTimeField8.get((long) ' ');
        long long15 = skipUndoDateTimeField8.set((long) 30, (int) (byte) 10);
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1814399970L) + "'", long15 == (-1814399970L));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        java.lang.String str45 = unsupportedDateTimeField44.getName();
        try {
            long long47 = unsupportedDateTimeField44.roundHalfEven(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfMonth" + "'", str45.equals("dayOfMonth"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.DurationField durationField5 = gJChronology3.years();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.monthOfYear();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundHalfEven((long) 2019);
        int int12 = skipUndoDateTimeField8.get((long) ' ');
        int int14 = skipUndoDateTimeField8.getMinimumValue((-210866846400000L));
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay8 = dateTime7.toTimeOfDay();
        try {
            org.joda.time.DateTime dateTime10 = dateTime7.withHourOfDay((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(timeOfDay8);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        mutableDateTime4.addMinutes((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        mutableDateTime4.setMillis((org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime4.weekOfWeekyear();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 1, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear(1);
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
        long long10 = gJChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj12 = mutableDateTime11.clone();
        boolean boolean13 = gJChronology0.equals((java.lang.Object) mutableDateTime11);
        org.joda.time.ReadableDuration readableDuration14 = null;
        mutableDateTime11.add(readableDuration14, 57600);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-28857599999L) + "'", long10 == (-28857599999L));
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipUndoDateTimeField32.getMinimumValue(readablePartial33);
        long long36 = skipUndoDateTimeField32.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear(1);
        org.joda.time.DateTime dateTime43 = dateTime41.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime41.toLocalDate();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale46);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        long long58 = gJChronology48.set((org.joda.time.ReadablePartial) localDate56, (long) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate56, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipUndoDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType61);
        long long64 = zeroIsMaxDateTimeField62.remainder((long) 2000);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28857599999L) + "'", long58 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 57602000L + "'", long64 == 57602000L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(32, 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 224 + "'", int2 == 224);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        int int3 = property1.getMaximumValue();
        int int4 = property1.getMinimumValueOverall();
        org.joda.time.DurationField durationField5 = property1.getRangeDurationField();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        boolean boolean45 = unsupportedDateTimeField44.isSupported();
        try {
            long long47 = unsupportedDateTimeField44.remainder((long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DurationField durationField7 = gJChronology6.weeks();
        org.joda.time.Instant instant8 = gJChronology6.getGregorianCutover();
        org.joda.time.MutableDateTime mutableDateTime9 = instant8.toMutableDateTime();
        boolean boolean11 = instant8.isAfter((long) (byte) -1);
        org.joda.time.DateTime dateTime12 = instant8.toDateTimeISO();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.halfdays();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property8 = dateTime4.era();
        org.joda.time.DateTime dateTime10 = dateTime4.minusMinutes(1);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        int int43 = dividedDateTimeField42.getDivisor();
        long long45 = dividedDateTimeField42.roundHalfFloor(12L);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 374400000L + "'", long45 == 374400000L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        mutableDateTime4.addMinutes((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        mutableDateTime4.setMillis((org.joda.time.ReadableInstant) mutableDateTime7);
        mutableDateTime4.setTime((long) 2019);
        mutableDateTime4.addHours(57600001);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-1L), (-2063199889L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2063199890L) + "'", long2 == (-2063199890L));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        mutableDateTime4.addMinutes((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        mutableDateTime4.setMillis((org.joda.time.ReadableInstant) mutableDateTime7);
        mutableDateTime4.setWeekyear(0);
        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62166787622000L) + "'", long11 == (-62166787622000L));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipUndoDateTimeField8.getType();
        try {
            long long29 = skipUndoDateTimeField8.set((long) (byte) 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [0,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        java.lang.Class<?> wildcardClass9 = skipUndoDateTimeField8.getClass();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology3 = gregorianChronology2.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        java.lang.String str6 = dateTimeZone4.getName(10L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
//        org.joda.time.Chronology chronology8 = julianChronology0.withZone(dateTimeZone4);
//        try {
//            org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 30");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("DateTimeField[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[dayOfMonth]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField7, 0);
        long long11 = skipUndoDateTimeField9.roundHalfEven((long) 2019);
        int int13 = skipUndoDateTimeField9.get((long) ' ');
        boolean boolean15 = skipUndoDateTimeField9.isLeap((long) 2019);
        int int16 = mutableDateTime0.get((org.joda.time.DateTimeField) skipUndoDateTimeField9);
        boolean boolean17 = skipUndoDateTimeField9.isLenient();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        org.joda.time.DurationField durationField45 = unsupportedDateTimeField44.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) 1, dateTimeZone47);
        org.joda.time.DateTime dateTime50 = dateTime48.withMonthOfYear(1);
        org.joda.time.DateTime dateTime52 = dateTime50.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate53 = dateTime50.toLocalDate();
        try {
            int int54 = unsupportedDateTimeField44.getMaximumValue((org.joda.time.ReadablePartial) localDate53);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertNull(durationField45);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDate53);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        mutableDateTime4.addMinutes((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        mutableDateTime4.setMillis((org.joda.time.ReadableInstant) mutableDateTime7);
        mutableDateTime4.setTime((long) 2019);
        int int11 = mutableDateTime4.getHourOfDay();
        org.joda.time.ReadableDuration readableDuration12 = null;
        mutableDateTime4.add(readableDuration12, 0);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = mutableDateTime1.copy();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) ' ', "JulianChronology[America/Los_Angeles]");
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 4664);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) '#');
        org.joda.time.DateTime.Property property7 = dateTime6.era();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        java.lang.String str10 = dateTimeZone9.getID();
        org.joda.time.Chronology chronology11 = iSOChronology0.withZone(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology11);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField7, 0);
//        long long11 = skipUndoDateTimeField9.roundHalfEven((long) 2019);
//        int int13 = skipUndoDateTimeField9.get((long) ' ');
//        boolean boolean15 = skipUndoDateTimeField9.isLeap((long) 2019);
//        int int16 = mutableDateTime0.get((org.joda.time.DateTimeField) skipUndoDateTimeField9);
//        int int17 = mutableDateTime0.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 20 + "'", int17 == 20);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfMinute();
        org.joda.time.DateTime.Property property6 = dateTime4.secondOfMinute();
        int int7 = property6.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 59 + "'", int7 == 59);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 1, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMillis((int) '#');
        org.joda.time.DateTime.Property property10 = dateTime9.era();
        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
        java.lang.String str13 = dateTimeZone12.getID();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((-100), 2000, (int) 'a', (-100), 20, dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        int int43 = dividedDateTimeField42.getDivisor();
        int int46 = dividedDateTimeField42.getDifference((long) (-100), (long) 0);
        java.util.Locale locale48 = null;
        java.lang.String str49 = dividedDateTimeField42.getAsText((long) (short) 1, locale48);
        long long51 = dividedDateTimeField42.roundFloor((long) 7);
        long long54 = dividedDateTimeField42.getDifferenceAsLong(1560428985128L, 0L);
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) 1, dateTimeZone56);
        org.joda.time.DateTime dateTime59 = dateTime57.withMonthOfYear(1);
        org.joda.time.DateTime dateTime61 = dateTime59.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate62 = dateTime59.toLocalDate();
        int[] intArray66 = new int[] { 30, (short) 100 };
        int[] intArray68 = dividedDateTimeField42.addWrapPartial((org.joda.time.ReadablePartial) localDate62, 32, intArray66, 0);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2" + "'", str49.equals("2"));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-662400000L) + "'", long51 == (-662400000L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1505L + "'", long54 == 1505L);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(localDate62);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray68);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime.Property property6 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        int int10 = mutableDateTime9.getYearOfEra();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
        org.joda.time.MutableDateTime mutableDateTime15 = property12.addWrapField((int) 'a');
        mutableDateTime9.setTime((org.joda.time.ReadableInstant) mutableDateTime15);
        org.joda.time.Chronology chronology17 = mutableDateTime9.getChronology();
        boolean boolean18 = dateTime7.isBefore((org.joda.time.ReadableInstant) mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        java.lang.String str16 = skipUndoDateTimeField11.toString();
        long long18 = skipUndoDateTimeField11.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField22, 59);
        try {
            long long29 = gregorianChronology0.getDateTimeMillis(59, (int) 'a', 3395, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str16.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        int int5 = cachedDateTimeZone3.getOffset(2000L);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 16, (org.joda.time.DateTimeZone) cachedDateTimeZone3);
        boolean boolean7 = mutableDateTime6.isEqualNow();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
//        boolean boolean3 = property1.isLeap();
//        org.joda.time.MutableDateTime mutableDateTime4 = property1.getMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime5 = property1.roundFloor();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        java.lang.String str7 = mutableDateTime5.toString(dateTimeFormatter6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = dateTime10.withZone(dateTimeZone11);
//        mutableDateTime5.setTime((org.joda.time.ReadableInstant) dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-12T00:00:00-07:00" + "'", str7.equals("2019-06-12T00:00:00-07:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DurationField durationField7 = gJChronology6.weeks();
        try {
            long long10 = durationField7.subtract((-28857599999L), (-62166787622000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 62166787622000 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        java.lang.String str16 = skipUndoDateTimeField11.toString();
        long long18 = skipUndoDateTimeField11.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, (int) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj22 = mutableDateTime21.clone();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 1, dateTimeZone24);
        int int26 = mutableDateTime21.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay29 = dateTime28.toTimeOfDay();
        int int30 = skipUndoDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay29);
        org.joda.time.DurationField durationField31 = skipUndoDateTimeField11.getRangeDurationField();
        int int33 = skipUndoDateTimeField11.get(374400000L);
        try {
            long long36 = skipUndoDateTimeField11.set((long) (byte) 100, "32");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str16.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(timeOfDay29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
        int int5 = mutableDateTime4.getRoundingMode();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.centuryOfEra();
        mutableDateTime4.add(0L);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime4.centuryOfEra();
        int int10 = mutableDateTime4.getYearOfCentury();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DurationField durationField6 = property5.getDurationField();
        org.joda.time.Chronology chronology8 = null;
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket(100L, chronology8, locale9, (java.lang.Integer) 1);
        java.lang.Object obj12 = dateTimeParserBucket11.saveState();
        java.util.Locale locale13 = dateTimeParserBucket11.getLocale();
        int int14 = property5.getMaximumTextLength(locale13);
        int int15 = property5.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(locale13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime8 = dateTime4.withMillis((long) (byte) 1);
        org.joda.time.DateTime dateTime10 = dateTime8.minusHours(7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = gregorianChronology1.withUTC();
        org.joda.time.DurationField durationField3 = gregorianChronology1.years();
        org.joda.time.DurationField durationField4 = gregorianChronology1.weekyears();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField5 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        mutableDateTime0.setSecondOfDay((int) (byte) 1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("AD", "12", (-100), 12);
        org.joda.time.DateTime dateTime9 = mutableDateTime0.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        mutableDateTime0.add(readablePeriod10);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipUndoDateTimeField32.getMinimumValue(readablePartial33);
        long long36 = skipUndoDateTimeField32.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear(1);
        org.joda.time.DateTime dateTime43 = dateTime41.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime41.toLocalDate();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale46);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        long long58 = gJChronology48.set((org.joda.time.ReadablePartial) localDate56, (long) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate56, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipUndoDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType61);
        long long65 = zeroIsMaxDateTimeField62.getDifferenceAsLong(1560342585128L, (long) 0);
        long long68 = zeroIsMaxDateTimeField62.addWrapField(10400111L, (int) (short) 100);
        long long70 = zeroIsMaxDateTimeField62.remainder((long) 100);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28857599999L) + "'", long58 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 18059L + "'", long65 == 18059L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-2063199889L) + "'", long68 == (-2063199889L));
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 57600100L + "'", long70 == 57600100L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        org.joda.time.DurationField durationField45 = unsupportedDateTimeField44.getLeapDurationField();
        org.joda.time.MutableDateTime mutableDateTime46 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj47 = mutableDateTime46.clone();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) 1, dateTimeZone49);
        int int51 = mutableDateTime46.compareTo((org.joda.time.ReadableInstant) dateTime50);
        org.joda.time.DateTime dateTime53 = dateTime50.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay54 = dateTime53.toTimeOfDay();
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.MutableDateTime mutableDateTime58 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property59 = mutableDateTime58.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone57, (org.joda.time.ReadableInstant) mutableDateTime58);
        java.util.Locale locale61 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket63 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology60, locale61, (java.lang.Integer) 100);
        org.joda.time.DateTimeField dateTimeField64 = gJChronology60.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField65 = gJChronology60.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime((long) 1, dateTimeZone68);
        org.joda.time.DateTime dateTime71 = dateTime69.withMonthOfYear(1);
        org.joda.time.DateTime dateTime73 = dateTime71.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate74 = dateTime71.toLocalDate();
        long long76 = gJChronology66.set((org.joda.time.ReadablePartial) localDate74, (long) (short) 1);
        int[] intArray78 = gJChronology60.get((org.joda.time.ReadablePartial) localDate74, (long) 100);
        try {
            int[] intArray80 = unsupportedDateTimeField44.add((org.joda.time.ReadablePartial) timeOfDay54, 0, intArray78, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertNull(durationField45);
        org.junit.Assert.assertNotNull(mutableDateTime46);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(timeOfDay54);
        org.junit.Assert.assertNotNull(mutableDateTime58);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(gJChronology60);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(gJChronology66);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(localDate74);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-28857599999L) + "'", long76 == (-28857599999L));
        org.junit.Assert.assertNotNull(intArray78);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime8 = dateTime4.withMillis((long) (byte) 1);
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withDayOfWeek((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField8.getAsShortText(2000, locale27);
        int int30 = skipUndoDateTimeField8.get((long) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType31);
        int int33 = delegatedDateTimeField32.getMaximumValue();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2000" + "'", str28.equals("2000"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 31 + "'", int33 == 31);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        org.joda.time.Chronology chronology6 = gJChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.clockhourOfDay();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        try {
            int[] intArray10 = gJChronology4.get(readablePeriod8, 18059L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime2.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekOfWeekyear(31);
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = buddhistChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        java.lang.String str9 = dateTimeZone7.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(0L, dateTimeZone7);
        org.joda.time.Chronology chronology12 = buddhistChronology2.withZone(dateTimeZone7);
        boolean boolean14 = buddhistChronology2.equals((java.lang.Object) 1560342587094L);
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology2.secondOfDay();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((-662400000L), (org.joda.time.Chronology) buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
        java.lang.String str5 = dateTimeFormatter3.print(0L);
        try {
            org.joda.time.Instant instant6 = org.joda.time.Instant.parse("AD", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"AD\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-365T16:00:00.000-08:00" + "'", str5.equals("1969-365T16:00:00.000-08:00"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("AD", "12", (-100), 12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        int int10 = fixedDateTimeZone7.getOffset(0L);
        int int12 = fixedDateTimeZone7.getStandardOffset((-1814399970L));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-100) + "'", int10 == (-100));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis((int) (byte) 0);
        org.joda.time.DateTime.Property property7 = dateTime2.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundHalfEven((long) 2019);
        int int12 = skipUndoDateTimeField8.get((long) ' ');
        long long15 = skipUndoDateTimeField8.set((long) 30, (int) (byte) 10);
        java.lang.String str16 = skipUndoDateTimeField8.getName();
        try {
            long long19 = skipUndoDateTimeField8.set((long) 30, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfMonth must be in the range [0,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1814399970L) + "'", long15 == (-1814399970L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfMonth" + "'", str16.equals("dayOfMonth"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-210861662400000L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 59.0d + "'", double1 == 59.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        try {
            long long46 = unsupportedDateTimeField44.roundCeiling(3000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime3);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getYearOfEra();
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.dayOfWeek();
//        int int3 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = mutableDateTime0.getRoundingField();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19841 + "'", int3 == 19841);
//        org.junit.Assert.assertNull(dateTimeField4);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("57600001", 100, 59, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for 57600001 must be in the range [59,-28800000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 12L, (java.lang.Number) (-2), (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getYearOfEra();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.MutableDateTime mutableDateTime6 = property3.addWrapField((int) 'a');
        mutableDateTime0.setTime((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime0.addYears((int) (short) 1);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        mutableDateTime4.setZoneRetainFields(dateTimeZone5);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getYearOfEra();
//        mutableDateTime0.setWeekyear(10);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) mutableDateTime7);
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField12, 0);
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        int int16 = skipUndoDateTimeField14.getMinimumValue(readablePartial15);
//        long long18 = skipUndoDateTimeField14.roundHalfFloor((long) (short) -1);
//        long long21 = skipUndoDateTimeField14.add(1560342585128L, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology24 = gregorianChronology23.withUTC();
//        java.lang.String str25 = gregorianChronology23.toString();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27);
//        java.util.Locale locale29 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology28, locale29, (java.lang.Integer) 12, (int) (short) 1);
//        long long35 = dateTimeParserBucket32.computeMillis(false, "");
//        java.util.Locale locale36 = dateTimeParserBucket32.getLocale();
//        boolean boolean37 = gregorianChronology23.equals((java.lang.Object) locale36);
//        java.lang.String str38 = skipUndoDateTimeField14.getAsShortText((-1L), locale36);
//        java.lang.String str39 = property4.getAsText(locale36);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560428985128L + "'", long21 == 1560428985128L);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "GregorianChronology[UTC]" + "'", str25.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 28800000L + "'", long35 == 28800000L);
//        org.junit.Assert.assertNotNull(locale36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "31" + "'", str38.equals("31"));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "5" + "'", str39.equals("5"));
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2000", false);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("UnsupportedDateTimeField", (int) (short) 10, (int) (byte) 10, (int) (short) 100, '4', 19841, 59, 2019, true, 3395);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        mutableDateTime4.addHours(0);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((-2));
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter0.parseDateTime("5");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"5\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipUndoDateTimeField8.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "31");
        java.lang.Number number29 = illegalFieldValueException28.getUpperBound();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) 1, dateTimeZone31);
        org.joda.time.DateTime dateTime34 = dateTime32.minusMillis((int) '#');
        org.joda.time.DateTime.Property property35 = dateTime34.era();
        org.joda.time.DateTime dateTime36 = property35.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone37 = dateTime36.getZone();
        java.lang.String str38 = dateTimeZone37.getID();
        long long40 = dateTimeZone37.convertUTCToLocal((long) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((java.lang.Object) number29, dateTimeZone37);
        org.joda.time.MutableDateTime.Property property42 = mutableDateTime41.secondOfMinute();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "America/Los_Angeles" + "'", str38.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-28799900L) + "'", long40 == (-28799900L));
        org.junit.Assert.assertNotNull(property42);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 1);
        int int5 = dateTimeParserBucket4.getOffset();
        long long8 = dateTimeParserBucket4.computeMillis(false, "DateTimeField[dayOfMonth]");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("2", "hi!", 0, (-100));
        java.util.TimeZone timeZone14 = fixedDateTimeZone13.toTimeZone();
        dateTimeParserBucket4.setZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28800100L + "'", long8 == 28800100L);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(12L, (-210861677222000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -2530340126664000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 1, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMonthOfYear(1);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTimeISO();
        org.joda.time.DateTime.Property property11 = dateTime9.weekOfWeekyear();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTime.Property property13 = dateTime12.dayOfWeek();
        int int14 = dateTime12.getEra();
        boolean boolean15 = dateTime4.isAfter((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime12.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) '#');
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTimeISO();
        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime10 = dateTime6.withMillis((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology12 = gregorianChronology11.withUTC();
        java.lang.String str13 = gregorianChronology11.toString();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) mutableDateTime15);
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = property19.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField20, 0);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int int24 = skipUndoDateTimeField22.getMinimumValue(readablePartial23);
        long long26 = skipUndoDateTimeField22.roundHalfFloor((long) (short) -1);
        java.lang.String str27 = skipUndoDateTimeField22.toString();
        long long29 = skipUndoDateTimeField22.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology11, (org.joda.time.DateTimeField) skipUndoDateTimeField22, (int) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj33 = mutableDateTime32.clone();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) 1, dateTimeZone35);
        int int37 = mutableDateTime32.compareTo((org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.DateTime dateTime39 = dateTime36.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay40 = dateTime39.toTimeOfDay();
        int int41 = skipUndoDateTimeField22.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay40);
        org.joda.time.DateTime dateTime42 = dateTime10.withFields((org.joda.time.ReadablePartial) timeOfDay40);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) timeOfDay40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-34L) + "'", long8 == (-34L));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[UTC]" + "'", str13.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 28800000L + "'", long26 == 28800000L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str27.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 28800000L + "'", long29 == 28800000L);
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(timeOfDay40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(dateTime42);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate7 = dateTime4.toLocalDate();
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        org.joda.time.DateTime dateTime9 = property8.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("57600001");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getYearOfEra();
        org.joda.time.Chronology chronology3 = null;
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(100L, chronology3, locale4, (java.lang.Integer) 1);
        java.lang.Object obj7 = dateTimeParserBucket6.saveState();
        java.util.Locale locale8 = dateTimeParserBucket6.getLocale();
        java.util.Calendar calendar9 = mutableDateTime0.toCalendar(locale8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) mutableDateTime13);
        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.dayOfYear();
        org.joda.time.DurationField durationField17 = gJChronology15.years();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.MutableDateTime mutableDateTime20 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, (org.joda.time.ReadableInstant) mutableDateTime20);
        org.joda.time.MutableDateTime mutableDateTime23 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime23.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField25 = property24.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology22, dateTimeField25, 0);
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = skipUndoDateTimeField27.getMinimumValue(readablePartial28);
        long long31 = skipUndoDateTimeField27.roundHalfFloor((long) (short) -1);
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipUndoDateTimeField27.getAsText((int) (short) 1, locale33);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.MutableDateTime mutableDateTime37 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property38 = mutableDateTime37.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone36, (org.joda.time.ReadableInstant) mutableDateTime37);
        java.util.Locale locale40 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket42 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology39, locale40, (java.lang.Integer) 100);
        org.joda.time.DateTimeField dateTimeField43 = gJChronology39.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField44 = gJChronology39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) 1, dateTimeZone47);
        org.joda.time.DateTime dateTime50 = dateTime48.withMonthOfYear(1);
        org.joda.time.DateTime dateTime52 = dateTime50.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate53 = dateTime50.toLocalDate();
        long long55 = gJChronology45.set((org.joda.time.ReadablePartial) localDate53, (long) (short) 1);
        int[] intArray57 = gJChronology39.get((org.joda.time.ReadablePartial) localDate53, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone60);
        java.util.Locale locale62 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket65 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology61, locale62, (java.lang.Integer) 12, (int) (short) 1);
        long long68 = dateTimeParserBucket65.computeMillis(false, "");
        java.util.Locale locale69 = dateTimeParserBucket65.getLocale();
        java.text.DateFormatSymbols dateFormatSymbols70 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale69);
        java.lang.String str71 = skipUndoDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate53, (int) ' ', locale69);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket73 = new org.joda.time.format.DateTimeParserBucket(1560342590826L, (org.joda.time.Chronology) gJChronology15, locale69, (java.lang.Integer) 224);
        int int74 = property10.getMaximumTextLength(locale69);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(locale8);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 28800000L + "'", long31 == 28800000L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-28857599999L) + "'", long55 == (-28857599999L));
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 28800000L + "'", long68 == 28800000L);
        org.junit.Assert.assertNotNull(locale69);
        org.junit.Assert.assertNotNull(dateFormatSymbols70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "32" + "'", str71.equals("32"));
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 3 + "'", int74 == 3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter1.parseMutableDateTime("0");
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTimeFormatter7.parseMutableDateTime("0");
        org.joda.time.DateTimeZone dateTimeZone10 = dateTimeFormatter7.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter6.withZone(dateTimeZone10);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, 0L, 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter0.withZone(dateTimeZone10);
        java.lang.StringBuffer stringBuffer16 = null;
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj18 = mutableDateTime17.clone();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 1, dateTimeZone20);
        int int22 = mutableDateTime17.compareTo((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property23 = dateTime21.secondOfMinute();
        org.joda.time.LocalDateTime localDateTime24 = dateTime21.toLocalDateTime();
        try {
            dateTimeFormatter0.printTo(stringBuffer16, (org.joda.time.ReadablePartial) localDateTime24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDateTime24);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        java.lang.String str16 = skipUndoDateTimeField11.toString();
        long long18 = skipUndoDateTimeField11.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField22, 59);
        long long27 = skipDateTimeField24.getDifferenceAsLong((long) 3395, 18059L);
        int int29 = skipDateTimeField24.get((long) (-2));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str16.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        int int47 = unsupportedDateTimeField44.getDifference(2000L, (long) (byte) 10);
        try {
            int int49 = unsupportedDateTimeField44.getMinimumValue((-10544400001L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1", "13", (-1), 4);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (-100));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        java.lang.String str2 = dateTimeFormatter0.print(readableInstant1);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime4 = dateTimeFormatter0.parseMutableDateTime("DateTimeField[dayOfMonth]");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[dayOfMonth]\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-163T05:30:45.419-07:00" + "'", str2.equals("2019-163T05:30:45.419-07:00"));
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundHalfEven((long) 2019);
        int int12 = skipUndoDateTimeField8.get((long) ' ');
        long long15 = skipUndoDateTimeField8.set((long) 30, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, (org.joda.time.ReadableInstant) mutableDateTime18);
        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField23 = property22.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology20, dateTimeField23, 0);
        long long27 = skipUndoDateTimeField25.roundHalfEven((long) 2019);
        int int29 = skipUndoDateTimeField25.get((long) ' ');
        int int31 = skipUndoDateTimeField25.getMinimumValue(28800100L);
        org.joda.time.MutableDateTime mutableDateTime33 = org.joda.time.MutableDateTime.now();
        int int34 = mutableDateTime33.getYearOfEra();
        org.joda.time.Chronology chronology36 = null;
        java.util.Locale locale37 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket39 = new org.joda.time.format.DateTimeParserBucket(100L, chronology36, locale37, (java.lang.Integer) 1);
        java.lang.Object obj40 = dateTimeParserBucket39.saveState();
        java.util.Locale locale41 = dateTimeParserBucket39.getLocale();
        java.util.Calendar calendar42 = mutableDateTime33.toCalendar(locale41);
        java.lang.String str43 = skipUndoDateTimeField25.getAsText(0, locale41);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter16.withLocale(locale41);
        int int45 = skipUndoDateTimeField8.getMaximumShortTextLength(locale41);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1814399970L) + "'", long15 == (-1814399970L));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28800000L + "'", long27 == 28800000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(locale41);
        org.junit.Assert.assertNotNull(calendar42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "0" + "'", str43.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2 + "'", int45 == 2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("2019-06-12T05:29:51.291-07:00");
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withWeekOfWeekyear(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 0, (java.lang.Number) (-5756400001L), (java.lang.Number) 62135568000001L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        int int43 = dividedDateTimeField42.getDivisor();
        int int46 = dividedDateTimeField42.getDifference((long) (-100), (long) 0);
        java.util.Locale locale48 = null;
        java.lang.String str49 = dividedDateTimeField42.getAsText((long) (short) 1, locale48);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.MutableDateTime mutableDateTime51 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property52 = mutableDateTime51.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50, (org.joda.time.ReadableInstant) mutableDateTime51);
        org.joda.time.MutableDateTime mutableDateTime54 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property55 = mutableDateTime54.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField56 = property55.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField58 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology53, dateTimeField56, 0);
        org.joda.time.ReadablePartial readablePartial59 = null;
        int int60 = skipUndoDateTimeField58.getMinimumValue(readablePartial59);
        long long62 = skipUndoDateTimeField58.roundHalfFloor((long) (short) -1);
        java.util.Locale locale64 = null;
        java.lang.String str65 = skipUndoDateTimeField58.getAsText((int) (short) 1, locale64);
        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime((long) 1, dateTimeZone68);
        org.joda.time.DateTime dateTime71 = dateTime69.withMonthOfYear(1);
        org.joda.time.DateTime dateTime73 = dateTime71.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate74 = dateTime71.toLocalDate();
        long long76 = gJChronology66.set((org.joda.time.ReadablePartial) localDate74, (long) (short) 1);
        java.util.Locale locale77 = null;
        java.lang.String str78 = skipUndoDateTimeField58.getAsShortText((org.joda.time.ReadablePartial) localDate74, locale77);
        int int79 = dividedDateTimeField42.getMinimumValue((org.joda.time.ReadablePartial) localDate74);
        boolean boolean80 = dividedDateTimeField42.isLenient();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2" + "'", str49.equals("2"));
        org.junit.Assert.assertNotNull(mutableDateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(gJChronology53);
        org.junit.Assert.assertNotNull(mutableDateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 28800000L + "'", long62 == 28800000L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "1" + "'", str65.equals("1"));
        org.junit.Assert.assertNotNull(gJChronology66);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(localDate74);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-28857599999L) + "'", long76 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "31" + "'", str78.equals("31"));
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfEra(1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMonths(10);
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        org.joda.time.MutableDateTime mutableDateTime14 = property11.addWrapField((int) 'a');
        int int15 = mutableDateTime14.getRoundingMode();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime14);
        boolean boolean17 = dateTime5.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = property19.getField();
        mutableDateTime14.setRounding(dateTimeField20);
        try {
            mutableDateTime14.setDateTime(30, 5, (int) (byte) -1, 2000, 32, 59, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getYearOfEra();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.yearOfEra();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = dateTime9.withZone(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        java.lang.String str17 = dateTimeZone15.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(0L, dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime9.toMutableDateTime(dateTimeZone15);
        try {
            org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime(2, (int) (byte) 100, 100, (int) (short) 100, 32, 4664, 1, dateTimeZone15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "America/Los_Angeles" + "'", str17.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(mutableDateTime20);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        java.lang.String str43 = dividedDateTimeField42.toString();
        long long45 = dividedDateTimeField42.roundHalfFloor((long) 1970);
        long long48 = dividedDateTimeField42.addWrapField((long) (short) -1, (-4663));
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str43.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 374400000L + "'", long45 == 374400000L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-1036800001L) + "'", long48 == (-1036800001L));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property8 = dateTime4.era();
        org.joda.time.DateTime dateTime10 = dateTime4.minusMinutes(1);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) mutableDateTime12);
        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField17 = property16.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField17, 0);
        org.joda.time.ReadablePartial readablePartial20 = null;
        int int21 = skipUndoDateTimeField19.getMinimumValue(readablePartial20);
        long long23 = skipUndoDateTimeField19.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 1, dateTimeZone25);
        org.joda.time.DateTime dateTime28 = dateTime26.withMonthOfYear(1);
        org.joda.time.DateTime dateTime30 = dateTime28.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate31 = dateTime28.toLocalDate();
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipUndoDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate31, (int) (byte) 0, locale33);
        long long36 = skipUndoDateTimeField19.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField19.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, "31");
        org.joda.time.DateTime dateTime41 = dateTime10.withField(dateTimeFieldType37, 2);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 28800000L + "'", long23 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(dateTime41);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 3395, chronology1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology3.getZone();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 100);
        long long9 = dateTimeParserBucket7.computeMillis(true);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560367785128L + "'", long9 == 1560367785128L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 1);
        int int5 = dateTimeParserBucket4.getOffset();
        org.joda.time.Chronology chronology6 = dateTimeParserBucket4.getChronology();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (byte) -1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("0");
        long long4 = dateTimeFormatter0.parseMillis("-2");
        boolean boolean5 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62230291200000L) + "'", long4 == (-62230291200000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        org.joda.time.DurationField durationField45 = unsupportedDateTimeField44.getLeapDurationField();
        try {
            long long48 = unsupportedDateTimeField44.set((long) (byte) 100, "");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertNull(durationField45);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 12, (int) (short) 1);
        long long10 = dateTimeParserBucket7.computeMillis(false, "");
        java.util.Locale locale11 = dateTimeParserBucket7.getLocale();
        try {
            java.lang.String str12 = org.joda.time.format.DateTimeFormat.patternForStyle("32", locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertNotNull(locale11);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        java.lang.String str4 = dateTimeZone2.getName(10L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        long long7 = cachedDateTimeZone5.nextTransition((-1L));
//        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone5.getUncachedZone();
//        org.joda.time.DateTimeZone dateTimeZone9 = cachedDateTimeZone5.getUncachedZone();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.months();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime3);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = property7.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField8, 0);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int int12 = skipUndoDateTimeField10.getMinimumValue(readablePartial11);
        long long14 = skipUndoDateTimeField10.roundHalfFloor((long) (short) -1);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField10.getAsText((int) (short) 1, locale16);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 1, dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.withMonthOfYear(1);
        org.joda.time.DateTime dateTime25 = dateTime23.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
        long long28 = gJChronology18.set((org.joda.time.ReadablePartial) localDate26, (long) (short) 1);
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipUndoDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate26, locale29);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.MutableDateTime mutableDateTime33 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime33.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, (org.joda.time.ReadableInstant) mutableDateTime33);
        java.util.Locale locale36 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket38 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology35, locale36, (java.lang.Integer) 100);
        org.joda.time.DateTimeField dateTimeField39 = gJChronology35.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField40 = gJChronology35.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) 1, dateTimeZone43);
        org.joda.time.DateTime dateTime46 = dateTime44.withMonthOfYear(1);
        org.joda.time.DateTime dateTime48 = dateTime46.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate49 = dateTime46.toLocalDate();
        long long51 = gJChronology41.set((org.joda.time.ReadablePartial) localDate49, (long) (short) 1);
        int[] intArray53 = gJChronology35.get((org.joda.time.ReadablePartial) localDate49, (long) 100);
        gJChronology0.validate((org.joda.time.ReadablePartial) localDate26, intArray53);
        org.joda.time.Chronology chronology55 = gJChronology0.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800000L + "'", long14 == 28800000L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-28857599999L) + "'", long28 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31" + "'", str30.equals("31"));
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-28857599999L) + "'", long51 == (-28857599999L));
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(chronology55);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime2.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekOfWeekyear(31);
        org.joda.time.DateTime dateTime10 = dateTime6.minusDays(0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(dateTimeZone1);
        try {
            org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 4664);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 4664");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
        int int5 = mutableDateTime4.getRoundingMode();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.centuryOfEra();
        mutableDateTime4.add(0L);
        mutableDateTime4.addYears((int) (short) 10);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((-210866846400000L));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("JulianChronology[America/Los_Angeles]", "0");
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundHalfEven((long) 2019);
        int int12 = skipUndoDateTimeField8.get((long) ' ');
        int int14 = skipUndoDateTimeField8.getMinimumValue(28800100L);
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now();
        int int17 = mutableDateTime16.getYearOfEra();
        org.joda.time.Chronology chronology19 = null;
        java.util.Locale locale20 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket(100L, chronology19, locale20, (java.lang.Integer) 1);
        java.lang.Object obj23 = dateTimeParserBucket22.saveState();
        java.util.Locale locale24 = dateTimeParserBucket22.getLocale();
        java.util.Calendar calendar25 = mutableDateTime16.toCalendar(locale24);
        java.lang.String str26 = skipUndoDateTimeField8.getAsText(0, locale24);
        long long28 = skipUndoDateTimeField8.roundCeiling((long) 1969);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(locale24);
        org.junit.Assert.assertNotNull(calendar25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 28800000L + "'", long28 == 28800000L);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
//        java.lang.String str3 = property1.getName();
//        int int4 = property1.getMaximumValueOverall();
//        java.lang.String str5 = property1.getAsString();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfMonth" + "'", str3.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12" + "'", str5.equals("12"));
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        java.lang.String str16 = skipUndoDateTimeField11.toString();
        long long18 = skipUndoDateTimeField11.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField22, 59);
        try {
            long long27 = skipDateTimeField24.set((long) (short) 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [0,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str16.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = buddhistChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        java.lang.String str8 = dateTimeZone6.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(0L, dateTimeZone6);
        org.joda.time.Chronology chronology11 = buddhistChronology1.withZone(dateTimeZone6);
        boolean boolean13 = buddhistChronology1.equals((java.lang.Object) 1560342587094L);
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipUndoDateTimeField32.getMinimumValue(readablePartial33);
        long long36 = skipUndoDateTimeField32.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear(1);
        org.joda.time.DateTime dateTime43 = dateTime41.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime41.toLocalDate();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale46);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        long long58 = gJChronology48.set((org.joda.time.ReadablePartial) localDate56, (long) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate56, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipUndoDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType61);
        long long65 = zeroIsMaxDateTimeField62.getDifferenceAsLong(1560342585128L, (long) 0);
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.MutableDateTime mutableDateTime67 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property68 = mutableDateTime67.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone66, (org.joda.time.ReadableInstant) mutableDateTime67);
        org.joda.time.MutableDateTime mutableDateTime70 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property71 = mutableDateTime70.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField72 = property71.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField74 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology69, dateTimeField72, 0);
        org.joda.time.ReadablePartial readablePartial75 = null;
        int int76 = skipUndoDateTimeField74.getMinimumValue(readablePartial75);
        long long78 = skipUndoDateTimeField74.roundHalfFloor((long) (short) -1);
        long long81 = skipUndoDateTimeField74.add(1560342585128L, 1);
        org.joda.time.DateTimeZone dateTimeZone83 = null;
        org.joda.time.DateTime dateTime84 = new org.joda.time.DateTime((long) 1, dateTimeZone83);
        org.joda.time.DateTime dateTime86 = dateTime84.withMonthOfYear(1);
        org.joda.time.DateTime dateTime88 = dateTime86.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate89 = dateTime86.toLocalDate();
        java.util.Locale locale90 = null;
        java.lang.String str91 = skipUndoDateTimeField74.getAsText((org.joda.time.ReadablePartial) localDate89, locale90);
        int[] intArray96 = new int[] { '#', 1969, (short) -1, (byte) -1 };
        try {
            int int97 = zeroIsMaxDateTimeField62.getMaximumValue((org.joda.time.ReadablePartial) localDate89, intArray96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1968");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28857599999L) + "'", long58 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 18059L + "'", long65 == 18059L);
        org.junit.Assert.assertNotNull(mutableDateTime67);
        org.junit.Assert.assertNotNull(property68);
        org.junit.Assert.assertNotNull(gJChronology69);
        org.junit.Assert.assertNotNull(mutableDateTime70);
        org.junit.Assert.assertNotNull(property71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 28800000L + "'", long78 == 28800000L);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1560428985128L + "'", long81 == 1560428985128L);
        org.junit.Assert.assertNotNull(dateTime86);
        org.junit.Assert.assertNotNull(dateTime88);
        org.junit.Assert.assertNotNull(localDate89);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "31" + "'", str91.equals("31"));
        org.junit.Assert.assertNotNull(intArray96);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField8.getAsText((int) (short) 1, locale14);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 1, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withMonthOfYear(1);
        org.joda.time.DateTime dateTime23 = dateTime21.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
        long long26 = gJChronology16.set((org.joda.time.ReadablePartial) localDate24, (long) (short) 1);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) localDate24, locale27);
        org.joda.time.DurationField durationField29 = skipUndoDateTimeField8.getRangeDurationField();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28857599999L) + "'", long26 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "31" + "'", str28.equals("31"));
        org.junit.Assert.assertNotNull(durationField29);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime dateTime7 = dateTime4.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        int int9 = property8.get();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57599966 + "'", int9 == 57599966);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.secondOfMinute();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("AD", "12", (-100), 12);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(1560342585128L);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 1, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.withMonthOfYear(1);
        org.joda.time.DateTime dateTime13 = dateTime11.withDayOfYear((int) (byte) 1);
        try {
            org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime11, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 16");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-100) + "'", int6 == (-100));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        mutableDateTime0.setSecondOfDay((int) (byte) 1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("AD", "12", (-100), 12);
        org.joda.time.DateTime dateTime9 = mutableDateTime0.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime0.weekyear();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime0.yearOfCentury();
        org.joda.time.ReadableDuration readableDuration12 = null;
        mutableDateTime0.add(readableDuration12, 0);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.secondOfMinute();
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withEra(4664);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4664 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        mutableDateTime4.addMinutes((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        mutableDateTime4.setMillis((org.joda.time.ReadableInstant) mutableDateTime7);
        mutableDateTime4.setTime((long) 2019);
        int int11 = mutableDateTime4.getHourOfDay();
        boolean boolean13 = mutableDateTime4.isEqual(1L);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime4.dayOfMonth();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj6 = mutableDateTime5.clone();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 1, dateTimeZone8);
        int int10 = mutableDateTime5.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime12 = dateTime9.minusMinutes((int) ' ');
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime12.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime12.getZone();
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(30, 57600, 16, 0, 30, dateTimeZone14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("365");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"365\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        long long13 = skipUndoDateTimeField11.roundHalfEven((long) 2019);
        int int15 = skipUndoDateTimeField11.get((long) ' ');
        int int17 = skipUndoDateTimeField11.getMinimumValue(28800100L);
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
        int int20 = mutableDateTime19.getYearOfEra();
        org.joda.time.Chronology chronology22 = null;
        java.util.Locale locale23 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket(100L, chronology22, locale23, (java.lang.Integer) 1);
        java.lang.Object obj26 = dateTimeParserBucket25.saveState();
        java.util.Locale locale27 = dateTimeParserBucket25.getLocale();
        java.util.Calendar calendar28 = mutableDateTime19.toCalendar(locale27);
        java.lang.String str29 = skipUndoDateTimeField11.getAsText(0, locale27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter2.withLocale(locale27);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 16, chronology1, locale27);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800000L + "'", long13 == 28800000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertNotNull(calendar28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        java.lang.Object obj1 = mutableDateTime0.clone();
//        mutableDateTime0.setSecondOfDay((int) (byte) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology5 = gregorianChronology4.withUTC();
//        java.lang.String str6 = gregorianChronology4.toString();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime8);
//        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField13, 0);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        int int17 = skipUndoDateTimeField15.getMinimumValue(readablePartial16);
//        long long19 = skipUndoDateTimeField15.roundHalfFloor((long) (short) -1);
//        java.lang.String str20 = skipUndoDateTimeField15.toString();
//        long long22 = skipUndoDateTimeField15.roundHalfCeiling((long) 31);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField15, (int) (byte) -1);
//        long long26 = skipUndoDateTimeField15.roundFloor(100L);
//        long long28 = skipUndoDateTimeField15.roundHalfEven((-62230291200000L));
//        int int29 = mutableDateTime0.get((org.joda.time.DateTimeField) skipUndoDateTimeField15);
//        int int31 = skipUndoDateTimeField15.getLeapAmount((-28799900L));
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(obj1);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800000L + "'", long19 == 28800000L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str20.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28800000L + "'", long22 == 28800000L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-57600000L) + "'", long26 == (-57600000L));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62230262822000L) + "'", long28 == (-62230262822000L));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weekyears();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis((-4663), 1970, 3, 365, (-4663), 3395, (-2));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        mutableDateTime4.addMinutes((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        mutableDateTime4.setMillis((org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime7.millisOfSecond();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        java.lang.String str43 = dividedDateTimeField42.toString();
        long long45 = dividedDateTimeField42.roundHalfFloor((long) 1970);
        long long48 = dividedDateTimeField42.addWrapField((-28857599999L), (int) '4');
        try {
            long long51 = dividedDateTimeField42.set(12L, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for dayOfMonth must be in the range [0,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str43.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 374400000L + "'", long45 == 374400000L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-30931199999L) + "'", long48 == (-30931199999L));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMonthOfYear(1);
        org.joda.time.DateTime dateTime8 = dateTime6.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate9 = dateTime6.toLocalDate();
        int int10 = property1.compareTo((org.joda.time.ReadablePartial) localDate9);
        java.lang.String str11 = property1.toString();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[dayOfMonth]" + "'", str11.equals("Property[dayOfMonth]"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) ' ');
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime7.getZone();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.DateTime dateTime12 = dateTime7.withField(dateTimeFieldType10, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("10");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"10\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipUndoDateTimeField32.getMinimumValue(readablePartial33);
        long long36 = skipUndoDateTimeField32.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear(1);
        org.joda.time.DateTime dateTime43 = dateTime41.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime41.toLocalDate();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale46);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        long long58 = gJChronology48.set((org.joda.time.ReadablePartial) localDate56, (long) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate56, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipUndoDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType61);
        long long65 = zeroIsMaxDateTimeField62.getDifferenceAsLong(1560342585128L, (long) 0);
        int int67 = zeroIsMaxDateTimeField62.getMaximumValue((long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.MutableDateTime mutableDateTime69 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property70 = mutableDateTime69.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone68, (org.joda.time.ReadableInstant) mutableDateTime69);
        org.joda.time.MutableDateTime mutableDateTime72 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property73 = mutableDateTime72.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField74 = property73.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField76 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology71, dateTimeField74, 0);
        org.joda.time.ReadablePartial readablePartial77 = null;
        int int78 = skipUndoDateTimeField76.getMinimumValue(readablePartial77);
        long long80 = skipUndoDateTimeField76.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone82 = null;
        org.joda.time.DateTime dateTime83 = new org.joda.time.DateTime((long) 1, dateTimeZone82);
        org.joda.time.DateTime dateTime85 = dateTime83.withMonthOfYear(1);
        org.joda.time.DateTime dateTime87 = dateTime85.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate88 = dateTime85.toLocalDate();
        java.util.Locale locale90 = null;
        java.lang.String str91 = skipUndoDateTimeField76.getAsText((org.joda.time.ReadablePartial) localDate88, (int) (byte) 0, locale90);
        int[] intArray98 = new int[] { '4', 2, (byte) 1, 57600001, 9409, 57600 };
        int int99 = zeroIsMaxDateTimeField62.getMaximumValue((org.joda.time.ReadablePartial) localDate88, intArray98);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28857599999L) + "'", long58 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 18059L + "'", long65 == 18059L);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 32 + "'", int67 == 32);
        org.junit.Assert.assertNotNull(mutableDateTime69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertNotNull(mutableDateTime72);
        org.junit.Assert.assertNotNull(property73);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 28800000L + "'", long80 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime85);
        org.junit.Assert.assertNotNull(dateTime87);
        org.junit.Assert.assertNotNull(localDate88);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "0" + "'", str91.equals("0"));
        org.junit.Assert.assertNotNull(intArray98);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 30 + "'", int99 == 30);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundHalfEven((long) 2019);
        int int12 = skipUndoDateTimeField8.get((long) ' ');
        boolean boolean14 = skipUndoDateTimeField8.isLeap((long) 2019);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField8.getAsText(2000, locale16);
        long long20 = skipUndoDateTimeField8.add(1560342590826L, (-5756400001L));
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2000" + "'", str17.equals("2000"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-497351399740631174L) + "'", long20 == (-497351399740631174L));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 100);
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.millisOfSecond();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology4);
        try {
            long long17 = gJChronology4.getDateTimeMillis(0, (int) '4', 224, 0, (int) ' ', 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        java.lang.String str16 = skipUndoDateTimeField11.toString();
        long long18 = skipUndoDateTimeField11.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, (int) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj22 = mutableDateTime21.clone();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 1, dateTimeZone24);
        int int26 = mutableDateTime21.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay29 = dateTime28.toTimeOfDay();
        int int30 = skipUndoDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay29);
        org.joda.time.DurationField durationField31 = skipUndoDateTimeField11.getRangeDurationField();
        long long33 = skipUndoDateTimeField11.remainder((-1036800001L));
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeUtils.getZone(dateTimeZone34);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeUtils.getZone(dateTimeZone37);
        org.joda.time.DateTime dateTime39 = dateTime36.withZone(dateTimeZone37);
        org.joda.time.LocalTime localTime40 = dateTime39.toLocalTime();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone43);
        java.util.Locale locale45 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket48 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology44, locale45, (java.lang.Integer) 12, (int) (short) 1);
        long long51 = dateTimeParserBucket48.computeMillis(false, "");
        java.util.Locale locale52 = dateTimeParserBucket48.getLocale();
        java.text.DateFormatSymbols dateFormatSymbols53 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale52);
        java.lang.String str54 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localTime40, 19, locale52);
        long long57 = skipUndoDateTimeField11.set((long) 365, "12");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str16.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(timeOfDay29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 57599999L + "'", long33 == 57599999L);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localTime40);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 28800000L + "'", long51 == 28800000L);
        org.junit.Assert.assertNotNull(locale52);
        org.junit.Assert.assertNotNull(dateFormatSymbols53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "19" + "'", str54.equals("19"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-1641599635L) + "'", long57 == (-1641599635L));
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField7, 0);
//        long long11 = skipUndoDateTimeField9.roundHalfEven((long) 2019);
//        int int13 = skipUndoDateTimeField9.get((long) ' ');
//        boolean boolean15 = skipUndoDateTimeField9.isLeap((long) 2019);
//        int int16 = mutableDateTime0.get((org.joda.time.DateTimeField) skipUndoDateTimeField9);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipUndoDateTimeField9.getAsShortText(1560428985128L, locale18);
//        int int21 = skipUndoDateTimeField9.getMinimumValue((-210866760000000L));
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13" + "'", str19.equals("13"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.MutableDateTime mutableDateTime38 = dateTimeFormatter36.parseMutableDateTime("0");
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.MutableDateTime mutableDateTime40 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property41 = mutableDateTime40.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone39, (org.joda.time.ReadableInstant) mutableDateTime40);
        org.joda.time.MutableDateTime mutableDateTime43 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime43.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField45 = property44.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology42, dateTimeField45, 0);
        org.joda.time.ReadablePartial readablePartial48 = null;
        int int49 = skipUndoDateTimeField47.getMinimumValue(readablePartial48);
        long long51 = skipUndoDateTimeField47.roundHalfFloor((long) (short) -1);
        long long54 = skipUndoDateTimeField47.add(1560342585128L, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology57 = gregorianChronology56.withUTC();
        java.lang.String str58 = gregorianChronology56.toString();
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone60);
        java.util.Locale locale62 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket65 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology61, locale62, (java.lang.Integer) 12, (int) (short) 1);
        long long68 = dateTimeParserBucket65.computeMillis(false, "");
        java.util.Locale locale69 = dateTimeParserBucket65.getLocale();
        boolean boolean70 = gregorianChronology56.equals((java.lang.Object) locale69);
        java.lang.String str71 = skipUndoDateTimeField47.getAsShortText((-1L), locale69);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = dateTimeFormatter36.withLocale(locale69);
        java.lang.String str73 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, 12, locale69);
        java.text.DateFormatSymbols dateFormatSymbols74 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale69);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(mutableDateTime38);
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(mutableDateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 28800000L + "'", long51 == 28800000L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560428985128L + "'", long54 == 1560428985128L);
        org.junit.Assert.assertNotNull(gregorianChronology56);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "GregorianChronology[UTC]" + "'", str58.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 28800000L + "'", long68 == 28800000L);
        org.junit.Assert.assertNotNull(locale69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "31" + "'", str71.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFormatter72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "12" + "'", str73.equals("12"));
        org.junit.Assert.assertNotNull(dateFormatSymbols74);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property5 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime7 = dateTime4.minusWeeks(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = gregorianChronology1.withUTC();
        java.lang.String str3 = gregorianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gregorianChronology1, locale4);
        org.joda.time.DurationField durationField6 = gregorianChronology1.weekyears();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        java.lang.String str4 = dateTimeZone2.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        java.lang.String str6 = dateTimeZone2.getID();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 10, dateTimeZone2);
        try {
            org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (-28799900L), 224);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 224");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "America/Los_Angeles" + "'", str6.equals("America/Los_Angeles"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfEra(1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMonths(10);
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        org.joda.time.MutableDateTime mutableDateTime14 = property11.addWrapField((int) 'a');
        int int15 = mutableDateTime14.getRoundingMode();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime14);
        boolean boolean17 = dateTime5.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.dayOfMonth();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond((int) '#');
        int int9 = dateTime6.getEra();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
//        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
//        int int5 = mutableDateTime4.getRoundingMode();
//        org.joda.time.DateTimeZone dateTimeZone6 = mutableDateTime4.getZone();
//        long long7 = mutableDateTime4.getMillis();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560947449084L + "'", long7 == 1560947449084L);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 1, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear(1);
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
        long long10 = gJChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj12 = mutableDateTime11.clone();
        boolean boolean13 = gJChronology0.equals((java.lang.Object) mutableDateTime11);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime11.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-28857599999L) + "'", long10 == (-28857599999L));
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            long long8 = julianChronology0.getDateTimeMillis(0, 57600, 10, 0, (int) ' ', 5, (-4663));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -4663 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("1");
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfDay();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        boolean boolean3 = property1.isLeap();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime5 = property1.roundHalfEven();
        boolean boolean6 = mutableDateTime5.isBeforeNow();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        long long9 = gJChronology4.add((long) 59, 200001L, (int) '4');
        org.joda.time.DurationField durationField10 = gJChronology4.years();
        org.joda.time.DurationField durationField11 = gJChronology4.days();
        org.joda.time.DurationField durationField12 = gJChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology4.millisOfSecond();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10400111L + "'", long9 == 10400111L);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.months();
        long long4 = durationField1.subtract((long) 20, (long) 720);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1893455999980L) + "'", long4 == (-1893455999980L));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime2.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        java.lang.String str11 = dateTimeZone9.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        java.lang.String str13 = dateTimeZone9.getID();
        org.joda.time.DateTime dateTime14 = dateTime7.toDateTime(dateTimeZone9);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, readableInstant15);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gJChronology16);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        mutableDateTime4.addMinutes((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        mutableDateTime4.setMillis((org.joda.time.ReadableInstant) mutableDateTime7);
        mutableDateTime4.setTime((long) 2019);
        int int11 = mutableDateTime4.getHourOfDay();
        boolean boolean12 = mutableDateTime4.isEqualNow();
        mutableDateTime4.setWeekyear(30);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray27 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType26 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList28 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList28, dateTimeFieldTypeArray27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList28, true, false);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList28, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter1.parseMutableDateTime("0");
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone4);
        boolean boolean6 = dateTimeFormatter5.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("0");
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = dateTime6.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        java.lang.String str14 = dateTimeZone12.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(0L, dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime6.toMutableDateTime(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, dateTimeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "America/Los_Angeles" + "'", str14.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime.Property property6 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.withMinimumValue();
        int int8 = dateTime7.getYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1", "13", (-1), 4);
        int int6 = fixedDateTimeZone4.getOffset((long) 1);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(1L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
        int int5 = mutableDateTime4.getRoundingMode();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.centuryOfEra();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 1, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMillis((int) '#');
        org.joda.time.DateTime.Property property13 = dateTime12.era();
        org.joda.time.DateTime dateTime14 = property13.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
        java.lang.String str16 = dateTimeZone15.getID();
        mutableDateTime4.setZone(dateTimeZone15);
        mutableDateTime4.setMillisOfDay((int) '#');
        int int20 = mutableDateTime4.getRoundingMode();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "America/Los_Angeles" + "'", str16.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField7, 0);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = skipUndoDateTimeField9.getMinimumValue(readablePartial10);
        long long13 = skipUndoDateTimeField9.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 1, dateTimeZone15);
        org.joda.time.DateTime dateTime18 = dateTime16.withMonthOfYear(1);
        org.joda.time.DateTime dateTime20 = dateTime18.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate21 = dateTime18.toLocalDate();
        java.util.Locale locale23 = null;
        java.lang.String str24 = skipUndoDateTimeField9.getAsText((org.joda.time.ReadablePartial) localDate21, (int) (byte) 0, locale23);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 1, dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime28.withMonthOfYear(1);
        org.joda.time.DateTime dateTime32 = dateTime30.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate33 = dateTime30.toLocalDate();
        long long35 = gJChronology25.set((org.joda.time.ReadablePartial) localDate33, (long) (short) 1);
        java.util.Locale locale36 = null;
        java.lang.String str37 = skipUndoDateTimeField9.getAsText((org.joda.time.ReadablePartial) localDate33, locale36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipUndoDateTimeField9.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800000L + "'", long13 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-28857599999L) + "'", long35 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "31" + "'", str37.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property5 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime7 = dateTime4.withWeekyear((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(1969);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1969) + "'", int1 == (-1969));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        java.lang.String str43 = dividedDateTimeField42.toString();
        long long45 = dividedDateTimeField42.roundHalfFloor((long) 1970);
        long long48 = dividedDateTimeField42.addWrapField((-28857599999L), (int) '4');
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone51);
        java.util.Locale locale53 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology52, locale53, (java.lang.Integer) 12, (int) (short) 1);
        long long59 = dateTimeParserBucket56.computeMillis(false, "");
        java.util.Locale locale60 = dateTimeParserBucket56.getLocale();
        java.text.DateFormatSymbols dateFormatSymbols61 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale60);
        java.lang.String str62 = dividedDateTimeField42.getAsText(1L, locale60);
        long long65 = dividedDateTimeField42.add(100L, 19841);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str43.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 374400000L + "'", long45 == 374400000L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-30931199999L) + "'", long48 == (-30931199999L));
        org.junit.Assert.assertNotNull(gJChronology52);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 28800000L + "'", long59 == 28800000L);
        org.junit.Assert.assertNotNull(locale60);
        org.junit.Assert.assertNotNull(dateFormatSymbols61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2" + "'", str62.equals("2"));
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 20571148800100L + "'", long65 == 20571148800100L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 1, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear(1);
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
        long long10 = gJChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) (short) 1);
        boolean boolean11 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate8);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-28857599999L) + "'", long10 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.secondOfMinute();
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        int int8 = dateTime4.getYear();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 100);
        dateTimeParserBucket7.setOffset((java.lang.Integer) 2);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.DurationField durationField5 = gJChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = property7.getField();
        boolean boolean9 = property7.isLeap();
        org.joda.time.MutableDateTime mutableDateTime10 = property7.getMutableDateTime();
        boolean boolean11 = gJChronology3.equals((java.lang.Object) mutableDateTime10);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology3.centuryOfEra();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        mutableDateTime2.setDate((-10544400001L));
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(gJChronology6);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.String str2 = julianChronology0.toString();
        long long6 = julianChronology0.add((long) (byte) 0, 0L, (int) (byte) 0);
        org.joda.time.DurationField durationField7 = julianChronology0.seconds();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField10 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType8, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipUndoDateTimeField32.getMinimumValue(readablePartial33);
        long long36 = skipUndoDateTimeField32.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear(1);
        org.joda.time.DateTime dateTime43 = dateTime41.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime41.toLocalDate();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale46);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        long long58 = gJChronology48.set((org.joda.time.ReadablePartial) localDate56, (long) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate56, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipUndoDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType61);
        long long65 = zeroIsMaxDateTimeField62.getDifferenceAsLong(1560342585128L, (long) 0);
        long long68 = zeroIsMaxDateTimeField62.addWrapField(10400111L, (int) (short) 100);
        org.joda.time.DurationField durationField69 = zeroIsMaxDateTimeField62.getDurationField();
        int int71 = zeroIsMaxDateTimeField62.get(0L);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28857599999L) + "'", long58 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 18059L + "'", long65 == 18059L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-2063199889L) + "'", long68 == (-2063199889L));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 31 + "'", int71 == 31);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 1, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis((int) '#');
        org.joda.time.DateTime dateTime10 = dateTime6.minusSeconds((int) ' ');
        boolean boolean11 = mutableDateTime1.isBefore((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime1.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.secondOfMinute();
        mutableDateTime1.setChronology((org.joda.time.Chronology) gregorianChronology13);
        try {
            mutableDateTime1.setMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getYearOfEra();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
//        org.joda.time.MutableDateTime mutableDateTime6 = property3.addWrapField((int) 'a');
//        mutableDateTime0.setTime((org.joda.time.ReadableInstant) mutableDateTime6);
//        boolean boolean8 = mutableDateTime6.isAfterNow();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        long long10 = skipUndoDateTimeField8.roundHalfEven((long) 2019);
        int int12 = skipUndoDateTimeField8.get((long) ' ');
        boolean boolean14 = skipUndoDateTimeField8.isLeap((long) 2019);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField8.getAsText(2000, locale16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (org.joda.time.ReadableInstant) mutableDateTime19);
        org.joda.time.MutableDateTime mutableDateTime22 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime22.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology21, dateTimeField24, 0);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = skipUndoDateTimeField26.getMinimumValue(readablePartial27);
        long long30 = skipUndoDateTimeField26.roundHalfFloor((long) (short) -1);
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipUndoDateTimeField26.getAsText((int) (short) 1, locale32);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.MutableDateTime mutableDateTime36 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property37 = mutableDateTime36.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, (org.joda.time.ReadableInstant) mutableDateTime36);
        java.util.Locale locale39 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket41 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology38, locale39, (java.lang.Integer) 100);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology38.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField43 = gJChronology38.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 1, dateTimeZone46);
        org.joda.time.DateTime dateTime49 = dateTime47.withMonthOfYear(1);
        org.joda.time.DateTime dateTime51 = dateTime49.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate52 = dateTime49.toLocalDate();
        long long54 = gJChronology44.set((org.joda.time.ReadablePartial) localDate52, (long) (short) 1);
        int[] intArray56 = gJChronology38.get((org.joda.time.ReadablePartial) localDate52, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone59);
        java.util.Locale locale61 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket64 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology60, locale61, (java.lang.Integer) 12, (int) (short) 1);
        long long67 = dateTimeParserBucket64.computeMillis(false, "");
        java.util.Locale locale68 = dateTimeParserBucket64.getLocale();
        java.text.DateFormatSymbols dateFormatSymbols69 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale68);
        java.lang.String str70 = skipUndoDateTimeField26.getAsText((org.joda.time.ReadablePartial) localDate52, (int) ' ', locale68);
        int int71 = skipUndoDateTimeField8.getMaximumTextLength(locale68);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2000" + "'", str17.equals("2000"));
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28800000L + "'", long30 == 28800000L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
        org.junit.Assert.assertNotNull(mutableDateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-28857599999L) + "'", long54 == (-28857599999L));
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(gJChronology60);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 28800000L + "'", long67 == 28800000L);
        org.junit.Assert.assertNotNull(locale68);
        org.junit.Assert.assertNotNull(dateFormatSymbols69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "32" + "'", str70.equals("32"));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2 + "'", int71 == 2);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime2.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekOfWeekyear(31);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime11.withZone(dateTimeZone12);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime16 = dateTime6.withFields((org.joda.time.ReadablePartial) localTime15);
        org.joda.time.DateTime dateTime18 = dateTime6.minusMinutes(2000);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 1, dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.minusMillis((int) '#');
        org.joda.time.DateTime dateTime24 = dateTime23.toDateTimeISO();
        long long25 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime27 = dateTime23.withMillis((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology29 = gregorianChronology28.withUTC();
        java.lang.String str30 = gregorianChronology28.toString();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime32.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, (org.joda.time.ReadableInstant) mutableDateTime32);
        org.joda.time.MutableDateTime mutableDateTime35 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField37 = property36.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology34, dateTimeField37, 0);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = skipUndoDateTimeField39.getMinimumValue(readablePartial40);
        long long43 = skipUndoDateTimeField39.roundHalfFloor((long) (short) -1);
        java.lang.String str44 = skipUndoDateTimeField39.toString();
        long long46 = skipUndoDateTimeField39.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology28, (org.joda.time.DateTimeField) skipUndoDateTimeField39, (int) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime49 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj50 = mutableDateTime49.clone();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 1, dateTimeZone52);
        int int54 = mutableDateTime49.compareTo((org.joda.time.ReadableInstant) dateTime53);
        org.joda.time.DateTime dateTime56 = dateTime53.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay57 = dateTime56.toTimeOfDay();
        int int58 = skipUndoDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay57);
        org.joda.time.DateTime dateTime59 = dateTime27.withFields((org.joda.time.ReadablePartial) timeOfDay57);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        org.joda.time.DateTime dateTime61 = dateTime6.withFields((org.joda.time.ReadablePartial) localTime60);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-34L) + "'", long25 == (-34L));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "GregorianChronology[UTC]" + "'", str30.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 28800000L + "'", long43 == 28800000L);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str44.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 28800000L + "'", long46 == 28800000L);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(timeOfDay57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(dateTime61);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        java.lang.Object obj1 = mutableDateTime0.clone();
//        mutableDateTime0.setSecondOfDay((int) (byte) 1);
//        int int4 = mutableDateTime0.getSecondOfMinute();
//        mutableDateTime0.setMinuteOfDay((int) (byte) 100);
//        java.lang.String str7 = mutableDateTime0.toString();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(obj1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-12T01:40:01.310-07:00" + "'", str7.equals("2019-06-12T01:40:01.310-07:00"));
//    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        long long2 = mutableDateTime0.getMillis();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.hourOfDay();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560342653321L + "'", long2 == 1560342653321L);
//        org.junit.Assert.assertNotNull(property3);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.String str2 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        long long8 = dateTimeZone4.adjustOffset((long) 12, false);
        org.joda.time.Chronology chronology9 = julianChronology0.withZone(dateTimeZone4);
        try {
            long long17 = julianChronology0.getDateTimeMillis((int) (byte) 0, 59, 57599966, 100, (int) (byte) 1, 0, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipUndoDateTimeField8.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "");
        java.lang.String str29 = illegalFieldValueException28.toString();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for dayOfMonth is not supported" + "'", str29.equals("org.joda.time.IllegalFieldValueException: Value \"\" for dayOfMonth is not supported"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        java.lang.String str43 = dividedDateTimeField42.toString();
        int int45 = dividedDateTimeField42.get(62135568000001L);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str43.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2 + "'", int45 == 2);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        java.lang.String str4 = dateTimeZone2.getName(10L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        long long7 = cachedDateTimeZone5.nextTransition((-210861662400000L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-210861662400000L) + "'", long7 == (-210861662400000L));
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("AD", "12", (-100), 12);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        int int4 = mutableDateTime1.getWeekyear();
        try {
            mutableDateTime1.setDayOfWeek(720);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 720 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfMinute();
        org.joda.time.DateTime.Property property6 = dateTime4.secondOfMinute();
        java.lang.Object obj7 = null;
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime4, obj7);
        org.joda.time.DateTime dateTime10 = dateTime4.minus(57599999L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeField dateTimeField38 = skipUndoDateTimeField8.getWrappedField();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(dateTimeField38);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj2 = mutableDateTime1.clone();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 1, dateTimeZone4);
        int int6 = mutableDateTime1.compareTo((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property9 = dateTime5.era();
        org.joda.time.DateTime dateTime11 = dateTime5.minusMinutes(1);
        java.lang.String str12 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property13 = dateTime11.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Dec 31, 1969 3:59:00 PM" + "'", str12.equals("Dec 31, 1969 3:59:00 PM"));
        org.junit.Assert.assertNotNull(property13);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
//        boolean boolean3 = property1.isLeap();
//        org.joda.time.MutableDateTime mutableDateTime4 = property1.getMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime5 = property1.roundFloor();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        java.lang.String str7 = mutableDateTime5.toString(dateTimeFormatter6);
//        int int8 = mutableDateTime5.getRoundingMode();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-12T00:00:00-07:00" + "'", str7.equals("2019-06-12T00:00:00-07:00"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("160000.010-0800");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"160000.010-0800/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        boolean boolean45 = unsupportedDateTimeField44.isSupported();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) 1, dateTimeZone47);
        org.joda.time.DateTime dateTime50 = dateTime48.minusMillis((int) '#');
        org.joda.time.DateTime dateTime51 = dateTime50.toDateTimeISO();
        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime50);
        org.joda.time.DateTime dateTime54 = dateTime50.withMillis((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology56 = gregorianChronology55.withUTC();
        java.lang.String str57 = gregorianChronology55.toString();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.MutableDateTime mutableDateTime59 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property60 = mutableDateTime59.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone58, (org.joda.time.ReadableInstant) mutableDateTime59);
        org.joda.time.MutableDateTime mutableDateTime62 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property63 = mutableDateTime62.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField64 = property63.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField66 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology61, dateTimeField64, 0);
        org.joda.time.ReadablePartial readablePartial67 = null;
        int int68 = skipUndoDateTimeField66.getMinimumValue(readablePartial67);
        long long70 = skipUndoDateTimeField66.roundHalfFloor((long) (short) -1);
        java.lang.String str71 = skipUndoDateTimeField66.toString();
        long long73 = skipUndoDateTimeField66.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField75 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology55, (org.joda.time.DateTimeField) skipUndoDateTimeField66, (int) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime76 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj77 = mutableDateTime76.clone();
        org.joda.time.DateTimeZone dateTimeZone79 = null;
        org.joda.time.DateTime dateTime80 = new org.joda.time.DateTime((long) 1, dateTimeZone79);
        int int81 = mutableDateTime76.compareTo((org.joda.time.ReadableInstant) dateTime80);
        org.joda.time.DateTime dateTime83 = dateTime80.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay84 = dateTime83.toTimeOfDay();
        int int85 = skipUndoDateTimeField66.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay84);
        org.joda.time.DateTime dateTime86 = dateTime54.withFields((org.joda.time.ReadablePartial) timeOfDay84);
        org.joda.time.LocalTime localTime87 = dateTime86.toLocalTime();
        java.util.Locale locale88 = null;
        try {
            java.lang.String str89 = unsupportedDateTimeField44.getAsText((org.joda.time.ReadablePartial) localTime87, locale88);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-34L) + "'", long52 == (-34L));
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(chronology56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "GregorianChronology[UTC]" + "'", str57.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(mutableDateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 28800000L + "'", long70 == 28800000L);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str71.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 28800000L + "'", long73 == 28800000L);
        org.junit.Assert.assertNotNull(mutableDateTime76);
        org.junit.Assert.assertNotNull(obj77);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(timeOfDay84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertNotNull(dateTime86);
        org.junit.Assert.assertNotNull(localTime87);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.MutableDateTime mutableDateTime44 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime44.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone43, (org.joda.time.ReadableInstant) mutableDateTime44);
        org.joda.time.MutableDateTime mutableDateTime47 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime47.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField49 = property48.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology46, dateTimeField49, 0);
        org.joda.time.ReadablePartial readablePartial52 = null;
        int int53 = skipUndoDateTimeField51.getMinimumValue(readablePartial52);
        long long55 = skipUndoDateTimeField51.roundHalfFloor((long) (short) -1);
        java.util.Locale locale57 = null;
        java.lang.String str58 = skipUndoDateTimeField51.getAsText((int) (short) 1, locale57);
        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime((long) 1, dateTimeZone61);
        org.joda.time.DateTime dateTime64 = dateTime62.withMonthOfYear(1);
        org.joda.time.DateTime dateTime66 = dateTime64.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate67 = dateTime64.toLocalDate();
        long long69 = gJChronology59.set((org.joda.time.ReadablePartial) localDate67, (long) (short) 1);
        java.util.Locale locale70 = null;
        java.lang.String str71 = skipUndoDateTimeField51.getAsShortText((org.joda.time.ReadablePartial) localDate67, locale70);
        int int72 = dividedDateTimeField42.getMaximumValue((org.joda.time.ReadablePartial) localDate67);
        try {
            long long74 = dividedDateTimeField42.roundHalfFloor((long) 57600001);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(mutableDateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(mutableDateTime47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 28800000L + "'", long55 == 28800000L);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "1" + "'", str58.equals("1"));
        org.junit.Assert.assertNotNull(gJChronology59);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-28857599999L) + "'", long69 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "31" + "'", str71.equals("31"));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone1);
        java.util.TimeZone timeZone5 = dateTimeZone1.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfEra(1);
        boolean boolean8 = dateTime7.isEqualNow();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = buddhistChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime5);
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField10, 0);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = skipUndoDateTimeField12.getMinimumValue(readablePartial13);
        long long16 = skipUndoDateTimeField12.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 1, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withMonthOfYear(1);
        org.joda.time.DateTime dateTime23 = dateTime21.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate24, (int) (byte) 0, locale26);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) 1, dateTimeZone30);
        org.joda.time.DateTime dateTime33 = dateTime31.withMonthOfYear(1);
        org.joda.time.DateTime dateTime35 = dateTime33.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate36 = dateTime33.toLocalDate();
        long long38 = gJChronology28.set((org.joda.time.ReadablePartial) localDate36, (long) (short) 1);
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate36, locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipUndoDateTimeField12.getType();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.MutableDateTime mutableDateTime43 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime43.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone42, (org.joda.time.ReadableInstant) mutableDateTime43);
        org.joda.time.DateTimeField dateTimeField46 = gJChronology45.dayOfYear();
        org.joda.time.DurationField durationField47 = gJChronology45.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField48 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType41, durationField47);
        org.joda.time.DurationField durationField49 = unsupportedDateTimeField48.getRangeDurationField();
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField50 = new org.joda.time.field.SkipDateTimeField(chronology3, (org.joda.time.DateTimeField) unsupportedDateTimeField48);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-28857599999L) + "'", long38 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "31" + "'", str40.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(mutableDateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField48);
        org.junit.Assert.assertNull(durationField49);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weekyears();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(57600, (-100), 5, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis((int) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury((int) '4');
        org.joda.time.DateTime dateTime10 = dateTime6.plusDays(3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }
}

