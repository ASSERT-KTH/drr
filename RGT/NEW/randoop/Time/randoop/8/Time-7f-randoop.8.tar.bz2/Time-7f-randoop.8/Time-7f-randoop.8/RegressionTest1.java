import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField8.getAsText((int) (short) 1, locale14);
        int int17 = skipUndoDateTimeField8.get((long) 3);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        long long47 = unsupportedDateTimeField44.add(0L, (long) '4');
        java.lang.String str48 = unsupportedDateTimeField44.toString();
        try {
            long long50 = unsupportedDateTimeField44.roundFloor((-1893455999980L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 136681200000L + "'", long47 == 136681200000L);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "UnsupportedDateTimeField" + "'", str48.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        long long15 = skipUndoDateTimeField8.add(1560342585128L, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology18 = gregorianChronology17.withUTC();
        java.lang.String str19 = gregorianChronology17.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
        java.util.Locale locale23 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology22, locale23, (java.lang.Integer) 12, (int) (short) 1);
        long long29 = dateTimeParserBucket26.computeMillis(false, "");
        java.util.Locale locale30 = dateTimeParserBucket26.getLocale();
        boolean boolean31 = gregorianChronology17.equals((java.lang.Object) locale30);
        java.lang.String str32 = skipUndoDateTimeField8.getAsShortText((-1L), locale30);
        java.lang.String str33 = skipUndoDateTimeField8.getName();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560428985128L + "'", long15 == 1560428985128L);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "GregorianChronology[UTC]" + "'", str19.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 28800000L + "'", long29 == 28800000L);
        org.junit.Assert.assertNotNull(locale30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "31" + "'", str32.equals("31"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "dayOfMonth" + "'", str33.equals("dayOfMonth"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 7, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107L + "'", long2 == 107L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology3);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField16, 0);
        org.joda.time.ReadablePartial readablePartial19 = null;
        int int20 = skipUndoDateTimeField18.getMinimumValue(readablePartial19);
        long long22 = skipUndoDateTimeField18.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 1, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withMonthOfYear(1);
        org.joda.time.DateTime dateTime29 = dateTime27.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate30 = dateTime27.toLocalDate();
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipUndoDateTimeField18.getAsText((org.joda.time.ReadablePartial) localDate30, (int) (byte) 0, locale32);
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 1, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.withMonthOfYear(1);
        org.joda.time.DateTime dateTime41 = dateTime39.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate42 = dateTime39.toLocalDate();
        long long44 = gJChronology34.set((org.joda.time.ReadablePartial) localDate42, (long) (short) 1);
        java.util.Locale locale45 = null;
        java.lang.String str46 = skipUndoDateTimeField18.getAsText((org.joda.time.ReadablePartial) localDate42, locale45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipUndoDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType47, 12);
        int int50 = dividedDateTimeField49.getDivisor();
        int int53 = dividedDateTimeField49.getDifference((long) (-100), (long) 0);
        java.util.Locale locale55 = null;
        java.lang.String str56 = dividedDateTimeField49.getAsShortText((long) (-1), locale55);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField57 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, (org.joda.time.DateTimeField) dividedDateTimeField49);
        try {
            mutableDateTime4.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField57, 57599966);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 57599966");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28800000L + "'", long22 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "0" + "'", str33.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-28857599999L) + "'", long44 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "31" + "'", str46.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 12 + "'", int50 == 12);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2" + "'", str56.equals("2"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 1);
        org.joda.time.DateTimeField dateTimeField5 = null;
        dateTimeParserBucket4.saveField(dateTimeField5, (int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField14, 0);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = skipUndoDateTimeField16.getMinimumValue(readablePartial17);
        long long20 = skipUndoDateTimeField16.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 1, dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.withMonthOfYear(1);
        org.joda.time.DateTime dateTime27 = dateTime25.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate28 = dateTime25.toLocalDate();
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate28, (int) (byte) 0, locale30);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.MutableDateTime mutableDateTime33 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime33.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, (org.joda.time.ReadableInstant) mutableDateTime33);
        org.joda.time.MutableDateTime mutableDateTime36 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property37 = mutableDateTime36.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField38 = property37.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology35, dateTimeField38, 0);
        org.joda.time.ReadablePartial readablePartial41 = null;
        int int42 = skipUndoDateTimeField40.getMinimumValue(readablePartial41);
        long long44 = skipUndoDateTimeField40.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 1, dateTimeZone46);
        org.joda.time.DateTime dateTime49 = dateTime47.withMonthOfYear(1);
        org.joda.time.DateTime dateTime51 = dateTime49.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate52 = dateTime49.toLocalDate();
        java.util.Locale locale54 = null;
        java.lang.String str55 = skipUndoDateTimeField40.getAsText((org.joda.time.ReadablePartial) localDate52, (int) (byte) 0, locale54);
        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) 1, dateTimeZone58);
        org.joda.time.DateTime dateTime61 = dateTime59.withMonthOfYear(1);
        org.joda.time.DateTime dateTime63 = dateTime61.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate64 = dateTime61.toLocalDate();
        long long66 = gJChronology56.set((org.joda.time.ReadablePartial) localDate64, (long) (short) 1);
        java.util.Locale locale67 = null;
        java.lang.String str68 = skipUndoDateTimeField40.getAsText((org.joda.time.ReadablePartial) localDate64, locale67);
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = skipUndoDateTimeField40.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField70 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType69);
        dateTimeParserBucket4.saveField(dateTimeFieldType69, 57600001);
        org.joda.time.DateTimeZone dateTimeZone73 = null;
        org.joda.time.MutableDateTime mutableDateTime74 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property75 = mutableDateTime74.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology76 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone73, (org.joda.time.ReadableInstant) mutableDateTime74);
        org.joda.time.DateTimeField dateTimeField77 = gJChronology76.dayOfYear();
        org.joda.time.DurationField durationField78 = gJChronology76.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType69, durationField78);
        try {
            int int80 = unsupportedDateTimeField79.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28800000L + "'", long20 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(mutableDateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 28800000L + "'", long44 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0" + "'", str55.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology56);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-28857599999L) + "'", long66 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "31" + "'", str68.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertNotNull(mutableDateTime74);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertNotNull(gJChronology76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(1560342590826L, "AD");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        java.lang.String str4 = illegalInstantException2.toString();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 2019-06-12T12:29:50.826 (AD)" + "'", str4.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 2019-06-12T12:29:50.826 (AD)"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfMinute();
        org.joda.time.DateTime.Property property6 = dateTime4.secondOfMinute();
        java.lang.Object obj7 = null;
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime4, obj7);
        org.joda.time.DateTime dateTime10 = dateTime4.withYearOfCentury(16);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        mutableDateTime1.add(readableDuration2, 1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        mutableDateTime1.setZone(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        boolean boolean3 = property1.isLeap();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        boolean boolean8 = property6.isLeap();
        org.joda.time.MutableDateTime mutableDateTime9 = property6.getMutableDateTime();
        mutableDateTime4.setTime((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 1, dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.withMonthOfYear(1);
        org.joda.time.DateTime dateTime17 = dateTime15.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate18 = dateTime15.toLocalDate();
        org.joda.time.DateTime.Property property19 = dateTime15.millisOfDay();
        org.joda.time.DateTime dateTime20 = dateTime15.toDateTimeISO();
        mutableDateTime4.setTime((org.joda.time.ReadableInstant) dateTime20);
        int int22 = mutableDateTime4.getSecondOfDay();
        int int23 = mutableDateTime4.getWeekyear();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 57600 + "'", int22 == 57600);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMonthOfYear(1);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        int int11 = dateTime9.getEra();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipUndoDateTimeField32.getMinimumValue(readablePartial33);
        long long36 = skipUndoDateTimeField32.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear(1);
        org.joda.time.DateTime dateTime43 = dateTime41.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime41.toLocalDate();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale46);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        long long58 = gJChronology48.set((org.joda.time.ReadablePartial) localDate56, (long) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate56, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipUndoDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType61);
        long long65 = zeroIsMaxDateTimeField62.getDifferenceAsLong(1560342585128L, (long) 0);
        long long68 = zeroIsMaxDateTimeField62.addWrapField(10400111L, (int) (short) 100);
        org.joda.time.DurationField durationField69 = zeroIsMaxDateTimeField62.getDurationField();
        long long71 = zeroIsMaxDateTimeField62.roundCeiling((-210861677222000L));
        org.joda.time.DateTimeZone dateTimeZone73 = null;
        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime((long) 1, dateTimeZone73);
        org.joda.time.DateTime dateTime76 = dateTime74.withMonthOfYear(1);
        org.joda.time.DateTime dateTime78 = dateTime76.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate79 = dateTime76.toLocalDate();
        int int80 = zeroIsMaxDateTimeField62.getMinimumValue((org.joda.time.ReadablePartial) localDate79);
        int int82 = zeroIsMaxDateTimeField62.getMaximumValue((-57600000L));
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28857599999L) + "'", long58 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 18059L + "'", long65 == 18059L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-2063199889L) + "'", long68 == (-2063199889L));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-210861677222000L) + "'", long71 == (-210861677222000L));
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertNotNull(localDate79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 32 + "'", int82 == 32);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("(\"org.joda.time.JodaTimePermission\" \"-2\")");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: (\"org.joda.time.JodaTimePermission\" \"-2\")");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.DurationField durationField5 = gJChronology3.years();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.year();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField14, 0);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = skipUndoDateTimeField16.getMinimumValue(readablePartial17);
        long long20 = skipUndoDateTimeField16.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 1, dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.withMonthOfYear(1);
        org.joda.time.DateTime dateTime27 = dateTime25.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate28 = dateTime25.toLocalDate();
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate28, (int) (byte) 0, locale30);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.MutableDateTime mutableDateTime33 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime33.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, (org.joda.time.ReadableInstant) mutableDateTime33);
        org.joda.time.MutableDateTime mutableDateTime36 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property37 = mutableDateTime36.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField38 = property37.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology35, dateTimeField38, 0);
        org.joda.time.ReadablePartial readablePartial41 = null;
        int int42 = skipUndoDateTimeField40.getMinimumValue(readablePartial41);
        long long44 = skipUndoDateTimeField40.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 1, dateTimeZone46);
        org.joda.time.DateTime dateTime49 = dateTime47.withMonthOfYear(1);
        org.joda.time.DateTime dateTime51 = dateTime49.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate52 = dateTime49.toLocalDate();
        java.util.Locale locale54 = null;
        java.lang.String str55 = skipUndoDateTimeField40.getAsText((org.joda.time.ReadablePartial) localDate52, (int) (byte) 0, locale54);
        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) 1, dateTimeZone58);
        org.joda.time.DateTime dateTime61 = dateTime59.withMonthOfYear(1);
        org.joda.time.DateTime dateTime63 = dateTime61.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate64 = dateTime61.toLocalDate();
        long long66 = gJChronology56.set((org.joda.time.ReadablePartial) localDate64, (long) (short) 1);
        java.util.Locale locale67 = null;
        java.lang.String str68 = skipUndoDateTimeField40.getAsText((org.joda.time.ReadablePartial) localDate64, locale67);
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = skipUndoDateTimeField40.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField70 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType69);
        long long73 = zeroIsMaxDateTimeField70.getDifferenceAsLong(1560342585128L, (long) 0);
        long long76 = zeroIsMaxDateTimeField70.addWrapField(10400111L, (int) (short) 100);
        org.joda.time.DurationField durationField77 = zeroIsMaxDateTimeField70.getDurationField();
        long long79 = zeroIsMaxDateTimeField70.roundCeiling((-210861677222000L));
        org.joda.time.DateTimeZone dateTimeZone81 = null;
        org.joda.time.DateTime dateTime82 = new org.joda.time.DateTime((long) 1, dateTimeZone81);
        org.joda.time.DateTime dateTime84 = dateTime82.withMonthOfYear(1);
        org.joda.time.DateTime dateTime86 = dateTime84.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate87 = dateTime84.toLocalDate();
        int int88 = zeroIsMaxDateTimeField70.getMinimumValue((org.joda.time.ReadablePartial) localDate87);
        long long90 = gJChronology3.set((org.joda.time.ReadablePartial) localDate87, 10L);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28800000L + "'", long20 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(mutableDateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 28800000L + "'", long44 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0" + "'", str55.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology56);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-28857599999L) + "'", long66 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "31" + "'", str68.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 18059L + "'", long73 == 18059L);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-2063199889L) + "'", long76 == (-2063199889L));
        org.junit.Assert.assertNotNull(durationField77);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + (-210861677222000L) + "'", long79 == (-210861677222000L));
        org.junit.Assert.assertNotNull(dateTime84);
        org.junit.Assert.assertNotNull(dateTime86);
        org.junit.Assert.assertNotNull(localDate87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + (-27734399990L) + "'", long90 == (-27734399990L));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property8 = dateTime4.era();
        try {
            org.joda.time.DateTime dateTime12 = dateTime4.withDate((int) '#', 365, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
//        org.joda.time.MutableDateTime mutableDateTime6 = property3.addWrapField(100);
//        mutableDateTime6.addMinutes((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
//        mutableDateTime6.setMillis((org.joda.time.ReadableInstant) mutableDateTime9);
//        mutableDateTime6.setTime((long) 2019);
//        int int13 = mutableDateTime6.getHourOfDay();
//        mutableDateTime6.setYear((int) '#');
//        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimePrinter1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0035-06-12T00:00:02-07:52:58" + "'", str16.equals("0035-06-12T00:00:02-07:52:58"));
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfYear();
        org.joda.time.DurationField durationField12 = gJChronology10.months();
        java.util.Locale locale13 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology10, locale13, (java.lang.Integer) 3395, (int) ' ');
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(2019, 0, 59, (int) 'a', (-1), 720, (org.joda.time.Chronology) gJChronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime2.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekOfWeekyear(31);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime11.withZone(dateTimeZone12);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime16 = dateTime6.withFields((org.joda.time.ReadablePartial) localTime15);
        org.joda.time.DateTime dateTime18 = dateTime16.withCenturyOfEra(9409);
        org.joda.time.DateTime dateTime20 = dateTime16.withYear(32);
        org.joda.time.DateTime.Property property21 = dateTime16.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
        mutableDateTime4.addMinutes((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        mutableDateTime4.setMillis((org.joda.time.ReadableInstant) mutableDateTime7);
        mutableDateTime4.setTime((long) 2019);
        int int11 = mutableDateTime4.getHourOfDay();
        org.joda.time.Chronology chronology12 = mutableDateTime4.getChronology();
        mutableDateTime4.setMillis((-28857599999L));
        mutableDateTime4.setMillisOfSecond(0);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate7 = dateTime4.toLocalDate();
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        org.joda.time.DateTime dateTime10 = dateTime4.withYearOfCentury((int) 'a');
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfCentury();
        org.joda.time.DurationField durationField12 = property11.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        long long47 = unsupportedDateTimeField44.add(0L, (long) '4');
        try {
            int int49 = unsupportedDateTimeField44.getLeapAmount(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 136681200000L + "'", long47 == 136681200000L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.secondOfMinute();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.millisOfSecond();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (-1));
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withDurationAdded(readableDuration2, (int) (byte) 0);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.String str2 = julianChronology0.toString();
        boolean boolean4 = julianChronology0.equals((java.lang.Object) "10");
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = julianChronology0.get(readablePeriod5, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = property5.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.plusWeeks((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime6.withYearOfCentury(0);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField12 = gJChronology11.months();
        long long16 = gJChronology11.add((long) 1, (long) (byte) 100, 2000);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology11.yearOfEra();
        org.joda.time.DateTime dateTime18 = dateTime6.withChronology((org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateMidnight dateMidnight19 = dateTime18.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200001L + "'", long16 == 200001L);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateMidnight19);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        long long44 = dividedDateTimeField42.roundHalfFloor((long) '#');
        org.joda.time.DurationField durationField45 = dividedDateTimeField42.getDurationField();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 374400000L + "'", long44 == 374400000L);
        org.junit.Assert.assertNotNull(durationField45);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        java.lang.String str45 = unsupportedDateTimeField44.getName();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.MutableDateTime mutableDateTime47 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime47.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (org.joda.time.ReadableInstant) mutableDateTime47);
        org.joda.time.MutableDateTime mutableDateTime50 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property51 = mutableDateTime50.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField52 = property51.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField54 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology49, dateTimeField52, 0);
        org.joda.time.ReadablePartial readablePartial55 = null;
        int int56 = skipUndoDateTimeField54.getMinimumValue(readablePartial55);
        long long58 = skipUndoDateTimeField54.roundHalfFloor((long) (short) -1);
        java.util.Locale locale60 = null;
        java.lang.String str61 = skipUndoDateTimeField54.getAsText((int) (short) 1, locale60);
        org.joda.time.chrono.GJChronology gJChronology62 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime((long) 1, dateTimeZone64);
        org.joda.time.DateTime dateTime67 = dateTime65.withMonthOfYear(1);
        org.joda.time.DateTime dateTime69 = dateTime67.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate70 = dateTime67.toLocalDate();
        long long72 = gJChronology62.set((org.joda.time.ReadablePartial) localDate70, (long) (short) 1);
        java.util.Locale locale73 = null;
        java.lang.String str74 = skipUndoDateTimeField54.getAsShortText((org.joda.time.ReadablePartial) localDate70, locale73);
        try {
            int int75 = unsupportedDateTimeField44.getMaximumValue((org.joda.time.ReadablePartial) localDate70);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfMonth" + "'", str45.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(mutableDateTime47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(gJChronology49);
        org.junit.Assert.assertNotNull(mutableDateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 28800000L + "'", long58 == 28800000L);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "1" + "'", str61.equals("1"));
        org.junit.Assert.assertNotNull(gJChronology62);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(localDate70);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-28857599999L) + "'", long72 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "31" + "'", str74.equals("31"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("org.joda.time.IllegalFieldValueException: Value \"31\" for dayOfMonth is not supported", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"org.joda.time.IllegalFieldValueException: Value \"31\" for dayOfMonth is not supported/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-2");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("GregorianChronology[UTC]");
        boolean boolean5 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"-2\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"-2\")"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate7 = dateTime4.toLocalDate();
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        java.lang.String str9 = property8.getAsShortText();
        org.joda.time.DateTime dateTime10 = property8.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime11 = property8.roundFloorCopy();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        org.joda.time.DateMidnight dateMidnight14 = dateTime13.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "57600001" + "'", str9.equals("57600001"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateMidnight14);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        org.joda.time.Chronology chronology6 = gJChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.millisOfDay();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime.Property property5 = dateTime2.dayOfWeek();
        org.joda.time.DateTime dateTime7 = dateTime2.withDayOfYear(1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        int int8 = dateTimeZone6.getOffsetFromLocal((-34L));
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((-100), 57599966, 0, 2019, 57599966, 4664, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        long long9 = gJChronology4.add((long) 59, 200001L, (int) '4');
        org.joda.time.DurationField durationField10 = gJChronology4.hours();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10400111L + "'", long9 == 10400111L);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        int int4 = mutableDateTime1.getWeekyear();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime1.dayOfYear();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime5 = property1.roundCeiling();
        int int6 = mutableDateTime5.getMillisOfDay();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 1, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.withMonthOfYear(1);
        org.joda.time.DateTime dateTime14 = dateTime12.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate15 = dateTime12.toLocalDate();
        org.joda.time.DateTime.Property property16 = dateTime12.millisOfDay();
        org.joda.time.DateTime dateTime18 = dateTime12.withYearOfCentury((int) 'a');
        int int19 = dateTime12.getYear();
        org.joda.time.DateTime.Property property20 = dateTime12.hourOfDay();
        boolean boolean21 = mutableDateTime5.isEqual((org.joda.time.ReadableInstant) dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField8.getAsText((int) (short) 1, locale14);
        long long17 = skipUndoDateTimeField8.roundFloor(62135568000001L);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 62135539200000L + "'", long17 == 62135539200000L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("2", "hi!", 0, (-100));
        java.util.TimeZone timeZone11 = fixedDateTimeZone10.toTimeZone();
        long long13 = fixedDateTimeZone10.previousTransition(1560342618736L);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((-28800000), 16, 3395, 2, 3, 100, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560342618736L + "'", long13 == 1560342618736L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        int int47 = unsupportedDateTimeField44.getDifference(2000L, (long) (byte) 10);
        try {
            int int48 = unsupportedDateTimeField44.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime3);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfEra(1);
        org.joda.time.DateTime dateTime10 = dateTime6.plusMonths(10);
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
        org.joda.time.MutableDateTime mutableDateTime15 = property12.addWrapField((int) 'a');
        int int16 = mutableDateTime15.getRoundingMode();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime15);
        boolean boolean18 = dateTime6.isEqual((org.joda.time.ReadableInstant) mutableDateTime15);
        try {
            java.lang.String str19 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.secondOfMinute();
        org.joda.time.DateTime dateTime8 = property7.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        int int43 = dividedDateTimeField42.getDivisor();
        int int46 = dividedDateTimeField42.getDifference((long) (-100), (long) 0);
        java.util.Locale locale48 = null;
        java.lang.String str49 = dividedDateTimeField42.getAsText((long) (short) 1, locale48);
        long long51 = dividedDateTimeField42.roundFloor((long) 7);
        long long53 = dividedDateTimeField42.roundCeiling((long) 1969);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2" + "'", str49.equals("2"));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-662400000L) + "'", long51 == (-662400000L));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 374400000L + "'", long53 == 374400000L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = property2.getField();
        org.joda.time.MutableDateTime mutableDateTime5 = property2.addWrapField(100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = property7.getField();
        org.joda.time.MutableDateTime mutableDateTime10 = property7.addWrapField((int) 'a');
        int int11 = property2.compareTo((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) mutableDateTime13);
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = property17.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField18, 0);
        long long22 = skipUndoDateTimeField20.roundHalfEven((long) 2019);
        int int24 = skipUndoDateTimeField20.get((long) ' ');
        int int26 = skipUndoDateTimeField20.getMinimumValue(28800100L);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        int int29 = mutableDateTime28.getYearOfEra();
        org.joda.time.Chronology chronology31 = null;
        java.util.Locale locale32 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket34 = new org.joda.time.format.DateTimeParserBucket(100L, chronology31, locale32, (java.lang.Integer) 1);
        java.lang.Object obj35 = dateTimeParserBucket34.saveState();
        java.util.Locale locale36 = dateTimeParserBucket34.getLocale();
        java.util.Calendar calendar37 = mutableDateTime28.toCalendar(locale36);
        java.lang.String str38 = skipUndoDateTimeField20.getAsText(0, locale36);
        java.util.Calendar calendar39 = mutableDateTime10.toCalendar(locale36);
        java.lang.String str42 = defaultNameProvider0.getShortName(locale36, "PST", "32");
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28800000L + "'", long22 == 28800000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 31 + "'", int24 == 31);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(locale36);
        org.junit.Assert.assertNotNull(calendar37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
        org.junit.Assert.assertNotNull(calendar39);
        org.junit.Assert.assertNull(str42);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.DateTime dateTime41 = dateTimeFormatter39.parseDateTime("2019-06-12T05:29:51.291-07:00");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.MutableDateTime mutableDateTime44 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime44.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone43, (org.joda.time.ReadableInstant) mutableDateTime44);
        org.joda.time.MutableDateTime mutableDateTime47 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime47.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField49 = property48.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology46, dateTimeField49, 0);
        long long53 = skipUndoDateTimeField51.roundHalfEven((long) 2019);
        int int55 = skipUndoDateTimeField51.get((long) ' ');
        int int57 = skipUndoDateTimeField51.getMinimumValue(28800100L);
        org.joda.time.MutableDateTime mutableDateTime59 = org.joda.time.MutableDateTime.now();
        int int60 = mutableDateTime59.getYearOfEra();
        org.joda.time.Chronology chronology62 = null;
        java.util.Locale locale63 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket65 = new org.joda.time.format.DateTimeParserBucket(100L, chronology62, locale63, (java.lang.Integer) 1);
        java.lang.Object obj66 = dateTimeParserBucket65.saveState();
        java.util.Locale locale67 = dateTimeParserBucket65.getLocale();
        java.util.Calendar calendar68 = mutableDateTime59.toCalendar(locale67);
        java.lang.String str69 = skipUndoDateTimeField51.getAsText(0, locale67);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = dateTimeFormatter42.withLocale(locale67);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter71 = dateTimeFormatter39.withLocale(locale67);
        java.lang.String str72 = skipUndoDateTimeField8.getAsText(0, locale67);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(mutableDateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(mutableDateTime47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 28800000L + "'", long53 == 28800000L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 31 + "'", int55 == 31);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(obj66);
        org.junit.Assert.assertNotNull(locale67);
        org.junit.Assert.assertNotNull(calendar68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "0" + "'", str69.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertNotNull(dateTimeFormatter71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "0" + "'", str72.equals("0"));
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        java.lang.Object obj1 = mutableDateTime0.clone();
//        mutableDateTime0.setSecondOfDay((int) (byte) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology5 = gregorianChronology4.withUTC();
//        java.lang.String str6 = gregorianChronology4.toString();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime8);
//        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField13, 0);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        int int17 = skipUndoDateTimeField15.getMinimumValue(readablePartial16);
//        long long19 = skipUndoDateTimeField15.roundHalfFloor((long) (short) -1);
//        java.lang.String str20 = skipUndoDateTimeField15.toString();
//        long long22 = skipUndoDateTimeField15.roundHalfCeiling((long) 31);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField15, (int) (byte) -1);
//        long long26 = skipUndoDateTimeField15.roundFloor(100L);
//        long long28 = skipUndoDateTimeField15.roundHalfEven((-62230291200000L));
//        int int29 = mutableDateTime0.get((org.joda.time.DateTimeField) skipUndoDateTimeField15);
//        int int30 = skipUndoDateTimeField15.getMinimumValue();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(obj1);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800000L + "'", long19 == 28800000L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str20.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28800000L + "'", long22 == 28800000L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-57600000L) + "'", long26 == (-57600000L));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62230262822000L) + "'", long28 == (-62230262822000L));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("0");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        long long18 = skipUndoDateTimeField11.add(1560342585128L, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology21 = gregorianChronology20.withUTC();
        java.lang.String str22 = gregorianChronology20.toString();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
        java.util.Locale locale26 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology25, locale26, (java.lang.Integer) 12, (int) (short) 1);
        long long32 = dateTimeParserBucket29.computeMillis(false, "");
        java.util.Locale locale33 = dateTimeParserBucket29.getLocale();
        boolean boolean34 = gregorianChronology20.equals((java.lang.Object) locale33);
        java.lang.String str35 = skipUndoDateTimeField11.getAsShortText((-1L), locale33);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter0.withLocale(locale33);
        java.text.DateFormatSymbols dateFormatSymbols37 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale33);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560428985128L + "'", long18 == 1560428985128L);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GregorianChronology[UTC]" + "'", str22.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 28800000L + "'", long32 == 28800000L);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "31" + "'", str35.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateFormatSymbols37);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DurationField durationField6 = property5.getDurationField();
        org.joda.time.DateTimeField dateTimeField7 = property5.getField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone1);
        boolean boolean6 = dateTime4.isEqual((long) 31);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 2019-06-12T12:29:50.826 (AD)");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalInstantExce...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        java.lang.String str16 = skipUndoDateTimeField11.toString();
        long long18 = skipUndoDateTimeField11.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, (int) (byte) -1);
        long long22 = skipUndoDateTimeField11.roundFloor(100L);
        long long24 = skipUndoDateTimeField11.remainder((long) 9409);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str16.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-57600000L) + "'", long22 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 57609409L + "'", long24 == 57609409L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property8 = dateTime4.era();
        org.joda.time.DateTime dateTime10 = dateTime4.minusMinutes(1);
        org.joda.time.DateTime.Property property11 = dateTime10.minuteOfHour();
        org.joda.time.DateTime.Property property12 = dateTime10.year();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfYear();
        org.joda.time.DurationField durationField13 = gJChronology11.months();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
        boolean boolean17 = property15.isLeap();
        org.joda.time.MutableDateTime mutableDateTime18 = property15.getMutableDateTime();
        boolean boolean19 = gJChronology11.equals((java.lang.Object) mutableDateTime18);
        mutableDateTime2.setChronology((org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 1, dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.minusMillis((int) '#');
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        long long27 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime29 = dateTime25.withMillis((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology31 = gregorianChronology30.withUTC();
        java.lang.String str32 = gregorianChronology30.toString();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.MutableDateTime mutableDateTime34 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, (org.joda.time.ReadableInstant) mutableDateTime34);
        org.joda.time.MutableDateTime mutableDateTime37 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property38 = mutableDateTime37.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField39 = property38.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology36, dateTimeField39, 0);
        org.joda.time.ReadablePartial readablePartial42 = null;
        int int43 = skipUndoDateTimeField41.getMinimumValue(readablePartial42);
        long long45 = skipUndoDateTimeField41.roundHalfFloor((long) (short) -1);
        java.lang.String str46 = skipUndoDateTimeField41.toString();
        long long48 = skipUndoDateTimeField41.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField50 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology30, (org.joda.time.DateTimeField) skipUndoDateTimeField41, (int) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime51 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj52 = mutableDateTime51.clone();
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((long) 1, dateTimeZone54);
        int int56 = mutableDateTime51.compareTo((org.joda.time.ReadableInstant) dateTime55);
        org.joda.time.DateTime dateTime58 = dateTime55.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay59 = dateTime58.toTimeOfDay();
        int int60 = skipUndoDateTimeField41.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay59);
        org.joda.time.DateTime dateTime61 = dateTime29.withFields((org.joda.time.ReadablePartial) timeOfDay59);
        org.joda.time.DateTime dateTime62 = dateTime29.toDateTimeISO();
        boolean boolean63 = mutableDateTime2.isEqual((org.joda.time.ReadableInstant) dateTime29);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-34L) + "'", long27 == (-34L));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "GregorianChronology[UTC]" + "'", str32.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 28800000L + "'", long45 == 28800000L);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str46.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 28800000L + "'", long48 == 28800000L);
        org.junit.Assert.assertNotNull(mutableDateTime51);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(timeOfDay59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipUndoDateTimeField32.getMinimumValue(readablePartial33);
        long long36 = skipUndoDateTimeField32.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear(1);
        org.joda.time.DateTime dateTime43 = dateTime41.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime41.toLocalDate();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale46);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        long long58 = gJChronology48.set((org.joda.time.ReadablePartial) localDate56, (long) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate56, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipUndoDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType61);
        long long65 = zeroIsMaxDateTimeField62.getDifferenceAsLong(1560342585128L, (long) 0);
        long long68 = zeroIsMaxDateTimeField62.addWrapField(10400111L, (int) (short) 100);
        org.joda.time.DurationField durationField69 = zeroIsMaxDateTimeField62.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime((long) 1, dateTimeZone71);
        org.joda.time.DateTime dateTime74 = dateTime72.withMonthOfYear(1);
        org.joda.time.DateTime dateTime76 = dateTime74.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate77 = dateTime74.toLocalDate();
        int[] intArray84 = new int[] { 31, 57600001, (byte) 100, 32, 12, 30 };
        int int85 = zeroIsMaxDateTimeField62.getMinimumValue((org.joda.time.ReadablePartial) localDate77, intArray84);
        boolean boolean86 = zeroIsMaxDateTimeField62.isLenient();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28857599999L) + "'", long58 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 18059L + "'", long65 == 18059L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-2063199889L) + "'", long68 == (-2063199889L));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertNotNull(localDate77);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        java.io.Writer writer3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime5);
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField10, 0);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = skipUndoDateTimeField12.getMinimumValue(readablePartial13);
        long long16 = skipUndoDateTimeField12.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 1, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withMonthOfYear(1);
        org.joda.time.DateTime dateTime23 = dateTime21.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate24, (int) (byte) 0, locale26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.MutableDateTime mutableDateTime29 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, (org.joda.time.ReadableInstant) mutableDateTime29);
        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime32.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField34 = property33.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology31, dateTimeField34, 0);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int int38 = skipUndoDateTimeField36.getMinimumValue(readablePartial37);
        long long40 = skipUndoDateTimeField36.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) 1, dateTimeZone42);
        org.joda.time.DateTime dateTime45 = dateTime43.withMonthOfYear(1);
        org.joda.time.DateTime dateTime47 = dateTime45.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate48 = dateTime45.toLocalDate();
        java.util.Locale locale50 = null;
        java.lang.String str51 = skipUndoDateTimeField36.getAsText((org.joda.time.ReadablePartial) localDate48, (int) (byte) 0, locale50);
        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((long) 1, dateTimeZone54);
        org.joda.time.DateTime dateTime57 = dateTime55.withMonthOfYear(1);
        org.joda.time.DateTime dateTime59 = dateTime57.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate60 = dateTime57.toLocalDate();
        long long62 = gJChronology52.set((org.joda.time.ReadablePartial) localDate60, (long) (short) 1);
        java.util.Locale locale63 = null;
        java.lang.String str64 = skipUndoDateTimeField36.getAsText((org.joda.time.ReadablePartial) localDate60, locale63);
        java.util.Locale locale65 = null;
        java.lang.String str66 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate60, locale65);
        try {
            dateTimeFormatter2.printTo(writer3, (org.joda.time.ReadablePartial) localDate60);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 28800000L + "'", long40 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "0" + "'", str51.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology52);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localDate60);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-28857599999L) + "'", long62 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "31" + "'", str64.equals("31"));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "31" + "'", str66.equals("31"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getYearOfEra();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.MutableDateTime mutableDateTime6 = property3.addWrapField((int) 'a');
        mutableDateTime0.setTime((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime0.add((long) 19);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("0");
        boolean boolean2 = dateTimeFormatter1.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 1);
        int int5 = dateTimeParserBucket4.getOffset();
        long long8 = dateTimeParserBucket4.computeMillis(false, "DateTimeField[dayOfMonth]");
        long long11 = dateTimeParserBucket4.computeMillis(false, "1969-365T16:00:00.000-08:00");
        java.lang.Integer int12 = dateTimeParserBucket4.getPivotYear();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28800100L + "'", long8 == 28800100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800100L + "'", long11 == 28800100L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12.equals(1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipUndoDateTimeField8.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "");
        java.lang.Number number29 = illegalFieldValueException28.getUpperBound();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNull(number29);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatterBuilder0.toFormatter();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Both printing and parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        org.joda.time.DurationField durationField26 = skipUndoDateTimeField8.getDurationField();
        org.joda.time.DurationField durationField27 = skipUndoDateTimeField8.getDurationField();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property8 = dateTime4.era();
        org.joda.time.DateTime dateTime10 = dateTime4.minusMinutes(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.DateTime dateTime13 = dateTime4.toDateTime(dateTimeZone12);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 1, dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withMonthOfYear(1);
        org.joda.time.DateTime dateTime21 = dateTime19.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate22 = dateTime19.toLocalDate();
        long long24 = gJChronology14.set((org.joda.time.ReadablePartial) localDate22, (long) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj26 = mutableDateTime25.clone();
        boolean boolean27 = gJChronology14.equals((java.lang.Object) mutableDateTime25);
        org.joda.time.DateTime dateTime28 = dateTime4.withChronology((org.joda.time.Chronology) gJChronology14);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-28857599999L) + "'", long24 == (-28857599999L));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("0035-06-12T00:00:02-07:52:58");
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        long long9 = gJChronology4.add((long) 59, 200001L, (int) '4');
        org.joda.time.DurationField durationField10 = gJChronology4.years();
        org.joda.time.DurationField durationField11 = gJChronology4.days();
        org.joda.time.DurationField durationField12 = gJChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology4.hourOfHalfday();
        org.joda.time.DurationField durationField14 = gJChronology4.seconds();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10400111L + "'", long9 == 10400111L);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("0");
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        org.joda.time.Chronology chronology4 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 100);
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.millisOfSecond();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology4);
        try {
            long long17 = gJChronology4.getDateTimeMillis(0, 57600001, (-593), 3395, (-18059), (-28800000), (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3395 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfHalfday(57600001);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfDay(57600);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTimeZoneOffset("2", false, 57600, 9409);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime2.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime6.withMillis((long) (short) -1);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime10 = mutableDateTime9.copy();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime9.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate7 = dateTime4.toLocalDate();
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        org.joda.time.DateTime dateTime9 = dateTime4.toDateTimeISO();
        int int10 = dateTime4.getYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DurationField durationField7 = gJChronology6.weeks();
        org.joda.time.Instant instant8 = gJChronology6.getGregorianCutover();
        org.joda.time.DateTime dateTime9 = instant8.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime10 = instant8.toMutableDateTime();
        org.joda.time.DateTime dateTime11 = instant8.toDateTime();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology2, locale3, (java.lang.Integer) 12, (int) (short) 1);
        org.joda.time.Chronology chronology7 = dateTimeParserBucket6.getChronology();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) 100, (int) (short) -1, (-1969), 57599966, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57599966 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("AD", "12", (-100), 12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        int int10 = fixedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        int int13 = fixedDateTimeZone7.getOffset((-28857599999L));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-100) + "'", int10 == (-100));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-100) + "'", int13 == (-100));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfHalfday(57600001);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatterBuilder2.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        java.lang.String str45 = unsupportedDateTimeField44.toString();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UnsupportedDateTimeField" + "'", str45.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfMinute();
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipUndoDateTimeField8.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "");
        java.lang.String str29 = illegalFieldValueException28.getIllegalStringValue();
        boolean boolean30 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException28);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.months();
        org.joda.time.DurationField durationField2 = gJChronology0.eras();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 1, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMillis((int) '#');
        org.joda.time.DateTime.Property property12 = dateTime11.era();
        org.joda.time.DateTime dateTime13 = property12.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        java.lang.String str15 = dateTimeZone14.getID();
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(1, 2000, 32, 5, (-1), 57600, 224, dateTimeZone14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "America/Los_Angeles" + "'", str15.equals("America/Los_Angeles"));
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology3 = gregorianChronology2.withUTC();
//        java.lang.String str4 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime6);
//        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField11, 0);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        int int15 = skipUndoDateTimeField13.getMinimumValue(readablePartial14);
//        long long17 = skipUndoDateTimeField13.roundHalfFloor((long) (short) -1);
//        java.lang.String str18 = skipUndoDateTimeField13.toString();
//        long long20 = skipUndoDateTimeField13.roundHalfCeiling((long) 31);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) skipUndoDateTimeField13, (int) (byte) -1);
//        boolean boolean23 = iSOChronology0.equals((java.lang.Object) (byte) -1);
//        org.joda.time.DurationField durationField24 = iSOChronology0.months();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = dateTime27.withZone(dateTimeZone28);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
//        java.lang.String str35 = dateTimeZone33.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(0L, dateTimeZone33);
//        org.joda.time.MutableDateTime mutableDateTime38 = dateTime27.toMutableDateTime(dateTimeZone33);
//        java.lang.String str40 = dateTimeZone33.getShortName(0L);
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33);
//        org.joda.time.Chronology chronology42 = iSOChronology0.withZone(dateTimeZone33);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str18.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28800000L + "'", long20 == 28800000L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "America/Los_Angeles" + "'", str35.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "PST" + "'", str40.equals("PST"));
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(chronology42);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.secondOfMinute();
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.DateTime.Property property8 = dateTime4.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime4.withZone(dateTimeZone9);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfMinute();
        org.joda.time.DateTime.Property property6 = dateTime4.secondOfMinute();
        java.lang.Object obj7 = null;
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime4, obj7);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime4.toMutableDateTime();
        try {
            mutableDateTime9.setSecondOfMinute((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property8 = dateTime4.era();
        org.joda.time.DateTime dateTime10 = dateTime4.minusMinutes(1);
        org.joda.time.DateTime.Property property11 = dateTime10.minuteOfHour();
        java.util.Date date12 = dateTime10.toDate();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-1036800001L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-89790386846400000L) + "'", long1 == (-89790386846400000L));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 1);
        org.joda.time.DateTimeField dateTimeField5 = null;
        dateTimeParserBucket4.saveField(dateTimeField5, (int) (short) 0);
        java.lang.Integer int8 = dateTimeParserBucket4.getPivotYear();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8.equals(1));
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
//        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
//        int int5 = mutableDateTime4.getRoundingMode();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.centuryOfEra();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.centuryOfEra();
//        int int8 = mutableDateTime4.getSecondOfDay();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19869 + "'", int8 == 19869);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        try {
            int[] intArray8 = gJChronology3.get(readablePeriod6, 1560342585128L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("0");
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime6);
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField11, 0);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = skipUndoDateTimeField13.getMinimumValue(readablePartial14);
        long long17 = skipUndoDateTimeField13.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 1, dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime20.withMonthOfYear(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate25 = dateTime22.toLocalDate();
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField13.getAsText((org.joda.time.ReadablePartial) localDate25, (int) (byte) 0, locale27);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) 1, dateTimeZone31);
        org.joda.time.DateTime dateTime34 = dateTime32.withMonthOfYear(1);
        org.joda.time.DateTime dateTime36 = dateTime34.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate37 = dateTime34.toLocalDate();
        long long39 = gJChronology29.set((org.joda.time.ReadablePartial) localDate37, (long) (short) 1);
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipUndoDateTimeField13.getAsText((org.joda.time.ReadablePartial) localDate37, locale40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipUndoDateTimeField13.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType42, 12);
        java.lang.String str45 = dividedDateTimeField44.toString();
        long long47 = dividedDateTimeField44.roundHalfFloor((long) 1970);
        long long50 = dividedDateTimeField44.addWrapField((-28857599999L), (int) '4');
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53);
        java.util.Locale locale55 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket58 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology54, locale55, (java.lang.Integer) 12, (int) (short) 1);
        long long61 = dateTimeParserBucket58.computeMillis(false, "");
        java.util.Locale locale62 = dateTimeParserBucket58.getLocale();
        java.text.DateFormatSymbols dateFormatSymbols63 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale62);
        java.lang.String str64 = dividedDateTimeField44.getAsText(1L, locale62);
        org.joda.time.ReadablePartial readablePartial65 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter67 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.MutableDateTime mutableDateTime69 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property70 = mutableDateTime69.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone68, (org.joda.time.ReadableInstant) mutableDateTime69);
        org.joda.time.MutableDateTime mutableDateTime72 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property73 = mutableDateTime72.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField74 = property73.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField76 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology71, dateTimeField74, 0);
        long long78 = skipUndoDateTimeField76.roundHalfEven((long) 2019);
        int int80 = skipUndoDateTimeField76.get((long) ' ');
        int int82 = skipUndoDateTimeField76.getMinimumValue(28800100L);
        org.joda.time.MutableDateTime mutableDateTime84 = org.joda.time.MutableDateTime.now();
        int int85 = mutableDateTime84.getYearOfEra();
        org.joda.time.Chronology chronology87 = null;
        java.util.Locale locale88 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket90 = new org.joda.time.format.DateTimeParserBucket(100L, chronology87, locale88, (java.lang.Integer) 1);
        java.lang.Object obj91 = dateTimeParserBucket90.saveState();
        java.util.Locale locale92 = dateTimeParserBucket90.getLocale();
        java.util.Calendar calendar93 = mutableDateTime84.toCalendar(locale92);
        java.lang.String str94 = skipUndoDateTimeField76.getAsText(0, locale92);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter95 = dateTimeFormatter67.withLocale(locale92);
        java.lang.String str96 = dividedDateTimeField44.getAsText(readablePartial65, 20, locale92);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter97 = dateTimeFormatter1.withLocale(locale92);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-28857599999L) + "'", long39 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "31" + "'", str41.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str45.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 374400000L + "'", long47 == 374400000L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-30931199999L) + "'", long50 == (-30931199999L));
        org.junit.Assert.assertNotNull(gJChronology54);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 28800000L + "'", long61 == 28800000L);
        org.junit.Assert.assertNotNull(locale62);
        org.junit.Assert.assertNotNull(dateFormatSymbols63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "2" + "'", str64.equals("2"));
        org.junit.Assert.assertNotNull(dateTimeFormatter67);
        org.junit.Assert.assertNotNull(mutableDateTime69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertNotNull(mutableDateTime72);
        org.junit.Assert.assertNotNull(property73);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 28800000L + "'", long78 == 28800000L);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 31 + "'", int80 == 31);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 2019 + "'", int85 == 2019);
        org.junit.Assert.assertNotNull(obj91);
        org.junit.Assert.assertNotNull(locale92);
        org.junit.Assert.assertNotNull(calendar93);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "0" + "'", str94.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatter95);
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "20" + "'", str96.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFormatter97);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime6);
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField11, 0);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = skipUndoDateTimeField13.getMinimumValue(readablePartial14);
        long long17 = skipUndoDateTimeField13.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 1, dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime20.withMonthOfYear(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate25 = dateTime22.toLocalDate();
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField13.getAsText((org.joda.time.ReadablePartial) localDate25, (int) (byte) 0, locale27);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) 1, dateTimeZone31);
        org.joda.time.DateTime dateTime34 = dateTime32.withMonthOfYear(1);
        org.joda.time.DateTime dateTime36 = dateTime34.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate37 = dateTime34.toLocalDate();
        long long39 = gJChronology29.set((org.joda.time.ReadablePartial) localDate37, (long) (short) 1);
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipUndoDateTimeField13.getAsText((org.joda.time.ReadablePartial) localDate37, locale40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipUndoDateTimeField13.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType42, 12);
        int int45 = dividedDateTimeField44.getDivisor();
        int int48 = dividedDateTimeField44.getDifference((long) (-100), (long) 0);
        java.util.Locale locale50 = null;
        java.lang.String str51 = dividedDateTimeField44.getAsShortText((long) (-1), locale50);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) dividedDateTimeField44);
        org.joda.time.DateTimeField dateTimeField53 = gJChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-28857599999L) + "'", long39 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "31" + "'", str41.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2" + "'", str51.equals("2"));
        org.junit.Assert.assertNotNull(dateTimeField53);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        long long47 = unsupportedDateTimeField44.add(0L, (long) '4');
        try {
            int int49 = unsupportedDateTimeField44.getLeapAmount((long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 136681200000L + "'", long47 == 136681200000L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("GregorianChronology[UTC]");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("-2");
        java.lang.String str4 = jodaTimePermission3.toString();
        boolean boolean5 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"-2\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"-2\")"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipUndoDateTimeField8.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "");
        java.lang.String str29 = illegalFieldValueException28.getIllegalValueAsString();
        java.lang.Number number30 = illegalFieldValueException28.getUpperBound();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime32.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, (org.joda.time.ReadableInstant) mutableDateTime32);
        org.joda.time.MutableDateTime mutableDateTime35 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField37 = property36.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology34, dateTimeField37, 0);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = skipUndoDateTimeField39.getMinimumValue(readablePartial40);
        long long43 = skipUndoDateTimeField39.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) 1, dateTimeZone45);
        org.joda.time.DateTime dateTime48 = dateTime46.withMonthOfYear(1);
        org.joda.time.DateTime dateTime50 = dateTime48.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate51 = dateTime48.toLocalDate();
        java.util.Locale locale53 = null;
        java.lang.String str54 = skipUndoDateTimeField39.getAsText((org.joda.time.ReadablePartial) localDate51, (int) (byte) 0, locale53);
        long long56 = skipUndoDateTimeField39.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = skipUndoDateTimeField39.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException59 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, "31");
        java.lang.String str60 = illegalFieldValueException59.toString();
        illegalFieldValueException28.addSuppressed((java.lang.Throwable) illegalFieldValueException59);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 28800000L + "'", long43 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "0" + "'", str54.equals("0"));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 28800000L + "'", long56 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"31\" for dayOfMonth is not supported" + "'", str60.equals("org.joda.time.IllegalFieldValueException: Value \"31\" for dayOfMonth is not supported"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipUndoDateTimeField32.getMinimumValue(readablePartial33);
        long long36 = skipUndoDateTimeField32.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear(1);
        org.joda.time.DateTime dateTime43 = dateTime41.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime41.toLocalDate();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale46);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        long long58 = gJChronology48.set((org.joda.time.ReadablePartial) localDate56, (long) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate56, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipUndoDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType61);
        long long65 = zeroIsMaxDateTimeField62.getDifferenceAsLong(1560342585128L, (long) 0);
        long long68 = zeroIsMaxDateTimeField62.addWrapField(10400111L, (int) (short) 100);
        org.joda.time.DurationField durationField69 = zeroIsMaxDateTimeField62.getDurationField();
        int int71 = zeroIsMaxDateTimeField62.getMinimumValue((long) 2);
        org.joda.time.DateTimeZone dateTimeZone73 = null;
        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime((long) 1, dateTimeZone73);
        org.joda.time.DateTime dateTime76 = dateTime74.minusMillis((int) '#');
        org.joda.time.DateTime.Property property77 = dateTime76.era();
        org.joda.time.DateTime dateTime78 = property77.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime80 = dateTime78.plusWeeks((int) (byte) 10);
        org.joda.time.DateTime dateTime82 = dateTime78.withYearOfCentury(0);
        org.joda.time.LocalTime localTime83 = dateTime82.toLocalTime();
        int[] intArray85 = null;
        try {
            int[] intArray87 = zeroIsMaxDateTimeField62.add((org.joda.time.ReadablePartial) localTime83, 31, intArray85, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28857599999L) + "'", long58 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 18059L + "'", long65 == 18059L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-2063199889L) + "'", long68 == (-2063199889L));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertNotNull(dateTime80);
        org.junit.Assert.assertNotNull(dateTime82);
        org.junit.Assert.assertNotNull(localTime83);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("0");
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology5);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        java.lang.String str45 = unsupportedDateTimeField44.getName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        boolean boolean47 = org.joda.time.field.FieldUtils.equals((java.lang.Object) str45, (java.lang.Object) dateTimeFormatter46);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfMonth" + "'", str45.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("57600001");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"57600001/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(20, 0, (int) (byte) 0, 59);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate7 = dateTime4.toLocalDate();
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        java.lang.String str9 = property8.getAsShortText();
        java.lang.String str10 = property8.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 1, dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.minusMillis((int) '#');
        org.joda.time.DateTime dateTime16 = dateTime15.toDateTimeISO();
        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime19 = dateTime15.withMillis((long) (byte) 1);
        org.joda.time.DateTime dateTime20 = dateTime19.toDateTimeISO();
        int int21 = property8.compareTo((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime22 = dateTime20.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "57600001" + "'", str9.equals("57600001"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[millisOfDay]" + "'", str10.equals("Property[millisOfDay]"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-34L) + "'", long17 == (-34L));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 1, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis((int) '#');
        org.joda.time.DateTime dateTime10 = dateTime6.minusSeconds((int) ' ');
        boolean boolean11 = mutableDateTime1.isBefore((org.joda.time.ReadableInstant) dateTime6);
        mutableDateTime1.setYear(100);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfEra(1);
        org.joda.time.DateTime dateTime9 = dateTime5.plus((long) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology2, locale3, (java.lang.Integer) 12, (int) (short) 1);
        dateTimeParserBucket6.setPivotYear((java.lang.Integer) 59);
        org.junit.Assert.assertNotNull(gJChronology2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        int int6 = dateTime4.getMillisOfDay();
        try {
            org.joda.time.DateTime dateTime8 = dateTime4.withDayOfWeek(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600001 + "'", int6 == 57600001);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField7, 0);
//        long long11 = skipUndoDateTimeField9.roundHalfEven((long) 2019);
//        int int13 = skipUndoDateTimeField9.get((long) ' ');
//        boolean boolean15 = skipUndoDateTimeField9.isLeap((long) 2019);
//        int int16 = mutableDateTime0.get((org.joda.time.DateTimeField) skipUndoDateTimeField9);
//        int int17 = mutableDateTime0.getSecondOfDay();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19872 + "'", int17 == 19872);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        int int47 = unsupportedDateTimeField44.getDifference(2000L, (long) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.MutableDateTime mutableDateTime50 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property51 = mutableDateTime50.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, (org.joda.time.ReadableInstant) mutableDateTime50);
        org.joda.time.MutableDateTime mutableDateTime53 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property54 = mutableDateTime53.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField55 = property54.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField57 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology52, dateTimeField55, 0);
        long long59 = skipUndoDateTimeField57.roundHalfEven((long) 2019);
        int int61 = skipUndoDateTimeField57.get((long) ' ');
        int int63 = skipUndoDateTimeField57.getMinimumValue(28800100L);
        org.joda.time.MutableDateTime mutableDateTime65 = org.joda.time.MutableDateTime.now();
        int int66 = mutableDateTime65.getYearOfEra();
        org.joda.time.Chronology chronology68 = null;
        java.util.Locale locale69 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket71 = new org.joda.time.format.DateTimeParserBucket(100L, chronology68, locale69, (java.lang.Integer) 1);
        java.lang.Object obj72 = dateTimeParserBucket71.saveState();
        java.util.Locale locale73 = dateTimeParserBucket71.getLocale();
        java.util.Calendar calendar74 = mutableDateTime65.toCalendar(locale73);
        java.lang.String str75 = skipUndoDateTimeField57.getAsText(0, locale73);
        try {
            java.lang.String str76 = unsupportedDateTimeField44.getAsText(2019, locale73);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(gJChronology52);
        org.junit.Assert.assertNotNull(mutableDateTime53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 28800000L + "'", long59 == 28800000L);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 31 + "'", int61 == 31);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
        org.junit.Assert.assertNotNull(obj72);
        org.junit.Assert.assertNotNull(locale73);
        org.junit.Assert.assertNotNull(calendar74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "0" + "'", str75.equals("0"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 1);
        java.lang.Object obj5 = dateTimeParserBucket4.saveState();
        java.util.Locale locale6 = dateTimeParserBucket4.getLocale();
        dateTimeParserBucket4.setOffset(100);
        long long11 = dateTimeParserBucket4.computeMillis(false, "AD");
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfHalfday(57600001);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) mutableDateTime7);
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField12, 0);
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        int int16 = skipUndoDateTimeField14.getMinimumValue(readablePartial15);
//        long long18 = skipUndoDateTimeField14.roundHalfFloor((long) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 1, dateTimeZone20);
//        org.joda.time.DateTime dateTime23 = dateTime21.withMonthOfYear(1);
//        org.joda.time.DateTime dateTime25 = dateTime23.withDayOfYear((int) (byte) 1);
//        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate26, (int) (byte) 0, locale28);
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 1, dateTimeZone32);
//        org.joda.time.DateTime dateTime35 = dateTime33.withMonthOfYear(1);
//        org.joda.time.DateTime dateTime37 = dateTime35.withDayOfYear((int) (byte) 1);
//        org.joda.time.LocalDate localDate38 = dateTime35.toLocalDate();
//        long long40 = gJChronology30.set((org.joda.time.ReadablePartial) localDate38, (long) (short) 1);
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate38, locale41);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = skipUndoDateTimeField14.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType43, 12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType43, 2);
//        org.joda.time.MutableDateTime mutableDateTime48 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property49 = mutableDateTime48.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField50 = property49.getField();
//        org.joda.time.MutableDateTime mutableDateTime52 = property49.addWrapField((int) 'a');
//        int int53 = mutableDateTime52.getRoundingMode();
//        org.joda.time.Chronology chronology54 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime52);
//        boolean boolean55 = mutableDateTime52.isBeforeNow();
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.MutableDateTime mutableDateTime57 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property58 = mutableDateTime57.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone56, (org.joda.time.ReadableInstant) mutableDateTime57);
//        org.joda.time.MutableDateTime mutableDateTime60 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property61 = mutableDateTime60.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField62 = property61.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField64 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology59, dateTimeField62, 0);
//        org.joda.time.ReadablePartial readablePartial65 = null;
//        int int66 = skipUndoDateTimeField64.getMinimumValue(readablePartial65);
//        long long68 = skipUndoDateTimeField64.roundHalfFloor((long) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone70 = null;
//        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((long) 1, dateTimeZone70);
//        org.joda.time.DateTime dateTime73 = dateTime71.withMonthOfYear(1);
//        org.joda.time.DateTime dateTime75 = dateTime73.withDayOfYear((int) (byte) 1);
//        org.joda.time.LocalDate localDate76 = dateTime73.toLocalDate();
//        java.util.Locale locale78 = null;
//        java.lang.String str79 = skipUndoDateTimeField64.getAsText((org.joda.time.ReadablePartial) localDate76, (int) (byte) 0, locale78);
//        long long81 = skipUndoDateTimeField64.roundHalfFloor((long) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType82 = skipUndoDateTimeField64.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException84 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType82, "");
//        org.joda.time.MutableDateTime.Property property85 = mutableDateTime52.property(dateTimeFieldType82);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder87 = dateTimeFormatterBuilder47.appendFixedSignedDecimal(dateTimeFieldType82, 720);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap88 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder89 = dateTimeFormatterBuilder47.appendTimeZoneName(strMap88);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-28857599999L) + "'", long40 == (-28857599999L));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "31" + "'", str42.equals("31"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(mutableDateTime52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(chronology54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(gJChronology59);
//        org.junit.Assert.assertNotNull(mutableDateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 28800000L + "'", long68 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(localDate76);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "0" + "'", str79.equals("0"));
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 28800000L + "'", long81 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType82);
//        org.junit.Assert.assertNotNull(property85);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder87);
//        org.junit.Assert.assertNotNull(strMap88);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder89);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ISOChronology[America/Los_Angeles]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("160000.010-0800");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"160000.010-0800\" is malformed at \".010-0800\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipUndoDateTimeField32.getMinimumValue(readablePartial33);
        long long36 = skipUndoDateTimeField32.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear(1);
        org.joda.time.DateTime dateTime43 = dateTime41.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime41.toLocalDate();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale46);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        long long58 = gJChronology48.set((org.joda.time.ReadablePartial) localDate56, (long) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate56, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipUndoDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType61);
        long long65 = zeroIsMaxDateTimeField62.getDifferenceAsLong(1560342585128L, (long) 0);
        long long68 = zeroIsMaxDateTimeField62.addWrapField(10400111L, (int) (short) 100);
        org.joda.time.DurationField durationField69 = zeroIsMaxDateTimeField62.getDurationField();
        int int71 = zeroIsMaxDateTimeField62.getMinimumValue((long) 2);
        int int72 = zeroIsMaxDateTimeField62.getMinimumValue();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28857599999L) + "'", long58 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 18059L + "'", long65 == 18059L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-2063199889L) + "'", long68 == (-2063199889L));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime8 = dateTime4.withMillis((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology10 = gregorianChronology9.withUTC();
        java.lang.String str11 = gregorianChronology9.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) mutableDateTime13);
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = property17.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField18, 0);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int int22 = skipUndoDateTimeField20.getMinimumValue(readablePartial21);
        long long24 = skipUndoDateTimeField20.roundHalfFloor((long) (short) -1);
        java.lang.String str25 = skipUndoDateTimeField20.toString();
        long long27 = skipUndoDateTimeField20.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeField) skipUndoDateTimeField20, (int) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime30 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj31 = mutableDateTime30.clone();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) 1, dateTimeZone33);
        int int35 = mutableDateTime30.compareTo((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime dateTime37 = dateTime34.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay38 = dateTime37.toTimeOfDay();
        int int39 = skipUndoDateTimeField20.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay38);
        org.joda.time.DateTime dateTime40 = dateTime8.withFields((org.joda.time.ReadablePartial) timeOfDay38);
        org.joda.time.DateTime dateTime42 = dateTime40.minusSeconds(59);
        int int43 = dateTime40.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[UTC]" + "'", str11.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28800000L + "'", long24 == 28800000L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str25.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28800000L + "'", long27 == 28800000L);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(timeOfDay38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("13", "Coordinated Universal Time");
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField7, 0);
        long long11 = skipUndoDateTimeField9.roundHalfEven((long) 2019);
        int int13 = skipUndoDateTimeField9.get((long) ' ');
        int int15 = skipUndoDateTimeField9.getMinimumValue(28800100L);
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
        int int18 = mutableDateTime17.getYearOfEra();
        org.joda.time.Chronology chronology20 = null;
        java.util.Locale locale21 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket23 = new org.joda.time.format.DateTimeParserBucket(100L, chronology20, locale21, (java.lang.Integer) 1);
        java.lang.Object obj24 = dateTimeParserBucket23.saveState();
        java.util.Locale locale25 = dateTimeParserBucket23.getLocale();
        java.util.Calendar calendar26 = mutableDateTime17.toCalendar(locale25);
        java.lang.String str27 = skipUndoDateTimeField9.getAsText(0, locale25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter0.withLocale(locale25);
        org.joda.time.MutableDateTime mutableDateTime29 = org.joda.time.MutableDateTime.now();
        int int30 = mutableDateTime29.getYearOfEra();
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime29.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField32 = mutableDateTime29.getRoundingField();
        mutableDateTime29.addWeekyears(4);
        int int37 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime29, "PST", 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(locale25);
        org.junit.Assert.assertNotNull(calendar26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1970) + "'", int37 == (-1970));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        int int44 = dividedDateTimeField42.get((long) 57599966);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.Chronology chronology3 = buddhistChronology1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology5 = gregorianChronology4.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology4.getZone();
//        java.lang.String str8 = dateTimeZone6.getName(10L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
//        org.joda.time.Chronology chronology10 = buddhistChronology1.withZone(dateTimeZone6);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
//        org.junit.Assert.assertNotNull(chronology10);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipUndoDateTimeField8.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "");
        org.joda.time.DurationFieldType durationFieldType29 = illegalFieldValueException28.getDurationFieldType();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNull(durationFieldType29);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
//        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
//        java.lang.String str5 = property1.getAsString();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19" + "'", str5.equals("19"));
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getYearOfEra();
//        org.joda.time.Chronology chronology3 = null;
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(100L, chronology3, locale4, (java.lang.Integer) 1);
//        java.lang.Object obj7 = dateTimeParserBucket6.saveState();
//        java.util.Locale locale8 = dateTimeParserBucket6.getLocale();
//        java.util.Calendar calendar9 = mutableDateTime0.toCalendar(locale8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime0.millisOfSecond();
//        int int11 = property10.get();
//        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now();
//        int int13 = mutableDateTime12.getYearOfEra();
//        org.joda.time.Chronology chronology15 = null;
//        java.util.Locale locale16 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(100L, chronology15, locale16, (java.lang.Integer) 1);
//        java.lang.Object obj19 = dateTimeParserBucket18.saveState();
//        java.util.Locale locale20 = dateTimeParserBucket18.getLocale();
//        java.util.Calendar calendar21 = mutableDateTime12.toCalendar(locale20);
//        mutableDateTime12.addWeekyears((int) (short) 0);
//        long long24 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime12);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNotNull(locale8);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 338 + "'", int11 == 338);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertNotNull(locale20);
//        org.junit.Assert.assertNotNull(calendar21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-20L) + "'", long24 == (-20L));
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis((int) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury((int) '4');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.Chronology chronology12 = buddhistChronology10.withZone(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        java.lang.String str17 = dateTimeZone15.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(0L, dateTimeZone15);
        org.joda.time.Chronology chronology20 = buddhistChronology10.withZone(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime6.toMutableDateTime(chronology20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "America/Los_Angeles" + "'", str17.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = gregorianChronology1.withUTC();
        java.lang.String str3 = gregorianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gregorianChronology1, locale4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 1, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMillis((int) '#');
        org.joda.time.DateTime dateTime12 = dateTime8.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime14 = dateTime12.withWeekOfWeekyear(31);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime17.withZone(dateTimeZone18);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        org.joda.time.DateTime dateTime22 = dateTime12.withFields((org.joda.time.ReadablePartial) localTime21);
        int[] intArray24 = gregorianChronology1.get((org.joda.time.ReadablePartial) localTime21, (long) 20);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime dateTime7 = dateTime4.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime4.yearOfEra();
        int int10 = property9.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
//        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
//        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
//        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
//        java.lang.String str24 = skipUndoDateTimeField8.toString();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26);
//        java.util.Locale locale28 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology27, locale28, (java.lang.Integer) 12, (int) (short) 1);
//        long long34 = dateTimeParserBucket31.computeMillis(false, "");
//        java.util.Locale locale35 = dateTimeParserBucket31.getLocale();
//        java.util.Locale locale36 = dateTimeParserBucket31.getLocale();
//        int int37 = skipUndoDateTimeField8.getMaximumTextLength(locale36);
//        org.joda.time.MutableDateTime mutableDateTime38 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property39 = mutableDateTime38.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField40 = property39.getField();
//        org.joda.time.MutableDateTime mutableDateTime42 = property39.addWrapField((int) 'a');
//        int int43 = mutableDateTime42.getRoundingMode();
//        org.joda.time.Chronology chronology44 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime42);
//        boolean boolean45 = mutableDateTime42.isBeforeNow();
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.MutableDateTime mutableDateTime47 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property48 = mutableDateTime47.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (org.joda.time.ReadableInstant) mutableDateTime47);
//        org.joda.time.MutableDateTime mutableDateTime50 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property51 = mutableDateTime50.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField52 = property51.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField54 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology49, dateTimeField52, 0);
//        org.joda.time.ReadablePartial readablePartial55 = null;
//        int int56 = skipUndoDateTimeField54.getMinimumValue(readablePartial55);
//        long long58 = skipUndoDateTimeField54.roundHalfFloor((long) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone60 = null;
//        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) 1, dateTimeZone60);
//        org.joda.time.DateTime dateTime63 = dateTime61.withMonthOfYear(1);
//        org.joda.time.DateTime dateTime65 = dateTime63.withDayOfYear((int) (byte) 1);
//        org.joda.time.LocalDate localDate66 = dateTime63.toLocalDate();
//        java.util.Locale locale68 = null;
//        java.lang.String str69 = skipUndoDateTimeField54.getAsText((org.joda.time.ReadablePartial) localDate66, (int) (byte) 0, locale68);
//        long long71 = skipUndoDateTimeField54.roundHalfFloor((long) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = skipUndoDateTimeField54.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException74 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType72, "");
//        org.joda.time.MutableDateTime.Property property75 = mutableDateTime42.property(dateTimeFieldType72);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField76 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType72);
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str24.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 28800000L + "'", long34 == 28800000L);
//        org.junit.Assert.assertNotNull(locale35);
//        org.junit.Assert.assertNotNull(locale36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(mutableDateTime42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(chronology44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(gJChronology49);
//        org.junit.Assert.assertNotNull(mutableDateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 28800000L + "'", long58 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(localDate66);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "0" + "'", str69.equals("0"));
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 28800000L + "'", long71 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertNotNull(property75);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-210861677222000L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 59L + "'", long1 == 59L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime3);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = property7.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField8, 0);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int int12 = skipUndoDateTimeField10.getMinimumValue(readablePartial11);
        long long14 = skipUndoDateTimeField10.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 1, dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withMonthOfYear(1);
        org.joda.time.DateTime dateTime21 = dateTime19.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate22 = dateTime19.toLocalDate();
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField10.getAsText((org.joda.time.ReadablePartial) localDate22, (int) (byte) 0, locale24);
        long long27 = skipUndoDateTimeField10.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipUndoDateTimeField10.getType();
        long long30 = skipUndoDateTimeField10.roundCeiling(1L);
        boolean boolean31 = skipUndoDateTimeField10.isSupported();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField10);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800000L + "'", long14 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28800000L + "'", long27 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28800000L + "'", long30 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField8.getAsShortText(2000, locale27);
        int int30 = skipUndoDateTimeField8.get((long) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType31);
        long long35 = delegatedDateTimeField32.addWrapField(0L, 720);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2000" + "'", str28.equals("2000"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-2073600000L) + "'", long35 == (-2073600000L));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        java.lang.String str45 = unsupportedDateTimeField44.getName();
        try {
            long long47 = unsupportedDateTimeField44.roundHalfFloor(1560367785128L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfMonth" + "'", str45.equals("dayOfMonth"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
        int int5 = mutableDateTime4.getRoundingMode();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.centuryOfEra();
        mutableDateTime4.add(0L);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime4.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 1, dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.minusMillis((int) '#');
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTimeISO();
        long long16 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime18 = dateTime14.withMillis((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology20 = gregorianChronology19.withUTC();
        java.lang.String str21 = gregorianChronology19.toString();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.MutableDateTime mutableDateTime23 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime23.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, (org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.MutableDateTime mutableDateTime26 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime26.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField28 = property27.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField28, 0);
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = skipUndoDateTimeField30.getMinimumValue(readablePartial31);
        long long34 = skipUndoDateTimeField30.roundHalfFloor((long) (short) -1);
        java.lang.String str35 = skipUndoDateTimeField30.toString();
        long long37 = skipUndoDateTimeField30.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, (org.joda.time.DateTimeField) skipUndoDateTimeField30, (int) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime40 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj41 = mutableDateTime40.clone();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) 1, dateTimeZone43);
        int int45 = mutableDateTime40.compareTo((org.joda.time.ReadableInstant) dateTime44);
        org.joda.time.DateTime dateTime47 = dateTime44.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay48 = dateTime47.toTimeOfDay();
        int int49 = skipUndoDateTimeField30.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay48);
        org.joda.time.DateTime dateTime50 = dateTime18.withFields((org.joda.time.ReadablePartial) timeOfDay48);
        org.joda.time.DateTime dateTime51 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime dateTime53 = dateTime18.minusDays(4664);
        int int54 = property9.compareTo((org.joda.time.ReadableInstant) dateTime18);
        int int55 = property9.getMinimumValueOverall();
        org.joda.time.MutableDateTime mutableDateTime56 = property9.getMutableDateTime();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-34L) + "'", long16 == (-34L));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GregorianChronology[UTC]" + "'", str21.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 28800000L + "'", long34 == 28800000L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str35.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 28800000L + "'", long37 == 28800000L);
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(timeOfDay48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime56);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2");
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        java.lang.String str10 = dateTimeZone8.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(0L, dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime2.toMutableDateTime(dateTimeZone8);
        java.lang.Object obj14 = mutableDateTime13.clone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        java.lang.String str16 = skipUndoDateTimeField11.toString();
        long long18 = skipUndoDateTimeField11.roundHalfCeiling((long) 31);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.dayOfWeek();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField22, 59);
        long long27 = skipDateTimeField24.getDifferenceAsLong((long) 3395, 18059L);
        int int28 = skipDateTimeField24.getMaximumValue();
        long long30 = skipDateTimeField24.remainder((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime32.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, (org.joda.time.ReadableInstant) mutableDateTime32);
        org.joda.time.MutableDateTime mutableDateTime35 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField37 = property36.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology34, dateTimeField37, 0);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = skipUndoDateTimeField39.getMinimumValue(readablePartial40);
        long long43 = skipUndoDateTimeField39.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) 1, dateTimeZone45);
        org.joda.time.DateTime dateTime48 = dateTime46.withMonthOfYear(1);
        org.joda.time.DateTime dateTime50 = dateTime48.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate51 = dateTime48.toLocalDate();
        java.util.Locale locale53 = null;
        java.lang.String str54 = skipUndoDateTimeField39.getAsText((org.joda.time.ReadablePartial) localDate51, (int) (byte) 0, locale53);
        java.lang.String str55 = skipUndoDateTimeField39.toString();
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone57);
        java.util.Locale locale59 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket62 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology58, locale59, (java.lang.Integer) 12, (int) (short) 1);
        long long65 = dateTimeParserBucket62.computeMillis(false, "");
        java.util.Locale locale66 = dateTimeParserBucket62.getLocale();
        java.util.Locale locale67 = dateTimeParserBucket62.getLocale();
        int int68 = skipUndoDateTimeField39.getMaximumTextLength(locale67);
        int int69 = skipDateTimeField24.getMaximumShortTextLength(locale67);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str16.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 57600000L + "'", long30 == 57600000L);
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 28800000L + "'", long43 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "0" + "'", str54.equals("0"));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str55.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 28800000L + "'", long65 == 28800000L);
        org.junit.Assert.assertNotNull(locale66);
        org.junit.Assert.assertNotNull(locale67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2 + "'", int68 == 2);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 3 + "'", int69 == 3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.secondOfMinute();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime9 = property7.roundHalfFloorCopy();
        java.lang.String str10 = property7.getAsString();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfHalfday(57600001);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfDay(57600);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendHourOfHalfday(2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("UnsupportedDateTimeField");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UnsupportedDateTimeField\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        int int43 = dividedDateTimeField42.getDivisor();
        int int46 = dividedDateTimeField42.getDifference((long) (-100), (long) 0);
        java.util.Locale locale48 = null;
        java.lang.String str49 = dividedDateTimeField42.getAsText((long) (short) 1, locale48);
        long long51 = dividedDateTimeField42.roundFloor((long) 7);
        long long54 = dividedDateTimeField42.getDifferenceAsLong(1560428985128L, 0L);
        int int55 = dividedDateTimeField42.getMinimumValue();
        int int56 = dividedDateTimeField42.getMinimumValue();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2" + "'", str49.equals("2"));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-662400000L) + "'", long51 == (-662400000L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1505L + "'", long54 == 1505L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        java.lang.String str10 = dateTimeZone8.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(0L, dateTimeZone8);
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime2.toMutableDateTime(dateTimeZone8);
//        java.lang.String str15 = dateTimeZone8.getShortName(0L);
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
//        try {
//            long long22 = gJChronology16.getDateTimeMillis(0L, 19869, 57599966, 100, 365);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19869 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PST" + "'", str15.equals("PST"));
//        org.junit.Assert.assertNotNull(gJChronology16);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        java.lang.String str38 = skipUndoDateTimeField8.toString();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str38.equals("DateTimeField[dayOfMonth]"));
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
//        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField(100);
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
//        org.joda.time.MutableDateTime mutableDateTime9 = property6.addWrapField((int) 'a');
//        int int10 = property1.compareTo((org.joda.time.ReadableInstant) mutableDateTime9);
//        int int11 = property1.getMinimumValue();
//        java.lang.String str12 = property1.getAsText();
//        org.joda.time.MutableDateTime mutableDateTime14 = property1.set("19");
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "22" + "'", str12.equals("22"));
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DurationField durationField7 = gJChronology6.weeks();
        org.joda.time.Instant instant8 = gJChronology6.getGregorianCutover();
        org.joda.time.Instant instant11 = instant8.withDurationAdded((long) (short) 1, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = buddhistChronology13.withZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        java.lang.String str20 = dateTimeZone18.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(0L, dateTimeZone18);
        org.joda.time.Chronology chronology23 = buddhistChronology13.withZone(dateTimeZone18);
        boolean boolean25 = buddhistChronology13.equals((java.lang.Object) 1560342587094L);
        org.joda.time.MutableDateTime mutableDateTime26 = instant8.toMutableDateTime((org.joda.time.Chronology) buddhistChronology13);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "America/Los_Angeles" + "'", str20.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(mutableDateTime26);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime.Property property6 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.withMinimumValue();
        int int8 = dateTime7.getYearOfEra();
        int int9 = dateTime7.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        org.joda.time.Chronology chronology6 = gJChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        long long5 = gregorianChronology0.add((-210861504422000L), (long) 57600, (-100));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-210861510182000L) + "'", long5 == (-210861510182000L));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        long long25 = skipUndoDateTimeField8.roundHalfFloor((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipUndoDateTimeField8.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "31");
        java.lang.String str29 = illegalFieldValueException28.getFieldName();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800000L + "'", long25 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "dayOfMonth" + "'", str29.equals("dayOfMonth"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        long long6 = iSOChronology0.add((long) 57600001, 107L, (int) (byte) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 57600001L + "'", long6 == 57600001L);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfHalfday(57600001);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) mutableDateTime7);
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField12, 0);
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        int int16 = skipUndoDateTimeField14.getMinimumValue(readablePartial15);
//        long long18 = skipUndoDateTimeField14.roundHalfFloor((long) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 1, dateTimeZone20);
//        org.joda.time.DateTime dateTime23 = dateTime21.withMonthOfYear(1);
//        org.joda.time.DateTime dateTime25 = dateTime23.withDayOfYear((int) (byte) 1);
//        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate26, (int) (byte) 0, locale28);
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 1, dateTimeZone32);
//        org.joda.time.DateTime dateTime35 = dateTime33.withMonthOfYear(1);
//        org.joda.time.DateTime dateTime37 = dateTime35.withDayOfYear((int) (byte) 1);
//        org.joda.time.LocalDate localDate38 = dateTime35.toLocalDate();
//        long long40 = gJChronology30.set((org.joda.time.ReadablePartial) localDate38, (long) (short) 1);
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate38, locale41);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = skipUndoDateTimeField14.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType43, 12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType43, 2);
//        org.joda.time.MutableDateTime mutableDateTime48 = org.joda.time.MutableDateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.MutableDateTime mutableDateTime50 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property51 = mutableDateTime50.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, (org.joda.time.ReadableInstant) mutableDateTime50);
//        org.joda.time.MutableDateTime mutableDateTime53 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property54 = mutableDateTime53.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField55 = property54.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField57 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology52, dateTimeField55, 0);
//        long long59 = skipUndoDateTimeField57.roundHalfEven((long) 2019);
//        int int61 = skipUndoDateTimeField57.get((long) ' ');
//        boolean boolean63 = skipUndoDateTimeField57.isLeap((long) 2019);
//        int int64 = mutableDateTime48.get((org.joda.time.DateTimeField) skipUndoDateTimeField57);
//        org.joda.time.DurationField durationField65 = skipUndoDateTimeField57.getRangeDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology67 = gregorianChronology66.withUTC();
//        org.joda.time.DurationField durationField68 = gregorianChronology66.years();
//        org.joda.time.DurationField durationField69 = gregorianChronology66.weekyears();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField70 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType43, durationField65, durationField69);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-28857599999L) + "'", long40 == (-28857599999L));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "31" + "'", str42.equals("31"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertNotNull(mutableDateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(gJChronology52);
//        org.junit.Assert.assertNotNull(mutableDateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 28800000L + "'", long59 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 31 + "'", int61 == 31);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 12 + "'", int64 == 12);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(chronology67);
//        org.junit.Assert.assertNotNull(durationField68);
//        org.junit.Assert.assertNotNull(durationField69);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 1, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear(1);
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localDate32, (long) (short) 1);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate32, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipUndoDateTimeField8.getType();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime39);
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.dayOfYear();
        org.joda.time.DurationField durationField43 = gJChronology41.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField43);
        java.lang.String str45 = unsupportedDateTimeField44.getName();
        long long48 = unsupportedDateTimeField44.getDifferenceAsLong((long) 31, (long) (byte) 10);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28857599999L) + "'", long34 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31" + "'", str36.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfMonth" + "'", str45.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis((int) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury((int) '4');
        org.joda.time.DateTime.Property property9 = dateTime6.yearOfCentury();
        org.joda.time.DateTime dateTime11 = dateTime6.withMillis((-5756400001L));
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        int int43 = dividedDateTimeField42.getDivisor();
        int int46 = dividedDateTimeField42.getDifference((long) (-100), (long) 0);
        long long48 = dividedDateTimeField42.roundHalfCeiling(0L);
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.MutableDateTime mutableDateTime52 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property53 = mutableDateTime52.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone51, (org.joda.time.ReadableInstant) mutableDateTime52);
        org.joda.time.MutableDateTime mutableDateTime55 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property56 = mutableDateTime55.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField57 = property56.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField59 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology54, dateTimeField57, 0);
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime((long) 1, dateTimeZone61);
        org.joda.time.DateTime dateTime64 = dateTime62.minusMillis((int) '#');
        org.joda.time.DateTime.Property property65 = dateTime64.era();
        org.joda.time.DurationField durationField66 = property65.getDurationField();
        org.joda.time.Chronology chronology68 = null;
        java.util.Locale locale69 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket71 = new org.joda.time.format.DateTimeParserBucket(100L, chronology68, locale69, (java.lang.Integer) 1);
        java.lang.Object obj72 = dateTimeParserBucket71.saveState();
        java.util.Locale locale73 = dateTimeParserBucket71.getLocale();
        int int74 = property65.getMaximumTextLength(locale73);
        int int75 = skipUndoDateTimeField59.getMaximumShortTextLength(locale73);
        try {
            long long76 = dividedDateTimeField42.set(10400111L, "", locale73);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 374400000L + "'", long48 == 374400000L);
        org.junit.Assert.assertNotNull(mutableDateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(gJChronology54);
        org.junit.Assert.assertNotNull(mutableDateTime55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(durationField66);
        org.junit.Assert.assertNotNull(obj72);
        org.junit.Assert.assertNotNull(locale73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2 + "'", int74 == 2);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2 + "'", int75 == 2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property8 = dateTime4.era();
        java.lang.String str9 = property8.getAsShortText();
        long long10 = property8.remainder();
        org.joda.time.DateTime dateTime11 = property8.withMinimumValue();
        org.joda.time.DateTime dateTime12 = property8.roundHalfCeilingCopy();
        java.lang.String str13 = property8.toString();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "AD" + "'", str9.equals("AD"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 62135568000001L + "'", long10 == 62135568000001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[era]" + "'", str13.equals("Property[era]"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime2.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekOfWeekyear(31);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMillis(9409);
        org.joda.time.DateTime dateTime12 = dateTime8.plusYears(3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (short) 100, 'a', (int) '#', 10, (int) (short) 100, true, (int) (short) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("365", 1969);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder8.setFixedSavings("JulianChronology[America/Los_Angeles]", 57600);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
        mutableDateTime4.addMonths(4664);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipUndoDateTimeField32.getMinimumValue(readablePartial33);
        long long36 = skipUndoDateTimeField32.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear(1);
        org.joda.time.DateTime dateTime43 = dateTime41.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime41.toLocalDate();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale46);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        long long58 = gJChronology48.set((org.joda.time.ReadablePartial) localDate56, (long) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate56, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipUndoDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType61);
        long long65 = zeroIsMaxDateTimeField62.getDifferenceAsLong(1560342585128L, (long) 0);
        long long68 = zeroIsMaxDateTimeField62.addWrapField(10400111L, (int) (short) 100);
        org.joda.time.DurationField durationField69 = zeroIsMaxDateTimeField62.getDurationField();
        int int71 = zeroIsMaxDateTimeField62.getMinimumValue((long) 2);
        java.util.Locale locale73 = null;
        java.lang.String str74 = zeroIsMaxDateTimeField62.getAsText(32, locale73);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28857599999L) + "'", long58 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 18059L + "'", long65 == 18059L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-2063199889L) + "'", long68 == (-2063199889L));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "32" + "'", str74.equals("32"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.minuteOfDay();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfHalfday(57600001);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("Dec 31, 1969 3:59:00 PM");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(224, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.halfdayOfDay();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipUndoDateTimeField32.getMinimumValue(readablePartial33);
        long long36 = skipUndoDateTimeField32.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear(1);
        org.joda.time.DateTime dateTime43 = dateTime41.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime41.toLocalDate();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale46);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        long long58 = gJChronology48.set((org.joda.time.ReadablePartial) localDate56, (long) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate56, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipUndoDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType61);
        long long65 = zeroIsMaxDateTimeField62.getDifferenceAsLong(1560342585128L, (long) 0);
        long long68 = zeroIsMaxDateTimeField62.addWrapField(10400111L, (int) (short) 100);
        org.joda.time.DurationField durationField69 = zeroIsMaxDateTimeField62.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime((long) 1, dateTimeZone71);
        org.joda.time.DateTime dateTime74 = dateTime72.withMonthOfYear(1);
        org.joda.time.DateTime dateTime76 = dateTime74.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate77 = dateTime74.toLocalDate();
        int[] intArray84 = new int[] { 31, 57600001, (byte) 100, 32, 12, 30 };
        int int85 = zeroIsMaxDateTimeField62.getMinimumValue((org.joda.time.ReadablePartial) localDate77, intArray84);
        int int87 = zeroIsMaxDateTimeField62.get((-1036800001L));
        long long89 = zeroIsMaxDateTimeField62.roundHalfCeiling((-89790386846400000L));
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28857599999L) + "'", long58 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 18059L + "'", long65 == 18059L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-2063199889L) + "'", long68 == (-2063199889L));
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertNotNull(localDate77);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 19 + "'", int87 == 19);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + (-89790386861222000L) + "'", long89 == (-89790386861222000L));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        java.lang.String str10 = dateTimeZone8.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(0L, dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime2.toMutableDateTime(dateTimeZone8);
        int int14 = mutableDateTime13.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.months();
        long long6 = gJChronology1.add((long) 1, (long) (byte) 100, 2000);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.MutableDateTime mutableDateTime11 = property8.addWrapField(100);
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        org.joda.time.MutableDateTime mutableDateTime16 = property13.addWrapField((int) 'a');
        int int17 = property8.compareTo((org.joda.time.ReadableInstant) mutableDateTime16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (org.joda.time.ReadableInstant) mutableDateTime19);
        org.joda.time.MutableDateTime mutableDateTime22 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime22.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology21, dateTimeField24, 0);
        long long28 = skipUndoDateTimeField26.roundHalfEven((long) 2019);
        int int30 = skipUndoDateTimeField26.get((long) ' ');
        int int32 = skipUndoDateTimeField26.getMinimumValue(28800100L);
        org.joda.time.MutableDateTime mutableDateTime34 = org.joda.time.MutableDateTime.now();
        int int35 = mutableDateTime34.getYearOfEra();
        org.joda.time.Chronology chronology37 = null;
        java.util.Locale locale38 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket40 = new org.joda.time.format.DateTimeParserBucket(100L, chronology37, locale38, (java.lang.Integer) 1);
        java.lang.Object obj41 = dateTimeParserBucket40.saveState();
        java.util.Locale locale42 = dateTimeParserBucket40.getLocale();
        java.util.Calendar calendar43 = mutableDateTime34.toCalendar(locale42);
        java.lang.String str44 = skipUndoDateTimeField26.getAsText(0, locale42);
        java.util.Calendar calendar45 = mutableDateTime16.toCalendar(locale42);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket48 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) gJChronology1, locale42, (java.lang.Integer) 57599966, (-593));
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 200001L + "'", long6 == 200001L);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 28800000L + "'", long28 == 28800000L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(locale42);
        org.junit.Assert.assertNotNull(calendar43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "0" + "'", str44.equals("0"));
        org.junit.Assert.assertNotNull(calendar45);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
        int int7 = dateTime6.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField8.getAsText((int) (short) 1, locale14);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, (org.joda.time.ReadableInstant) mutableDateTime18);
        java.util.Locale locale21 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket23 = new org.joda.time.format.DateTimeParserBucket(1560342585128L, (org.joda.time.Chronology) gJChronology20, locale21, (java.lang.Integer) 100);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology20.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology20.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 1, dateTimeZone28);
        org.joda.time.DateTime dateTime31 = dateTime29.withMonthOfYear(1);
        org.joda.time.DateTime dateTime33 = dateTime31.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate34 = dateTime31.toLocalDate();
        long long36 = gJChronology26.set((org.joda.time.ReadablePartial) localDate34, (long) (short) 1);
        int[] intArray38 = gJChronology20.get((org.joda.time.ReadablePartial) localDate34, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41);
        java.util.Locale locale43 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology42, locale43, (java.lang.Integer) 12, (int) (short) 1);
        long long49 = dateTimeParserBucket46.computeMillis(false, "");
        java.util.Locale locale50 = dateTimeParserBucket46.getLocale();
        java.text.DateFormatSymbols dateFormatSymbols51 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale50);
        java.lang.String str52 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate34, (int) ' ', locale50);
        org.joda.time.DurationField durationField53 = skipUndoDateTimeField8.getRangeDurationField();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-28857599999L) + "'", long36 == (-28857599999L));
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 28800000L + "'", long49 == 28800000L);
        org.junit.Assert.assertNotNull(locale50);
        org.junit.Assert.assertNotNull(dateFormatSymbols51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "32" + "'", str52.equals("32"));
        org.junit.Assert.assertNotNull(durationField53);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        boolean boolean3 = property1.isLeap();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        boolean boolean8 = property6.isLeap();
        org.joda.time.MutableDateTime mutableDateTime9 = property6.getMutableDateTime();
        mutableDateTime4.setTime((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        mutableDateTime4.setZoneRetainFields(dateTimeZone11);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gJChronology13);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        java.lang.String str2 = dateTimeFormatter0.print(readableInstant1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 4664);
//        boolean boolean5 = dateTimeFormatter0.isParser();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-163T05:31:21.038-07:00" + "'", str2.equals("2019-163T05:31:21.038-07:00"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.junit.Assert.assertNotNull(strMap1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(2000, 100, (int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(20, 6, 720, 20, 57599966, chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57599966 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        int int8 = mutableDateTime7.getYearOfEra();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.MutableDateTime mutableDateTime13 = property10.addWrapField((int) 'a');
        mutableDateTime7.setTime((org.joda.time.ReadableInstant) mutableDateTime13);
        org.joda.time.Chronology chronology15 = mutableDateTime7.getChronology();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime6, chronology15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime6.toDateTime(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfHalfday(57600001);
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = skipUndoDateTimeField14.getMinimumValue(readablePartial15);
        long long18 = skipUndoDateTimeField14.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 1, dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.withMonthOfYear(1);
        org.joda.time.DateTime dateTime25 = dateTime23.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate26, (int) (byte) 0, locale28);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 1, dateTimeZone32);
        org.joda.time.DateTime dateTime35 = dateTime33.withMonthOfYear(1);
        org.joda.time.DateTime dateTime37 = dateTime35.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate38 = dateTime35.toLocalDate();
        long long40 = gJChronology30.set((org.joda.time.ReadablePartial) localDate38, (long) (short) 1);
        java.util.Locale locale41 = null;
        java.lang.String str42 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate38, locale41);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = skipUndoDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType43, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType43, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder47.appendClockhourOfDay(7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder49.appendHourOfHalfday(57599966);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-28857599999L) + "'", long40 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "31" + "'", str42.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.secondOfMinute();
        mutableDateTime0.addMinutes((int) 'a');
        int int4 = mutableDateTime0.getEra();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 1, 5, 4, 32, 30, 31);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime3);
        int int6 = mutableDateTime3.getWeekyear();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime3);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime3.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.dayOfYear();
        org.joda.time.DurationField durationField14 = gJChronology12.months();
        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField17 = property16.getField();
        boolean boolean18 = property16.isLeap();
        org.joda.time.MutableDateTime mutableDateTime19 = property16.getMutableDateTime();
        boolean boolean20 = gJChronology12.equals((java.lang.Object) mutableDateTime19);
        mutableDateTime3.setChronology((org.joda.time.Chronology) gJChronology12);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime3.dayOfYear();
        org.joda.time.DateTimeField dateTimeField23 = property22.getField();
        org.joda.time.MutableDateTime mutableDateTime24 = property22.roundHalfFloor();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime24);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(gJChronology25);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipUndoDateTimeField8.getMinimumValue(readablePartial9);
        long long12 = skipUndoDateTimeField8.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(1);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate20, (int) (byte) 0, locale22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipUndoDateTimeField32.getMinimumValue(readablePartial33);
        long long36 = skipUndoDateTimeField32.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear(1);
        org.joda.time.DateTime dateTime43 = dateTime41.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime41.toLocalDate();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale46);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 1, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMonthOfYear(1);
        org.joda.time.DateTime dateTime55 = dateTime53.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = dateTime53.toLocalDate();
        long long58 = gJChronology48.set((org.joda.time.ReadablePartial) localDate56, (long) (short) 1);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate56, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = skipUndoDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType61);
        long long65 = zeroIsMaxDateTimeField62.getDifferenceAsLong(1560342585128L, (long) 0);
        int int67 = zeroIsMaxDateTimeField62.getMaximumValue((long) (byte) 100);
        int int68 = zeroIsMaxDateTimeField62.getMaximumValue();
        int int71 = zeroIsMaxDateTimeField62.getDifference((long) 19841, 1560342585128L);
        int int73 = zeroIsMaxDateTimeField62.getLeapAmount(59L);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-28857599999L) + "'", long58 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 18059L + "'", long65 == 18059L);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 32 + "'", int67 == 32);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 32 + "'", int68 == 32);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-18059) + "'", int71 == (-18059));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.String str2 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        long long8 = dateTimeZone4.adjustOffset((long) 12, false);
        org.joda.time.Chronology chronology9 = julianChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMonthOfYear(1);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis((int) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury((int) '4');
        org.joda.time.DateTime.Property property9 = dateTime6.yearOfCentury();
        org.joda.time.DateTime dateTime11 = dateTime6.withMillis((-5756400001L));
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime6.plus(readableDuration12);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField11.getMinimumValue(readablePartial12);
        long long15 = skipUndoDateTimeField11.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 1, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withMonthOfYear(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate23, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 1, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMonthOfYear(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = gJChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) (short) 1);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate35, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField11.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType40, 12);
        java.lang.String str43 = dividedDateTimeField42.toString();
        java.util.Locale locale45 = null;
        java.lang.String str46 = dividedDateTimeField42.getAsShortText((-2), locale45);
        java.util.Locale locale48 = null;
        java.lang.String str49 = dividedDateTimeField42.getAsText((long) 9409, locale48);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.MutableDateTime mutableDateTime51 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property52 = mutableDateTime51.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50, (org.joda.time.ReadableInstant) mutableDateTime51);
        org.joda.time.MutableDateTime mutableDateTime54 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property55 = mutableDateTime54.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField56 = property55.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField58 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology53, dateTimeField56, 0);
        org.joda.time.ReadablePartial readablePartial59 = null;
        int int60 = skipUndoDateTimeField58.getMinimumValue(readablePartial59);
        long long62 = skipUndoDateTimeField58.roundHalfFloor((long) (short) -1);
        java.util.Locale locale64 = null;
        java.lang.String str65 = skipUndoDateTimeField58.getAsText((int) (short) 1, locale64);
        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime((long) 1, dateTimeZone68);
        org.joda.time.DateTime dateTime71 = dateTime69.withMonthOfYear(1);
        org.joda.time.DateTime dateTime73 = dateTime71.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate74 = dateTime71.toLocalDate();
        long long76 = gJChronology66.set((org.joda.time.ReadablePartial) localDate74, (long) (short) 1);
        java.util.Locale locale77 = null;
        java.lang.String str78 = skipUndoDateTimeField58.getAsShortText((org.joda.time.ReadablePartial) localDate74, locale77);
        int int79 = dividedDateTimeField42.getMinimumValue((org.joda.time.ReadablePartial) localDate74);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-28857599999L) + "'", long37 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31" + "'", str39.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str43.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-2" + "'", str46.equals("-2"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2" + "'", str49.equals("2"));
        org.junit.Assert.assertNotNull(mutableDateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(gJChronology53);
        org.junit.Assert.assertNotNull(mutableDateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 28800000L + "'", long62 == 28800000L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "1" + "'", str65.equals("1"));
        org.junit.Assert.assertNotNull(gJChronology66);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(localDate74);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-28857599999L) + "'", long76 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "31" + "'", str78.equals("31"));
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        java.lang.String str8 = dateTimeZone7.getID();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology10.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        int int14 = cachedDateTimeZone12.getOffset(2000L);
        long long16 = cachedDateTimeZone12.previousTransition((long) (-100));
        org.joda.time.Chronology chronology17 = gregorianChronology9.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-5756400001L) + "'", long16 == (-5756400001L));
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 9409, 1970);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 18535730L + "'", long2 == 18535730L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 1);
        org.joda.time.DateTimeField dateTimeField5 = null;
        dateTimeParserBucket4.saveField(dateTimeField5, (int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField14, 0);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = skipUndoDateTimeField16.getMinimumValue(readablePartial17);
        long long20 = skipUndoDateTimeField16.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 1, dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.withMonthOfYear(1);
        org.joda.time.DateTime dateTime27 = dateTime25.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate28 = dateTime25.toLocalDate();
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate28, (int) (byte) 0, locale30);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.MutableDateTime mutableDateTime33 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime33.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, (org.joda.time.ReadableInstant) mutableDateTime33);
        org.joda.time.MutableDateTime mutableDateTime36 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property37 = mutableDateTime36.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField38 = property37.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology35, dateTimeField38, 0);
        org.joda.time.ReadablePartial readablePartial41 = null;
        int int42 = skipUndoDateTimeField40.getMinimumValue(readablePartial41);
        long long44 = skipUndoDateTimeField40.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 1, dateTimeZone46);
        org.joda.time.DateTime dateTime49 = dateTime47.withMonthOfYear(1);
        org.joda.time.DateTime dateTime51 = dateTime49.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate52 = dateTime49.toLocalDate();
        java.util.Locale locale54 = null;
        java.lang.String str55 = skipUndoDateTimeField40.getAsText((org.joda.time.ReadablePartial) localDate52, (int) (byte) 0, locale54);
        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) 1, dateTimeZone58);
        org.joda.time.DateTime dateTime61 = dateTime59.withMonthOfYear(1);
        org.joda.time.DateTime dateTime63 = dateTime61.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate64 = dateTime61.toLocalDate();
        long long66 = gJChronology56.set((org.joda.time.ReadablePartial) localDate64, (long) (short) 1);
        java.util.Locale locale67 = null;
        java.lang.String str68 = skipUndoDateTimeField40.getAsText((org.joda.time.ReadablePartial) localDate64, locale67);
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = skipUndoDateTimeField40.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField70 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType69);
        dateTimeParserBucket4.saveField(dateTimeFieldType69, 57600001);
        org.joda.time.DateTimeZone dateTimeZone73 = null;
        org.joda.time.MutableDateTime mutableDateTime74 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property75 = mutableDateTime74.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology76 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone73, (org.joda.time.ReadableInstant) mutableDateTime74);
        org.joda.time.DateTimeField dateTimeField77 = gJChronology76.dayOfYear();
        org.joda.time.DurationField durationField78 = gJChronology76.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType69, durationField78);
        boolean boolean80 = unsupportedDateTimeField79.isLenient();
        int int83 = unsupportedDateTimeField79.getDifference((long) (short) 1, 1560342585128L);
        org.joda.time.DurationField durationField84 = unsupportedDateTimeField79.getLeapDurationField();
        try {
            int int85 = unsupportedDateTimeField79.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28800000L + "'", long20 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(mutableDateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 28800000L + "'", long44 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0" + "'", str55.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology56);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-28857599999L) + "'", long66 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "31" + "'", str68.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertNotNull(mutableDateTime74);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertNotNull(gJChronology76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-593) + "'", int83 == (-593));
        org.junit.Assert.assertNull(durationField84);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("AD", "12", (-100), 12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        boolean boolean9 = fixedDateTimeZone7.isFixed();
        java.lang.String str10 = fixedDateTimeZone7.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "AD" + "'", str10.equals("AD"));
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
//        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
//        int int5 = mutableDateTime4.getRoundingMode();
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime4);
//        boolean boolean7 = mutableDateTime4.isBeforeNow();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField14, 0);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        int int18 = skipUndoDateTimeField16.getMinimumValue(readablePartial17);
//        long long20 = skipUndoDateTimeField16.roundHalfFloor((long) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 1, dateTimeZone22);
//        org.joda.time.DateTime dateTime25 = dateTime23.withMonthOfYear(1);
//        org.joda.time.DateTime dateTime27 = dateTime25.withDayOfYear((int) (byte) 1);
//        org.joda.time.LocalDate localDate28 = dateTime25.toLocalDate();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = skipUndoDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate28, (int) (byte) 0, locale30);
//        long long33 = skipUndoDateTimeField16.roundHalfFloor((long) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipUndoDateTimeField16.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, "");
//        org.joda.time.MutableDateTime.Property property37 = mutableDateTime4.property(dateTimeFieldType34);
//        mutableDateTime4.addMinutes(16);
//        try {
//            mutableDateTime4.setHourOfDay(30);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28800000L + "'", long20 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28800000L + "'", long33 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(property37);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfHalfday(57600001);
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = skipUndoDateTimeField14.getMinimumValue(readablePartial15);
        long long18 = skipUndoDateTimeField14.roundHalfFloor((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 1, dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.withMonthOfYear(1);
        org.joda.time.DateTime dateTime25 = dateTime23.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate26, (int) (byte) 0, locale28);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 1, dateTimeZone32);
        org.joda.time.DateTime dateTime35 = dateTime33.withMonthOfYear(1);
        org.joda.time.DateTime dateTime37 = dateTime35.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate38 = dateTime35.toLocalDate();
        long long40 = gJChronology30.set((org.joda.time.ReadablePartial) localDate38, (long) (short) 1);
        java.util.Locale locale41 = null;
        java.lang.String str42 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate38, locale41);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = skipUndoDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType43, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType43, 2);
        org.joda.time.format.DateTimeParser dateTimeParser48 = dateTimeFormatterBuilder47.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder47.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-28857599999L) + "'", long40 == (-28857599999L));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "31" + "'", str42.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeParser48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
//        org.joda.time.MutableDateTime mutableDateTime4 = property1.addWrapField((int) 'a');
//        int int5 = mutableDateTime4.getRoundingMode();
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime4);
//        boolean boolean7 = mutableDateTime4.isBeforeNow();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField14, 0);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        int int18 = skipUndoDateTimeField16.getMinimumValue(readablePartial17);
//        long long20 = skipUndoDateTimeField16.roundHalfFloor((long) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 1, dateTimeZone22);
//        org.joda.time.DateTime dateTime25 = dateTime23.withMonthOfYear(1);
//        org.joda.time.DateTime dateTime27 = dateTime25.withDayOfYear((int) (byte) 1);
//        org.joda.time.LocalDate localDate28 = dateTime25.toLocalDate();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = skipUndoDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate28, (int) (byte) 0, locale30);
//        long long33 = skipUndoDateTimeField16.roundHalfFloor((long) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipUndoDateTimeField16.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, "");
//        org.joda.time.MutableDateTime.Property property37 = mutableDateTime4.property(dateTimeFieldType34);
//        mutableDateTime4.addMinutes(16);
//        org.joda.time.MutableDateTime.Property property40 = mutableDateTime4.weekyear();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28800000L + "'", long20 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28800000L + "'", long33 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(property40);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology10);
        long long15 = gJChronology10.add((long) 59, 200001L, (int) '4');
        org.joda.time.DurationField durationField16 = gJChronology10.years();
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((-593), (int) (short) -1, 6, 224, (-18059), 1969, (org.joda.time.Chronology) gJChronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 224 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10400111L + "'", long15 == 10400111L);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("2019-06-12T05:29:51.291-07:00");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime5);
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField10, 0);
        long long14 = skipUndoDateTimeField12.roundHalfEven((long) 2019);
        int int16 = skipUndoDateTimeField12.get((long) ' ');
        int int18 = skipUndoDateTimeField12.getMinimumValue(28800100L);
        org.joda.time.MutableDateTime mutableDateTime20 = org.joda.time.MutableDateTime.now();
        int int21 = mutableDateTime20.getYearOfEra();
        org.joda.time.Chronology chronology23 = null;
        java.util.Locale locale24 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket(100L, chronology23, locale24, (java.lang.Integer) 1);
        java.lang.Object obj27 = dateTimeParserBucket26.saveState();
        java.util.Locale locale28 = dateTimeParserBucket26.getLocale();
        java.util.Calendar calendar29 = mutableDateTime20.toCalendar(locale28);
        java.lang.String str30 = skipUndoDateTimeField12.getAsText(0, locale28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter3.withLocale(locale28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter0.withLocale(locale28);
        java.text.DateFormatSymbols dateFormatSymbols33 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale28);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800000L + "'", long14 == 28800000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(locale28);
        org.junit.Assert.assertNotNull(calendar29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0" + "'", str30.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateFormatSymbols33);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMonthOfYear(1);
        org.joda.time.DateTime dateTime8 = dateTime6.withDayOfYear((int) (byte) 1);
        org.joda.time.LocalDate localDate9 = dateTime6.toLocalDate();
        int int10 = property1.compareTo((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.MutableDateTime mutableDateTime11 = property1.roundHalfCeiling();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfEra(1);
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        org.joda.time.MutableDateTime mutableDateTime12 = property9.addWrapField((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime13 = property9.roundCeiling();
        int int14 = mutableDateTime13.getMillisOfDay();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime17.withZone(dateTimeZone18);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime13, (org.joda.time.ReadableInstant) dateTime20);
        int int23 = dateTime7.compareTo((org.joda.time.ReadableInstant) dateTime20);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime dateTime7 = dateTime4.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        org.joda.time.DateTime dateTime10 = property8.addToCopy(0L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
        org.joda.time.DurationField durationField6 = gJChronology4.months();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology4, locale7, (java.lang.Integer) 3395, (int) ' ');
        long long11 = dateTimeParserBucket10.computeMillis();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeParserBucket10.getZone();
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime(dateTimeZone12);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        java.lang.Object obj1 = mutableDateTime0.clone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 1, dateTimeZone3);
        int int5 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property8 = dateTime4.era();
        org.joda.time.DateTime dateTime10 = dateTime4.minusMinutes(1);
        org.joda.time.DateTime.Property property11 = dateTime10.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime13 = dateTime10.withDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("2019-06-12T01:40:01.310-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12T01:40:01.310-07:00\" is malformed at \"-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfEra(1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMonths(10);
        org.joda.time.DateTime dateTime11 = dateTime5.minusYears(2);
        org.joda.time.DateTime dateTime13 = dateTime5.plus((-210866760000000L));
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        java.lang.String str17 = dateTimeZone15.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime19 = dateTime13.toMutableDateTime(dateTimeZone15);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "America/Los_Angeles" + "'", str17.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
    }
}

