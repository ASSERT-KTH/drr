import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Duration duration3 = period1.toDurationFrom(readableInstant2);
        org.joda.time.Period period5 = period1.minusYears(3599999);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Seconds seconds5 = period4.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period4.get(durationFieldType6);
        org.joda.time.Duration duration8 = period4.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType10);
        org.joda.time.PeriodType periodType12 = periodType10.withMonthsRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PeriodType[YearDayTime]", "", 6, 8);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap5);
        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) strMap5);
        boolean boolean9 = fixedDateTimeZone4.isStandardOffset((long) ' ');
        long long13 = fixedDateTimeZone4.convertLocalToUTC(0L, false, 0L);
        org.junit.Assert.assertNotNull(strMap5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-6L) + "'", long13 == (-6L));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone10.getUncachedZone();
        int int13 = cachedDateTimeZone10.getOffset(35L);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology16 = zonedChronology14.withZone(dateTimeZone15);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology14);
        java.lang.String str18 = zonedChronology14.toString();
        org.joda.time.DateTimeZone dateTimeZone19 = zonedChronology14.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ZonedChronology[ISOChronology[UTC], +00:00:00.100]" + "'", str18.equals("ZonedChronology[ISOChronology[UTC], +00:00:00.100]"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.withMillis(100);
        int int6 = period1.getValue((int) (byte) 1);
        org.joda.time.Period period8 = period1.withMillis((int) (byte) 0);
        int int9 = period8.getDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period2 = period1.negated();
        int int3 = period1.getSeconds();
        org.joda.time.Period period5 = period1.multipliedBy(10);
        org.joda.time.Period period6 = period1.normalizedStandard();
        try {
            org.joda.time.DurationFieldType durationFieldType8 = period1.getFieldType(36);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test007");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        long long9 = offsetDateTimeField7.remainder(0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.Period period1 = org.joda.time.Period.months(37);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Seconds seconds5 = period4.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period4.get(durationFieldType6);
        org.joda.time.Duration duration8 = period4.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfYear();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.clockhourOfDay();
        org.joda.time.DurationField durationField15 = gregorianChronology12.eras();
        org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) readableInstant9, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology12.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology12.dayOfMonth();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        long long16 = unsupportedDateTimeField13.getDifferenceAsLong((long) 97, (long) (byte) 0);
        try {
            int int18 = unsupportedDateTimeField13.getLeapAmount((long) 35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.minuteOfDay();
        org.joda.time.Chronology chronology10 = iSOChronology5.withUTC();
        boolean boolean11 = lenientChronology2.equals((java.lang.Object) iSOChronology5);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long17 = dateTimeZone13.getMillisKeepLocal(dateTimeZone15, 0L);
        long long20 = dateTimeZone13.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
        java.lang.String str23 = cachedDateTimeZone21.getName((long) 97);
        java.lang.String str25 = cachedDateTimeZone21.getShortName(62L);
        org.joda.time.Chronology chronology26 = lenientChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone21);
        long long28 = cachedDateTimeZone21.previousTransition((-12960003600001L));
        long long30 = cachedDateTimeZone21.nextTransition(101L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3600010L + "'", long20 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-01:00" + "'", str23.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-01:00" + "'", str25.equals("-01:00"));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-12960003600001L) + "'", long28 == (-12960003600001L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 101L + "'", long30 == 101L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.hours();
        org.joda.time.Chronology chronology4 = iSOChronology2.withUTC();
        org.joda.time.DurationField durationField5 = iSOChronology2.centuries();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (short) 100, "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DurationField durationField14 = lenientChronology11.millis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology18 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField19 = lenientChronology17.centuries();
        org.joda.time.DurationField durationField20 = lenientChronology17.millis();
        org.joda.time.Chronology chronology21 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField22 = lenientChronology17.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField23 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField22);
        long long24 = preciseDateTimeField23.getUnitMillis();
        int int26 = preciseDateTimeField23.getLeapAmount((-100L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period3 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period5 = period3.plusWeeks((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationTo(readableInstant6);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.millis();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        java.lang.String str11 = periodType8.toString();
        org.joda.time.PeriodType periodType12 = periodType8.withMinutesRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration7, periodType12);
        long long14 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration7);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7);
        org.joda.time.Period period17 = period15.plusSeconds(6);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(0L, 0L, periodType22, chronology23);
        boolean boolean26 = periodType22.equals((java.lang.Object) 0);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology29 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology27);
        org.joda.time.Chronology chronology30 = lenientChronology29.withUTC();
        org.joda.time.DurationField durationField31 = lenientChronology29.centuries();
        org.joda.time.DateTimeField dateTimeField32 = lenientChronology29.clockhourOfHalfday();
        org.joda.time.Period period33 = new org.joda.time.Period(62L, (long) (-3600000), periodType22, (org.joda.time.Chronology) lenientChronology29);
        org.joda.time.PeriodType periodType34 = org.joda.time.DateTimeUtils.getPeriodType(periodType22);
        org.joda.time.Period period35 = period15.withPeriodType(periodType34);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PeriodType[Millis]" + "'", str11.equals("PeriodType[Millis]"));
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3120000L + "'", long14 == 3120000L);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(lenientChronology29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(period35);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, 3599999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 3599999");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) 10);
        org.joda.time.Period period3 = org.joda.time.Period.seconds(1);
        org.joda.time.Period period5 = period3.multipliedBy(35);
        boolean boolean6 = period1.equals((java.lang.Object) 35);
        org.joda.time.Period period8 = org.joda.time.Period.years(0);
        org.joda.time.Period period9 = period1.plus((org.joda.time.ReadablePeriod) period8);
        int int10 = period1.getMonths();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Period period6 = period4.plusHours(1);
        org.joda.time.Period period7 = period6.negated();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.dayOfYear();
        boolean boolean11 = gregorianChronology8.equals((java.lang.Object) (-149));
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology8.millisOfDay();
        boolean boolean14 = period7.equals((java.lang.Object) gregorianChronology8);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 0);
        org.joda.time.PeriodType periodType2 = period1.getPeriodType();
        org.joda.time.Period period4 = period1.withDays(136);
        org.joda.time.Period period6 = period4.withHours(97);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test023");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.Chronology chronology5 = lenientChronology4.withUTC();
//        org.joda.time.DurationField durationField6 = lenientChronology4.centuries();
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology4.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.secondOfMinute();
//        org.joda.time.DurationField durationField14 = iSOChronology11.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField14);
//        org.joda.time.DurationField durationField16 = unsupportedDateTimeField15.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = unsupportedDateTimeField15.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType17, 6, (int) (short) 1, (int) (byte) -1);
//        long long23 = offsetDateTimeField21.roundHalfCeiling((long) (short) 100);
//        java.lang.String str25 = offsetDateTimeField21.getAsShortText((long) (-33307296));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(lenientChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "371" + "'", str25.equals("371"));
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = unsupportedDateTimeField13.getType();
        java.util.Locale locale18 = null;
        try {
            long long19 = unsupportedDateTimeField13.set(349200000L, "47", locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "136");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone10.getUncachedZone();
        int int13 = cachedDateTimeZone10.getOffset(35L);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology16 = zonedChronology14.withZone(dateTimeZone15);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology14);
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology14.clockhourOfHalfday();
        try {
            long long26 = zonedChronology14.getDateTimeMillis(3600000, (-33307296), (int) (byte) 0, (int) (byte) 1, (int) 'a', (int) ' ', (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period2 = period1.negated();
        int int3 = period1.getSeconds();
        org.joda.time.Period period5 = period1.multipliedBy(10);
        org.joda.time.Period period6 = period1.normalizedStandard();
        org.joda.time.Period period8 = period6.withSeconds(10);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(0L, 0L, periodType15, chronology16);
        boolean boolean19 = periodType15.equals((java.lang.Object) 0);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology22 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology20);
        org.joda.time.Chronology chronology23 = lenientChronology22.withUTC();
        org.joda.time.DurationField durationField24 = lenientChronology22.centuries();
        org.joda.time.DateTimeField dateTimeField25 = lenientChronology22.clockhourOfHalfday();
        org.joda.time.Period period26 = new org.joda.time.Period(62L, (long) (-3600000), periodType15, (org.joda.time.Chronology) lenientChronology22);
        org.joda.time.PeriodType periodType27 = org.joda.time.DateTimeUtils.getPeriodType(periodType15);
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType27);
        org.joda.time.PeriodType periodType29 = periodType27.withYearsRemoved();
        org.joda.time.Period period30 = period8.withPeriodType(periodType27);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(lenientChronology22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(period30);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        long long6 = iSOChronology2.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.year();
        org.joda.time.DurationField durationField9 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.weekyearOfCentury();
        boolean boolean12 = period1.equals((java.lang.Object) dateTimeField11);
        org.joda.time.Period period14 = period1.plusMinutes((int) (short) 0);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType17 = null;
        int int18 = period16.indexOf(durationFieldType17);
        org.joda.time.DurationFieldType durationFieldType19 = null;
        int int20 = period16.get(durationFieldType19);
        org.joda.time.Period period22 = period16.minusDays((int) (byte) 1);
        org.joda.time.Period period23 = new org.joda.time.Period((java.lang.Object) period22);
        org.joda.time.Period period24 = period14.minus((org.joda.time.ReadablePeriod) period23);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test029");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
//        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField7.getType();
//        org.joda.time.DurationField durationField13 = offsetDateTimeField7.getRangeDurationField();
//        long long15 = offsetDateTimeField7.roundHalfEven(422000L);
//        int int17 = offsetDateTimeField7.getMaximumValue((long) 36);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 47 + "'", int17 == 47);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (short) 10);
        org.joda.time.Period period4 = period2.plusWeeks((-3600000));
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(0L, 0L, periodType9, chronology10);
        boolean boolean13 = periodType9.equals((java.lang.Object) 0);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology16 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.Chronology chronology17 = lenientChronology16.withUTC();
        org.joda.time.DurationField durationField18 = lenientChronology16.centuries();
        org.joda.time.DateTimeField dateTimeField19 = lenientChronology16.clockhourOfHalfday();
        org.joda.time.Period period20 = new org.joda.time.Period(62L, (long) (-3600000), periodType9, (org.joda.time.Chronology) lenientChronology16);
        org.joda.time.PeriodType periodType21 = org.joda.time.DateTimeUtils.getPeriodType(periodType9);
        org.joda.time.PeriodType periodType22 = periodType21.withYearsRemoved();
        org.joda.time.PeriodType periodType23 = periodType22.withYearsRemoved();
        org.joda.time.Period period24 = period2.normalizedStandard(periodType23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone26);
        org.joda.time.DateTimeZone dateTimeZone28 = cachedDateTimeZone27.getUncachedZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone27);
        org.joda.time.Period period30 = new org.joda.time.Period((-1L), periodType23, (org.joda.time.Chronology) gregorianChronology29);
        int int31 = period30.getSeconds();
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(lenientChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField4 = lenientChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology3.weekyear();
        org.joda.time.Period period7 = new org.joda.time.Period((-210858120000000L), (org.joda.time.Chronology) lenientChronology3);
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology3.millisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) 10);
        org.joda.time.Period period3 = org.joda.time.Period.seconds(1);
        org.joda.time.Period period5 = period3.multipliedBy(35);
        boolean boolean6 = period1.equals((java.lang.Object) 35);
        org.joda.time.Period period8 = org.joda.time.Period.years(0);
        org.joda.time.Period period9 = period1.plus((org.joda.time.ReadablePeriod) period8);
        try {
            int int11 = period8.getValue(349200000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("39");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"39\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 0L);
        long long8 = dateTimeZone1.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean10 = cachedDateTimeZone9.isFixed();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(0L, 0L, periodType13, chronology14);
        org.joda.time.PeriodType periodType16 = periodType13.withWeeksRemoved();
        boolean boolean17 = cachedDateTimeZone9.equals((java.lang.Object) periodType13);
        long long19 = cachedDateTimeZone9.nextTransition((long) 10);
        long long21 = cachedDateTimeZone9.nextTransition((long) (short) 1);
        long long23 = cachedDateTimeZone9.previousTransition((long) (byte) 0);
        long long25 = cachedDateTimeZone9.previousTransition(422000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600010L + "'", long8 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 422000L + "'", long25 == 422000L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((-1));
        org.joda.time.Period period3 = period1.minusYears((int) (short) 10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(0L, 0L, periodType4, chronology5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType4, chronology7);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType4.indexOf(durationFieldType9);
        org.joda.time.Period period12 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType13 = null;
        int int14 = period12.indexOf(durationFieldType13);
        org.joda.time.DurationFieldType durationFieldType16 = period12.getFieldType(0);
        int int17 = periodType4.indexOf(durationFieldType16);
        org.joda.time.field.PreciseDurationField preciseDurationField19 = new org.joda.time.field.PreciseDurationField(durationFieldType16, 0L);
        org.joda.time.DurationFieldType durationFieldType20 = preciseDurationField19.getType();
        try {
            long long22 = preciseDurationField19.getValueAsLong((long) 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(durationFieldType20);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) 10);
        org.joda.time.Period period3 = org.joda.time.Period.seconds(1);
        org.joda.time.Period period5 = period3.multipliedBy(35);
        boolean boolean6 = period1.equals((java.lang.Object) 35);
        org.joda.time.Minutes minutes7 = period1.toStandardMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(minutes7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone10.getUncachedZone();
        int int13 = cachedDateTimeZone10.getOffset(35L);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.DateTimeField dateTimeField15 = zonedChronology14.millisOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology18 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Chronology chronology19 = lenientChronology18.withUTC();
        org.joda.time.DurationField durationField20 = lenientChronology18.centuries();
        org.joda.time.DateTimeField dateTimeField21 = lenientChronology18.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField23.getType();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology27 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology25);
        org.joda.time.Chronology chronology28 = lenientChronology27.withUTC();
        org.joda.time.DurationField durationField29 = lenientChronology27.centuries();
        org.joda.time.DurationField durationField30 = lenientChronology27.millis();
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology33 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology31);
        org.joda.time.Chronology chronology34 = lenientChronology33.withUTC();
        org.joda.time.DurationField durationField35 = lenientChronology33.centuries();
        org.joda.time.DurationField durationField36 = lenientChronology33.millis();
        org.joda.time.Chronology chronology37 = lenientChronology33.withUTC();
        org.joda.time.DurationField durationField38 = lenientChronology33.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField39 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType24, durationField30, durationField38);
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, "1");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, dateTimeFieldType24, (-1));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(lenientChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(lenientChronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(lenientChronology33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(durationField38);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField7.getType();
        java.lang.String str14 = offsetDateTimeField7.getAsText(1L);
        boolean boolean15 = offsetDateTimeField7.isLenient();
        java.lang.String str17 = offsetDateTimeField7.getAsShortText(3600000L);
        java.lang.String str19 = offsetDateTimeField7.getAsShortText((long) 33);
        int int20 = offsetDateTimeField7.getOffset();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "47" + "'", str14.equals("47"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "36" + "'", str17.equals("36"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "47" + "'", str19.equals("47"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 35 + "'", int20 == 35);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        org.joda.time.Period period13 = period11.plusMinutes(10);
        org.joda.time.Period period15 = period13.minusDays(0);
        org.joda.time.Period period17 = period13.minusMonths(2230000);
        org.joda.time.Period period19 = period13.withDays(2);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply(30108833654400000L, 126000004L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 30108833654400000 * 126000004");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DurationField durationField14 = lenientChronology11.millis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology18 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField19 = lenientChronology17.centuries();
        org.joda.time.DurationField durationField20 = lenientChronology17.millis();
        org.joda.time.Chronology chronology21 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField22 = lenientChronology17.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField23 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField22);
        org.joda.time.DurationField durationField24 = preciseDateTimeField23.getRangeDurationField();
        long long26 = preciseDateTimeField23.roundCeiling((long) '#');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        long long17 = unsupportedDateTimeField13.add(97L, (int) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = unsupportedDateTimeField13.getType();
        long long21 = unsupportedDateTimeField13.getDifferenceAsLong((long) (short) 10, (long) (short) -1);
        org.joda.time.ReadablePartial readablePartial22 = null;
        java.util.Locale locale23 = null;
        try {
            java.lang.String str24 = unsupportedDateTimeField13.getAsText(readablePartial22, locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 96L + "'", long17 == 96L);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 11L + "'", long21 == 11L);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test044");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DurationField durationField5 = lenientChronology2.millis();
//        org.joda.time.DurationField durationField6 = lenientChronology2.days();
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) lenientChronology2, dateTimeZone8);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = zonedChronology9.equals(obj10);
//        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology9.getZone();
//        long long18 = zonedChronology9.getDateTimeMillis(86399900L, (int) (byte) 0, 32, 7, (int) (short) 100);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(zonedChronology9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1927100L + "'", long18 == 1927100L);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-12960003600001L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2290587.458333322d + "'", double1 == 2290587.458333322d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.months(0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationFrom(readableInstant3);
        long long5 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration4, readableInstant6, periodType7);
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration4);
        java.lang.Object obj11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology12.minuteOfDay();
        org.joda.time.DurationField durationField17 = iSOChronology12.days();
        org.joda.time.DurationField durationField18 = iSOChronology12.weekyears();
        org.joda.time.Period period19 = new org.joda.time.Period(obj11, (org.joda.time.Chronology) iSOChronology12);
        int int20 = period19.getMonths();
        boolean boolean21 = period10.equals((java.lang.Object) period19);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long7 = dateTimeZone3.getMillisKeepLocal(dateTimeZone5, 0L);
        long long10 = dateTimeZone3.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        boolean boolean12 = cachedDateTimeZone11.isFixed();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(0L, 0L, periodType15, chronology16);
        org.joda.time.PeriodType periodType18 = periodType15.withWeeksRemoved();
        boolean boolean19 = cachedDateTimeZone11.equals((java.lang.Object) periodType15);
        org.joda.time.PeriodType periodType20 = periodType15.withSecondsRemoved();
        org.joda.time.Period period21 = new org.joda.time.Period((-65L), (long) 47, periodType15);
        org.joda.time.PeriodType periodType22 = periodType15.withWeeksRemoved();
        java.lang.String str23 = periodType15.toString();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600010L + "'", long10 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PeriodType[YearDayTime]" + "'", str23.equals("PeriodType[YearDayTime]"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        boolean boolean15 = unsupportedDateTimeField13.isLenient();
        try {
            java.lang.String str17 = unsupportedDateTimeField13.getAsShortText(3599900L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.dayOfYear();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder9.setStandardOffset(33);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder11.setStandardOffset(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder11.setFixedSavings("", (-3600000));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder16.setFixedSavings("PeriodType[YearDayTime]", (int) (short) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder16.setFixedSavings("GregorianChronology[+00:00:00.100]", (int) '#');
        boolean boolean23 = iSOChronology0.equals((java.lang.Object) "GregorianChronology[+00:00:00.100]");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-01:00");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long8 = dateTimeZone4.getMillisKeepLocal(dateTimeZone6, 0L);
        long long11 = dateTimeZone4.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        boolean boolean13 = cachedDateTimeZone12.isFixed();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(0L, 0L, periodType16, chronology17);
        org.joda.time.PeriodType periodType19 = periodType16.withWeeksRemoved();
        boolean boolean20 = cachedDateTimeZone12.equals((java.lang.Object) periodType16);
        long long22 = cachedDateTimeZone12.nextTransition((long) 10);
        jodaTimePermission1.checkGuard((java.lang.Object) long22);
        java.lang.String str24 = jodaTimePermission1.getActions();
        java.lang.String str25 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-01:00" + "'", str25.equals("-01:00"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(0L, 0L, periodType4, chronology5);
        org.joda.time.PeriodType periodType7 = periodType4.withWeeksRemoved();
        org.joda.time.Period period8 = new org.joda.time.Period(3600010L, (long) 2230000, periodType7);
        org.joda.time.PeriodType periodType9 = periodType7.withMonthsRemoved();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        org.joda.time.Period period13 = period11.plusMinutes(10);
        org.joda.time.Period period15 = period13.minusDays(0);
        org.joda.time.Period period17 = period13.minusMonths(2230000);
        org.joda.time.PeriodType periodType18 = period17.getPeriodType();
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField7.getType();
        java.lang.String str14 = offsetDateTimeField7.getAsText(1L);
        int int16 = offsetDateTimeField7.getMaximumValue((long) (byte) -1);
        long long19 = offsetDateTimeField7.addWrapField((-100L), 0);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.Chronology chronology24 = lenientChronology23.withUTC();
        org.joda.time.DurationField durationField25 = lenientChronology23.centuries();
        org.joda.time.DateTimeField dateTimeField26 = lenientChronology23.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField28.getType();
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsText(35, locale31);
        long long35 = offsetDateTimeField28.add(10L, (int) 'a');
        int int37 = offsetDateTimeField28.getMaximumValue((long) 97);
        org.joda.time.DurationField durationField38 = offsetDateTimeField28.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial39 = null;
        int[] intArray44 = new int[] { (byte) 10, (-3600000), (short) 0 };
        int[] intArray46 = offsetDateTimeField28.addWrapPartial(readablePartial39, 0, intArray44, 0);
        int int47 = offsetDateTimeField7.getMaximumValue(readablePartial20, intArray44);
        try {
            long long50 = offsetDateTimeField7.set((-126000000L), (-149));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -149 for clockhourOfHalfday must be in the range [36,47]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "47" + "'", str14.equals("47"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 47 + "'", int16 == 47);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-100L) + "'", long19 == (-100L));
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "35" + "'", str32.equals("35"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 349200010L + "'", long35 == 349200010L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 47 + "'", int37 == 47);
        org.junit.Assert.assertNull(durationField38);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 47 + "'", int47 == 47);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        int int10 = offsetDateTimeField7.getLeapAmount((long) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology15 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Chronology chronology16 = lenientChronology15.withUTC();
        org.joda.time.DurationField durationField17 = lenientChronology15.centuries();
        org.joda.time.DateTimeField dateTimeField18 = lenientChronology15.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfDay();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.secondOfMinute();
        org.joda.time.DurationField durationField25 = iSOChronology22.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
        org.joda.time.DurationField durationField27 = unsupportedDateTimeField26.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = unsupportedDateTimeField26.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType28, 6, (int) (short) 1, (int) (byte) -1);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType28, 4);
        long long37 = dividedDateTimeField34.addWrapField((long) 97, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(lenientChronology15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        int int17 = unsupportedDateTimeField13.getDifference(2590588L, 3599900L);
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.dayOfYear();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.clockhourOfDay();
        org.joda.time.DurationField durationField23 = gregorianChronology20.eras();
        org.joda.time.Period period25 = org.joda.time.Period.months(0);
        int[] intArray27 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period25, (long) (-1));
        try {
            int[] intArray29 = unsupportedDateTimeField13.add(readablePartial18, (int) '4', intArray27, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1009312) + "'", int17 == (-1009312));
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.lang.Throwable throwable0 = null;
        try {
            boolean boolean1 = org.joda.time.IllegalInstantException.isIllegalInstant(throwable0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        int int17 = unsupportedDateTimeField13.getDifference((long) (-52), (long) 'a');
        org.joda.time.ReadablePartial readablePartial18 = null;
        try {
            int int19 = unsupportedDateTimeField13.getMaximumValue(readablePartial18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-149) + "'", int17 == (-149));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        boolean boolean14 = unsupportedDateTimeField13.isSupported();
        long long17 = unsupportedDateTimeField13.add(100L, (-2440587L));
        org.joda.time.DurationField durationField18 = unsupportedDateTimeField13.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2440487L) + "'", long17 == (-2440487L));
        org.junit.Assert.assertNull(durationField18);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.joda.time.Period period3 = period1.withMillis((int) '#');
        org.joda.time.Period period5 = period1.minusSeconds(0);
        org.joda.time.Period period7 = period1.plusWeeks(2);
        int int9 = period7.getValue(6);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone9);
        org.joda.time.Chronology chronology11 = zonedChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology10.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology10.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (short) 100, "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 33, (java.lang.Number) (short) -1, (java.lang.Number) 100.0d);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = illegalFieldValueException15.getDateTimeFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType16, 1, 0, (int) '4');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField13.getRangeDurationField();
        boolean boolean16 = unsupportedDateTimeField13.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 100, 47);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4700L + "'", long2 == 4700L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 0);
        org.joda.time.Period period3 = period1.plusMillis((int) (byte) -1);
        org.joda.time.Period period5 = period1.minusDays(33);
        org.joda.time.Period period7 = period5.plusSeconds(136);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test066");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
//        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = offsetDateTimeField7.getAsText(0, locale13);
//        int int16 = offsetDateTimeField7.getMinimumValue((long) 100);
//        long long18 = offsetDateTimeField7.roundHalfCeiling((-100L));
//        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField7.getWrappedField();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField7.getAsText(8, locale21);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 36 + "'", int16 == 36);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "8" + "'", str22.equals("8"));
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test067");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTimeField dateTimeField3 = lenientChronology2.secondOfDay();
//        java.lang.String str4 = lenientChronology2.toString();
//        org.joda.time.DurationField durationField5 = lenientChronology2.minutes();
//        boolean boolean7 = lenientChronology2.equals((java.lang.Object) (byte) 1);
//        java.lang.Object obj8 = null;
//        boolean boolean9 = lenientChronology2.equals(obj8);
//        org.joda.time.DateTimeField dateTimeField10 = lenientChronology2.secondOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LenientChronology[ISOChronology[]]" + "'", str4.equals("LenientChronology[ISOChronology[]]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-12781));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        int int10 = offsetDateTimeField7.getLeapAmount((long) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology15 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Chronology chronology16 = lenientChronology15.withUTC();
        org.joda.time.DurationField durationField17 = lenientChronology15.centuries();
        org.joda.time.DateTimeField dateTimeField18 = lenientChronology15.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfDay();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.secondOfMinute();
        org.joda.time.DurationField durationField25 = iSOChronology22.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
        org.joda.time.DurationField durationField27 = unsupportedDateTimeField26.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = unsupportedDateTimeField26.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType28, 6, (int) (short) 1, (int) (byte) -1);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType28, 4);
        int int37 = dividedDateTimeField34.getDifference(62L, (long) (-37));
        long long40 = dividedDateTimeField34.add((-2440587L), 35);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(lenientChronology15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 501559413L + "'", long40 == 501559413L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(0L, 0L, periodType4, chronology5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType4, chronology7);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType4.indexOf(durationFieldType9);
        org.joda.time.Period period12 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType13 = null;
        int int14 = period12.indexOf(durationFieldType13);
        org.joda.time.DurationFieldType durationFieldType16 = period12.getFieldType(0);
        int int17 = periodType4.indexOf(durationFieldType16);
        org.joda.time.field.PreciseDurationField preciseDurationField19 = new org.joda.time.field.PreciseDurationField(durationFieldType16, 0L);
        org.joda.time.DurationFieldType durationFieldType20 = preciseDurationField19.getType();
        try {
            int int22 = preciseDurationField19.getValue((-3600136L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(durationFieldType20);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test071");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) (-149));
//        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology6);
//        org.joda.time.Chronology chronology9 = lenientChronology8.withUTC();
//        org.joda.time.DurationField durationField10 = lenientChronology8.centuries();
//        org.joda.time.DateTimeField dateTimeField11 = lenientChronology8.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField13.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
//        org.joda.time.Chronology chronology18 = lenientChronology17.withUTC();
//        org.joda.time.DurationField durationField19 = lenientChronology17.centuries();
//        org.joda.time.DurationField durationField20 = lenientChronology17.millis();
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology21);
//        org.joda.time.Chronology chronology24 = lenientChronology23.withUTC();
//        org.joda.time.DurationField durationField25 = lenientChronology23.centuries();
//        org.joda.time.DurationField durationField26 = lenientChronology23.millis();
//        org.joda.time.Chronology chronology27 = lenientChronology23.withUTC();
//        org.joda.time.DurationField durationField28 = lenientChronology23.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField29 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType14, durationField20, durationField28);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType14, (int) '#', 3599999, 32);
//        long long35 = offsetDateTimeField33.remainder((long) 5);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(lenientChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(lenientChronology17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(lenientChronology23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 259200005L + "'", long35 == 259200005L);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 0L);
        long long8 = dateTimeZone1.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean10 = cachedDateTimeZone9.isFixed();
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = cachedDateTimeZone9.isLocalDateTimeGap(localDateTime11);
        long long14 = cachedDateTimeZone9.previousTransition((long) 'a');
        boolean boolean15 = cachedDateTimeZone9.isFixed();
        long long17 = cachedDateTimeZone9.nextTransition(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600010L + "'", long8 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField7.getMaximumValue(readablePartial12);
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField7.getWrappedField();
        int int16 = offsetDateTimeField7.getLeapAmount((long) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 47 + "'", int13 == 47);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "-01:00", 0, 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long10 = dateTimeZone6.getMillisKeepLocal(dateTimeZone8, 0L);
        long long13 = dateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        boolean boolean15 = cachedDateTimeZone14.isFixed();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(0L, 0L, periodType18, chronology19);
        org.joda.time.PeriodType periodType21 = periodType18.withWeeksRemoved();
        boolean boolean22 = cachedDateTimeZone14.equals((java.lang.Object) periodType18);
        long long24 = cachedDateTimeZone14.nextTransition((long) 10);
        long long26 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone14, (-100L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone14);
        long long29 = cachedDateTimeZone14.previousTransition(0L);
        long long31 = cachedDateTimeZone14.nextTransition((long) 2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600010L + "'", long13 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 3599900L + "'", long26 == 3599900L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2L + "'", long31 == 2L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period10 = period9.toPeriod();
        org.joda.time.Period period12 = period9.withYears((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.Period period14 = period9.withFields(readablePeriod13);
        int int15 = period9.getDays();
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField7.getType();
        java.lang.String str14 = offsetDateTimeField7.getAsText(1L);
        int int16 = offsetDateTimeField7.getMaximumValue((long) (byte) -1);
        long long19 = offsetDateTimeField7.addWrapField((-100L), 0);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.Chronology chronology24 = lenientChronology23.withUTC();
        org.joda.time.DurationField durationField25 = lenientChronology23.centuries();
        org.joda.time.DateTimeField dateTimeField26 = lenientChronology23.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField28.getType();
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsText(35, locale31);
        long long35 = offsetDateTimeField28.add(10L, (int) 'a');
        int int37 = offsetDateTimeField28.getMaximumValue((long) 97);
        org.joda.time.DurationField durationField38 = offsetDateTimeField28.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial39 = null;
        int[] intArray44 = new int[] { (byte) 10, (-3600000), (short) 0 };
        int[] intArray46 = offsetDateTimeField28.addWrapPartial(readablePartial39, 0, intArray44, 0);
        int int47 = offsetDateTimeField7.getMaximumValue(readablePartial20, intArray44);
        int int49 = offsetDateTimeField7.getLeapAmount(30108833654399968L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "47" + "'", str14.equals("47"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 47 + "'", int16 == 47);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-100L) + "'", long19 == (-100L));
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "35" + "'", str32.equals("35"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 349200010L + "'", long35 == 349200010L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 47 + "'", int37 == 47);
        org.junit.Assert.assertNull(durationField38);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 47 + "'", int47 == 47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 6, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.year();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "-01:00", 0, 1);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long18 = dateTimeZone14.getMillisKeepLocal(dateTimeZone16, 0L);
        long long21 = dateTimeZone14.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        boolean boolean23 = cachedDateTimeZone22.isFixed();
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(0L, 0L, periodType26, chronology27);
        org.joda.time.PeriodType periodType29 = periodType26.withWeeksRemoved();
        boolean boolean30 = cachedDateTimeZone22.equals((java.lang.Object) periodType26);
        long long32 = cachedDateTimeZone22.nextTransition((long) 10);
        long long34 = fixedDateTimeZone12.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone22, (-100L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone35 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
        int int37 = cachedDateTimeZone22.getStandardOffset(96L);
        org.joda.time.chrono.ZonedChronology zonedChronology38 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone22);
        org.joda.time.ReadablePartial readablePartial39 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int41 = gregorianChronology40.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField42 = gregorianChronology40.weeks();
        org.joda.time.PeriodType periodType51 = null;
        org.joda.time.Period period52 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType51);
        org.joda.time.Period period54 = period52.withWeeks(10);
        org.joda.time.Period period56 = period52.plusMonths((int) ' ');
        int[] intArray58 = gregorianChronology40.get((org.joda.time.ReadablePeriod) period52, (-3600001L));
        try {
            iSOChronology0.validate(readablePartial39, intArray58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3600010L + "'", long21 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3599900L + "'", long34 == 3599900L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-3600000) + "'", int37 == (-3600000));
        org.junit.Assert.assertNotNull(zonedChronology38);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(intArray58);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test079");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.Chronology chronology5 = lenientChronology4.withUTC();
//        org.joda.time.DurationField durationField6 = lenientChronology4.centuries();
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology4.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.secondOfMinute();
//        org.joda.time.DurationField durationField14 = iSOChronology11.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField14);
//        org.joda.time.DurationField durationField16 = unsupportedDateTimeField15.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = unsupportedDateTimeField15.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType17, 6, (int) (short) 1, (int) (byte) -1);
//        int int23 = offsetDateTimeField21.getLeapAmount((long) (byte) 10);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField21.getAsText((long) (byte) 10, locale25);
//        java.lang.String str27 = offsetDateTimeField21.getName();
//        long long29 = offsetDateTimeField21.roundHalfCeiling((-58571700L));
//        org.joda.time.ReadablePartial readablePartial30 = null;
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = offsetDateTimeField21.getAsText(readablePartial30, (int) (byte) 100, locale32);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(lenientChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "7" + "'", str26.equals("7"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "clockhourOfHalfday" + "'", str27.equals("clockhourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-86400000L) + "'", long29 == (-86400000L));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) (-149));
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.Period period1 = org.joda.time.Period.hours(35);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(0L, 0L, periodType4, chronology5);
        org.joda.time.Seconds seconds7 = period6.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period6.get(durationFieldType8);
        int int10 = period6.getMinutes();
        org.joda.time.Period period12 = period6.plusYears((int) (short) 100);
        org.joda.time.Period period14 = period6.minusMillis(1);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (short) 0);
        org.joda.time.Period period17 = period6.minus((org.joda.time.ReadablePeriod) period16);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(0L, 0L, periodType22, chronology23);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType22, chronology25);
        org.joda.time.DurationFieldType durationFieldType27 = null;
        int int28 = periodType22.indexOf(durationFieldType27);
        org.joda.time.Period period30 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType31 = null;
        int int32 = period30.indexOf(durationFieldType31);
        org.joda.time.DurationFieldType durationFieldType34 = period30.getFieldType(0);
        int int35 = periodType22.indexOf(durationFieldType34);
        int int36 = period16.indexOf(durationFieldType34);
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(durationFieldType34, (java.lang.Number) (-12960000000001L), (java.lang.Number) 4L, (java.lang.Number) (-125999900L));
        int int41 = period1.indexOf(durationFieldType34);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(seconds7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology2.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.joda.time.Period period3 = period1.withMillis((int) '#');
        org.joda.time.Period period5 = period1.minusMonths((-52));
        org.joda.time.Period period7 = period5.plusHours((-12781));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DurationField durationField14 = lenientChronology11.millis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology18 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField19 = lenientChronology17.centuries();
        org.joda.time.DurationField durationField20 = lenientChronology17.millis();
        org.joda.time.Chronology chronology21 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField22 = lenientChronology17.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField23 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField22);
        long long24 = preciseDateTimeField23.getUnitMillis();
        long long27 = preciseDateTimeField23.addWrapField(0L, (int) 'a');
        long long30 = preciseDateTimeField23.set((-3060892800100L), 97);
        int int32 = preciseDateTimeField23.getMaximumValue(86399900L);
        long long34 = preciseDateTimeField23.roundFloor((long) 47);
        long long37 = preciseDateTimeField23.addWrapField((-125999900L), 46);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-3060896399903L) + "'", long30 == (-3060896399903L));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3599999 + "'", int32 == 3599999);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 47L + "'", long34 == 47L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-125999854L) + "'", long37 == (-125999854L));
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test085");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
//        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
//        int int11 = offsetDateTimeField7.getOffset();
//        org.joda.time.ReadablePartial readablePartial12 = null;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = offsetDateTimeField7.getAsShortText(readablePartial12, 6, locale14);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology18 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology16);
//        org.joda.time.Chronology chronology19 = lenientChronology18.withUTC();
//        org.joda.time.DurationField durationField20 = lenientChronology18.centuries();
//        org.joda.time.DateTimeField dateTimeField21 = lenientChronology18.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField23.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) (short) 100, "");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType24, (-3600000));
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology32 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology30);
//        org.joda.time.Chronology chronology33 = lenientChronology32.withUTC();
//        org.joda.time.DurationField durationField34 = lenientChronology32.centuries();
//        org.joda.time.DateTimeField dateTimeField35 = lenientChronology32.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField37.getType();
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = offsetDateTimeField37.getAsText(35, locale40);
//        org.joda.time.ReadablePartial readablePartial42 = null;
//        int int43 = offsetDateTimeField37.getMaximumValue(readablePartial42);
//        org.joda.time.DurationField durationField44 = offsetDateTimeField37.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField44);
//        java.lang.String str46 = unsupportedDateTimeField45.getName();
//        try {
//            boolean boolean48 = unsupportedDateTimeField45.isLeap((long) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "6" + "'", str15.equals("6"));
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(lenientChronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(lenientChronology32);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "35" + "'", str41.equals("35"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 47 + "'", int43 == 47);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "clockhourOfHalfday" + "'", str46.equals("clockhourOfHalfday"));
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DurationField durationField5 = lenientChronology2.millis();
        org.joda.time.DurationField durationField6 = lenientChronology2.days();
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) lenientChronology2, dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology9.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "-01:00", 0, 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long10 = dateTimeZone6.getMillisKeepLocal(dateTimeZone8, 0L);
        long long13 = dateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        boolean boolean15 = cachedDateTimeZone14.isFixed();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(0L, 0L, periodType18, chronology19);
        org.joda.time.PeriodType periodType21 = periodType18.withWeeksRemoved();
        boolean boolean22 = cachedDateTimeZone14.equals((java.lang.Object) periodType18);
        long long24 = cachedDateTimeZone14.nextTransition((long) 10);
        long long26 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone14, (-100L));
        long long28 = fixedDateTimeZone4.nextTransition((-3599990L));
        long long30 = fixedDateTimeZone4.previousTransition(126000004L);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long36 = dateTimeZone32.getMillisKeepLocal(dateTimeZone34, 0L);
        long long39 = dateTimeZone32.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone40 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone32);
        int int42 = dateTimeZone32.getOffsetFromLocal((long) (short) 10);
        long long44 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone32, 1104364800014L);
        java.util.TimeZone timeZone45 = dateTimeZone32.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forTimeZone(timeZone45);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600010L + "'", long13 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 3599900L + "'", long26 == 3599900L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-3599990L) + "'", long28 == (-3599990L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 126000004L + "'", long30 == 126000004L);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 3600010L + "'", long39 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-3600000) + "'", int42 == (-3600000));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1104368400014L + "'", long44 == 1104368400014L);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField3 = gregorianChronology1.weeks();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Period period6 = period4.minusMillis((-149));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period3 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period5 = period3.plusWeeks((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationTo(readableInstant6);
        long long8 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration7);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration7, periodType9);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7);
        org.joda.time.Period period13 = period11.plusMinutes(361009311);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3120000L + "'", long8 == 3120000L);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.multipliedBy(47);
        org.joda.time.Period period6 = period1.multipliedBy((int) (short) 1);
        org.joda.time.Days days7 = period1.toStandardDays();
        org.joda.time.Period period9 = period1.plusMonths(10);
        int int10 = period1.getMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(days7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (short) 100, "");
        java.lang.Throwable[] throwableArray12 = illegalFieldValueException11.getSuppressed();
        java.lang.String str13 = illegalFieldValueException11.toString();
        java.lang.Number number14 = illegalFieldValueException11.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType15 = illegalFieldValueException11.getDurationFieldType();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100 for clockhourOfHalfday is not supported: " + "'", str13.equals("org.joda.time.IllegalFieldValueException: Value 100 for clockhourOfHalfday is not supported: "));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 100 + "'", number14.equals((short) 100));
        org.junit.Assert.assertNull(durationFieldType15);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.hours();
        org.joda.time.Chronology chronology4 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.Chronology chronology9 = lenientChronology8.withUTC();
        org.joda.time.DurationField durationField10 = lenientChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField11 = lenientChronology8.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (short) 100, "");
        illegalFieldValueException17.prependMessage("0");
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = illegalFieldValueException17.getDateTimeFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType20, 32);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.Period period5 = period1.minusSeconds(1);
        org.joda.time.Period period7 = period1.withMillis(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DurationField durationField14 = lenientChronology11.millis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology18 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField19 = lenientChronology17.centuries();
        org.joda.time.DurationField durationField20 = lenientChronology17.millis();
        org.joda.time.Chronology chronology21 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField22 = lenientChronology17.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField23 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField22);
        int int24 = preciseDateTimeField23.getMaximumValue();
        long long26 = preciseDateTimeField23.roundCeiling((-1L));
        long long29 = preciseDateTimeField23.set((-1L), 3599999);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3599999 + "'", int24 == 3599999);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (short) 100, "");
        java.lang.Throwable[] throwableArray12 = illegalFieldValueException11.getSuppressed();
        java.lang.String str13 = illegalFieldValueException11.toString();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology16 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.Chronology chronology17 = lenientChronology16.withUTC();
        org.joda.time.DurationField durationField18 = lenientChronology16.centuries();
        org.joda.time.DateTimeField dateTimeField19 = lenientChronology16.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField21.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) (short) 100, "");
        java.lang.Throwable[] throwableArray26 = illegalFieldValueException25.getSuppressed();
        java.lang.String str27 = illegalFieldValueException25.getFieldName();
        illegalFieldValueException11.addSuppressed((java.lang.Throwable) illegalFieldValueException25);
        illegalFieldValueException11.prependMessage("+10:08");
        java.lang.Number number31 = illegalFieldValueException11.getUpperBound();
        java.lang.String str32 = illegalFieldValueException11.getFieldName();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100 for clockhourOfHalfday is not supported: " + "'", str13.equals("org.joda.time.IllegalFieldValueException: Value 100 for clockhourOfHalfday is not supported: "));
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(lenientChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "clockhourOfHalfday" + "'", str27.equals("clockhourOfHalfday"));
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "clockhourOfHalfday" + "'", str32.equals("clockhourOfHalfday"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.minuteOfDay();
        org.joda.time.Chronology chronology10 = iSOChronology5.withUTC();
        boolean boolean11 = lenientChronology2.equals((java.lang.Object) iSOChronology5);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long17 = dateTimeZone13.getMillisKeepLocal(dateTimeZone15, 0L);
        long long20 = dateTimeZone13.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
        java.lang.String str23 = cachedDateTimeZone21.getName((long) 97);
        java.lang.String str25 = cachedDateTimeZone21.getShortName(62L);
        org.joda.time.Chronology chronology26 = lenientChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone21);
        org.joda.time.DurationField durationField27 = lenientChronology2.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3600010L + "'", long20 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-01:00" + "'", str23.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-01:00" + "'", str25.equals("-01:00"));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(durationField27);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("P-35Y-1M1W-10DT-97H-1M-52.100S");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"P-35Y-1M1W-10DT-97H-1M-52.100S/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        int int17 = unsupportedDateTimeField13.getDifference((long) (-52), (long) 'a');
        try {
            long long19 = unsupportedDateTimeField13.roundHalfCeiling((long) 2230000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-149) + "'", int17 == (-149));
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test099");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
//        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField7.getWrappedField();
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        int int14 = offsetDateTimeField7.getMaximumValue(readablePartial13);
//        int int15 = offsetDateTimeField7.getMaximumValue();
//        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField7.getWrappedField();
//        long long18 = offsetDateTimeField7.roundHalfFloor(32399900L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 47 + "'", int14 == 47);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 47 + "'", int15 == 47);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 32400000L + "'", long18 == 32400000L);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField7.getMaximumValue(readablePartial12);
        long long16 = offsetDateTimeField7.addWrapField(0L, 1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 47 + "'", int13 == 47);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-39600000L) + "'", long16 == (-39600000L));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField3 = gregorianChronology1.weeks();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 1, (org.joda.time.Chronology) gregorianChronology1);
        int int5 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("-01:00");
        java.lang.String str8 = jodaTimePermission7.getName();
        boolean boolean9 = gregorianChronology1.equals((java.lang.Object) str8);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-01:00" + "'", str8.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("LenientChronology[ISOChronology[]]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"LenientChronology[ISOChronology[]]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 0L);
        long long8 = dateTimeZone1.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean10 = cachedDateTimeZone9.isFixed();
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = cachedDateTimeZone9.isLocalDateTimeGap(localDateTime11);
        long long14 = cachedDateTimeZone9.previousTransition((long) 'a');
        java.lang.String str15 = cachedDateTimeZone9.getID();
        java.lang.String str16 = cachedDateTimeZone9.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600010L + "'", long8 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-01:00" + "'", str15.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-01:00" + "'", str16.equals("-01:00"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period3 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period5 = period3.plusWeeks((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationTo(readableInstant6);
        long long8 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration7);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration7, periodType9);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(0L, 0L, periodType16, chronology17);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType16, chronology19);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        int int22 = periodType16.indexOf(durationFieldType21);
        org.joda.time.Period period24 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType25 = null;
        int int26 = period24.indexOf(durationFieldType25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        int int29 = periodType16.indexOf(durationFieldType28);
        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType28, 0L);
        org.joda.time.DurationFieldType durationFieldType32 = preciseDurationField31.getType();
        int int33 = period11.indexOf(durationFieldType32);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3120000L + "'", long8 == 3120000L);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        org.joda.time.Period period13 = period11.plusMinutes(10);
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.Period period15 = period11.normalizedStandard(periodType14);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(0L, 0L, periodType4, chronology5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType4, chronology7);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType4.indexOf(durationFieldType9);
        org.joda.time.Period period12 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType13 = null;
        int int14 = period12.indexOf(durationFieldType13);
        org.joda.time.DurationFieldType durationFieldType16 = period12.getFieldType(0);
        int int17 = periodType4.indexOf(durationFieldType16);
        org.joda.time.field.PreciseDurationField preciseDurationField19 = new org.joda.time.field.PreciseDurationField(durationFieldType16, 0L);
        org.joda.time.DurationFieldType durationFieldType20 = preciseDurationField19.getType();
        long long23 = preciseDurationField19.add(0L, 0);
        long long26 = preciseDurationField19.add((long) 349200000, 0);
        try {
            int int29 = preciseDurationField19.getValue(0L, (-12960003600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 349200000L + "'", long26 == 349200000L);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test107");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.Chronology chronology5 = lenientChronology4.withUTC();
//        org.joda.time.DurationField durationField6 = lenientChronology4.centuries();
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology4.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.secondOfMinute();
//        org.joda.time.DurationField durationField14 = iSOChronology11.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField14);
//        org.joda.time.DurationField durationField16 = unsupportedDateTimeField15.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = unsupportedDateTimeField15.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType17, 6, (int) (short) 1, (int) (byte) -1);
//        long long23 = offsetDateTimeField21.roundHalfCeiling((long) (short) 100);
//        boolean boolean25 = offsetDateTimeField21.isLeap((long) 136);
//        org.joda.time.ReadablePartial readablePartial26 = null;
//        int int27 = offsetDateTimeField21.getMaximumValue(readablePartial26);
//        org.joda.time.DurationField durationField28 = offsetDateTimeField21.getDurationField();
//        int int31 = offsetDateTimeField21.getDifference(259200005L, (long) 361009311);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(lenientChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        long long18 = iSOChronology14.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology14.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology14.clockhourOfDay();
        org.joda.time.DurationField durationField21 = iSOChronology14.weekyears();
        long long24 = durationField21.subtract((-100L), 97);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField21);
        try {
            int int27 = unsupportedDateTimeField25.get(3600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-3060892800100L) + "'", long24 == (-3060892800100L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType9);
        org.joda.time.Period period11 = period10.toPeriod();
        org.joda.time.PeriodType periodType12 = period10.getPeriodType();
        org.joda.time.PeriodType periodType13 = periodType12.withMonthsRemoved();
        int int14 = periodType12.size();
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(0L, 0L, periodType22, chronology23);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType22, chronology25);
        org.joda.time.Period period27 = new org.joda.time.Period((-1104364799967L), 422000L, periodType22);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology31 = lenientChronology30.withUTC();
        org.joda.time.DurationField durationField32 = lenientChronology30.centuries();
        org.joda.time.DateTimeField dateTimeField33 = lenientChronology30.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        long long39 = offsetDateTimeField35.add((long) (short) 0, 3600010L);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField35.getType();
        java.lang.String str42 = offsetDateTimeField35.getAsText(1L);
        boolean boolean43 = offsetDateTimeField35.isLenient();
        java.lang.String str45 = offsetDateTimeField35.getAsShortText(3600000L);
        boolean boolean46 = periodType22.equals((java.lang.Object) 3600000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int48 = gregorianChronology47.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology51 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DateTimeField dateTimeField52 = lenientChronology51.secondOfDay();
        org.joda.time.DateTimeField dateTimeField53 = lenientChronology51.weekOfWeekyear();
        boolean boolean54 = gregorianChronology47.equals((java.lang.Object) dateTimeField53);
        org.joda.time.Period period55 = new org.joda.time.Period(0L, periodType22, (org.joda.time.Chronology) gregorianChronology47);
        org.joda.time.Period period56 = new org.joda.time.Period((-17L), periodType12, (org.joda.time.Chronology) gregorianChronology47);
        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology47.dayOfYear();
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 12960036000000L + "'", long39 == 12960036000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "47" + "'", str42.equals("47"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "36" + "'", str45.equals("36"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(lenientChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(dateTimeField57);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        boolean boolean14 = unsupportedDateTimeField13.isSupported();
        long long17 = unsupportedDateTimeField13.add(100L, (-2440587L));
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = unsupportedDateTimeField13.getType();
        java.lang.String str19 = unsupportedDateTimeField13.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2440487L) + "'", long17 == (-2440487L));
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UnsupportedDateTimeField" + "'", str19.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.withMillis(100);
        org.joda.time.Period period6 = period4.minusMonths((-52));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = period1.get(durationFieldType4);
        org.joda.time.Period period7 = period1.minusDays((int) (byte) 1);
        int[] intArray8 = period7.getValues();
        org.joda.time.Period period10 = period7.minusWeeks((int) (short) 1);
        int int11 = period7.getWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-01:00");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DurationField durationField5 = lenientChronology2.millis();
        org.joda.time.Chronology chronology6 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField7 = lenientChronology2.hours();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = lenientChronology2.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test116");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.yearOfEra();
//        java.lang.String str8 = iSOChronology0.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[]" + "'", str8.equals("ISOChronology[]"));
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test117");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTimeField dateTimeField3 = lenientChronology2.secondOfDay();
//        java.lang.String str4 = lenientChronology2.toString();
//        org.joda.time.DurationField durationField5 = lenientChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField6 = lenientChronology2.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology2.halfdayOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LenientChronology[ISOChronology[]]" + "'", str4.equals("LenientChronology[ISOChronology[]]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((-3600000));
        org.joda.time.Period period3 = period1.withSeconds((-52));
        org.joda.time.Period period5 = period1.withYears(6);
        org.joda.time.MutablePeriod mutablePeriod6 = period1.toMutablePeriod();
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period1.getFieldTypes();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.forFields(durationFieldTypeArray7);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(mutablePeriod6);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        int int10 = offsetDateTimeField7.getLeapAmount((long) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology15 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Chronology chronology16 = lenientChronology15.withUTC();
        org.joda.time.DurationField durationField17 = lenientChronology15.centuries();
        org.joda.time.DateTimeField dateTimeField18 = lenientChronology15.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfDay();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.secondOfMinute();
        org.joda.time.DurationField durationField25 = iSOChronology22.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
        org.joda.time.DurationField durationField27 = unsupportedDateTimeField26.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = unsupportedDateTimeField26.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType28, 6, (int) (short) 1, (int) (byte) -1);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType28, 4);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology37 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology35);
        org.joda.time.Chronology chronology38 = lenientChronology37.withUTC();
        org.joda.time.DurationField durationField39 = lenientChronology37.centuries();
        org.joda.time.DateTimeField dateTimeField40 = lenientChronology37.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField42.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) (short) 100, "");
        illegalFieldValueException46.prependMessage("0");
        java.lang.Number number49 = illegalFieldValueException46.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = illegalFieldValueException46.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = illegalFieldValueException46.getDateTimeFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField34, dateTimeFieldType51);
        long long55 = dividedDateTimeField34.getDifferenceAsLong(12960036000000L, 1104368400014L);
        try {
            long long58 = dividedDateTimeField34.set((long) 52, 349200000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 349200000 for clockhourOfHalfday must be in the range [9,11]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(lenientChronology15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(lenientChronology37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 823310L + "'", long55 == 823310L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone9);
        org.joda.time.Chronology chronology11 = zonedChronology10.withUTC();
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        boolean boolean13 = zonedChronology10.equals((java.lang.Object) periodType12);
        try {
            long long21 = zonedChronology10.getDateTimeMillis(4, 136, 0, 0, 4760, 136, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4760 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology4.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology4.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((-86400136L), 501559413L, periodType2, chronology3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(0L, 0L, periodType4, chronology5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType4, chronology7);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType4.indexOf(durationFieldType9);
        org.joda.time.Period period12 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType13 = null;
        int int14 = period12.indexOf(durationFieldType13);
        org.joda.time.DurationFieldType durationFieldType16 = period12.getFieldType(0);
        int int17 = periodType4.indexOf(durationFieldType16);
        org.joda.time.field.PreciseDurationField preciseDurationField19 = new org.joda.time.field.PreciseDurationField(durationFieldType16, 0L);
        org.joda.time.field.PreciseDurationField preciseDurationField21 = new org.joda.time.field.PreciseDurationField(durationFieldType16, (long) (short) 100);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone9);
        org.joda.time.Chronology chronology11 = zonedChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology10.secondOfMinute();
        org.joda.time.DurationField durationField13 = zonedChronology10.minutes();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("0");
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DurationField durationField14 = lenientChronology11.millis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology18 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField19 = lenientChronology17.centuries();
        org.joda.time.DurationField durationField20 = lenientChronology17.millis();
        org.joda.time.Chronology chronology21 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField22 = lenientChronology17.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField23 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField22);
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "1");
        illegalFieldValueException25.prependMessage("PeriodType[YearDayTimeNoYears]");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getShortName((long) 'a', locale3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int7 = cachedDateTimeZone5.getStandardOffset(0L);
        long long9 = cachedDateTimeZone5.previousTransition((-35L));
        long long11 = cachedDateTimeZone5.nextTransition((-58571700L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:00" + "'", str4.equals("-01:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-3600000) + "'", int7 == (-3600000));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-35L) + "'", long9 == (-35L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-58571700L) + "'", long11 == (-58571700L));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 0);
        org.joda.time.PeriodType periodType2 = period1.getPeriodType();
        org.joda.time.Period period4 = period1.withDays(136);
        org.joda.time.Period period6 = period1.withDays((-9));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(0L, 0L, periodType4, chronology5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType4, chronology7);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType4.indexOf(durationFieldType9);
        org.joda.time.Period period12 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType13 = null;
        int int14 = period12.indexOf(durationFieldType13);
        org.joda.time.DurationFieldType durationFieldType16 = period12.getFieldType(0);
        int int17 = periodType4.indexOf(durationFieldType16);
        org.joda.time.field.PreciseDurationField preciseDurationField19 = new org.joda.time.field.PreciseDurationField(durationFieldType16, 0L);
        org.joda.time.DurationFieldType durationFieldType20 = preciseDurationField19.getType();
        long long23 = preciseDurationField19.add(0L, 0);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        long long28 = iSOChronology24.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology24.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology24.year();
        org.joda.time.DurationField durationField31 = iSOChronology24.minutes();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology24, dateTimeZone33);
        boolean boolean35 = preciseDurationField19.equals((java.lang.Object) iSOChronology24);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1L) + "'", long28 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(zonedChronology34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField7.getType();
        java.lang.String str14 = offsetDateTimeField7.getAsText(1L);
        try {
            long long17 = offsetDateTimeField7.add(0L, (-311039642440487L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -311039642440487 * 3600000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "47" + "'", str14.equals("47"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone10.getUncachedZone();
        int int13 = cachedDateTimeZone10.getOffset(35L);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.DateTimeField dateTimeField15 = zonedChronology14.millisOfDay();
        try {
            long long23 = zonedChronology14.getDateTimeMillis((int) 'a', 0, 46, (-52), 10, (int) '#', (-9));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 10, 30108833654399900L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 301088336543999000L + "'", long2 == 301088336543999000L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DurationField durationField5 = lenientChronology2.millis();
        org.joda.time.Chronology chronology6 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField7 = lenientChronology2.hours();
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology2.dayOfMonth();
        org.joda.time.DurationField durationField9 = lenientChronology2.weeks();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DurationField durationField14 = lenientChronology11.millis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology18 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField19 = lenientChronology17.centuries();
        org.joda.time.DurationField durationField20 = lenientChronology17.millis();
        org.joda.time.Chronology chronology21 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField22 = lenientChronology17.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField23 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField22);
        int int24 = preciseDateTimeField23.getMaximumValue();
        long long26 = preciseDateTimeField23.roundFloor((long) 0);
        long long28 = preciseDateTimeField23.remainder((long) 4760);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = preciseDateTimeField23.getType();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3599999 + "'", int24 == 3599999);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone9);
        org.joda.time.Chronology chronology11 = zonedChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology10.secondOfMinute();
        org.joda.time.Period period14 = org.joda.time.Period.months(136);
        org.joda.time.Period period16 = period14.withMillis(97);
        boolean boolean17 = zonedChronology10.equals((java.lang.Object) 97);
        org.joda.time.DurationField durationField18 = zonedChronology10.minutes();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.Period period2 = org.joda.time.Period.days((int) (short) 10);
        org.joda.time.Period period4 = period2.plusWeeks((-3600000));
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(0L, 0L, periodType9, chronology10);
        boolean boolean13 = periodType9.equals((java.lang.Object) 0);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology16 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.Chronology chronology17 = lenientChronology16.withUTC();
        org.joda.time.DurationField durationField18 = lenientChronology16.centuries();
        org.joda.time.DateTimeField dateTimeField19 = lenientChronology16.clockhourOfHalfday();
        org.joda.time.Period period20 = new org.joda.time.Period(62L, (long) (-3600000), periodType9, (org.joda.time.Chronology) lenientChronology16);
        org.joda.time.PeriodType periodType21 = org.joda.time.DateTimeUtils.getPeriodType(periodType9);
        org.joda.time.PeriodType periodType22 = periodType21.withYearsRemoved();
        org.joda.time.PeriodType periodType23 = periodType22.withYearsRemoved();
        org.joda.time.Period period24 = period2.normalizedStandard(periodType23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone26);
        org.joda.time.DateTimeZone dateTimeZone28 = cachedDateTimeZone27.getUncachedZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone27);
        org.joda.time.Period period30 = new org.joda.time.Period((-1L), periodType23, (org.joda.time.Chronology) gregorianChronology29);
        java.lang.String str31 = gregorianChronology29.toString();
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(lenientChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "GregorianChronology[+00:00:00.100]" + "'", str31.equals("GregorianChronology[+00:00:00.100]"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
        org.joda.time.DurationField durationField12 = offsetDateTimeField7.getRangeDurationField();
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(0L, 0L, periodType17, chronology18);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType17, chronology20);
        org.joda.time.DurationFieldType durationFieldType22 = null;
        int int23 = periodType17.indexOf(durationFieldType22);
        org.joda.time.Period period25 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType26 = null;
        int int27 = period25.indexOf(durationFieldType26);
        org.joda.time.DurationFieldType durationFieldType29 = period25.getFieldType(0);
        int int30 = periodType17.indexOf(durationFieldType29);
        org.joda.time.field.PreciseDurationField preciseDurationField32 = new org.joda.time.field.PreciseDurationField(durationFieldType29, 0L);
        org.joda.time.DurationFieldType durationFieldType33 = preciseDurationField32.getType();
        org.joda.time.field.DecoratedDurationField decoratedDurationField34 = new org.joda.time.field.DecoratedDurationField(durationField12, durationFieldType33);
        long long37 = decoratedDurationField34.getMillis((-126000041L), 0L);
        long long40 = decoratedDurationField34.add((long) (byte) 1, 0);
        try {
            long long43 = decoratedDurationField34.add((long) (short) 10, 30108833654399900L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 30108833654399900 * 43200000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-5443201771200000L) + "'", long37 == (-5443201771200000L));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1L + "'", long40 == 1L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField4 = lenientChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology3.weekyear();
        org.joda.time.Period period7 = new org.joda.time.Period((-210858120000000L), (org.joda.time.Chronology) lenientChronology3);
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) lenientChronology3);
        org.joda.time.DateTimeField dateTimeField9 = lenientChronology8.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DurationField durationField14 = lenientChronology11.millis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology18 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField19 = lenientChronology17.centuries();
        org.joda.time.DurationField durationField20 = lenientChronology17.millis();
        org.joda.time.Chronology chronology21 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField22 = lenientChronology17.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField23 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField22);
        long long24 = preciseDateTimeField23.getUnitMillis();
        long long27 = preciseDateTimeField23.addWrapField(349199900L, (-1009312));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 348190588L + "'", long27 == 348190588L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        boolean boolean14 = unsupportedDateTimeField13.isSupported();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField13.getDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(349200000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-349200000) + "'", int1 == (-349200000));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "47");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "GregorianChronology[+00:00:00.100]", "46");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "", "35");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale14 = null;
        java.lang.String str17 = defaultNameProvider0.getName(locale14, "39", "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str17);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test144");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
//        int int10 = offsetDateTimeField7.getLeapAmount((long) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfYear();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology15 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.Chronology chronology16 = lenientChronology15.withUTC();
//        org.joda.time.DurationField durationField17 = lenientChronology15.centuries();
//        org.joda.time.DateTimeField dateTimeField18 = lenientChronology15.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.secondOfMinute();
//        org.joda.time.DurationField durationField25 = iSOChronology22.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField26.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = unsupportedDateTimeField26.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType28, 6, (int) (short) 1, (int) (byte) -1);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType28, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology37 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology35);
//        org.joda.time.Chronology chronology38 = lenientChronology37.withUTC();
//        org.joda.time.DurationField durationField39 = lenientChronology37.centuries();
//        org.joda.time.DateTimeField dateTimeField40 = lenientChronology37.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField42.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) (short) 100, "");
//        illegalFieldValueException46.prependMessage("0");
//        java.lang.Number number49 = illegalFieldValueException46.getLowerBound();
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = illegalFieldValueException46.getDateTimeFieldType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = illegalFieldValueException46.getDateTimeFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField34, dateTimeFieldType51);
//        long long54 = remainderDateTimeField52.roundHalfEven((long) 349200000);
//        long long56 = remainderDateTimeField52.roundHalfEven(0L);
//        org.joda.time.DurationField durationField57 = remainderDateTimeField52.getRangeDurationField();
//        org.joda.time.DurationField durationField58 = remainderDateTimeField52.getRangeDurationField();
//        long long60 = remainderDateTimeField52.roundHalfFloor((long) (-1009312));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(lenientChronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(lenientChronology37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 349200000L + "'", long54 == 349200000L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("40", (java.lang.Number) (-9), (java.lang.Number) (-1009312), (java.lang.Number) 0.0f);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test146");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
//        int int10 = offsetDateTimeField7.getLeapAmount((long) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfYear();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology15 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.Chronology chronology16 = lenientChronology15.withUTC();
//        org.joda.time.DurationField durationField17 = lenientChronology15.centuries();
//        org.joda.time.DateTimeField dateTimeField18 = lenientChronology15.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.secondOfMinute();
//        org.joda.time.DurationField durationField25 = iSOChronology22.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField26.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = unsupportedDateTimeField26.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType28, 6, (int) (short) 1, (int) (byte) -1);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType28, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology37 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology35);
//        org.joda.time.Chronology chronology38 = lenientChronology37.withUTC();
//        org.joda.time.DurationField durationField39 = lenientChronology37.centuries();
//        org.joda.time.DateTimeField dateTimeField40 = lenientChronology37.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField42.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) (short) 100, "");
//        illegalFieldValueException46.prependMessage("0");
//        java.lang.Number number49 = illegalFieldValueException46.getLowerBound();
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = illegalFieldValueException46.getDateTimeFieldType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = illegalFieldValueException46.getDateTimeFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField34, dateTimeFieldType51);
//        long long54 = remainderDateTimeField52.roundHalfEven((long) 349200000);
//        long long56 = remainderDateTimeField52.roundHalfEven(0L);
//        long long59 = remainderDateTimeField52.addWrapField((-136L), (int) '4');
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(lenientChronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(lenientChronology37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 349200000L + "'", long54 == 349200000L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-136L) + "'", long59 == (-136L));
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "-01:00", 0, 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long10 = dateTimeZone6.getMillisKeepLocal(dateTimeZone8, 0L);
        long long13 = dateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        boolean boolean15 = cachedDateTimeZone14.isFixed();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(0L, 0L, periodType18, chronology19);
        org.joda.time.PeriodType periodType21 = periodType18.withWeeksRemoved();
        boolean boolean22 = cachedDateTimeZone14.equals((java.lang.Object) periodType18);
        long long24 = cachedDateTimeZone14.nextTransition((long) 10);
        long long26 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone14, (-100L));
        long long28 = fixedDateTimeZone4.nextTransition((-3599990L));
        long long30 = fixedDateTimeZone4.previousTransition(126000004L);
        long long32 = fixedDateTimeZone4.convertUTCToLocal(20952039631964L);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600010L + "'", long13 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 3599900L + "'", long26 == 3599900L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-3599990L) + "'", long28 == (-3599990L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 126000004L + "'", long30 == 126000004L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 20952039631964L + "'", long32 == 20952039631964L);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test148");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
//        int int10 = offsetDateTimeField7.getLeapAmount((long) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfYear();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology15 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.Chronology chronology16 = lenientChronology15.withUTC();
//        org.joda.time.DurationField durationField17 = lenientChronology15.centuries();
//        org.joda.time.DateTimeField dateTimeField18 = lenientChronology15.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.secondOfMinute();
//        org.joda.time.DurationField durationField25 = iSOChronology22.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField26.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = unsupportedDateTimeField26.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType28, 6, (int) (short) 1, (int) (byte) -1);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType28, 4);
//        long long36 = dividedDateTimeField34.roundFloor(3600010L);
//        long long38 = dividedDateTimeField34.remainder((-125999854L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(lenientChronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 3600000L + "'", long36 == 3600000L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-97199854L) + "'", long38 == (-97199854L));
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test149");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
//        long long14 = offsetDateTimeField7.add(10L, (int) 'a');
//        long long16 = offsetDateTimeField7.roundCeiling((long) '#');
//        org.joda.time.DurationField durationField17 = offsetDateTimeField7.getLeapDurationField();
//        org.joda.time.DurationField durationField18 = offsetDateTimeField7.getLeapDurationField();
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology21);
//        org.joda.time.Chronology chronology24 = lenientChronology23.withUTC();
//        org.joda.time.DurationField durationField25 = lenientChronology23.centuries();
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology26.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology26.minuteOfDay();
//        org.joda.time.Chronology chronology31 = iSOChronology26.withUTC();
//        boolean boolean32 = lenientChronology23.equals((java.lang.Object) iSOChronology26);
//        org.joda.time.DateTimeField dateTimeField33 = lenientChronology23.secondOfDay();
//        org.joda.time.Period period35 = org.joda.time.Period.months(0);
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.Duration duration37 = period35.toDurationFrom(readableInstant36);
//        org.joda.time.PeriodType periodType38 = org.joda.time.PeriodType.yearDayTime();
//        org.joda.time.Period period39 = period35.normalizedStandard(periodType38);
//        int[] intArray42 = lenientChronology23.get((org.joda.time.ReadablePeriod) period39, 0L, (-1104364799967L));
//        try {
//            int[] intArray44 = offsetDateTimeField7.set(readablePartial19, (int) (short) 100, intArray42, 4760);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4760 for clockhourOfHalfday must be in the range [36,47]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 349200010L + "'", long14 == 349200010L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600000L + "'", long16 == 3600000L);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertNull(durationField18);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(lenientChronology23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(duration37);
//        org.junit.Assert.assertNotNull(periodType38);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertNotNull(intArray42);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Seconds seconds5 = period4.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period4.get(durationFieldType6);
        org.joda.time.Period period9 = period4.withDays(0);
        org.joda.time.Period period11 = period4.withSeconds((int) '#');
        org.joda.time.DurationFieldType[] durationFieldTypeArray12 = period4.getFieldTypes();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(durationFieldTypeArray12);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Seconds seconds5 = period4.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period4.get(durationFieldType6);
        org.joda.time.Duration duration8 = period4.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfYear();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.clockhourOfDay();
        org.joda.time.DurationField durationField15 = gregorianChronology12.eras();
        org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) readableInstant9, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.Period period18 = period16.plusYears((-3600000));
        org.joda.time.format.PeriodFormatter periodFormatter19 = null;
        java.lang.String str20 = period16.toString(periodFormatter19);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PT0S" + "'", str20.equals("PT0S"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(0L, 0L, periodType4, chronology5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType4, chronology7);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType4.indexOf(durationFieldType9);
        org.joda.time.Period period12 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType13 = null;
        int int14 = period12.indexOf(durationFieldType13);
        org.joda.time.DurationFieldType durationFieldType16 = period12.getFieldType(0);
        int int17 = periodType4.indexOf(durationFieldType16);
        org.joda.time.field.PreciseDurationField preciseDurationField19 = new org.joda.time.field.PreciseDurationField(durationFieldType16, 0L);
        org.joda.time.DurationFieldType durationFieldType20 = preciseDurationField19.getType();
        long long23 = preciseDurationField19.add(0L, 0);
        try {
            long long26 = preciseDurationField19.getValueAsLong((-3600000L), (-44171700L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test153");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
//        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
//        int int11 = offsetDateTimeField7.getOffset();
//        int int13 = offsetDateTimeField7.getLeapAmount((long) '#');
//        int int14 = offsetDateTimeField7.getOffset();
//        long long17 = offsetDateTimeField7.addWrapField((long) 10, (int) 'a');
//        long long20 = offsetDateTimeField7.add((-3600001L), (-3600000));
//        java.lang.String str21 = offsetDateTimeField7.getName();
//        int int23 = offsetDateTimeField7.getMinimumValue(3599975L);
//        int int25 = offsetDateTimeField7.getLeapAmount(0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-39599990L) + "'", long17 == (-39599990L));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-12960003600001L) + "'", long20 == (-12960003600001L));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "clockhourOfHalfday" + "'", str21.equals("clockhourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 36 + "'", int23 == 36);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DurationField durationField14 = lenientChronology11.millis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology18 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField19 = lenientChronology17.centuries();
        org.joda.time.DurationField durationField20 = lenientChronology17.millis();
        org.joda.time.Chronology chronology21 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField22 = lenientChronology17.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField23 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField22);
        long long24 = preciseDateTimeField23.getUnitMillis();
        long long27 = preciseDateTimeField23.addWrapField(0L, (int) 'a');
        long long30 = preciseDateTimeField23.set((-3060892800100L), 97);
        long long32 = preciseDateTimeField23.roundCeiling(129600000L);
        org.joda.time.ReadablePartial readablePartial33 = null;
        org.joda.time.Period period35 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period36 = period35.negated();
        org.joda.time.Period period38 = period35.withMillis(100);
        int[] intArray39 = period38.getValues();
        int int40 = preciseDateTimeField23.getMaximumValue(readablePartial33, intArray39);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-3060896399903L) + "'", long30 == (-3060896399903L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 129600000L + "'", long32 == 129600000L);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3599999 + "'", int40 == 3599999);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(0L, 0L, periodType6, chronology7);
        boolean boolean10 = periodType6.equals((java.lang.Object) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology13 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.Chronology chronology14 = lenientChronology13.withUTC();
        org.joda.time.DurationField durationField15 = lenientChronology13.centuries();
        org.joda.time.DateTimeField dateTimeField16 = lenientChronology13.clockhourOfHalfday();
        org.joda.time.Period period17 = new org.joda.time.Period(62L, (long) (-3600000), periodType6, (org.joda.time.Chronology) lenientChronology13);
        org.joda.time.PeriodType periodType18 = org.joda.time.DateTimeUtils.getPeriodType(periodType6);
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType6);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(lenientChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(periodType18);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DurationField durationField14 = lenientChronology11.millis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology18 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField19 = lenientChronology17.centuries();
        org.joda.time.DurationField durationField20 = lenientChronology17.millis();
        org.joda.time.Chronology chronology21 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField22 = lenientChronology17.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField23 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField22);
        int int24 = preciseDateTimeField23.getMaximumValue();
        long long26 = preciseDateTimeField23.roundFloor((long) 0);
        long long28 = preciseDateTimeField23.remainder((long) 4760);
        java.lang.String str29 = preciseDateTimeField23.getName();
        org.joda.time.DurationField durationField30 = preciseDateTimeField23.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3599999 + "'", int24 == 3599999);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "clockhourOfHalfday" + "'", str29.equals("clockhourOfHalfday"));
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology5.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DurationField durationField14 = lenientChronology11.millis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology18 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField19 = lenientChronology17.centuries();
        org.joda.time.DurationField durationField20 = lenientChronology17.millis();
        org.joda.time.Chronology chronology21 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField22 = lenientChronology17.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField23 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField22);
        int int24 = preciseDateTimeField23.getMinimumValue();
        long long26 = preciseDateTimeField23.remainder(349200000L);
        java.util.Locale locale28 = null;
        java.lang.String str29 = preciseDateTimeField23.getAsText((int) (short) 10, locale28);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "10" + "'", str29.equals("10"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "-01:00", 0, 1);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((-1104364799967L));
        java.lang.String str8 = fixedDateTimeZone4.getName((long) (short) 100);
        int int10 = fixedDateTimeZone4.getOffset((long) 7);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-01:00" + "'", str6.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Period period6 = period4.plusHours(1);
        org.joda.time.Period period7 = period6.negated();
        org.joda.time.DurationFieldType[] durationFieldTypeArray8 = period7.getFieldTypes();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(durationFieldTypeArray8);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(33);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("47", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test163");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
//        int int10 = offsetDateTimeField7.getLeapAmount((long) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfYear();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology15 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.Chronology chronology16 = lenientChronology15.withUTC();
//        org.joda.time.DurationField durationField17 = lenientChronology15.centuries();
//        org.joda.time.DateTimeField dateTimeField18 = lenientChronology15.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.secondOfMinute();
//        org.joda.time.DurationField durationField25 = iSOChronology22.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField26.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = unsupportedDateTimeField26.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType28, 6, (int) (short) 1, (int) (byte) -1);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType28, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology37 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology35);
//        org.joda.time.Chronology chronology38 = lenientChronology37.withUTC();
//        org.joda.time.DurationField durationField39 = lenientChronology37.centuries();
//        org.joda.time.DateTimeField dateTimeField40 = lenientChronology37.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField42.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) (short) 100, "");
//        illegalFieldValueException46.prependMessage("0");
//        java.lang.Number number49 = illegalFieldValueException46.getLowerBound();
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = illegalFieldValueException46.getDateTimeFieldType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = illegalFieldValueException46.getDateTimeFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField34, dateTimeFieldType51);
//        long long55 = remainderDateTimeField52.addWrapField((long) 46, 349200000);
//        long long57 = remainderDateTimeField52.remainder((long) 136);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(lenientChronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(lenientChronology37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 46L + "'", long55 == 46L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 136L + "'", long57 == 136L);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 0L);
        long long8 = dateTimeZone1.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str11 = cachedDateTimeZone9.getName((long) 97);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        java.util.Locale locale15 = null;
        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
        int int19 = cachedDateTimeZone17.getStandardOffset((long) (-52));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone20 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone21 = cachedDateTimeZone17.getUncachedZone();
        long long25 = dateTimeZone21.convertLocalToUTC((-12960003600001L), true, 28800000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        long long28 = cachedDateTimeZone9.getMillisKeepLocal(dateTimeZone21, (-28800000L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600010L + "'", long8 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-01:00" + "'", str11.equals("-01:00"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-01:00" + "'", str16.equals("-01:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-3600000) + "'", int19 == (-3600000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-12960000000001L) + "'", long25 == (-12960000000001L));
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-28800000L) + "'", long28 == (-28800000L));
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test165");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
//        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField7.getWrappedField();
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        int int14 = offsetDateTimeField7.getMaximumValue(readablePartial13);
//        int int16 = offsetDateTimeField7.getMaximumValue((long) ' ');
//        long long19 = offsetDateTimeField7.add((-58571700L), 4L);
//        org.joda.time.ReadablePartial readablePartial20 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.dayOfYear();
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology26 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology24);
//        org.joda.time.Chronology chronology27 = lenientChronology26.withUTC();
//        org.joda.time.DurationField durationField28 = lenientChronology26.centuries();
//        org.joda.time.DateTimeField dateTimeField29 = lenientChronology26.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField31.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.secondOfMinute();
//        org.joda.time.DurationField durationField36 = iSOChronology33.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType32, durationField36);
//        org.joda.time.DurationField durationField38 = unsupportedDateTimeField37.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = unsupportedDateTimeField37.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, dateTimeFieldType39, 6, (int) (short) 1, (int) (byte) -1);
//        long long45 = offsetDateTimeField43.roundHalfCeiling((long) (short) 100);
//        boolean boolean47 = offsetDateTimeField43.isLeap((long) 136);
//        org.joda.time.ReadablePartial readablePartial48 = null;
//        int int49 = offsetDateTimeField43.getMaximumValue(readablePartial48);
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = offsetDateTimeField43.getType();
//        org.joda.time.ReadablePartial readablePartial51 = null;
//        org.joda.time.Period period53 = org.joda.time.Period.minutes((int) '4');
//        org.joda.time.Period period54 = period53.negated();
//        org.joda.time.Period period56 = period53.withMillis(100);
//        int[] intArray57 = period56.getValues();
//        int int58 = offsetDateTimeField43.getMinimumValue(readablePartial51, intArray57);
//        try {
//            int[] intArray60 = offsetDateTimeField7.add(readablePartial20, 35, intArray57, (-1009312));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 47 + "'", int14 == 47);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 47 + "'", int16 == 47);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-44171700L) + "'", long19 == (-44171700L));
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(lenientChronology26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertNotNull(period53);
//        org.junit.Assert.assertNotNull(period54);
//        org.junit.Assert.assertNotNull(period56);
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 7 + "'", int58 == 7);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.plusSeconds((int) (short) 100);
        org.joda.time.Period period5 = period3.minusSeconds(100);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(349200000);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getShortName((long) 'a', locale3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int7 = cachedDateTimeZone5.getStandardOffset((long) (-52));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = cachedDateTimeZone5.getUncachedZone();
        long long13 = dateTimeZone9.convertLocalToUTC((-12960003600001L), true, 28800000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        int int15 = gregorianChronology14.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:00" + "'", str4.equals("-01:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-3600000) + "'", int7 == (-3600000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-12960000000001L) + "'", long13 == (-12960000000001L));
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test169");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
//        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
//        int int11 = offsetDateTimeField7.getOffset();
//        org.joda.time.ReadablePartial readablePartial12 = null;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = offsetDateTimeField7.getAsShortText(readablePartial12, 6, locale14);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology18 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology16);
//        org.joda.time.Chronology chronology19 = lenientChronology18.withUTC();
//        org.joda.time.DurationField durationField20 = lenientChronology18.centuries();
//        org.joda.time.DateTimeField dateTimeField21 = lenientChronology18.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField23.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) (short) 100, "");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType24, (-3600000));
//        long long32 = offsetDateTimeField29.getDifferenceAsLong(99L, 30108833654399968L);
//        long long34 = offsetDateTimeField29.roundHalfEven(0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "6" + "'", str15.equals("6"));
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(lenientChronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-8363564903L) + "'", long32 == (-8363564903L));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-01:00");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = cachedDateTimeZone4.getUncachedZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4);
        java.lang.String str8 = cachedDateTimeZone4.getNameKey((long) (byte) 1);
        boolean boolean9 = jodaTimePermission1.equals((java.lang.Object) str8);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfDay();
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField6 = iSOChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology8);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test172");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.Chronology chronology5 = lenientChronology4.withUTC();
//        org.joda.time.DurationField durationField6 = lenientChronology4.centuries();
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology4.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.secondOfMinute();
//        org.joda.time.DurationField durationField14 = iSOChronology11.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField14);
//        org.joda.time.DurationField durationField16 = unsupportedDateTimeField15.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = unsupportedDateTimeField15.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType17, 6, (int) (short) 1, (int) (byte) -1);
//        long long23 = offsetDateTimeField21.roundHalfCeiling((long) (short) 100);
//        boolean boolean25 = offsetDateTimeField21.isLeap((long) 136);
//        org.joda.time.ReadablePartial readablePartial26 = null;
//        int int27 = offsetDateTimeField21.getMaximumValue(readablePartial26);
//        try {
//            long long30 = offsetDateTimeField21.add((long) (byte) 0, 0L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 7 for clockhourOfHalfday must be in the range [7,-1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(lenientChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DurationField durationField14 = lenientChronology11.millis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology18 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField19 = lenientChronology17.centuries();
        org.joda.time.DurationField durationField20 = lenientChronology17.millis();
        org.joda.time.Chronology chronology21 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField22 = lenientChronology17.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField23 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField22);
        int int24 = preciseDateTimeField23.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial25 = null;
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology29 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology27);
        org.joda.time.Chronology chronology30 = lenientChronology29.withUTC();
        org.joda.time.DurationField durationField31 = lenientChronology29.centuries();
        org.joda.time.DateTimeField dateTimeField32 = lenientChronology29.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField34.getType();
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField34.getAsText(35, locale37);
        long long41 = offsetDateTimeField34.add(10L, (int) 'a');
        int int43 = offsetDateTimeField34.getMaximumValue((long) 97);
        org.joda.time.DurationField durationField44 = offsetDateTimeField34.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial45 = null;
        int[] intArray50 = new int[] { (byte) 10, (-3600000), (short) 0 };
        int[] intArray52 = offsetDateTimeField34.addWrapPartial(readablePartial45, 0, intArray50, 0);
        try {
            int[] intArray54 = preciseDateTimeField23.set(readablePartial25, (int) (short) 100, intArray52, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(lenientChronology29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "35" + "'", str38.equals("35"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 349200010L + "'", long41 == 349200010L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 47 + "'", int43 == 47);
        org.junit.Assert.assertNull(durationField44);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray52);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 0L);
        long long8 = dateTimeZone1.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean10 = cachedDateTimeZone9.isFixed();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(0L, 0L, periodType13, chronology14);
        org.joda.time.PeriodType periodType16 = periodType13.withWeeksRemoved();
        boolean boolean17 = cachedDateTimeZone9.equals((java.lang.Object) periodType13);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int23 = gregorianChronology22.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField24 = gregorianChronology22.weeks();
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) 1, (org.joda.time.Chronology) gregorianChronology22);
        int int26 = gregorianChronology22.getMinimumDaysInFirstWeek();
        org.joda.time.Period period27 = new org.joda.time.Period(97L, periodType20, (org.joda.time.Chronology) gregorianChronology22);
        try {
            org.joda.time.Period period28 = new org.joda.time.Period((java.lang.Object) cachedDateTimeZone9, periodType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.CachedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600010L + "'", long8 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
        org.joda.time.DurationField durationField12 = offsetDateTimeField7.getRangeDurationField();
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(0L, 0L, periodType17, chronology18);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType17, chronology20);
        org.joda.time.DurationFieldType durationFieldType22 = null;
        int int23 = periodType17.indexOf(durationFieldType22);
        org.joda.time.Period period25 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType26 = null;
        int int27 = period25.indexOf(durationFieldType26);
        org.joda.time.DurationFieldType durationFieldType29 = period25.getFieldType(0);
        int int30 = periodType17.indexOf(durationFieldType29);
        org.joda.time.field.PreciseDurationField preciseDurationField32 = new org.joda.time.field.PreciseDurationField(durationFieldType29, 0L);
        org.joda.time.DurationFieldType durationFieldType33 = preciseDurationField32.getType();
        org.joda.time.field.DecoratedDurationField decoratedDurationField34 = new org.joda.time.field.DecoratedDurationField(durationField12, durationFieldType33);
        long long37 = decoratedDurationField34.getMillis((-126000041L), 0L);
        org.joda.time.DurationField durationField38 = decoratedDurationField34.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-5443201771200000L) + "'", long37 == (-5443201771200000L));
        org.junit.Assert.assertNotNull(durationField38);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test176");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.Chronology chronology5 = lenientChronology4.withUTC();
//        org.joda.time.DurationField durationField6 = lenientChronology4.centuries();
//        org.joda.time.DateTimeField dateTimeField7 = lenientChronology4.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.secondOfMinute();
//        org.joda.time.DurationField durationField14 = iSOChronology11.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField14);
//        org.joda.time.DurationField durationField16 = unsupportedDateTimeField15.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = unsupportedDateTimeField15.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType17, 6, (int) (short) 1, (int) (byte) -1);
//        int int23 = offsetDateTimeField21.getLeapAmount((long) (byte) 10);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField21.getAsText((long) (byte) 10, locale25);
//        java.lang.String str27 = offsetDateTimeField21.getName();
//        long long29 = offsetDateTimeField21.roundHalfCeiling((-58571700L));
//        org.joda.time.ReadablePartial readablePartial30 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.dayOfYear();
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology35 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology33);
//        org.joda.time.Chronology chronology36 = lenientChronology35.withUTC();
//        org.joda.time.DurationField durationField37 = lenientChronology35.centuries();
//        org.joda.time.DateTimeField dateTimeField38 = lenientChronology35.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField40.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.secondOfMinute();
//        org.joda.time.DurationField durationField45 = iSOChronology42.millis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType41, durationField45);
//        org.joda.time.DurationField durationField47 = unsupportedDateTimeField46.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = unsupportedDateTimeField46.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, dateTimeFieldType48, 6, (int) (short) 1, (int) (byte) -1);
//        long long54 = offsetDateTimeField52.roundHalfCeiling((long) (short) 100);
//        boolean boolean56 = offsetDateTimeField52.isLeap((long) 136);
//        org.joda.time.ReadablePartial readablePartial57 = null;
//        int int58 = offsetDateTimeField52.getMaximumValue(readablePartial57);
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = offsetDateTimeField52.getType();
//        org.joda.time.ReadablePartial readablePartial60 = null;
//        org.joda.time.Period period62 = org.joda.time.Period.minutes((int) '4');
//        org.joda.time.Period period63 = period62.negated();
//        org.joda.time.Period period65 = period62.withMillis(100);
//        int[] intArray66 = period65.getValues();
//        int int67 = offsetDateTimeField52.getMinimumValue(readablePartial60, intArray66);
//        int int68 = offsetDateTimeField21.getMaximumValue(readablePartial30, intArray66);
//        boolean boolean70 = offsetDateTimeField21.isLeap((long) '4');
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(lenientChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "7" + "'", str26.equals("7"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "clockhourOfHalfday" + "'", str27.equals("clockhourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-86400000L) + "'", long29 == (-86400000L));
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(lenientChronology35);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeFieldType48);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertNotNull(period62);
//        org.junit.Assert.assertNotNull(period63);
//        org.junit.Assert.assertNotNull(period65);
//        org.junit.Assert.assertNotNull(intArray66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 7 + "'", int67 == 7);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DurationField durationField14 = lenientChronology11.millis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology18 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField19 = lenientChronology17.centuries();
        org.joda.time.DurationField durationField20 = lenientChronology17.millis();
        org.joda.time.Chronology chronology21 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField22 = lenientChronology17.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField23 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField22);
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "1");
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) 3599900L, (java.lang.Number) 3600000L, (java.lang.Number) 1);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology33 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology31);
        org.joda.time.Chronology chronology34 = lenientChronology33.withUTC();
        org.joda.time.DurationField durationField35 = lenientChronology33.centuries();
        org.joda.time.DateTimeField dateTimeField36 = lenientChronology33.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField38.getType();
        long long42 = offsetDateTimeField38.add((long) (short) 0, 3600010L);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField38.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException45 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, "PeriodType[YearDayTime]");
        illegalFieldValueException30.addSuppressed((java.lang.Throwable) illegalFieldValueException45);
        java.lang.Throwable[] throwableArray47 = illegalFieldValueException45.getSuppressed();
        illegalFieldValueException25.addSuppressed((java.lang.Throwable) illegalFieldValueException45);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(lenientChronology33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 12960036000000L + "'", long42 == 12960036000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(throwableArray47);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DurationField durationField14 = lenientChronology11.millis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology18 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField19 = lenientChronology17.centuries();
        org.joda.time.DurationField durationField20 = lenientChronology17.millis();
        org.joda.time.Chronology chronology21 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField22 = lenientChronology17.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField23 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField22);
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1009312), (java.lang.Number) (-12960003600001L), (java.lang.Number) 1.0d);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology30 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology28);
        org.joda.time.Chronology chronology31 = lenientChronology30.withUTC();
        org.joda.time.DurationField durationField32 = lenientChronology30.centuries();
        org.joda.time.DurationField durationField33 = lenientChronology30.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField33);
        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.Period period39 = new org.joda.time.Period(0L, 0L, periodType37, chronology38);
        org.joda.time.Seconds seconds40 = period39.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType41 = null;
        int int42 = period39.get(durationFieldType41);
        int int43 = period39.getMinutes();
        org.joda.time.Period period45 = period39.plusYears((int) (short) 100);
        org.joda.time.Period period47 = period39.minusMillis(1);
        org.joda.time.Period period49 = org.joda.time.Period.minutes((int) (short) 0);
        org.joda.time.Period period50 = period39.minus((org.joda.time.ReadablePeriod) period49);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology56 = null;
        org.joda.time.Period period57 = new org.joda.time.Period(0L, 0L, periodType55, chronology56);
        org.joda.time.Chronology chronology58 = null;
        org.joda.time.Period period59 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType55, chronology58);
        org.joda.time.DurationFieldType durationFieldType60 = null;
        int int61 = periodType55.indexOf(durationFieldType60);
        org.joda.time.Period period63 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType64 = null;
        int int65 = period63.indexOf(durationFieldType64);
        org.joda.time.DurationFieldType durationFieldType67 = period63.getFieldType(0);
        int int68 = periodType55.indexOf(durationFieldType67);
        int int69 = period49.indexOf(durationFieldType67);
        org.joda.time.field.ScaledDurationField scaledDurationField71 = new org.joda.time.field.ScaledDurationField(durationField33, durationFieldType67, (-33307296));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(lenientChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(seconds40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
    }
}

