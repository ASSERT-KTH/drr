import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 0L + "'", long0 == 0L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DurationField durationField2 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) 'a', (int) (byte) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        try {
            int int3 = period1.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        java.lang.String str2 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:00.032" + "'", str2.equals("+00:00:00.032"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "PeriodType[YearDayTime]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.Period period1 = new org.joda.time.Period(1L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (byte) 10, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period((java.lang.Object) dateTimeZone1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 1, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) -1, 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-100L) + "'", long2 == (-100L));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) '#');
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Seconds seconds5 = period4.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period4.get(durationFieldType6);
        org.joda.time.Period period9 = period4.withDays(0);
        try {
            int int11 = period9.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.ReadablePartial readablePartial2 = null;
        int[] intArray8 = new int[] { 10, '#', (byte) 100, (byte) 0, '4' };
        try {
            iSOChronology0.validate(readablePartial2, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) -1, 100, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        org.joda.time.Period period12 = period9.negated();
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period9.toString(periodFormatter13);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "P35Y1M-1W10DT97H1M52.100S" + "'", str14.equals("P35Y1M-1W10DT97H1M52.100S"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(97);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.withMillis(100);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.Period period7 = period4.withField(durationFieldType5, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getShortName((-1L), locale3);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = dateTimeZone1.isLocalDateTimeGap(localDateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.032" + "'", str4.equals("+00:00:00.032"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField6, (int) (short) 100, (int) ' ', (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for year must be in the range [32,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (-1), 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfHalfday must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-52) + "'", int1 == (-52));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "PeriodType[YearDayTime]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.joda.time.Period period3 = period1.withMillis((int) '#');
        int int4 = period1.getMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = period1.get(durationFieldType4);
        org.joda.time.Period period7 = period1.minusDays((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.Period period10 = period1.withField(durationFieldType8, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.Period period8 = new org.joda.time.Period(10, (int) '#', (int) (short) 10, 0, 0, (int) '4', (int) (short) 10, (int) ' ');
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) '4', 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 62L + "'", long2 == 62L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(0L, 0L, periodType4, chronology5);
        boolean boolean8 = periodType4.equals((java.lang.Object) 0);
        try {
            org.joda.time.Period period9 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfDay();
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray7 = new int[] {};
        try {
            iSOChronology0.validate(readablePartial6, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.Period period8 = new org.joda.time.Period(1, (int) (short) 10, (int) (byte) 100, 0, 1, (int) (short) 100, (-52), 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone9);
        try {
            long long16 = zonedChronology10.getDateTimeMillis((long) (short) -1, (int) (byte) 0, (int) ' ', (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.Hours hours4 = period1.toStandardHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(hours4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, (int) (short) -1, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfDay();
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        try {
            org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) chronology5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.ReadableInstant readableInstant0 = null;
        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        try {
            long long12 = iSOChronology0.getDateTimeMillis(35, (int) (short) 0, (int) '#', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(100, (-1), 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 0);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.Period period4 = period1.withFieldAdded(durationFieldType2, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.Period period3 = period0.withField(durationFieldType1, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long6 = dateTimeZone1.convertLocalToUTC((long) '#', true, (long) 97);
        boolean boolean8 = dateTimeZone1.isStandardOffset((long) '4');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-65L) + "'", long6 == (-65L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.Period period1 = org.joda.time.Period.hours(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DurationField durationField14 = lenientChronology11.millis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.millisOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.secondOfMinute();
        org.joda.time.DurationField durationField18 = iSOChronology15.millis();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField19 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The effective range must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField7.getAsText(0, locale13);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField7, (-1), 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for clockhourOfHalfday must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            int[] intArray5 = iSOChronology0.get(readablePartial3, 35L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Duration duration3 = period1.toDurationFrom(readableInstant2);
        org.joda.time.PeriodType periodType4 = period1.getPeriodType();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) -1, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) unsupportedDateTimeField13, dateTimeFieldType14, (int) (short) 1, 10, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyearOfCentury();
        try {
            long long17 = iSOChronology0.getDateTimeMillis((int) (short) -1, (-3600000), (int) 'a', (int) (byte) -1, 0, 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.withMillis(100);
        org.joda.time.Minutes minutes5 = period1.toStandardMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(minutes5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(0L, 0L, periodType4, chronology5);
        org.joda.time.PeriodType periodType7 = periodType4.withWeeksRemoved();
        org.joda.time.PeriodType periodType8 = periodType7.withSecondsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period((long) '#', (long) 35, periodType7);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(0, (int) (short) 10, (int) (short) 100, (-52));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale15 = null;
        try {
            java.lang.String str16 = unsupportedDateTimeField13.getAsText(readablePartial14, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType8, 97, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for clockhourOfHalfday must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.Period period1 = org.joda.time.Period.days(1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        try {
            java.lang.String str16 = unsupportedDateTimeField13.getAsShortText((long) (-52));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        try {
            org.joda.time.DurationFieldType durationFieldType13 = period9.getFieldType((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Period period6 = period4.plusHours(1);
        int int8 = period4.getValue(0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        long long16 = unsupportedDateTimeField13.getDifferenceAsLong((long) 97, (long) (byte) 0);
        try {
            int int18 = unsupportedDateTimeField13.getMaximumValue(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis((int) 'a', 47, (int) (byte) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 47 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        try {
            boolean boolean15 = unsupportedDateTimeField13.isLeap((long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology5 = lenientChronology4.withUTC();
        org.joda.time.DurationField durationField6 = lenientChronology4.centuries();
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology4.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField12 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        try {
            int int17 = unsupportedDateTimeField13.get((long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        try {
            org.joda.time.Weeks weeks12 = period9.toStandardWeeks();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Weeks as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("39", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray24 = new int[] { '#', (-3600000), 0, (-52), (short) 10, 97 };
        java.util.Locale locale26 = null;
        try {
            int[] intArray27 = unsupportedDateTimeField13.set(readablePartial16, (-3600000), intArray24, "UnsupportedDateTimeField", locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) ' ', (int) 'a', (int) ' ', 47);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 33 + "'", int4 == 33);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        java.util.Locale locale15 = null;
        try {
            java.lang.String str16 = unsupportedDateTimeField13.getAsText(0L, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        try {
            int int17 = unsupportedDateTimeField13.get(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        long long16 = unsupportedDateTimeField13.getDifferenceAsLong((long) 97, (long) (byte) 0);
        try {
            int int18 = unsupportedDateTimeField13.getLeapAmount((long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = unsupportedDateTimeField13.getAsText(0L, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = new org.joda.time.DurationFieldType[] {};
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 0L);
        long long8 = dateTimeZone1.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean10 = cachedDateTimeZone9.isFixed();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(0L, 0L, periodType13, chronology14);
        org.joda.time.PeriodType periodType16 = periodType13.withWeeksRemoved();
        boolean boolean17 = cachedDateTimeZone9.equals((java.lang.Object) periodType13);
        long long19 = cachedDateTimeZone9.nextTransition((long) 10);
        long long21 = cachedDateTimeZone9.nextTransition((long) (short) 1);
        org.joda.time.LocalDateTime localDateTime22 = null;
        boolean boolean23 = cachedDateTimeZone9.isLocalDateTimeGap(localDateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600010L + "'", long8 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 100, 36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 136 + "'", int2 == 136);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.ReadablePartial readablePartial5 = null;
        int[] intArray6 = new int[] {};
        try {
            lenientChronology2.validate(readablePartial5, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        try {
            long long17 = unsupportedDateTimeField13.roundHalfCeiling((long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 47, "UnsupportedDateTimeField");
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(1, 36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36 + "'", int2 == 36);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        long long16 = unsupportedDateTimeField13.getDifferenceAsLong((long) 97, (long) (byte) 0);
        try {
            java.lang.String str18 = unsupportedDateTimeField13.getAsShortText((long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Seconds seconds5 = period4.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period4.get(durationFieldType6);
        org.joda.time.Period period9 = period4.withDays(0);
        int int10 = period9.getDays();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(33, 4, (int) (byte) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 37 + "'", int4 == 37);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone9);
        try {
            long long15 = zonedChronology10.getDateTimeMillis(37, 0, 100, 35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        try {
            long long17 = unsupportedDateTimeField13.set(10L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((int) (short) 1, 47, (int) (short) 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 47 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 0L);
        long long8 = dateTimeZone1.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean10 = cachedDateTimeZone9.isFixed();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(0L, 0L, periodType13, chronology14);
        org.joda.time.PeriodType periodType16 = periodType13.withWeeksRemoved();
        boolean boolean17 = cachedDateTimeZone9.equals((java.lang.Object) periodType13);
        boolean boolean18 = cachedDateTimeZone9.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600010L + "'", long8 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = unsupportedDateTimeField13.getAsText(readablePartial14, (int) (byte) 1, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(0L, 0L, periodType4, chronology5);
        org.joda.time.PeriodType periodType7 = periodType4.withWeeksRemoved();
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType4);
        org.joda.time.Period period10 = period8.multipliedBy((int) '#');
        int int11 = period8.getWeeks();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(0L, 0L, periodType4, chronology5);
        org.joda.time.PeriodType periodType7 = periodType4.withWeeksRemoved();
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType4);
        org.joda.time.PeriodType periodType9 = periodType4.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) 62L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        org.joda.time.ReadablePartial readablePartial15 = null;
        int[] intArray21 = new int[] { (byte) 0, (byte) -1, ' ', 35 };
        try {
            int[] intArray23 = unsupportedDateTimeField13.set(readablePartial15, (int) (short) 0, intArray21, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        org.joda.time.ReadablePartial readablePartial15 = null;
        int[] intArray21 = new int[] { (-1), 35, 100, '4' };
        try {
            int[] intArray23 = unsupportedDateTimeField13.addWrapField(readablePartial15, (int) (short) 0, intArray21, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName((-100L), locale3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.032" + "'", str4.equals("+00:00:00.032"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DateTimeField dateTimeField14 = lenientChronology11.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField16.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField18 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = period9.indexOf(durationFieldType10);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = period9.get(durationFieldType12);
        org.joda.time.DurationFieldType durationFieldType14 = null;
        boolean boolean15 = period9.isSupported(durationFieldType14);
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(0L, 0L, periodType20, chronology21);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType20, chronology23);
        org.joda.time.Period period25 = period9.normalizedStandard(periodType20);
        try {
            org.joda.time.Period period26 = new org.joda.time.Period((int) (byte) -1, (int) (short) -1, (-1), (-52), (int) (byte) 1, 37, (int) 'a', (-52), periodType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone9);
        org.joda.time.Chronology chronology11 = zonedChronology10.withUTC();
        try {
            long long19 = zonedChronology10.getDateTimeMillis(97, (int) ' ', 35, (int) ' ', 6, 1, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("clockhourOfHalfday");
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("-01:00", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"-01:00/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        try {
            long long15 = unsupportedDateTimeField13.remainder(100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) ' ', 'a', 6, (int) '4', (int) (short) 100, false, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("+00:00:00.032", false);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder0.toDateTimeZone("35", true);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("+00:00:00.032");
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName((long) '#', locale3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.032" + "'", str4.equals("+00:00:00.032"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        int int12 = period11.getDays();
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        long long16 = unsupportedDateTimeField13.getDifferenceAsLong((long) 97, (long) (byte) 0);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = unsupportedDateTimeField13.getAsShortText(readablePartial17, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(0L, 0L, periodType6, chronology7);
        boolean boolean10 = periodType6.equals((java.lang.Object) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology13 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.Chronology chronology14 = lenientChronology13.withUTC();
        org.joda.time.DurationField durationField15 = lenientChronology13.centuries();
        org.joda.time.DateTimeField dateTimeField16 = lenientChronology13.clockhourOfHalfday();
        org.joda.time.Period period17 = new org.joda.time.Period(62L, (long) (-3600000), periodType6, (org.joda.time.Chronology) lenientChronology13);
        org.joda.time.PeriodType periodType18 = org.joda.time.DateTimeUtils.getPeriodType(periodType6);
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType18);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        try {
            org.joda.time.Period period22 = period19.withFieldAdded(durationFieldType20, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(lenientChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(periodType18);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-52), (java.lang.Number) 97L, (java.lang.Number) 62L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        org.joda.time.Period period13 = period11.plusMinutes(10);
        try {
            org.joda.time.Duration duration14 = period13.toStandardDuration();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Duration as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "-01:00", 0, 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long10 = dateTimeZone6.getMillisKeepLocal(dateTimeZone8, 0L);
        long long13 = dateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        boolean boolean15 = cachedDateTimeZone14.isFixed();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(0L, 0L, periodType18, chronology19);
        org.joda.time.PeriodType periodType21 = periodType18.withWeeksRemoved();
        boolean boolean22 = cachedDateTimeZone14.equals((java.lang.Object) periodType18);
        long long24 = cachedDateTimeZone14.nextTransition((long) 10);
        long long26 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone14, (-100L));
        java.util.TimeZone timeZone27 = fixedDateTimeZone4.toTimeZone();
        int int29 = fixedDateTimeZone4.getOffsetFromLocal((long) (short) 100);
        int int31 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600010L + "'", long13 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 3599900L + "'", long26 == 3599900L);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
//        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField7.getType();
//        java.lang.String str14 = offsetDateTimeField7.getAsText(1L);
//        boolean boolean15 = offsetDateTimeField7.isLenient();
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        int[] intArray19 = new int[] { 1 };
//        try {
//            int[] intArray21 = offsetDateTimeField7.set(readablePartial16, (int) (byte) -1, intArray19, 47);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "39" + "'", str14.equals("39"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(intArray19);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(12960036000000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2590588L + "'", long1 == 2590588L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = unsupportedDateTimeField13.getType();
        try {
            java.lang.String str17 = unsupportedDateTimeField13.getAsText(3600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        int int1 = period0.getYears();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(0L, 0L, periodType6, chronology7);
        org.joda.time.PeriodType periodType9 = periodType6.withWeeksRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType6);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.monthOfYear();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.monthOfYear();
        try {
            org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) int1, periodType6, (org.joda.time.Chronology) iSOChronology11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        int int2 = periodType0.indexOf(durationFieldType1);
        java.lang.String str3 = periodType0.toString();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[Millis]" + "'", str3.equals("PeriodType[Millis]"));
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.lang.Object obj0 = null;
        java.lang.Object obj1 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(0L, 0L, periodType6, chronology7);
        org.joda.time.PeriodType periodType9 = periodType6.withWeeksRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType6);
        try {
            org.joda.time.Period period11 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        long long16 = unsupportedDateTimeField13.getDifferenceAsLong((long) 97, (long) (byte) 0);
        try {
            long long18 = unsupportedDateTimeField13.roundHalfEven((long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField6 = lenientChronology2.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.Period period19 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period19.indexOf(durationFieldType20);
        org.joda.time.DurationFieldType durationFieldType22 = null;
        int int23 = period19.get(durationFieldType22);
        org.joda.time.Period period25 = period19.minusDays((int) (byte) 1);
        int[] intArray26 = period25.getValues();
        try {
            int[] intArray28 = unsupportedDateTimeField13.addWrapPartial(readablePartial16, 33, intArray26, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        try {
            long long16 = unsupportedDateTimeField13.roundHalfEven((long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology5 = lenientChronology4.withUTC();
        org.joda.time.DurationField durationField6 = lenientChronology4.centuries();
        org.joda.time.DurationField durationField7 = lenientChronology4.millis();
        org.joda.time.DurationField durationField8 = lenientChronology4.days();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField9 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
        try {
            long long11 = iSOChronology0.getDateTimeMillis(10, (-3600000), 4, (int) (byte) 1, 0, (int) (short) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3600000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 349200010L, (java.lang.Number) 0L, (java.lang.Number) 35L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(37, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-3600000), (java.lang.Number) 33, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
//        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
//        int int11 = offsetDateTimeField7.getOffset();
//        int int13 = offsetDateTimeField7.getLeapAmount((long) '#');
//        int int14 = offsetDateTimeField7.getOffset();
//        long long17 = offsetDateTimeField7.addWrapField((long) 10, (int) 'a');
//        int int19 = offsetDateTimeField7.getMaximumValue(0L);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology22 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.Chronology chronology23 = lenientChronology22.withUTC();
//        org.joda.time.DurationField durationField24 = lenientChronology22.centuries();
//        org.joda.time.DateTimeField dateTimeField25 = lenientChronology22.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField27.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) (short) 100, "");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 33, (java.lang.Number) (short) -1, (java.lang.Number) 100.0d);
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField36 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType28);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 3600010L + "'", long17 == 3600010L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 47 + "'", int19 == 47);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(lenientChronology22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period2 = period1.negated();
        int int3 = period1.getSeconds();
        org.joda.time.Period period5 = period1.multipliedBy(10);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.Period period8 = period5.withFieldAdded(durationFieldType6, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        java.lang.String str5 = gregorianChronology4.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[+00:00:00.100]" + "'", str5.equals("GregorianChronology[+00:00:00.100]"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DurationField durationField4 = iSOChronology0.months();
        try {
            long long12 = iSOChronology0.getDateTimeMillis(0, 0, 10, 35, (int) (short) 1, 35, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.Period period18 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType19 = null;
        int int20 = period18.indexOf(durationFieldType19);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        int int22 = period18.get(durationFieldType21);
        org.joda.time.Period period24 = period18.minusDays((int) (byte) 1);
        int[] intArray25 = period24.getValues();
        try {
            int[] intArray27 = unsupportedDateTimeField13.add(readablePartial15, 6, intArray25, 47);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = periodType2.indexOf(durationFieldType3);
        java.lang.String str5 = periodType2.toString();
        try {
            org.joda.time.Period period6 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PeriodType[Millis]" + "'", str5.equals("PeriodType[Millis]"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = unsupportedDateTimeField13.getAsShortText((long) 37, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.Period period18 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType19 = null;
        int int20 = period18.indexOf(durationFieldType19);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        int int22 = period18.get(durationFieldType21);
        org.joda.time.Period period24 = period18.minusDays((int) (byte) 1);
        int[] intArray25 = period24.getValues();
        try {
            int[] intArray27 = unsupportedDateTimeField13.addWrapPartial(readablePartial15, 97, intArray25, 47);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "-01:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
        long long14 = offsetDateTimeField7.add(10L, (int) 'a');
        long long16 = offsetDateTimeField7.roundCeiling((long) '#');
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField7, 1, 4, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for clockhourOfHalfday must be in the range [4,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 349200010L + "'", long14 == 349200010L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600000L + "'", long16 == 3600000L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.field.FieldUtils.verifyValueBounds("40", 33, (int) (byte) 1, (int) (short) 100);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        java.util.Locale locale16 = null;
        try {
            int int17 = unsupportedDateTimeField13.getMaximumTextLength(locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        java.lang.String str16 = unsupportedDateTimeField13.toString();
        org.joda.time.ReadablePartial readablePartial17 = null;
        try {
            int int18 = unsupportedDateTimeField13.getMaximumValue(readablePartial17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UnsupportedDateTimeField" + "'", str16.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 0L);
        long long8 = dateTimeZone1.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean10 = cachedDateTimeZone9.isFixed();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(0L, 0L, periodType13, chronology14);
        org.joda.time.PeriodType periodType16 = periodType13.withWeeksRemoved();
        boolean boolean17 = cachedDateTimeZone9.equals((java.lang.Object) periodType13);
        long long19 = cachedDateTimeZone9.nextTransition((long) 10);
        long long21 = cachedDateTimeZone9.nextTransition((long) (short) 1);
        long long23 = cachedDateTimeZone9.convertUTCToLocal((long) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600010L + "'", long8 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-3599990L) + "'", long23 == (-3599990L));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField7.getAsText(0, locale13);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int[] intArray17 = null;
        try {
            int[] intArray19 = offsetDateTimeField7.addWrapField(readablePartial15, (-3600000), intArray17, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.minuteOfHour();
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 100.0f, (java.lang.Object) dateTimeField5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearDayTime();
        java.lang.Class<?> wildcardClass8 = periodType7.getClass();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) 100.0f, periodType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Float");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) -1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone9);
        org.joda.time.Chronology chronology11 = zonedChronology10.withUTC();
        try {
            long long16 = zonedChronology10.getDateTimeMillis(136, 0, 37, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
        long long14 = offsetDateTimeField7.add(10L, (int) 'a');
        long long16 = offsetDateTimeField7.roundCeiling((long) '#');
        org.joda.time.DurationField durationField17 = offsetDateTimeField7.getLeapDurationField();
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField7.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 349200010L + "'", long14 == 349200010L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600000L + "'", long16 == 3600000L);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.ReadablePartial readablePartial8 = null;
        org.joda.time.Period period11 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = period11.indexOf(durationFieldType12);
        org.joda.time.DurationFieldType durationFieldType14 = null;
        int int15 = period11.get(durationFieldType14);
        org.joda.time.Period period17 = period11.minusDays((int) (byte) 1);
        int[] intArray18 = period17.getValues();
        try {
            int[] intArray20 = offsetDateTimeField7.addWrapField(readablePartial8, 36, intArray18, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 36");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        java.lang.String str16 = unsupportedDateTimeField13.toString();
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = unsupportedDateTimeField13.getAsText(readablePartial17, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UnsupportedDateTimeField" + "'", str16.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone9);
        org.joda.time.Chronology chronology11 = zonedChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology10.secondOfMinute();
        try {
            long long18 = zonedChronology10.getDateTimeMillis((long) 10, (int) 'a', (-149), (int) (byte) 0, 37);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 'a');
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(35, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        long long16 = unsupportedDateTimeField13.getDifferenceAsLong((long) 97, (long) (byte) 0);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        try {
            int int19 = unsupportedDateTimeField13.getMaximumValue(3600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (short) 100, "");
        java.lang.Throwable[] throwableArray12 = illegalFieldValueException11.getSuppressed();
        java.lang.String str13 = illegalFieldValueException11.getFieldName();
        illegalFieldValueException11.prependMessage("UnsupportedDateTimeField");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "clockhourOfHalfday" + "'", str13.equals("clockhourOfHalfday"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.Period period1 = org.joda.time.Period.years((-3600000));
        org.joda.time.Period period3 = period1.withMillis((int) (short) -1);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Period period6 = period1.withFieldAdded(durationFieldType4, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField13.getRangeDurationField();
        java.util.Locale locale16 = null;
        try {
            int int17 = unsupportedDateTimeField13.getMaximumShortTextLength(locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("-01:00", "-01:00");
        java.lang.Throwable throwable3 = null;
        try {
            illegalFieldValueException2.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        try {
            org.joda.time.Period period6 = period4.withWeeks((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.joda.time.Period period3 = period1.withMillis((int) '#');
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.time();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        long long9 = iSOChronology5.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.year();
        org.joda.time.DurationField durationField12 = iSOChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology5.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology5.weekyearOfCentury();
        try {
            org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) '#', periodType4, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Character");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = cachedDateTimeZone2.getUncachedZone();
        int int5 = cachedDateTimeZone2.getOffset(35L);
        int int7 = cachedDateTimeZone2.getOffset((long) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 10, 8);
        java.lang.String str3 = dateTimeZone2.getID();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+10:08" + "'", str3.equals("+10:08"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period2 = period1.negated();
        int int3 = period1.getSeconds();
        org.joda.time.Period period5 = period1.multipliedBy(10);
        org.joda.time.Period period7 = period1.minusYears(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Chronology chronology4 = lenientChronology3.withUTC();
        org.joda.time.DurationField durationField5 = lenientChronology3.centuries();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology3.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField8.getType();
        long long12 = offsetDateTimeField8.add((long) (short) 0, 3600010L);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField8.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField14 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 12960036000000L + "'", long12 == 12960036000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        long long17 = unsupportedDateTimeField13.add(97L, (int) (byte) -1);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = unsupportedDateTimeField13.getAsText(readablePartial18, 136, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 96L + "'", long17 == 96L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(2590588L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Period period6 = period4.plusHours(1);
        org.joda.time.Weeks weeks7 = period6.toStandardWeeks();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(weeks7);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        int int12 = period9.getHours();
        org.joda.time.Period period14 = org.joda.time.Period.months(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period14.toDurationFrom(readableInstant15);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Period period18 = period14.normalizedStandard(periodType17);
        org.joda.time.Period period19 = period9.plus((org.joda.time.ReadablePeriod) period14);
        try {
            org.joda.time.DurationFieldType durationFieldType21 = period19.getFieldType(136);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 136");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
//        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
//        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
//        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
//        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField7.getType();
//        java.lang.String str14 = offsetDateTimeField7.getAsText(1L);
//        boolean boolean15 = offsetDateTimeField7.isLenient();
//        java.lang.String str17 = offsetDateTimeField7.getAsShortText(3600000L);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        int[] intArray22 = new int[] { (short) 1, (-3600000) };
//        try {
//            int[] intArray24 = offsetDateTimeField7.addWrapField(readablePartial18, (-52), intArray22, 37);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -52");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(lenientChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "39" + "'", str14.equals("39"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "40" + "'", str17.equals("40"));
//        org.junit.Assert.assertNotNull(intArray22);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        long long16 = unsupportedDateTimeField13.getDifferenceAsLong((long) 97, (long) (byte) 0);
        try {
            long long19 = unsupportedDateTimeField13.set((long) (-1), "-01:00");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = period1.get(durationFieldType4);
        org.joda.time.Period period7 = period1.minusDays((int) (byte) 1);
        org.joda.time.Period period8 = period1.normalizedStandard();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("P35Y1M-1W10DT97H1M52.100S", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
        long long14 = offsetDateTimeField7.add(10L, (int) 'a');
        long long16 = offsetDateTimeField7.roundCeiling((long) '#');
        long long19 = offsetDateTimeField7.add(0L, (-3600000));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 349200010L + "'", long14 == 349200010L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600000L + "'", long16 == 3600000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-12960000000000L) + "'", long19 == (-12960000000000L));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        long long17 = unsupportedDateTimeField13.getDifferenceAsLong(100L, 0L);
        java.util.Locale locale20 = null;
        try {
            long long21 = unsupportedDateTimeField13.set(0L, "", locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        java.lang.String str16 = unsupportedDateTimeField13.toString();
        try {
            java.lang.String str18 = unsupportedDateTimeField13.getAsText((long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UnsupportedDateTimeField" + "'", str16.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "-01:00", 0, 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long10 = dateTimeZone6.getMillisKeepLocal(dateTimeZone8, 0L);
        long long13 = dateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        boolean boolean15 = cachedDateTimeZone14.isFixed();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(0L, 0L, periodType18, chronology19);
        org.joda.time.PeriodType periodType21 = periodType18.withWeeksRemoved();
        boolean boolean22 = cachedDateTimeZone14.equals((java.lang.Object) periodType18);
        long long24 = cachedDateTimeZone14.nextTransition((long) 10);
        long long26 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone14, (-100L));
        java.util.TimeZone timeZone27 = fixedDateTimeZone4.toTimeZone();
        long long29 = fixedDateTimeZone4.previousTransition((long) '#');
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600010L + "'", long13 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 3599900L + "'", long26 == 3599900L);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period3 = period1.plusWeeks((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period1.toDurationTo(readableInstant4);
        int int6 = period1.getWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        java.lang.String str3 = periodType2.toString();
        int int4 = periodType2.size();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[YearDayTime]" + "'", str3.equals("PeriodType[YearDayTime]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
        int int11 = offsetDateTimeField7.getOffset();
        int int13 = offsetDateTimeField7.getLeapAmount((long) ' ');
        long long15 = offsetDateTimeField7.roundCeiling((long) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 8, (-210858120000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -1686864960000000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) 3599900L, (java.lang.Number) 3600000L, (java.lang.Number) 1);
        illegalFieldValueException4.prependMessage("UTC");
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfDay();
        org.joda.time.DurationField durationField5 = iSOChronology0.weeks();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = cachedDateTimeZone2.getUncachedZone();
        int int5 = cachedDateTimeZone2.getStandardOffset((long) 0);
        int int7 = cachedDateTimeZone2.getStandardOffset((long) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(3600000L, locale3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.010" + "'", str4.equals("+00:00:00.010"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        long long12 = iSOChronology8.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology8.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology8.year();
        org.joda.time.DurationField durationField15 = iSOChronology8.minutes();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology8, dateTimeZone17);
        org.joda.time.Chronology chronology19 = zonedChronology18.withUTC();
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.seconds();
        boolean boolean21 = zonedChronology18.equals((java.lang.Object) periodType20);
        try {
            org.joda.time.Period period22 = new org.joda.time.Period(0, 47, (-52), 35, 6, 97, (int) (short) 1, (int) (short) 1, periodType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone9);
        try {
            long long16 = zonedChronology10.getDateTimeMillis((long) (byte) 1, (int) ' ', (int) (short) 1, (int) (short) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        int int17 = unsupportedDateTimeField13.getDifference((long) (-52), (long) 'a');
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int21 = gregorianChronology20.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField22 = gregorianChronology20.weeks();
        org.joda.time.PeriodType periodType31 = null;
        org.joda.time.Period period32 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType31);
        org.joda.time.Period period34 = period32.withWeeks(10);
        org.joda.time.Period period36 = period32.plusMonths((int) ' ');
        int[] intArray38 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period32, (-3600001L));
        try {
            int[] intArray40 = unsupportedDateTimeField13.addWrapPartial(readablePartial18, 47, intArray38, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-149) + "'", int17 == (-149));
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.joda.time.Period period3 = period1.withMillis((int) '#');
        int int4 = period3.getMonths();
        org.joda.time.Days days5 = period3.toStandardDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(days5);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
        long long14 = offsetDateTimeField7.add(10L, (int) 'a');
        long long16 = offsetDateTimeField7.roundCeiling((long) '#');
        org.joda.time.DurationField durationField17 = offsetDateTimeField7.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.Period period21 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType22 = null;
        int int23 = period21.indexOf(durationFieldType22);
        org.joda.time.DurationFieldType durationFieldType24 = null;
        int int25 = period21.get(durationFieldType24);
        org.joda.time.Period period27 = period21.minusDays((int) (byte) 1);
        int[] intArray28 = period27.getValues();
        try {
            int[] intArray30 = offsetDateTimeField7.addWrapPartial(readablePartial18, (-149), intArray28, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -149");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 349200010L + "'", long14 == 349200010L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600000L + "'", long16 == 3600000L);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "-01:00", 0, 1);
        long long8 = fixedDateTimeZone4.convertLocalToUTC(2590588L, false, 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2590588L + "'", long8 == 2590588L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        int int17 = unsupportedDateTimeField13.getDifference((long) (-52), (long) 'a');
        try {
            long long20 = unsupportedDateTimeField13.set(96L, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-149) + "'", int17 == (-149));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 0L);
        long long8 = dateTimeZone1.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean10 = cachedDateTimeZone9.isFixed();
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler11 = new org.joda.time.tz.ZoneInfoCompiler();
        boolean boolean12 = cachedDateTimeZone9.equals((java.lang.Object) zoneInfoCompiler11);
        java.io.File file13 = null;
        java.io.File file14 = null;
        java.io.File[] fileArray15 = new java.io.File[] { file14 };
        try {
            java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap16 = zoneInfoCompiler11.compile(file13, fileArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600010L + "'", long8 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fileArray15);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.Period period17 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType18 = null;
        int int19 = period17.indexOf(durationFieldType18);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period17.get(durationFieldType20);
        org.joda.time.Period period23 = period17.minusDays((int) (byte) 1);
        int[] intArray24 = period23.getValues();
        try {
            int int25 = unsupportedDateTimeField13.getMaximumValue(readablePartial15, intArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField7.getAsText(0, locale13);
        int int16 = offsetDateTimeField7.getMinimumValue((long) 100);
        long long18 = offsetDateTimeField7.roundHalfCeiling((-100L));
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField7.getAsText((long) (byte) 10, locale20);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 36 + "'", int16 == 36);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "47" + "'", str21.equals("47"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField7.getAsText(0, locale13);
        int int16 = offsetDateTimeField7.getMinimumValue((long) 100);
        long long18 = offsetDateTimeField7.roundHalfCeiling((-100L));
        int int19 = offsetDateTimeField7.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 36 + "'", int16 == 36);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 36 + "'", int19 == 36);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
        int int11 = offsetDateTimeField7.getOffset();
        int int12 = offsetDateTimeField7.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 36 + "'", int12 == 36);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period10 = period9.toPeriod();
        org.joda.time.Period period11 = period9.negated();
        try {
            org.joda.time.Hours hours12 = period11.toStandardHours();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Hours as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
        long long14 = offsetDateTimeField7.add(10L, (int) 'a');
        long long16 = offsetDateTimeField7.roundCeiling((long) '#');
        int int18 = offsetDateTimeField7.getMaximumValue((long) 136);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 349200010L + "'", long14 == 349200010L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600000L + "'", long16 == 3600000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 47 + "'", int18 == 47);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 0L);
        long long8 = dateTimeZone1.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean10 = cachedDateTimeZone9.isFixed();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(0L, 0L, periodType13, chronology14);
        org.joda.time.PeriodType periodType16 = periodType13.withWeeksRemoved();
        boolean boolean17 = cachedDateTimeZone9.equals((java.lang.Object) periodType13);
        org.joda.time.PeriodType periodType18 = periodType13.withSecondsRemoved();
        org.joda.time.DurationFieldType durationFieldType19 = null;
        int int20 = periodType18.indexOf(durationFieldType19);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600010L + "'", long8 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField13.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = unsupportedDateTimeField13.getAsText(readablePartial16, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        try {
            long long15 = unsupportedDateTimeField13.roundHalfFloor((long) 47);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField7 = iSOChronology0.weekyears();
        long long10 = durationField7.subtract((long) 33, (int) '#');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1104364799967L) + "'", long10 == (-1104364799967L));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        java.lang.String str6 = cachedDateTimeZone2.getNameKey((long) 10);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        long long17 = unsupportedDateTimeField13.getDifferenceAsLong(100L, 0L);
        org.joda.time.DurationField durationField18 = unsupportedDateTimeField13.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial19 = null;
        try {
            int int20 = unsupportedDateTimeField13.getMinimumValue(readablePartial19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertNull(durationField18);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        java.lang.String str6 = cachedDateTimeZone2.getNameKey((long) 10);
        java.lang.String str8 = cachedDateTimeZone2.getName(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.100" + "'", str8.equals("+00:00:00.100"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone9);
        org.joda.time.Chronology chronology11 = zonedChronology10.withUTC();
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        boolean boolean13 = zonedChronology10.equals((java.lang.Object) periodType12);
        try {
            long long19 = zonedChronology10.getDateTimeMillis((-3600001L), (int) (short) -1, 4, (int) '4', 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.secondOfDay();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology4.weekOfWeekyear();
        boolean boolean7 = gregorianChronology0.equals((java.lang.Object) dateTimeField6);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField6, (int) '#', 33, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for weekOfWeekyear must be in the range [33,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        java.lang.String str16 = unsupportedDateTimeField13.toString();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 8, (-3600000) };
        try {
            int[] intArray23 = unsupportedDateTimeField13.addWrapField(readablePartial17, 4, intArray21, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UnsupportedDateTimeField" + "'", str16.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        java.lang.String str16 = unsupportedDateTimeField13.toString();
        try {
            java.lang.String str18 = unsupportedDateTimeField13.getAsShortText(12960036000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UnsupportedDateTimeField" + "'", str16.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 2440588L, number2, (java.lang.Number) 2590588L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.Period period3 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.PeriodType periodType5 = period4.getPeriodType();
        try {
            org.joda.time.Period period6 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int5 = gregorianChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField6 = gregorianChronology4.weeks();
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType15);
        org.joda.time.Period period18 = period16.withWeeks(10);
        org.joda.time.Period period20 = period16.plusMonths((int) ' ');
        int[] intArray22 = gregorianChronology4.get((org.joda.time.ReadablePeriod) period16, (-3600001L));
        try {
            iSOChronology0.validate(readablePartial3, intArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
        int int11 = offsetDateTimeField7.getOffset();
        int int13 = offsetDateTimeField7.getLeapAmount((long) '#');
        int int14 = offsetDateTimeField7.getOffset();
        long long17 = offsetDateTimeField7.addWrapField((long) 10, (int) 'a');
        int int19 = offsetDateTimeField7.getMaximumValue(0L);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int23 = gregorianChronology22.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField24 = gregorianChronology22.weeks();
        org.joda.time.PeriodType periodType33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType33);
        org.joda.time.Period period36 = period34.withWeeks(10);
        org.joda.time.Period period38 = period34.plusMonths((int) ' ');
        int[] intArray40 = gregorianChronology22.get((org.joda.time.ReadablePeriod) period34, (-3600001L));
        try {
            int[] intArray42 = offsetDateTimeField7.add(readablePartial20, 97, intArray40, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100L) + "'", long10 == (-100L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-39599990L) + "'", long17 == (-39599990L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 47 + "'", int19 == 47);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(intArray40);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) (-149));
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology0.years();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (short) 100, "");
        java.lang.Throwable[] throwableArray12 = illegalFieldValueException11.getSuppressed();
        java.lang.String str13 = illegalFieldValueException11.toString();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology16 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.Chronology chronology17 = lenientChronology16.withUTC();
        org.joda.time.DurationField durationField18 = lenientChronology16.centuries();
        org.joda.time.DateTimeField dateTimeField19 = lenientChronology16.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField21.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) (short) 100, "");
        java.lang.Throwable[] throwableArray26 = illegalFieldValueException25.getSuppressed();
        java.lang.String str27 = illegalFieldValueException25.getFieldName();
        illegalFieldValueException11.addSuppressed((java.lang.Throwable) illegalFieldValueException25);
        java.lang.Number number29 = illegalFieldValueException11.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100 for clockhourOfHalfday is not supported: " + "'", str13.equals("org.joda.time.IllegalFieldValueException: Value 100 for clockhourOfHalfday is not supported: "));
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(lenientChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "clockhourOfHalfday" + "'", str27.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (short) 100 + "'", number29.equals((short) 100));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        long long6 = iSOChronology2.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.year();
        org.joda.time.DurationField durationField9 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.weekyearOfCentury();
        boolean boolean12 = period1.equals((java.lang.Object) dateTimeField11);
        org.joda.time.Seconds seconds13 = period1.toStandardSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(seconds13);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 47, (-1104364799967L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1104364800014L + "'", long2 == 1104364800014L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DurationField durationField4 = iSOChronology0.weeks();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, (-3600000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        long long17 = unsupportedDateTimeField13.getDifferenceAsLong(100L, 0L);
        org.joda.time.DurationField durationField18 = unsupportedDateTimeField13.getRangeDurationField();
        try {
            java.lang.String str20 = unsupportedDateTimeField13.getAsText((long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertNull(durationField18);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(1L, 2440588L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2440587L) + "'", long2 == (-2440587L));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "-01:00", 0, 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long10 = dateTimeZone6.getMillisKeepLocal(dateTimeZone8, 0L);
        long long13 = dateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        boolean boolean15 = cachedDateTimeZone14.isFixed();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(0L, 0L, periodType18, chronology19);
        org.joda.time.PeriodType periodType21 = periodType18.withWeeksRemoved();
        boolean boolean22 = cachedDateTimeZone14.equals((java.lang.Object) periodType18);
        long long24 = cachedDateTimeZone14.nextTransition((long) 10);
        long long26 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone14, (-100L));
        java.util.TimeZone timeZone27 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600010L + "'", long13 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 3599900L + "'", long26 == 3599900L);
        org.junit.Assert.assertNotNull(timeZone27);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) ' ', 'a', 6, (int) '4', (int) (short) 100, false, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("+00:00:00.032", false);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addCutover((int) (short) 100, ' ', 97, 0, 6, true, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = unsupportedDateTimeField13.getAsText(0L, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(349200000L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 349200000 + "'", int1 == 349200000);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField7.getWrappedField();
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField7.getMaximumValue(readablePartial13);
        try {
            long long17 = offsetDateTimeField7.set((long) 37, 136);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 136 for clockhourOfHalfday must be in the range [36,47]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 47 + "'", int14 == 47);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField13.getRangeDurationField();
        long long18 = unsupportedDateTimeField13.getDifferenceAsLong(3600010L, (long) '#');
        try {
            long long21 = unsupportedDateTimeField13.addWrapField(100L, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3599975L + "'", long18 == 3599975L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        boolean boolean14 = unsupportedDateTimeField13.isSupported();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        org.joda.time.ReadablePartial readablePartial16 = null;
        try {
            int int17 = unsupportedDateTimeField13.getMinimumValue(readablePartial16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 0);
        org.joda.time.Period period3 = period1.plusMillis((int) (byte) -1);
        org.joda.time.Period period5 = org.joda.time.Period.weeks((-3600000));
        org.joda.time.Period period7 = period5.withSeconds((-52));
        boolean boolean8 = period1.equals((java.lang.Object) period7);
        org.joda.time.Period period10 = period7.plusYears((int) (short) 10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField7.getAsText(0, locale13);
        int int16 = offsetDateTimeField7.getMinimumValue((long) 100);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField7.getAsText(readablePartial17, 0, locale19);
        boolean boolean21 = offsetDateTimeField7.isLenient();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField7, 35, 0, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for clockhourOfHalfday must be in the range [0,6]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 36 + "'", int16 == 36);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("ZonedChronology[ISOChronology[UTC], UTC]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ZonedChronology[ISOChronology[UTC], UTC]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
        int int11 = offsetDateTimeField7.getOffset();
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField7.getAsShortText(readablePartial12, 6, locale14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology18 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Chronology chronology19 = lenientChronology18.withUTC();
        org.joda.time.DurationField durationField20 = lenientChronology18.centuries();
        org.joda.time.DateTimeField dateTimeField21 = lenientChronology18.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField23.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) (short) 100, "");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType24, (-3600000));
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology32 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology30);
        org.joda.time.Chronology chronology33 = lenientChronology32.withUTC();
        org.joda.time.DurationField durationField34 = lenientChronology32.centuries();
        org.joda.time.DateTimeField dateTimeField35 = lenientChronology32.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField37.getType();
        java.util.Locale locale40 = null;
        java.lang.String str41 = offsetDateTimeField37.getAsText(35, locale40);
        org.joda.time.ReadablePartial readablePartial42 = null;
        int int43 = offsetDateTimeField37.getMaximumValue(readablePartial42);
        org.joda.time.DurationField durationField44 = offsetDateTimeField37.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField44);
        try {
            long long48 = unsupportedDateTimeField45.set(12960036000000L, (-149));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100L) + "'", long10 == (-100L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "6" + "'", str15.equals("6"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(lenientChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(lenientChronology32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "35" + "'", str41.equals("35"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 47 + "'", int43 == 47);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        boolean boolean14 = unsupportedDateTimeField13.isSupported();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        try {
            long long17 = unsupportedDateTimeField13.roundCeiling(349200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("ZonedChronology[ISOChronology[UTC], UTC]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ZonedChronology[ISOChronology[UTC], UTC]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.PeriodType periodType5 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withSecondsRemoved();
        int int7 = periodType6.size();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        java.lang.String str16 = unsupportedDateTimeField13.toString();
        try {
            long long18 = unsupportedDateTimeField13.roundHalfCeiling(96L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UnsupportedDateTimeField" + "'", str16.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "-01:00", 0, 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long10 = dateTimeZone6.getMillisKeepLocal(dateTimeZone8, 0L);
        long long13 = dateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        boolean boolean15 = cachedDateTimeZone14.isFixed();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(0L, 0L, periodType18, chronology19);
        org.joda.time.PeriodType periodType21 = periodType18.withWeeksRemoved();
        boolean boolean22 = cachedDateTimeZone14.equals((java.lang.Object) periodType18);
        long long24 = cachedDateTimeZone14.nextTransition((long) 10);
        long long26 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone14, (-100L));
        long long28 = fixedDateTimeZone4.nextTransition((-3599990L));
        long long30 = fixedDateTimeZone4.previousTransition(126000004L);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long36 = dateTimeZone32.getMillisKeepLocal(dateTimeZone34, 0L);
        long long39 = dateTimeZone32.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone40 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone32);
        int int42 = dateTimeZone32.getOffsetFromLocal((long) (short) 10);
        long long44 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone32, 1104364800014L);
        java.lang.String str46 = fixedDateTimeZone4.getShortName(3600000L);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600010L + "'", long13 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 3599900L + "'", long26 == 3599900L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-3599990L) + "'", long28 == (-3599990L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 126000004L + "'", long30 == 126000004L);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 3600010L + "'", long39 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-3600000) + "'", int42 == (-3600000));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1104368400014L + "'", long44 == 1104368400014L);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+00:00" + "'", str46.equals("+00:00"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField7.getWrappedField();
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField7.getMaximumValue(readablePartial13);
        int int15 = offsetDateTimeField7.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = offsetDateTimeField7.getMinimumValue(readablePartial16);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 47 + "'", int14 == 47);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 47 + "'", int15 == 47);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 36 + "'", int17 == 36);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 349200000, number2, (java.lang.Number) 2230000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.joda.time.Period period3 = period1.withMillis((int) '#');
        int int4 = period3.getMonths();
        org.joda.time.Duration duration5 = period3.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period8 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant6, periodType7);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType7.indexOf(durationFieldType9);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField13.getRangeDurationField();
        try {
            long long18 = unsupportedDateTimeField13.set((long) 'a', "7");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(33);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder2.setStandardOffset(1);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder2.addCutover((int) ' ', '4', 36, (int) (byte) 1, (int) ' ', true, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfHour();
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(2230000L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2230000 + "'", int1 == 2230000);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (short) 100, "");
        java.lang.Throwable[] throwableArray12 = illegalFieldValueException11.getSuppressed();
        java.lang.String str13 = illegalFieldValueException11.toString();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology16 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.Chronology chronology17 = lenientChronology16.withUTC();
        org.joda.time.DurationField durationField18 = lenientChronology16.centuries();
        org.joda.time.DateTimeField dateTimeField19 = lenientChronology16.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField21.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) (short) 100, "");
        java.lang.Throwable[] throwableArray26 = illegalFieldValueException25.getSuppressed();
        java.lang.String str27 = illegalFieldValueException25.getFieldName();
        illegalFieldValueException11.addSuppressed((java.lang.Throwable) illegalFieldValueException25);
        boolean boolean29 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException25);
        boolean boolean30 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException25);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100 for clockhourOfHalfday is not supported: " + "'", str13.equals("org.joda.time.IllegalFieldValueException: Value 100 for clockhourOfHalfday is not supported: "));
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(lenientChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "clockhourOfHalfday" + "'", str27.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
        int int11 = offsetDateTimeField7.getOffset();
        int int13 = offsetDateTimeField7.getLeapAmount((long) '#');
        int int14 = offsetDateTimeField7.getOffset();
        long long17 = offsetDateTimeField7.addWrapField((long) 10, (int) 'a');
        long long20 = offsetDateTimeField7.add((-3600001L), (-3600000));
        org.joda.time.ReadablePartial readablePartial21 = null;
        java.util.Locale locale22 = null;
        try {
            java.lang.String str23 = offsetDateTimeField7.getAsText(readablePartial21, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100L) + "'", long10 == (-100L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-39599990L) + "'", long17 == (-39599990L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-12960003600001L) + "'", long20 == (-12960003600001L));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField13.getRangeDurationField();
        try {
            long long18 = unsupportedDateTimeField13.set(2590588L, "(\"org.joda.time.JodaTimePermission\" \"-01:00\")");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
        int int11 = offsetDateTimeField7.getOffset();
        int int13 = offsetDateTimeField7.getLeapAmount((long) '#');
        int int14 = offsetDateTimeField7.getOffset();
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = offsetDateTimeField7.getAsText(readablePartial15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100L) + "'", long10 == (-100L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Duration duration3 = period1.toDurationFrom(readableInstant2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Period period5 = period1.normalizedStandard(periodType4);
        org.joda.time.Period period6 = period1.toPeriod();
        try {
            int int8 = period1.getValue((-3600000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        int int8 = offsetDateTimeField7.getOffset();
        java.util.Locale locale11 = null;
        try {
            long long12 = offsetDateTimeField7.set(2230000L, "org.joda.time.IllegalFieldValueException: Value 100 for clockhourOfHalfday is not supported: ", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value 100 for clockhourOfHalfday is not supported: \" for clockhourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period4 = org.joda.time.Period.months(0);
        org.joda.time.Period period6 = period4.withMillis((int) '#');
        int int7 = period6.getMonths();
        org.joda.time.Duration duration8 = period6.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(0L, 0L, periodType14, chronology15);
        org.joda.time.PeriodType periodType17 = periodType14.withWeeksRemoved();
        org.joda.time.PeriodType periodType18 = periodType17.withSecondsRemoved();
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration8, periodType17);
        org.joda.time.ReadableInterval readableInterval20 = null;
        org.joda.time.ReadableInterval readableInterval21 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval20);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval20);
        org.joda.time.Period period23 = new org.joda.time.Period(0L, 35L, periodType17, chronology22);
        org.joda.time.Period period25 = period23.minusSeconds((int) (byte) 100);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(readableInterval21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField13.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray18 = null;
        java.util.Locale locale20 = null;
        try {
            int[] intArray21 = unsupportedDateTimeField13.set(readablePartial16, (int) (byte) 0, intArray18, "+10:08", locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        int int17 = unsupportedDateTimeField13.getDifference((long) (-52), (long) 'a');
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = unsupportedDateTimeField13.getAsShortText(readablePartial18, (int) (short) -1, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-149) + "'", int17 == (-149));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period10 = period9.toPeriod();
        org.joda.time.Period period12 = period9.withYears((int) ' ');
        org.joda.time.Period period14 = period12.withSeconds(2230000);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 2230000, (long) (byte) -1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        java.lang.String str3 = periodType2.toString();
        int int4 = periodType2.size();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[YearDayTime]" + "'", str3.equals("PeriodType[YearDayTime]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = period1.get(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        boolean boolean7 = period1.isSupported(durationFieldType6);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(0L, 0L, periodType12, chronology13);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType12, chronology15);
        org.joda.time.Period period17 = period1.normalizedStandard(periodType12);
        int int18 = period17.getSeconds();
        try {
            org.joda.time.DurationFieldType durationFieldType20 = period17.getFieldType((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        java.lang.String str16 = unsupportedDateTimeField13.toString();
        java.util.Locale locale19 = null;
        try {
            long long20 = unsupportedDateTimeField13.set((long) (-1), "GregorianChronology[+00:00:00.100]", locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UnsupportedDateTimeField" + "'", str16.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Chronology chronology4 = lenientChronology3.withUTC();
        org.joda.time.DurationField durationField5 = lenientChronology3.centuries();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology3.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField8.getType();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.secondOfMinute();
        org.joda.time.DurationField durationField13 = iSOChronology10.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField14 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField13);
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField14.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField14.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType16, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        int int2 = periodType0.indexOf(durationFieldType1);
        java.lang.String str3 = periodType0.toString();
        org.joda.time.PeriodType periodType4 = periodType0.withMinutesRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[Millis]" + "'", str3.equals("PeriodType[Millis]"));
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DurationField durationField5 = lenientChronology2.millis();
        org.joda.time.Chronology chronology6 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField7 = lenientChronology2.hours();
        java.lang.String str8 = lenientChronology2.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "LenientChronology[ISOChronology[+00:00:00.100]]" + "'", str8.equals("LenientChronology[ISOChronology[+00:00:00.100]]"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        java.lang.String str16 = unsupportedDateTimeField13.toString();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray19 = null;
        java.util.Locale locale21 = null;
        try {
            int[] intArray22 = unsupportedDateTimeField13.set(readablePartial17, 349200000, intArray19, "46", locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UnsupportedDateTimeField" + "'", str16.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 4, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DurationField durationField4 = iSOChronology0.weeks();
        org.joda.time.DurationField durationField5 = iSOChronology0.weeks();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 0L);
        long long8 = dateTimeZone1.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean10 = cachedDateTimeZone9.isFixed();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(0L, 0L, periodType13, chronology14);
        org.joda.time.PeriodType periodType16 = periodType13.withWeeksRemoved();
        boolean boolean17 = cachedDateTimeZone9.equals((java.lang.Object) periodType13);
        long long19 = cachedDateTimeZone9.nextTransition((long) 10);
        int int21 = cachedDateTimeZone9.getStandardOffset(126000004L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600010L + "'", long8 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-3600000) + "'", int21 == (-3600000));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) ' ', 'a', 6, (int) '4', (int) (short) 100, false, (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder8.setStandardOffset(4);
        java.io.DataOutput dataOutput12 = null;
        try {
            dateTimeZoneBuilder10.writeTo("+00:00:00.032", dataOutput12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.monthOfYear();
        try {
            long long12 = gregorianChronology0.getDateTimeMillis(35, 35, (int) (byte) 1, (int) (short) 10, 6, (int) (short) 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
        int int11 = offsetDateTimeField7.getOffset();
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField7.getAsShortText(readablePartial12, 6, locale14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology18 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Chronology chronology19 = lenientChronology18.withUTC();
        org.joda.time.DurationField durationField20 = lenientChronology18.centuries();
        org.joda.time.DateTimeField dateTimeField21 = lenientChronology18.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField23.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) (short) 100, "");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType24, (-3600000));
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology32 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology30);
        org.joda.time.Chronology chronology33 = lenientChronology32.withUTC();
        org.joda.time.DurationField durationField34 = lenientChronology32.centuries();
        org.joda.time.DateTimeField dateTimeField35 = lenientChronology32.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField37.getType();
        java.util.Locale locale40 = null;
        java.lang.String str41 = offsetDateTimeField37.getAsText(35, locale40);
        org.joda.time.ReadablePartial readablePartial42 = null;
        int int43 = offsetDateTimeField37.getMaximumValue(readablePartial42);
        org.joda.time.DurationField durationField44 = offsetDateTimeField37.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        org.joda.time.Period period48 = org.joda.time.Period.months(0);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.Duration duration50 = period48.toDurationFrom(readableInstant49);
        long long51 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration50);
        org.joda.time.ReadableInstant readableInstant52 = null;
        org.joda.time.PeriodType periodType53 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType54 = org.joda.time.DateTimeUtils.getPeriodType(periodType53);
        org.joda.time.Period period55 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration50, readableInstant52, periodType53);
        try {
            org.joda.time.Period period56 = new org.joda.time.Period((java.lang.Object) unsupportedDateTimeField45, periodType53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.field.UnsupportedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100L) + "'", long10 == (-100L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "6" + "'", str15.equals("6"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(lenientChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(lenientChronology32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "35" + "'", str41.equals("35"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 47 + "'", int43 == 47);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "clockhourOfHalfday" + "'", str46.equals("clockhourOfHalfday"));
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(duration50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(periodType54);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = period1.get(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        boolean boolean7 = period1.isSupported(durationFieldType6);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(0L, 0L, periodType12, chronology13);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType12, chronology15);
        org.joda.time.Period period17 = period1.normalizedStandard(periodType12);
        org.joda.time.Duration duration18 = period17.toStandardDuration();
        long long19 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long26 = dateTimeZone22.getMillisKeepLocal(dateTimeZone24, 0L);
        long long29 = dateTimeZone22.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone30 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone22);
        boolean boolean31 = cachedDateTimeZone30.isFixed();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.Period period36 = new org.joda.time.Period(0L, 0L, periodType34, chronology35);
        org.joda.time.PeriodType periodType37 = periodType34.withWeeksRemoved();
        boolean boolean38 = cachedDateTimeZone30.equals((java.lang.Object) periodType34);
        org.joda.time.PeriodType periodType39 = periodType34.withSecondsRemoved();
        org.joda.time.Period period40 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration18, readableInstant20, periodType34);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3120000L + "'", long19 == 3120000L);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3600010L + "'", long29 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(periodType39);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        org.joda.time.Period period13 = period11.plusMinutes(10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period13.getFieldTypes();
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("35");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"35\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) ' ', 'a', 6, (int) '4', (int) (short) 100, false, (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder8.setStandardOffset(4);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = dateTimeZoneBuilder10.addCutover((int) (short) 1, ' ', (int) (short) 0, 10, 100, false, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("UnsupportedDateTimeField");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"UnsupportedDateTimeField\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"UnsupportedDateTimeField\")"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Seconds seconds5 = period4.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period4.get(durationFieldType6);
        int int8 = period4.getMinutes();
        org.joda.time.Period period10 = period4.minusMinutes(97);
        try {
            org.joda.time.Period period12 = period10.plusWeeks(36);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "-01:00");
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(97, 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Seconds seconds5 = period4.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period4.get(durationFieldType6);
        boolean boolean9 = period4.equals((java.lang.Object) 10L);
        try {
            org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Seconds seconds5 = period4.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period4.get(durationFieldType6);
        int int8 = period4.getMinutes();
        org.joda.time.Period period10 = period4.minusMinutes(97);
        org.joda.time.MutablePeriod mutablePeriod11 = period10.toMutablePeriod();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        boolean boolean14 = mutablePeriod11.equals((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(mutablePeriod11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(3599999L, 86399900L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-82799901L) + "'", long2 == (-82799901L));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) ' ', 'a', 6, (int) '4', (int) (short) 100, false, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("+00:00:00.032", false);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addCutover(10, 'a', 8, (-52), (int) (short) 0, false, (-52));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        boolean boolean14 = unsupportedDateTimeField13.isSupported();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField13.getType();
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = unsupportedDateTimeField13.getAsShortText(readablePartial17, (-1), locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.Period period8 = new org.joda.time.Period((-149), 1, (-52), 10, (int) (byte) -1, 35, (int) '4', (int) '4');
        org.joda.time.Period period10 = period8.withYears(4);
        org.joda.time.MutablePeriod mutablePeriod11 = period10.toMutablePeriod();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.Period period14 = period10.withFieldAdded(durationFieldType12, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(mutablePeriod11);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        boolean boolean14 = unsupportedDateTimeField13.isSupported();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        try {
            long long18 = unsupportedDateTimeField13.set((long) 349200000, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "-01:00", 0, 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long10 = dateTimeZone6.getMillisKeepLocal(dateTimeZone8, 0L);
        long long13 = dateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        boolean boolean15 = cachedDateTimeZone14.isFixed();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(0L, 0L, periodType18, chronology19);
        org.joda.time.PeriodType periodType21 = periodType18.withWeeksRemoved();
        boolean boolean22 = cachedDateTimeZone14.equals((java.lang.Object) periodType18);
        long long24 = cachedDateTimeZone14.nextTransition((long) 10);
        long long26 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone14, (-100L));
        java.lang.String str28 = fixedDateTimeZone4.getNameKey((long) (-3600000));
        int int30 = fixedDateTimeZone4.getStandardOffset((long) (short) 10);
        int int32 = fixedDateTimeZone4.getStandardOffset(35L);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600010L + "'", long13 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 3599900L + "'", long26 == 3599900L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-01:00" + "'", str28.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withMinutesRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00", "+00:00");
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Chronology chronology4 = lenientChronology3.withUTC();
        org.joda.time.DurationField durationField5 = lenientChronology3.centuries();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology3.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField8.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (short) 100, "");
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.Period period1 = org.joda.time.Period.years(47);
        org.joda.time.Period period3 = period1.withSeconds((int) (short) -1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = unsupportedDateTimeField13.getAsText((long) 35, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = period1.get(durationFieldType4);
        org.joda.time.Period period7 = period1.minusDays((int) (byte) 1);
        int int8 = period7.getYears();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("+00:00:00.032", (-1), (int) (short) 1, 47);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for +00:00:00.032 must be in the range [1,47]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) 10);
        org.joda.time.Period period3 = period1.plusMinutes(97);
        org.joda.time.Period period5 = period1.withYears(0);
        org.joda.time.Period period7 = period5.withDays((-1));
        org.joda.time.Period period9 = period7.withHours(4);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.months(0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationFrom(readableInstant3);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.minutes();
        int int6 = periodType5.size();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration4, periodType5);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        int int12 = period9.getHours();
        org.joda.time.Period period14 = org.joda.time.Period.months(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period14.toDurationFrom(readableInstant15);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Period period18 = period14.normalizedStandard(periodType17);
        org.joda.time.Period period19 = period9.plus((org.joda.time.ReadablePeriod) period14);
        try {
            org.joda.time.Duration duration20 = period19.toStandardDuration();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Duration as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        java.lang.String str16 = unsupportedDateTimeField13.toString();
        try {
            int int17 = unsupportedDateTimeField13.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UnsupportedDateTimeField" + "'", str16.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 0L);
        long long8 = dateTimeZone1.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean10 = cachedDateTimeZone9.isFixed();
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler11 = new org.joda.time.tz.ZoneInfoCompiler();
        boolean boolean12 = cachedDateTimeZone9.equals((java.lang.Object) zoneInfoCompiler11);
        java.io.BufferedReader bufferedReader13 = null;
        try {
            zoneInfoCompiler11.parseDataFile(bufferedReader13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600010L + "'", long8 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        int int12 = period9.getHours();
        org.joda.time.Period period14 = org.joda.time.Period.months(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period14.toDurationFrom(readableInstant15);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Period period18 = period14.normalizedStandard(periodType17);
        org.joda.time.Period period19 = period9.plus((org.joda.time.ReadablePeriod) period14);
        int int20 = period14.getDays();
        org.joda.time.Period period22 = period14.multipliedBy((-3600000));
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.dayOfWeek();
        org.joda.time.DurationField durationField27 = iSOChronology23.months();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology23.era();
        org.joda.time.Period period29 = new org.joda.time.Period((java.lang.Object) period14, (org.joda.time.Chronology) iSOChronology23);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology23.millisOfSecond();
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.Period period1 = org.joda.time.Period.days(100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        long long17 = unsupportedDateTimeField13.add(97L, (int) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = unsupportedDateTimeField13.getType();
        java.util.Locale locale19 = null;
        try {
            int int20 = unsupportedDateTimeField13.getMaximumShortTextLength(locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 96L + "'", long17 == 96L);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-3600000), 35, (int) (byte) 100, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 0L);
        long long8 = dateTimeZone1.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long13 = cachedDateTimeZone9.convertLocalToUTC((long) 10, false, (long) 36);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600010L + "'", long8 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600010L + "'", long13 == 3600010L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        int int2 = periodType0.indexOf(durationFieldType1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = periodType0.indexOf(durationFieldType3);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period3 = period1.plusWeeks((int) (short) 0);
        int int4 = period3.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.Period period1 = new org.joda.time.Period(126000004L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.monthOfYear();
        try {
            long long12 = gregorianChronology0.getDateTimeMillis(6, (int) '4', (int) (byte) -1, 97, 6, 2230000, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "-01:00", 0, 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long10 = dateTimeZone6.getMillisKeepLocal(dateTimeZone8, 0L);
        long long13 = dateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        boolean boolean15 = cachedDateTimeZone14.isFixed();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(0L, 0L, periodType18, chronology19);
        org.joda.time.PeriodType periodType21 = periodType18.withWeeksRemoved();
        boolean boolean22 = cachedDateTimeZone14.equals((java.lang.Object) periodType18);
        long long24 = cachedDateTimeZone14.nextTransition((long) 10);
        long long26 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone14, (-100L));
        java.lang.String str28 = fixedDateTimeZone4.getNameKey((long) (-3600000));
        int int30 = fixedDateTimeZone4.getStandardOffset((long) (short) 10);
        boolean boolean31 = fixedDateTimeZone4.isFixed();
        java.lang.String str33 = fixedDateTimeZone4.getNameKey((-210858120000000L));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600010L + "'", long13 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 3599900L + "'", long26 == 3599900L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-01:00" + "'", str28.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "-01:00" + "'", str33.equals("-01:00"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        long long17 = unsupportedDateTimeField13.add(97L, (int) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = unsupportedDateTimeField13.getType();
        try {
            long long20 = unsupportedDateTimeField13.roundHalfCeiling((long) 35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 96L + "'", long17 == 96L);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        boolean boolean14 = unsupportedDateTimeField13.isSupported();
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = unsupportedDateTimeField13.getAsShortText(readablePartial15, (int) (short) 100, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(1, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract((-3599990L), (-3600001L));
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 11L + "'", long3 == 11L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        org.joda.time.Period period12 = period9.negated();
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Period period14 = period9.withPeriodType(periodType13);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 33, (long) (-1009312));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-33307296) + "'", int2 == (-33307296));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Seconds seconds5 = period4.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period4.get(durationFieldType6);
        org.joda.time.Duration duration8 = period4.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfYear();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.clockhourOfDay();
        org.joda.time.DurationField durationField15 = gregorianChronology12.eras();
        org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) readableInstant9, (org.joda.time.Chronology) gregorianChronology12);
        try {
            long long21 = gregorianChronology12.getDateTimeMillis(37, (int) 'a', (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("LenientChronology[ISOChronology[+00:00:00.100]]");
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period3 = period1.plusWeeks((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period1.toDurationTo(readableInstant4);
        long long6 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant9);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3120000L + "'", long6 == 3120000L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology4);
        long long11 = lenientChronology5.getDateTimeMillis(101L, (int) ' ', 35, 6, (int) '#');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 117305935L + "'", long11 == 117305935L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        org.joda.time.Period period13 = period11.plusMinutes(10);
        org.joda.time.Period period15 = period13.minusDays(0);
        org.joda.time.Period period17 = period13.minusMonths(2230000);
        org.joda.time.Period period19 = period17.minusMillis(0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
        int int11 = offsetDateTimeField7.getOffset();
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField7.getAsShortText(readablePartial12, 6, locale14);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField7.getWrappedField();
        boolean boolean17 = offsetDateTimeField7.isLenient();
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = offsetDateTimeField7.getAsText(readablePartial18, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100L) + "'", long10 == (-100L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "6" + "'", str15.equals("6"));
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(0L, 0L, periodType4, chronology5);
        org.joda.time.PeriodType periodType7 = periodType4.withWeeksRemoved();
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType4);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        boolean boolean10 = period8.isSupported(durationFieldType9);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        try {
            int int14 = unsupportedDateTimeField13.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = unsupportedDateTimeField13.getAsShortText(97, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("LenientChronology[ISOChronology[+00:00:00.100]]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"LenientChronology[ISOChronology[+00:00:00.100]]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = iSOChronology0.millis();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.Period period1 = org.joda.time.Period.years((-3600000));
        org.joda.time.Period period3 = period1.withMillis((int) (short) -1);
        try {
            int int5 = period3.getValue(33);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField7.getMaximumValue(readablePartial12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField7.getDurationField();
        long long16 = offsetDateTimeField7.roundCeiling((-1L));
        java.lang.String str18 = offsetDateTimeField7.getAsText((long) '4');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 47 + "'", int13 == 47);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3599900L + "'", long16 == 3599900L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "47" + "'", str18.equals("47"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField7.getAsText(0, locale13);
        int int16 = offsetDateTimeField7.getMinimumValue((long) 100);
        long long18 = offsetDateTimeField7.roundHalfCeiling((-100L));
        long long20 = offsetDateTimeField7.roundHalfCeiling(3600000L);
        long long23 = offsetDateTimeField7.add(0L, 97);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 36 + "'", int16 == 36);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-100L) + "'", long18 == (-100L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3599900L + "'", long20 == 3599900L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 349200000L + "'", long23 == 349200000L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(0L, 0L, periodType12, chronology13);
        boolean boolean16 = periodType12.equals((java.lang.Object) 0);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology19 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.Chronology chronology20 = lenientChronology19.withUTC();
        org.joda.time.DurationField durationField21 = lenientChronology19.centuries();
        org.joda.time.DateTimeField dateTimeField22 = lenientChronology19.clockhourOfHalfday();
        org.joda.time.Period period23 = new org.joda.time.Period(62L, (long) (-3600000), periodType12, (org.joda.time.Chronology) lenientChronology19);
        org.joda.time.PeriodType periodType24 = org.joda.time.DateTimeUtils.getPeriodType(periodType12);
        org.joda.time.PeriodType periodType25 = periodType24.withYearsRemoved();
        try {
            org.joda.time.Period period26 = new org.joda.time.Period(0, 33, 1, 0, (int) (short) -1, 0, 37, 36, periodType24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(lenientChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
        int int11 = offsetDateTimeField7.getOffset();
        int int13 = offsetDateTimeField7.getLeapAmount((long) '#');
        java.lang.String str15 = offsetDateTimeField7.getAsShortText((-100L));
        try {
            long long18 = offsetDateTimeField7.set((long) 100, (-1009312));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1009312 for clockhourOfHalfday must be in the range [36,47]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100L) + "'", long10 == (-100L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "47" + "'", str15.equals("47"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        int int17 = unsupportedDateTimeField13.getDifference((long) (-52), (long) 'a');
        org.joda.time.ReadablePartial readablePartial18 = null;
        try {
            int int19 = unsupportedDateTimeField13.getMinimumValue(readablePartial18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-149) + "'", int17 == (-149));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Seconds seconds5 = period4.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period4.get(durationFieldType6);
        int int8 = period4.getMinutes();
        org.joda.time.Period period10 = period4.plusYears((int) (short) 100);
        org.joda.time.Period period12 = period4.plusDays((int) (byte) 100);
        int int13 = period4.getYears();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        int int10 = offsetDateTimeField7.getLeapAmount((long) (short) 1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText((int) (short) 1, locale12);
        try {
            long long16 = offsetDateTimeField7.set((-3599990L), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for clockhourOfHalfday must be in the range [36,47]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("UnsupportedDateTimeField", (java.lang.Number) 349200000, (java.lang.Number) (-1.0d), (java.lang.Number) 1);
        java.lang.String str5 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 349200000 for UnsupportedDateTimeField must be in the range [-1.0,1]" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value 349200000 for UnsupportedDateTimeField must be in the range [-1.0,1]"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, (-3600000), (-1009312), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DurationField durationField7 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        int int13 = dateTimeZone9.getOffset(readableInstant12);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) ' ', 'a', 6, (int) '4', (int) (short) 100, false, (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder8.setStandardOffset(4);
        java.io.OutputStream outputStream12 = null;
        try {
            dateTimeZoneBuilder8.writeTo("org.joda.time.IllegalFieldValueException: Value 100 for clockhourOfHalfday is not supported: ", outputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        int int17 = unsupportedDateTimeField13.getDifference(2590588L, 3599900L);
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField21 = gregorianChronology19.weeks();
        org.joda.time.PeriodType periodType30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType30);
        org.joda.time.Period period33 = period31.withWeeks(10);
        org.joda.time.Period period35 = period31.plusMonths((int) ' ');
        int[] intArray37 = gregorianChronology19.get((org.joda.time.ReadablePeriod) period31, (-3600001L));
        try {
            int int38 = unsupportedDateTimeField13.getMaximumValue(readablePartial18, intArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1009312) + "'", int17 == (-1009312));
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getShortName((long) 2230000, locale3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.100" + "'", str4.equals("+00:00:00.100"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", (int) '#', (-33307296), 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for  must be in the range [-33307296,4]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
        int int11 = offsetDateTimeField7.getOffset();
        int int13 = offsetDateTimeField7.getLeapAmount((long) '#');
        int int14 = offsetDateTimeField7.getOffset();
        long long17 = offsetDateTimeField7.addWrapField((long) 10, (int) 'a');
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField7.getAsShortText(96L, locale19);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100L) + "'", long10 == (-100L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-39599990L) + "'", long17 == (-39599990L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "47" + "'", str20.equals("47"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        int int10 = offsetDateTimeField7.getLeapAmount((long) (short) 1);
        long long12 = offsetDateTimeField7.roundHalfFloor(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-100L) + "'", long12 == (-100L));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866846400000L) + "'", long1 == (-210866846400000L));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfEra();
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        int int8 = offsetDateTimeField7.getOffset();
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField7.getMaximumTextLength(locale9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) ' ', 'a', 6, (int) '4', (int) (short) 100, false, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("+00:00:00.032", false);
        long long14 = dateTimeZone11.adjustOffset((long) 136, false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 136L + "'", long14 == 136L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField7.getMaximumValue(readablePartial12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField7.getDurationField();
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = offsetDateTimeField7.getAsShortText(readablePartial15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 47 + "'", int13 == 47);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        long long16 = unsupportedDateTimeField13.getDifferenceAsLong((long) 97, (long) (byte) 0);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        try {
            long long20 = unsupportedDateTimeField13.addWrapField((long) 33, 136);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfHour();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, 4, 2, 2230000);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("PeriodType[Millis]", false);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("1", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = periodType2.indexOf(durationFieldType3);
        java.lang.String str5 = periodType2.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField8 = gregorianChronology6.weeks();
        org.joda.time.PeriodType periodType17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType17);
        org.joda.time.Period period20 = period18.withWeeks(10);
        org.joda.time.Period period22 = period18.plusMonths((int) ' ');
        int[] intArray24 = gregorianChronology6.get((org.joda.time.ReadablePeriod) period18, (-3600001L));
        org.joda.time.Period period25 = new org.joda.time.Period((long) (-3600000), 0L, periodType2, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.Chronology chronology26 = gregorianChronology6.withUTC();
        try {
            long long34 = gregorianChronology6.getDateTimeMillis((int) (byte) 1, 97, 47, 8, 35, 136, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 136 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PeriodType[Millis]" + "'", str5.equals("PeriodType[Millis]"));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) (-149));
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfMonth();
        java.lang.String str5 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[+00:00:00.100]" + "'", str5.equals("GregorianChronology[+00:00:00.100]"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.Period period1 = org.joda.time.Period.years((-3600000));
        org.joda.time.MutablePeriod mutablePeriod2 = period1.toMutablePeriod();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        long long7 = iSOChronology3.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology3.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.year();
        org.joda.time.DurationField durationField10 = iSOChronology3.minutes();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology3, dateTimeZone12);
        org.joda.time.Chronology chronology14 = zonedChronology13.withUTC();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        boolean boolean16 = zonedChronology13.equals((java.lang.Object) periodType15);
        org.joda.time.PeriodType periodType17 = periodType15.withDaysRemoved();
        try {
            org.joda.time.Period period18 = period1.normalizedStandard(periodType15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(mutablePeriod2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(periodType17);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 4);
        org.joda.time.Weeks weeks2 = period1.toStandardWeeks();
        org.junit.Assert.assertNotNull(weeks2);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(37, (int) (short) 100, (-1009312));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
        int int11 = offsetDateTimeField7.getOffset();
        int int13 = offsetDateTimeField7.getLeapAmount((long) ' ');
        long long15 = offsetDateTimeField7.roundHalfEven((-1L));
        boolean boolean17 = offsetDateTimeField7.isLeap((long) (-33307296));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100L) + "'", long10 == (-100L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-100L) + "'", long15 == (-100L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (short) 100, "");
        java.lang.Throwable[] throwableArray12 = illegalFieldValueException11.getSuppressed();
        java.lang.String str13 = illegalFieldValueException11.toString();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology16 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.Chronology chronology17 = lenientChronology16.withUTC();
        org.joda.time.DurationField durationField18 = lenientChronology16.centuries();
        org.joda.time.DateTimeField dateTimeField19 = lenientChronology16.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField21.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) (short) 100, "");
        java.lang.Throwable[] throwableArray26 = illegalFieldValueException25.getSuppressed();
        java.lang.String str27 = illegalFieldValueException25.getFieldName();
        illegalFieldValueException11.addSuppressed((java.lang.Throwable) illegalFieldValueException25);
        illegalFieldValueException25.prependMessage("hi!");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100 for clockhourOfHalfday is not supported: " + "'", str13.equals("org.joda.time.IllegalFieldValueException: Value 100 for clockhourOfHalfday is not supported: "));
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(lenientChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "clockhourOfHalfday" + "'", str27.equals("clockhourOfHalfday"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.eras();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) (-65L));
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            long long8 = gregorianChronology0.set(readablePartial6, (long) 33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfDay();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (byte) 0, 349200000, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for minuteOfDay must be in the range [349200000,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        boolean boolean14 = unsupportedDateTimeField13.isSupported();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        try {
            long long18 = unsupportedDateTimeField13.set(0L, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.months(0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationFrom(readableInstant3);
        long long5 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType8 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration4, readableInstant6, periodType7);
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration4);
        org.joda.time.Period period12 = period10.plusMillis(2);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        long long17 = unsupportedDateTimeField13.add(97L, (int) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = unsupportedDateTimeField13.getType();
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = unsupportedDateTimeField13.getAsShortText((-12960003600001L), locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 96L + "'", long17 == 96L);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField6 = lenientChronology2.years();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "-01:00", 0, 1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long10 = dateTimeZone6.getMillisKeepLocal(dateTimeZone8, 0L);
        long long13 = dateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        boolean boolean15 = cachedDateTimeZone14.isFixed();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(0L, 0L, periodType18, chronology19);
        org.joda.time.PeriodType periodType21 = periodType18.withWeeksRemoved();
        boolean boolean22 = cachedDateTimeZone14.equals((java.lang.Object) periodType18);
        long long24 = cachedDateTimeZone14.nextTransition((long) 10);
        long long26 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone14, (-100L));
        java.lang.String str28 = cachedDateTimeZone14.getNameKey((long) 2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600010L + "'", long13 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 3599900L + "'", long26 == 3599900L);
        org.junit.Assert.assertNull(str28);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField13.getRangeDurationField();
        try {
            long long17 = unsupportedDateTimeField13.roundHalfEven(2230000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(0L, 0L, periodType4, chronology5);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType4, chronology7);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType4.indexOf(durationFieldType9);
        org.joda.time.PeriodType periodType11 = periodType4.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-52), (java.lang.Number) 3599975L, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        try {
            org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) chronology3, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.LenientChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) '#', 136);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4760 + "'", int2 == 4760);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        java.lang.String str6 = cachedDateTimeZone2.getNameKey((long) (byte) 1);
        int int8 = cachedDateTimeZone2.getOffset(3120000L);
        int int10 = cachedDateTimeZone2.getStandardOffset(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        int int12 = period9.getHours();
        try {
            org.joda.time.DurationFieldType durationFieldType14 = period9.getFieldType(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology0.months();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType11);
        org.joda.time.Period period14 = period12.withWeeks(10);
        org.joda.time.Period period16 = period12.plusMonths((int) ' ');
        int[] intArray18 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period12, (-3600001L));
        try {
            org.joda.time.Duration duration19 = period12.toStandardDuration();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Duration as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 0L);
        long long8 = dateTimeZone1.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.TimeZone timeZone10 = cachedDateTimeZone9.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600010L + "'", long8 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        long long17 = unsupportedDateTimeField13.getDifferenceAsLong(100L, 0L);
        org.joda.time.DurationField durationField18 = unsupportedDateTimeField13.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology23 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.Chronology chronology24 = lenientChronology23.withUTC();
        org.joda.time.DurationField durationField25 = lenientChronology23.centuries();
        org.joda.time.DateTimeField dateTimeField26 = lenientChronology23.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField28.getType();
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsText(35, locale31);
        long long35 = offsetDateTimeField28.add(10L, (int) 'a');
        long long37 = offsetDateTimeField28.roundCeiling((long) '#');
        boolean boolean38 = offsetDateTimeField28.isSupported();
        org.joda.time.ReadablePartial readablePartial39 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.dayOfYear();
        boolean boolean44 = gregorianChronology41.equals((java.lang.Object) (-149));
        int int45 = gregorianChronology41.getMinimumDaysInFirstWeek();
        org.joda.time.Period period47 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType48 = null;
        int int49 = period47.indexOf(durationFieldType48);
        org.joda.time.Period period51 = period47.minusSeconds(1);
        int[] intArray53 = gregorianChronology41.get((org.joda.time.ReadablePeriod) period47, 3599999L);
        int[] intArray55 = offsetDateTimeField28.addWrapPartial(readablePartial39, 349200000, intArray53, 0);
        try {
            int[] intArray57 = unsupportedDateTimeField13.add(readablePartial19, 5, intArray53, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(lenientChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "35" + "'", str32.equals("35"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 349200010L + "'", long35 == 349200010L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3599900L + "'", long37 == 3599900L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray55);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
        long long14 = offsetDateTimeField7.add(10L, (int) 'a');
        int int16 = offsetDateTimeField7.getMaximumValue((long) 97);
        org.joda.time.DurationField durationField17 = offsetDateTimeField7.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int21 = gregorianChronology20.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField22 = gregorianChronology20.weeks();
        org.joda.time.PeriodType periodType31 = null;
        org.joda.time.Period period32 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType31);
        org.joda.time.Period period34 = period32.withWeeks(10);
        org.joda.time.Period period36 = period32.plusMonths((int) ' ');
        int[] intArray38 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period32, (-3600001L));
        try {
            int[] intArray40 = offsetDateTimeField7.add(readablePartial18, (int) '#', intArray38, 4760);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 349200010L + "'", long14 == 349200010L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 47 + "'", int16 == 47);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("P35Y1M-1W10DT97H1M52.100S");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "P35Y1M-1W10DT97H1M52.100S" + "'", str2.equals("P35Y1M-1W10DT97H1M52.100S"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"P35Y1M-1W10DT97H1M52.100S\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"P35Y1M-1W10DT97H1M52.100S\")"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("P35Y1M-1W10DT97H1M52.100S", "PeriodType[Millis]", 0, 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Seconds seconds5 = period4.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period4.get(durationFieldType6);
        int int8 = period4.getMinutes();
        org.joda.time.Period period10 = period4.plusYears((int) (short) 100);
        org.joda.time.Period period12 = period4.plusHours((int) (byte) 0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.Period period13 = period11.minus(readablePeriod12);
        org.joda.time.Period period14 = period11.negated();
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1009312));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = period1.get(durationFieldType4);
        org.joda.time.Period period7 = period1.minusDays((int) (byte) 1);
        int[] intArray8 = period7.getValues();
        int int9 = period7.getMillis();
        org.joda.time.MutablePeriod mutablePeriod10 = period7.toMutablePeriod();
        org.joda.time.format.PeriodFormatter periodFormatter11 = null;
        java.lang.String str12 = mutablePeriod10.toString(periodFormatter11);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(mutablePeriod10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "P-1DT52M" + "'", str12.equals("P-1DT52M"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
        int int11 = offsetDateTimeField7.getOffset();
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField7.getAsShortText(readablePartial12, 6, locale14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology18 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Chronology chronology19 = lenientChronology18.withUTC();
        org.joda.time.DurationField durationField20 = lenientChronology18.centuries();
        org.joda.time.DateTimeField dateTimeField21 = lenientChronology18.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField23.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) (short) 100, "");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType24, (-3600000));
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology32 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology30);
        org.joda.time.Chronology chronology33 = lenientChronology32.withUTC();
        org.joda.time.DurationField durationField34 = lenientChronology32.centuries();
        org.joda.time.DateTimeField dateTimeField35 = lenientChronology32.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField37.getType();
        java.util.Locale locale40 = null;
        java.lang.String str41 = offsetDateTimeField37.getAsText(35, locale40);
        org.joda.time.ReadablePartial readablePartial42 = null;
        int int43 = offsetDateTimeField37.getMaximumValue(readablePartial42);
        org.joda.time.DurationField durationField44 = offsetDateTimeField37.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        try {
            long long49 = unsupportedDateTimeField45.set((long) 35, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100L) + "'", long10 == (-100L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "6" + "'", str15.equals("6"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(lenientChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(lenientChronology32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "35" + "'", str41.equals("35"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 47 + "'", int43 == 47);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "clockhourOfHalfday" + "'", str46.equals("clockhourOfHalfday"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(3599999);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.joda.time.Period period3 = period1.withMillis((int) '#');
        org.joda.time.Period period5 = period1.minusSeconds(0);
        java.lang.String str6 = period5.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0S" + "'", str6.equals("PT0S"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField13.getRangeDurationField();
        long long18 = unsupportedDateTimeField13.getDifferenceAsLong(3600010L, (long) '#');
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = unsupportedDateTimeField13.getAsShortText(4, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3599975L + "'", long18 == 3599975L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(0L, 0L, periodType4, chronology5);
        boolean boolean8 = periodType4.equals((java.lang.Object) 0);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DateTimeField dateTimeField14 = lenientChronology11.clockhourOfHalfday();
        org.joda.time.Period period15 = new org.joda.time.Period(62L, (long) (-3600000), periodType4, (org.joda.time.Chronology) lenientChronology11);
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.PeriodType periodType18 = periodType17.withYearsRemoved();
        java.lang.String str19 = periodType18.toString();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PeriodType[YearDayTimeNoYears]" + "'", str19.equals("PeriodType[YearDayTimeNoYears]"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.secondOfDay();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology4.weekOfWeekyear();
        boolean boolean7 = gregorianChronology0.equals((java.lang.Object) dateTimeField6);
        try {
            long long12 = gregorianChronology0.getDateTimeMillis((int) '#', 4, (-52), 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = unsupportedDateTimeField13.getType();
        org.joda.time.ReadablePartial readablePartial16 = null;
        try {
            int int17 = unsupportedDateTimeField13.getMinimumValue(readablePartial16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(0L, 0L, periodType5, chronology6);
        org.joda.time.PeriodType periodType8 = periodType5.withWeeksRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(3600010L, (long) 2230000, periodType8);
        org.joda.time.Period period10 = new org.joda.time.Period(obj0, periodType8);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
        int int11 = offsetDateTimeField7.getOffset();
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField7.getAsShortText(readablePartial12, 6, locale14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology18 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Chronology chronology19 = lenientChronology18.withUTC();
        org.joda.time.DurationField durationField20 = lenientChronology18.centuries();
        org.joda.time.DateTimeField dateTimeField21 = lenientChronology18.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField23.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) (short) 100, "");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType24, (-3600000));
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology32 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology30);
        org.joda.time.Chronology chronology33 = lenientChronology32.withUTC();
        org.joda.time.DurationField durationField34 = lenientChronology32.centuries();
        org.joda.time.DateTimeField dateTimeField35 = lenientChronology32.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField37.getType();
        java.util.Locale locale40 = null;
        java.lang.String str41 = offsetDateTimeField37.getAsText(35, locale40);
        org.joda.time.ReadablePartial readablePartial42 = null;
        int int43 = offsetDateTimeField37.getMaximumValue(readablePartial42);
        org.joda.time.DurationField durationField44 = offsetDateTimeField37.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField44);
        java.lang.String str46 = unsupportedDateTimeField45.getName();
        int int49 = unsupportedDateTimeField45.getDifference(96L, (-28799990L));
        java.util.Locale locale51 = null;
        try {
            java.lang.String str52 = unsupportedDateTimeField45.getAsShortText(33, locale51);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100L) + "'", long10 == (-100L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "6" + "'", str15.equals("6"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(lenientChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(lenientChronology32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "35" + "'", str41.equals("35"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 47 + "'", int43 == 47);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "clockhourOfHalfday" + "'", str46.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 8 + "'", int49 == 8);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology0.getZone();
        org.joda.time.DurationField durationField8 = iSOChronology0.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Seconds seconds5 = period4.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period4.get(durationFieldType6);
        org.joda.time.Duration duration8 = period4.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant12);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = unsupportedDateTimeField13.getAsText(readablePartial16, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(33);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder2.setStandardOffset(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder2.setFixedSavings("", (-3600000));
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = dateTimeZoneBuilder2.addCutover((int) (byte) 1, '#', 0, (-1009312), (-52), false, 47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.PeriodType periodType5 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withSecondsRemoved();
        org.joda.time.PeriodType periodType7 = periodType6.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(33);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder2.setStandardOffset(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder2.setFixedSavings("", (-3600000));
        java.io.DataOutput dataOutput9 = null;
        try {
            dateTimeZoneBuilder7.writeTo("40", dataOutput9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Chronology chronology4 = lenientChronology3.withUTC();
        org.joda.time.DurationField durationField5 = lenientChronology3.centuries();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology3.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField8.getType();
        long long11 = offsetDateTimeField8.roundHalfFloor((long) ' ');
        int int12 = offsetDateTimeField8.getOffset();
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText(readablePartial13, 6, locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology19 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.Chronology chronology20 = lenientChronology19.withUTC();
        org.joda.time.DurationField durationField21 = lenientChronology19.centuries();
        org.joda.time.DateTimeField dateTimeField22 = lenientChronology19.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField24.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) (short) 100, "");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType25, (-3600000));
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology33 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology31);
        org.joda.time.Chronology chronology34 = lenientChronology33.withUTC();
        org.joda.time.DurationField durationField35 = lenientChronology33.centuries();
        org.joda.time.DateTimeField dateTimeField36 = lenientChronology33.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField38.getType();
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField38.getAsText(35, locale41);
        org.joda.time.ReadablePartial readablePartial43 = null;
        int int44 = offsetDateTimeField38.getMaximumValue(readablePartial43);
        org.joda.time.DurationField durationField45 = offsetDateTimeField38.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField45);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField48 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType25, 4760);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-100L) + "'", long11 == (-100L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "6" + "'", str16.equals("6"));
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(lenientChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(lenientChronology33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "35" + "'", str42.equals("35"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 47 + "'", int44 == 47);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        long long16 = unsupportedDateTimeField13.getDifferenceAsLong((long) 97, (long) (byte) 0);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        java.util.Locale locale18 = null;
        try {
            int int19 = unsupportedDateTimeField13.getMaximumTextLength(locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(0L, 0L, periodType6, chronology7);
        org.joda.time.PeriodType periodType9 = periodType6.withWeeksRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType6);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology13 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField14 = lenientChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = lenientChronology13.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField16 = lenientChronology13.dayOfYear();
        org.joda.time.Period period17 = new org.joda.time.Period(0L, (-65L), periodType6, (org.joda.time.Chronology) lenientChronology13);
        java.lang.String str18 = periodType6.toString();
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(lenientChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PeriodType[YearDayTime]" + "'", str18.equals("PeriodType[YearDayTime]"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        java.lang.String str6 = cachedDateTimeZone2.getNameKey((long) (byte) 1);
        long long8 = cachedDateTimeZone2.previousTransition(3600010L);
        boolean boolean9 = cachedDateTimeZone2.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600010L + "'", long8 == 3600010L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField7.getMaximumValue(readablePartial12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField7.getDurationField();
        long long17 = durationField14.subtract((long) (byte) 100, 35);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 47 + "'", int13 == 47);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-125999900L) + "'", long17 == (-125999900L));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 30108833654399968L, (java.lang.Number) (-12960003600001L), (java.lang.Number) 1104368400014L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.joda.time.Period period3 = period1.withMillis((int) '#');
        org.joda.time.Period period5 = period1.minusMonths((-52));
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period1.get(durationFieldType6);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        java.util.Locale locale15 = null;
        try {
            java.lang.String str16 = unsupportedDateTimeField13.getAsText(6, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        long long17 = unsupportedDateTimeField13.getDifferenceAsLong(100L, 0L);
        try {
            int int18 = unsupportedDateTimeField13.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
        int int11 = offsetDateTimeField7.getOffset();
        int int13 = offsetDateTimeField7.getLeapAmount((long) ' ');
        long long15 = offsetDateTimeField7.roundHalfEven((-1L));
        long long17 = offsetDateTimeField7.remainder((-210858120000000L));
        org.joda.time.DurationField durationField18 = offsetDateTimeField7.getLeapDurationField();
        try {
            long long21 = offsetDateTimeField7.set((-3599999L), 2230000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2230000 for clockhourOfHalfday must be in the range [36,47]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100L) + "'", long10 == (-100L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-100L) + "'", long15 == (-100L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertNull(durationField18);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        try {
            int int15 = unsupportedDateTimeField13.getMinimumValue(126000004L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
        long long14 = offsetDateTimeField7.add(10L, (int) 'a');
        long long16 = offsetDateTimeField7.roundCeiling((long) '#');
        boolean boolean17 = offsetDateTimeField7.isSupported();
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.dayOfYear();
        boolean boolean23 = gregorianChronology20.equals((java.lang.Object) (-149));
        int int24 = gregorianChronology20.getMinimumDaysInFirstWeek();
        org.joda.time.Period period26 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType27 = null;
        int int28 = period26.indexOf(durationFieldType27);
        org.joda.time.Period period30 = period26.minusSeconds(1);
        int[] intArray32 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period26, 3599999L);
        int[] intArray34 = offsetDateTimeField7.addWrapPartial(readablePartial18, 349200000, intArray32, 0);
        int int35 = offsetDateTimeField7.getOffset();
        long long37 = offsetDateTimeField7.roundCeiling(30108833654399968L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 349200010L + "'", long14 == 349200010L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3599900L + "'", long16 == 3599900L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 30108833657999900L + "'", long37 == 30108833657999900L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) (-149));
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology7 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology8 = lenientChronology7.withUTC();
        org.joda.time.DurationField durationField9 = lenientChronology7.centuries();
        org.joda.time.DateTimeField dateTimeField10 = lenientChronology7.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField12.getAsText(35, locale15);
        long long19 = offsetDateTimeField12.add(10L, (int) 'a');
        long long21 = offsetDateTimeField12.roundCeiling((long) '#');
        boolean boolean22 = gregorianChronology0.equals((java.lang.Object) long21);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(lenientChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "35" + "'", str16.equals("35"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 349200010L + "'", long19 == 349200010L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3599900L + "'", long21 == 3599900L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = lenientChronology11.withUTC();
        org.joda.time.DurationField durationField13 = lenientChronology11.centuries();
        org.joda.time.DurationField durationField14 = lenientChronology11.millis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology18 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField19 = lenientChronology17.centuries();
        org.joda.time.DurationField durationField20 = lenientChronology17.millis();
        org.joda.time.Chronology chronology21 = lenientChronology17.withUTC();
        org.joda.time.DurationField durationField22 = lenientChronology17.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField23 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField22);
        int int24 = preciseDateTimeField23.getMaximumValue();
        org.joda.time.DurationField durationField25 = preciseDateTimeField23.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3599999 + "'", int24 == 3599999);
        org.junit.Assert.assertNotNull(durationField25);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (short) 100, "");
        illegalFieldValueException11.prependMessage("0");
        java.lang.String str14 = illegalFieldValueException11.getFieldName();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        boolean boolean14 = unsupportedDateTimeField13.isSupported();
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int17 = gregorianChronology16.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology16.weeks();
        org.joda.time.PeriodType periodType27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType27);
        org.joda.time.Period period30 = period28.withWeeks(10);
        org.joda.time.Period period32 = period28.plusMonths((int) ' ');
        int[] intArray34 = gregorianChronology16.get((org.joda.time.ReadablePeriod) period28, (-3600001L));
        try {
            int int35 = unsupportedDateTimeField13.getMinimumValue(readablePartial15, intArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.seconds();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-01:00");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long8 = dateTimeZone4.getMillisKeepLocal(dateTimeZone6, 0L);
        long long11 = dateTimeZone4.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        boolean boolean13 = cachedDateTimeZone12.isFixed();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(0L, 0L, periodType16, chronology17);
        org.joda.time.PeriodType periodType19 = periodType16.withWeeksRemoved();
        boolean boolean20 = cachedDateTimeZone12.equals((java.lang.Object) periodType16);
        long long22 = cachedDateTimeZone12.nextTransition((long) 10);
        jodaTimePermission1.checkGuard((java.lang.Object) long22);
        org.joda.time.PeriodType periodType32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType32);
        org.joda.time.Period period35 = period33.withWeeks(10);
        org.joda.time.Period period36 = period33.negated();
        int int38 = period36.getValue(6);
        jodaTimePermission1.checkGuard((java.lang.Object) period36);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-52) + "'", int38 == (-52));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.multipliedBy(47);
        org.joda.time.Period period6 = period1.multipliedBy((int) (short) 1);
        int int7 = period6.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        boolean boolean14 = unsupportedDateTimeField13.isSupported();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfYear();
        boolean boolean21 = gregorianChronology18.equals((java.lang.Object) (-149));
        int int22 = gregorianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.Period period24 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType25 = null;
        int int26 = period24.indexOf(durationFieldType25);
        org.joda.time.Period period28 = period24.minusSeconds(1);
        int[] intArray30 = gregorianChronology18.get((org.joda.time.ReadablePeriod) period24, 3599999L);
        try {
            int[] intArray32 = unsupportedDateTimeField13.set(readablePartial16, 97, intArray30, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '4');
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = period1.get(durationFieldType4);
        org.joda.time.Period period7 = period1.minusDays((int) (byte) 1);
        org.joda.time.Period period8 = period7.normalizedStandard();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        org.joda.time.DurationField durationField16 = unsupportedDateTimeField13.getDurationField();
        org.joda.time.ReadablePartial readablePartial17 = null;
        try {
            int int18 = unsupportedDateTimeField13.getMaximumValue(readablePartial17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText(35, locale10);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField7.getMaximumValue(readablePartial12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField7.getDurationField();
        long long16 = offsetDateTimeField7.roundCeiling((-1L));
        try {
            long long19 = offsetDateTimeField7.set((-3599999L), (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for clockhourOfHalfday must be in the range [36,47]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35" + "'", str11.equals("35"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 47 + "'", int13 == 47);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3599900L + "'", long16 == 3599900L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("0", "349200000");
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getShortName((-1L), locale3);
        java.lang.String str5 = dateTimeZone1.getID();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.032" + "'", str4.equals("+00:00:00.032"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.032" + "'", str5.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(iSOChronology6);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long7 = dateTimeZone3.getMillisKeepLocal(dateTimeZone5, 0L);
        long long10 = dateTimeZone3.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        boolean boolean12 = cachedDateTimeZone11.isFixed();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(0L, 0L, periodType15, chronology16);
        org.joda.time.PeriodType periodType18 = periodType15.withWeeksRemoved();
        boolean boolean19 = cachedDateTimeZone11.equals((java.lang.Object) periodType15);
        org.joda.time.PeriodType periodType20 = periodType15.withSecondsRemoved();
        org.joda.time.Period period21 = new org.joda.time.Period(30108833657999900L, 62L, periodType20);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600010L + "'", long10 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(periodType20);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.minuteOfDay();
        org.joda.time.Chronology chronology10 = iSOChronology5.withUTC();
        boolean boolean11 = lenientChronology2.equals((java.lang.Object) iSOChronology5);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long17 = dateTimeZone13.getMillisKeepLocal(dateTimeZone15, 0L);
        long long20 = dateTimeZone13.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
        java.lang.String str23 = cachedDateTimeZone21.getName((long) 97);
        java.lang.String str25 = cachedDateTimeZone21.getShortName(62L);
        org.joda.time.Chronology chronology26 = lenientChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone21);
        org.joda.time.Period period28 = org.joda.time.Period.months(0);
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Duration duration30 = period28.toDurationFrom(readableInstant29);
        org.joda.time.PeriodType periodType31 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Period period32 = period28.normalizedStandard(periodType31);
        long long35 = lenientChronology2.add((org.joda.time.ReadablePeriod) period32, (-39599990L), (int) (short) -1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3600010L + "'", long20 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-01:00" + "'", str23.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-01:00" + "'", str25.equals("-01:00"));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(duration30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-39599990L) + "'", long35 == (-39599990L));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        java.lang.String str15 = unsupportedDateTimeField13.toString();
        java.lang.String str16 = unsupportedDateTimeField13.toString();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField13.getRangeDurationField();
        try {
            java.lang.String str19 = unsupportedDateTimeField13.getAsShortText((long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnsupportedDateTimeField" + "'", str15.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UnsupportedDateTimeField" + "'", str16.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNull(durationField17);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long10 = offsetDateTimeField7.roundHalfFloor((long) ' ');
        int int11 = offsetDateTimeField7.getOffset();
        int int13 = offsetDateTimeField7.getLeapAmount((long) '#');
        int int14 = offsetDateTimeField7.getOffset();
        long long17 = offsetDateTimeField7.addWrapField((long) 10, (int) 'a');
        long long20 = offsetDateTimeField7.add((-3600001L), (-3600000));
        java.lang.String str21 = offsetDateTimeField7.toString();
        int int23 = offsetDateTimeField7.getMinimumValue(4L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100L) + "'", long10 == (-100L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-39599990L) + "'", long17 == (-39599990L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-12960003600001L) + "'", long20 == (-12960003600001L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "DateTimeField[clockhourOfHalfday]" + "'", str21.equals("DateTimeField[clockhourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 36 + "'", int23 == 36);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.Chronology chronology6 = lenientChronology5.withUTC();
        org.joda.time.DurationField durationField7 = lenientChronology5.centuries();
        org.joda.time.DurationField durationField8 = lenientChronology5.millis();
        org.joda.time.Chronology chronology9 = lenientChronology5.withUTC();
        org.joda.time.DurationField durationField10 = lenientChronology5.weeks();
        org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) readableInterval2, (org.joda.time.Chronology) lenientChronology5);
        org.joda.time.Chronology chronology12 = lenientChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = lenientChronology5.era();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) ' ', 'a', 6, (int) '4', (int) (short) 100, false, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("+00:00:00.032", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.setFixedSavings("clockhourOfHalfday", (int) '4');
        java.io.DataOutput dataOutput16 = null;
        try {
            dateTimeZoneBuilder0.writeTo("1", dataOutput16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.Period period12 = period9.withField(durationFieldType10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField7.getType();
        java.lang.String str14 = offsetDateTimeField7.getAsText(1L);
        boolean boolean15 = offsetDateTimeField7.isSupported();
        boolean boolean17 = offsetDateTimeField7.isLeap(0L);
        java.lang.String str18 = offsetDateTimeField7.getName();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "47" + "'", str14.equals("47"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "clockhourOfHalfday" + "'", str18.equals("clockhourOfHalfday"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        long long11 = offsetDateTimeField7.add((long) (short) 0, 3600010L);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField7.getAsText(0, locale13);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField7.getAsShortText(readablePartial15, 37, locale17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField7.getAsShortText((int) (short) 1, locale20);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int[] intArray24 = null;
        try {
            int[] intArray26 = offsetDateTimeField7.addWrapPartial(readablePartial22, (-33307296), intArray24, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12960036000000L + "'", long11 == 12960036000000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "37" + "'", str18.equals("37"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((-1009312));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-01:00");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long8 = dateTimeZone4.getMillisKeepLocal(dateTimeZone6, 0L);
        long long11 = dateTimeZone4.convertLocalToUTC(10L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        boolean boolean13 = cachedDateTimeZone12.isFixed();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(0L, 0L, periodType16, chronology17);
        org.joda.time.PeriodType periodType19 = periodType16.withWeeksRemoved();
        boolean boolean20 = cachedDateTimeZone12.equals((java.lang.Object) periodType16);
        long long22 = cachedDateTimeZone12.nextTransition((long) 10);
        jodaTimePermission1.checkGuard((java.lang.Object) long22);
        java.security.Permission permission24 = null;
        boolean boolean25 = jodaTimePermission1.implies(permission24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3600010L + "'", long11 == 3600010L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) '#', 1, (-1), 10, (int) 'a', 1, (int) '4', (int) (byte) 100, periodType8);
        org.joda.time.Period period11 = period9.withWeeks(10);
        org.joda.time.Period period13 = period9.multipliedBy((int) ' ');
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology5 = lenientChronology4.withUTC();
        org.joda.time.DurationField durationField6 = lenientChronology4.centuries();
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology4.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfDay();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.secondOfMinute();
        org.joda.time.DurationField durationField14 = iSOChronology11.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField14);
        org.joda.time.DurationField durationField16 = unsupportedDateTimeField15.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = unsupportedDateTimeField15.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType17, 6, (int) (short) 1, (int) (byte) -1);
        long long23 = offsetDateTimeField21.roundHalfCeiling((long) (short) 100);
        java.lang.String str25 = offsetDateTimeField21.getAsText(0L);
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField21.getAsShortText(422000L, locale27);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-100L) + "'", long23 == (-100L));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "7" + "'", str25.equals("7"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        int int10 = offsetDateTimeField7.getDifference(0L, (long) (short) 10);
        long long13 = offsetDateTimeField7.getDifferenceAsLong((-210858120000000L), 2230000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-58571700L) + "'", long13 == (-58571700L));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File file2 = null;
        java.io.File[] fileArray3 = new java.io.File[] { file2 };
        try {
            java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = zoneInfoCompiler0.compile(file1, fileArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, 0L, periodType2, chronology3);
        org.joda.time.Seconds seconds5 = period4.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period4.get(durationFieldType6);
        int int8 = period4.getMinutes();
        org.joda.time.Period period10 = period4.plusYears((int) (short) 100);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(0L, 0L, periodType18, chronology19);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period((long) (byte) 1, (long) (short) 10, periodType18, chronology21);
        org.joda.time.Period period23 = new org.joda.time.Period((-1104364799967L), 422000L, periodType18);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology26 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology24);
        org.joda.time.Chronology chronology27 = lenientChronology26.withUTC();
        org.joda.time.DurationField durationField28 = lenientChronology26.centuries();
        org.joda.time.DateTimeField dateTimeField29 = lenientChronology26.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField31.getType();
        long long35 = offsetDateTimeField31.add((long) (short) 0, 3600010L);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField31.getType();
        java.lang.String str38 = offsetDateTimeField31.getAsText(1L);
        boolean boolean39 = offsetDateTimeField31.isLenient();
        java.lang.String str41 = offsetDateTimeField31.getAsShortText(3600000L);
        boolean boolean42 = periodType18.equals((java.lang.Object) 3600000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int44 = gregorianChronology43.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology47 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology45);
        org.joda.time.DateTimeField dateTimeField48 = lenientChronology47.secondOfDay();
        org.joda.time.DateTimeField dateTimeField49 = lenientChronology47.weekOfWeekyear();
        boolean boolean50 = gregorianChronology43.equals((java.lang.Object) dateTimeField49);
        org.joda.time.Period period51 = new org.joda.time.Period(0L, periodType18, (org.joda.time.Chronology) gregorianChronology43);
        org.joda.time.DurationFieldType[] durationFieldTypeArray52 = period51.getFieldTypes();
        org.joda.time.Period period53 = period10.plus((org.joda.time.ReadablePeriod) period51);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(lenientChronology26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 12960036000000L + "'", long35 == 12960036000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "47" + "'", str38.equals("47"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "36" + "'", str41.equals("36"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(lenientChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(durationFieldTypeArray52);
        org.junit.Assert.assertNotNull(period53);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField4 = lenientChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology2.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = iSOChronology9.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getDurationField();
        long long17 = unsupportedDateTimeField13.add(97L, (int) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = unsupportedDateTimeField13.getType();
        org.joda.time.ReadablePartial readablePartial19 = null;
        try {
            int int20 = unsupportedDateTimeField13.getMaximumValue(readablePartial19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 96L + "'", long17 == 96L);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology0.getZone();
        org.joda.time.DurationField durationField8 = iSOChronology0.eras();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.joda.time.Period period3 = period1.withMillis((int) '#');
        org.joda.time.Period period5 = period3.minusHours(10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "-01:00", 0, 1);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((-1104364799967L));
        int int8 = fixedDateTimeZone4.getStandardOffset((long) 3599999);
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-01:00" + "'", str6.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(0L, 0L, periodType5, chronology6);
        org.joda.time.PeriodType periodType8 = periodType5.withWeeksRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 0, periodType8);
        int int10 = periodType8.size();
        try {
            org.joda.time.Period period11 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        java.lang.String str1 = periodType0.toString();
        org.joda.time.PeriodType periodType2 = periodType0.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PeriodType[YearDayTime]" + "'", str1.equals("PeriodType[YearDayTime]"));
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) -1, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone10.getUncachedZone();
        int int13 = cachedDateTimeZone10.getOffset(35L);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.DurationField durationField15 = zonedChronology14.days();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "47");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "GregorianChronology[+00:00:00.100]", "46");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "", "35");
        java.util.Locale locale13 = null;
        java.lang.String str16 = defaultNameProvider0.getName(locale13, "ISOChronology[+00:00:00.100]", "-1");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) ' ', 'a', 6, (int) '4', (int) (short) 100, false, (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder8.setStandardOffset(4);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = dateTimeZoneBuilder10.addCutover(35, ' ', (int) 'a', (-1009312), (int) '#', true, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }
}

