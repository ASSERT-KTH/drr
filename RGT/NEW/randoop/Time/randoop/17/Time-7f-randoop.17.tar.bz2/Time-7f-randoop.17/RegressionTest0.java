import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865896000000L) + "'", long1 == (-210865896000000L));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, (int) (short) 10, (int) (byte) -1, (int) (short) 10, (int) (short) 100, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(10L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfYear();
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((java.lang.Object) gJChronology0, (org.joda.time.Chronology) gJChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, 57600010);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.minutes();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField4 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter1.parseLocalDate("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test020");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) '4', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62 + "'", int2 == 62);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long6 = gJChronology0.getDateTimeMillis((long) (short) -1, (-1), 0, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 62, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 62L + "'", long2 == 62L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        long long8 = mutableDateTime3.getMillis();
        try {
            mutableDateTime3.setWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58665600010L + "'", long8 == 58665600010L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        try {
            long long9 = julianChronology1.getDateTimeMillis(62, (int) (byte) 0, (-1), (int) (short) 100, 0, 0, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 10, 97, 0, (int) (byte) 1, (int) (short) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        try {
            long long11 = gJChronology0.getDateTimeMillis((-2649600000L), (int) 'a', (int) '4', 0, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) '4', 62, (int) ' ', (int) (short) 1, 62, (int) '#', dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 62 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        try {
            long long6 = julianChronology1.getDateTimeMillis((int) '#', (int) ' ', 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        java.lang.String str6 = skipDateTimeField5.toString();
//        long long8 = skipDateTimeField5.remainder((long) (short) -1);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipDateTimeField5, 0, (int) (short) 100, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [100,0]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[monthOfYear]" + "'", str6.equals("DateTimeField[monthOfYear]"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2649599999L + "'", long8 == 2649599999L);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
//        int int4 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DurationFieldType durationFieldType7 = null;
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime1.withFieldAdded(durationFieldType7, 960);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600010 + "'", int4 == 57600010);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        try {
            long long11 = gJChronology1.getDateTimeMillis(100, 10, 0, 2000, (int) 'a', 57600010, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        try {
            long long9 = julianChronology1.getDateTimeMillis((int) '4', (int) (byte) -1, 100, (int) 'a', (int) (byte) 1, (int) '4', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 97);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858379200000L) + "'", long1 == (-210858379200000L));
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test051");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        java.lang.String str6 = skipDateTimeField5.toString();
//        long long8 = skipDateTimeField5.remainder((long) (short) -1);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        try {
//            int int10 = skipDateTimeField5.getMaximumValue(readablePartial9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[monthOfYear]" + "'", str6.equals("DateTimeField[monthOfYear]"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2649599999L + "'", long8 == 2649599999L);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant2 = dateTime1.toInstant();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.Chronology chronology5 = gJChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime1.toMutableDateTime((org.joda.time.Chronology) gJChronology3);
        try {
            mutableDateTime7.setDayOfYear((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.property(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        try {
            org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0, (int) (short) 0, 960, 10, (int) '4', 0, 0, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int6 = skipDateTimeField5.getMinimumValue();
        int int7 = skipDateTimeField5.getMinimumValue();
        int int8 = skipDateTimeField5.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(6, 2000, (int) (short) -1, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfYear();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) 10, 3, 2000, 0, 0, (int) (short) 100, (org.joda.time.Chronology) gJChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 960);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 960 + "'", int1 == 960);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime6 = property4.roundCeilingCopy();
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumShortTextLength(locale7);
        int int9 = property4.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "millisOfDay" + "'", str5.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 62, (java.lang.Number) 97, (java.lang.Number) 2440588L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        mutableDateTime3.setDate((long) (-1));
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = mutableDateTime3.toString("", locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter2.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePartial readablePartial1 = null;
        int[] intArray2 = null;
        try {
            gregorianChronology0.validate(readablePartial1, intArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int6 = skipDateTimeField5.getMinimumValue();
        int int7 = skipDateTimeField5.getMinimumValue();
        int int8 = skipDateTimeField5.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray17 = new int[] { 12, '4', '#', (byte) 10, 3, 3 };
        try {
            int[] intArray19 = skipDateTimeField5.addWrapField(readablePartial9, 3, intArray17, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            int[] intArray4 = gJChronology0.get(readablePartial2, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.lang.String str6 = skipDateTimeField5.toString();
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray11 = new int[] { 57600010, 57600010, 6 };
        try {
            int int12 = skipDateTimeField5.getMaximumValue(readablePartial7, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[monthOfYear]" + "'", str6.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        long long8 = mutableDateTime3.getMillis();
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime3.copy();
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = mutableDateTime3.toString("PST", locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58665600010L + "'", long8 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "960");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.ReadablePartial readablePartial3 = null;
        int[] intArray7 = new int[] { 12, 57600010, (short) 0 };
        try {
            gregorianChronology1.validate(readablePartial3, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        long long8 = mutableDateTime3.getMillis();
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime3.copy();
        org.joda.time.MutableDateTime mutableDateTime10 = mutableDateTime3.copy();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            mutableDateTime10.set(dateTimeFieldType11, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58665600010L + "'", long8 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        mutableDateTime3.setDate(3, (int) (short) 10, 10);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        java.lang.Appendable appendable4 = null;
        try {
            dateTimeFormatter0.printTo(appendable4, (long) 24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.io.Writer writer2 = null;
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            dateTimeFormatter0.printTo(writer2, readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
//        java.lang.String str5 = dateTimeZone2.getShortName((long) '4');
//        try {
//            org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2, 960);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 960");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        java.util.Set<java.lang.String> strSet2 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean3 = julianChronology1.equals((java.lang.Object) strSet2);
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int[] intArray6 = julianChronology1.get(readablePartial4, 2649599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(100L, dateTimeZone1);
        mutableDateTime2.addDays(62);
        mutableDateTime2.addYears(1971);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 57600010);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.millisOfDay();
        java.util.Locale locale4 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = property2.set("hi!", locale4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            int[] intArray9 = gJChronology0.get(readablePartial7, (-2678399900L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            int[] intArray9 = gJChronology0.get(readablePartial7, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) -1);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfDay();
        int int3 = property2.getMinimumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        try {
            org.joda.time.DateTime dateTime2 = dateTime0.withDayOfMonth(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
//        int int4 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        try {
//            org.joda.time.DateTime.Property property8 = dateTime1.property(dateTimeFieldType7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600010 + "'", int4 == 57600010);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        try {
            long long14 = gJChronology0.getDateTimeMillis(1, (int) (byte) 1, 1, (int) (short) 1, 1971, (int) (short) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1971 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        java.util.Set<java.lang.String> strSet7 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean8 = julianChronology6.equals((java.lang.Object) strSet7);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.monthOfYear();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(2000, (int) (byte) -1, 0, 62, (int) (short) 10, (org.joda.time.Chronology) julianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 62 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560343655006L + "'", long0 == 1560343655006L);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
//        int int5 = property4.get();
//        try {
//            org.joda.time.MutableDateTime mutableDateTime7 = property4.set("hi!");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for minuteOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 960 + "'", int5 == 960);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int6 = skipDateTimeField5.getMinimumValue();
        int int7 = skipDateTimeField5.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField5.getWrappedField();
        java.util.Locale locale11 = null;
        try {
            long long12 = skipDateTimeField5.set((long) 0, "960", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"960\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(57600010, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 57600010");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) -1);
        try {
            mutableDateTime1.setWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int6 = skipDateTimeField5.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial7 = null;
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = skipDateTimeField5.getAsText(readablePartial7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        mutableDateTime3.setDate((long) 3);
        mutableDateTime3.setTime((long) (short) 100);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) -1);
        try {
            mutableDateTime1.setDateTime(62, (int) '#', (int) (short) 0, (int) ' ', (int) (short) 100, 62, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        java.lang.String str6 = skipDateTimeField5.toString();
//        long long8 = skipDateTimeField5.remainder((long) (short) -1);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((java.lang.Object) skipDateTimeField5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.SkipDateTimeField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[monthOfYear]" + "'", str6.equals("DateTimeField[monthOfYear]"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2649599999L + "'", long8 == 2649599999L);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract((long) (short) 10, (int) (short) 1);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(100L, dateTimeZone1);
        mutableDateTime2.addDays(62);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField7);
        int int11 = skipDateTimeField10.getMinimumValue();
        int int12 = skipDateTimeField10.getMinimumValue();
        try {
            mutableDateTime2.setRounding((org.joda.time.DateTimeField) skipDateTimeField10, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
//        int int4 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
//        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime();
//        org.joda.time.DateTime dateTime15 = dateTime13.minusHours(0);
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime15.withYearOfEra(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600010 + "'", int4 == 57600010);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(8, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology5);
        mutableDateTime7.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration10 = null;
        mutableDateTime7.add(readableDuration10);
        long long12 = mutableDateTime7.getMillis();
        org.joda.time.MutableDateTime mutableDateTime13 = mutableDateTime7.copy();
        org.joda.time.MutableDateTime mutableDateTime14 = mutableDateTime7.copy();
        try {
            dateTimeFormatter2.printTo(stringBuffer3, (org.joda.time.ReadableInstant) mutableDateTime14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 58665600010L + "'", long12 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology7);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField12);
        java.lang.String str16 = skipDateTimeField15.toString();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, (org.joda.time.DateTimeField) skipDateTimeField15, (int) 'a');
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipDateTimeField18);
        org.joda.time.ReadablePartial readablePartial20 = null;
        int[] intArray25 = new int[] { 1971, 'a', (byte) 10 };
        try {
            int[] intArray27 = skipDateTimeField19.set(readablePartial20, (int) '4', intArray25, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[monthOfYear]" + "'", str16.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        java.lang.String str8 = property7.getAsText();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "163" + "'", str8.equals("163"));
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = julianChronology1.withUTC();
        try {
            long long7 = julianChronology1.getDateTimeMillis(960, 1, 1971, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1971 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        org.joda.time.MutableDateTime mutableDateTime8 = mutableDateTime3.toMutableDateTimeISO();
        try {
            mutableDateTime3.setDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.secondOfDay();
        org.joda.time.DateMidnight dateMidnight6 = dateTime3.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateMidnight6);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        java.lang.String str6 = skipDateTimeField5.toString();
//        long long8 = skipDateTimeField5.roundFloor((long) 97);
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfYear();
//        org.joda.time.TimeOfDay timeOfDay17 = dateTime15.toTimeOfDay();
//        int[] intArray22 = new int[] { 'a', 1, ' ' };
//        java.util.Locale locale24 = null;
//        try {
//            int[] intArray25 = skipDateTimeField5.set((org.joda.time.ReadablePartial) timeOfDay17, 7, intArray22, "Dec", locale24);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Dec\" for monthOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[monthOfYear]" + "'", str6.equals("DateTimeField[monthOfYear]"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2649600000L) + "'", long8 == (-2649600000L));
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(timeOfDay17);
//        org.junit.Assert.assertNotNull(intArray22);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) -1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        mutableDateTime2.add(readableDuration4, 0);
//        mutableDateTime2.setTime((long) 0);
//        org.joda.time.DurationFieldType durationFieldType9 = null;
//        try {
//            mutableDateTime2.add(durationFieldType9, 3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969-12-31T15:59:59" + "'", str3.equals("1969-12-31T15:59:59"));
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant2 = dateTime1.toInstant();
        org.joda.time.DateTime dateTime3 = instant2.toDateTimeISO();
        long long4 = instant2.getMillis();
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter5.withZone(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (byte) -1, 97, 62, (int) (byte) -1, (int) (byte) 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("Coordinated Universal Time", true);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("960", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        try {
            mutableDateTime3.setDate((int) (byte) 0, 97, 1971);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsShortText(locale5);
//        org.joda.time.MutableDateTime mutableDateTime7 = property4.roundFloor();
//        mutableDateTime7.setMinuteOfHour(0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "960" + "'", str6.equals("960"));
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withPivotYear(1971);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        long long8 = mutableDateTime3.getMillis();
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime3.copy();
        org.joda.time.MutableDateTime mutableDateTime10 = mutableDateTime3.copy();
        mutableDateTime10.addMonths(8);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58665600010L + "'", long8 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(24, 24, 2000, (int) (short) 10, 10, 24, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        long long7 = delegatedDateTimeField4.add((long) 1, (long) 3);
//        long long9 = delegatedDateTimeField4.roundHalfFloor((long) 3);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField4.getType();
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField11 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7776000001L + "'", long7 == 7776000001L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsShortText(locale5);
//        org.joda.time.MutableDateTime mutableDateTime7 = property4.roundFloor();
//        org.joda.time.MutableDateTime mutableDateTime9 = property4.add(7);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "960" + "'", str6.equals("960"));
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) -1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        mutableDateTime2.add(readableDuration4, 0);
//        mutableDateTime2.setWeekyear(19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969-12-31T15:59:59" + "'", str3.equals("1969-12-31T15:59:59"));
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int6 = skipDateTimeField5.getMinimumValue();
        int int7 = skipDateTimeField5.getMinimumValue();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10, dateTimeFieldType11);
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField10);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTime.Property property15 = dateTime14.dayOfYear();
        org.joda.time.TimeOfDay timeOfDay16 = dateTime14.toTimeOfDay();
        int[] intArray19 = new int[] { 12 };
        try {
            int[] intArray21 = skipDateTimeField5.addWrapField((org.joda.time.ReadablePartial) timeOfDay16, (int) '4', intArray19, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(timeOfDay16);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add((long) 1, (long) 3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (short) -1);
        org.joda.time.DateTimeField dateTimeField13 = delegatedDateTimeField7.getWrappedField();
        java.util.Locale locale15 = null;
        try {
            java.lang.String str16 = delegatedDateTimeField7.getAsText((int) 'a', locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7776000001L + "'", long10 == 7776000001L);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        boolean boolean6 = jodaTimePermission3.equals((java.lang.Object) (-1.0f));
        java.lang.String str7 = jodaTimePermission3.getName();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.Chronology chronology2 = gJChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.yearOfCentury();
        try {
            long long11 = gJChronology0.getDateTimeMillis((int) (short) 10, 5, 62, (int) 'a', 8, 6, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int6 = skipDateTimeField5.getMinimumValue();
        int int7 = skipDateTimeField5.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField5.getWrappedField();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTime.Property property16 = dateTime15.dayOfYear();
        org.joda.time.TimeOfDay timeOfDay17 = dateTime15.toTimeOfDay();
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = skipDateTimeField5.getAsText((org.joda.time.ReadablePartial) timeOfDay17, 57600010, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 57600010");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(timeOfDay17);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getShortName((long) (short) 0, locale9);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10, 10, (-63), (int) (byte) 100, 57600010, (int) (byte) 0, (int) '4', dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        mutableDateTime8.addWeeks((int) 'a');
        int int11 = property4.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
        try {
            org.joda.time.DateTime dateTime13 = property4.setCopy("1969-12-31T15:59:59");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-31T15:59:59\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        mutableDateTime8.addWeeks((int) 'a');
        int int11 = property4.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
        try {
            java.lang.String str13 = mutableDateTime8.toString("1969-12-31T15:59:59.999-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        java.lang.String str6 = skipDateTimeField5.toString();
//        long long8 = skipDateTimeField5.remainder((long) (short) -1);
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfYear();
//        org.joda.time.TimeOfDay timeOfDay17 = dateTime15.toTimeOfDay();
//        java.util.Locale locale19 = null;
//        try {
//            java.lang.String str20 = skipDateTimeField5.getAsText((org.joda.time.ReadablePartial) timeOfDay17, 24, locale19);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 24");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[monthOfYear]" + "'", str6.equals("DateTimeField[monthOfYear]"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2649599999L + "'", long8 == 2649599999L);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(timeOfDay17);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) -1);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfDay();
        mutableDateTime1.addHours((int) (byte) 10);
        mutableDateTime1.addMonths(8);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        try {
            int[] intArray9 = gJChronology4.get(readablePeriod7, (long) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = julianChronology1.withUTC();
        try {
            long long7 = julianChronology1.getDateTimeMillis(57600010, (int) (short) 0, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
//        int int4 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime1.minus(readablePeriod7);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime1.plus(readableDuration9);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600010 + "'", int4 == 57600010);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = dateTimeFormatter2.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        java.util.Set<java.lang.String> strSet2 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean3 = julianChronology1.equals((java.lang.Object) strSet2);
        org.joda.time.DurationField durationField4 = julianChronology1.years();
        try {
            long long10 = julianChronology1.getDateTimeMillis((-210858379200000L), 62, (-63), 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 62 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
//        long long5 = gJChronology0.add((long) (byte) 1, 2649599999L, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getShortName((long) (short) 0, locale8);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone6);
//        try {
//            long long18 = zonedChronology10.getDateTimeMillis(4, 0, 3, 10, 5, 0, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 26495999991L + "'", long5 == 26495999991L);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology10);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        try {
            long long10 = gregorianChronology1.getDateTimeMillis(100, 0, (int) (byte) 1, (int) (byte) 10, 24, (int) (short) 10, 57600010);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600010 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(58665600010L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 58665600020L + "'", long2 == 58665600020L);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType10);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField9);
//        java.lang.String str13 = skipDateTimeField12.toString();
//        long long15 = skipDateTimeField12.remainder((long) (short) -1);
//        int int16 = dateTime6.get((org.joda.time.DateTimeField) skipDateTimeField12);
//        int int17 = dateTime6.getWeekOfWeekyear();
//        org.joda.time.DateMidnight dateMidnight18 = dateTime6.toDateMidnight();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[monthOfYear]" + "'", str13.equals("DateTimeField[monthOfYear]"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2649599999L + "'", long15 == 2649599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertNotNull(dateMidnight18);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int6 = skipDateTimeField5.getMinimumValue();
        int int7 = skipDateTimeField5.getMinimumValue();
        int int8 = skipDateTimeField5.getMaximumValue();
        try {
            long long11 = skipDateTimeField5.set((long) 1971, 24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int6 = skipDateTimeField5.getMinimumValue();
        int int7 = skipDateTimeField5.getMinimumValue();
        int int8 = skipDateTimeField5.getMaximumValue();
        try {
            long long11 = skipDateTimeField5.set((long) 960, 24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
//        int int4 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getShortName((long) (short) 0, locale9);
//        org.joda.time.DateTime dateTime11 = dateTime6.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.DateTime dateTime12 = dateTime6.toDateTime();
//        try {
//            org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField3 = gJChronology0.hours();
        try {
            long long11 = gJChronology0.getDateTimeMillis((int) '#', 0, 12, 7, (int) (byte) -1, 6, 62);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) '4');
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withEra(7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 7 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.joda.time.DateTime dateTime14 = dateTime9.withMillis((-2678399900L));
        int int15 = dateTime14.getCenturyOfEra();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (byte) 1);
        java.lang.String str18 = dateTime14.toString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-01T00:00:00.100Z" + "'", str18.equals("1969-12-01T00:00:00.100Z"));
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
//        int int4 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getShortName((long) (short) 0, locale9);
//        org.joda.time.DateTime dateTime11 = dateTime6.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.DateTime dateTime12 = dateTime6.toDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.mediumDate();
//        java.lang.String str14 = dateTime12.toString(dateTimeFormatter13);
//        org.joda.time.DurationFieldType durationFieldType15 = null;
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime12.withFieldAdded(durationFieldType15, 57600072);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Jan 3, 1970" + "'", str14.equals("Jan 3, 1970"));
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology1.days();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int6 = skipDateTimeField5.getMinimumValue();
        int int7 = skipDateTimeField5.getMinimumValue();
        int int8 = skipDateTimeField5.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField11 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType9, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfEra((int) (short) 1);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime();
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours(0);
        org.joda.time.DateTime.Property property16 = dateTime13.year();
        java.lang.String str17 = property16.getAsShortText();
        org.joda.time.DateTime dateTime18 = property16.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1970" + "'", str17.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970001T000000.100Z" + "'", str2.equals("1970001T000000.100Z"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.lang.String str6 = skipDateTimeField5.toString();
        java.util.Locale locale7 = null;
        int int8 = skipDateTimeField5.getMaximumTextLength(locale7);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[monthOfYear]" + "'", str6.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add((long) 1, (long) 3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (short) -1);
        org.joda.time.DateTimeField dateTimeField13 = delegatedDateTimeField7.getWrappedField();
        boolean boolean14 = delegatedDateTimeField7.isLenient();
        java.util.Locale locale17 = null;
        try {
            long long18 = delegatedDateTimeField7.set((long) 2000, "JulianChronology[America/Los_Angeles]", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"JulianChronology[America/Los_Angeles]\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7776000001L + "'", long10 == 7776000001L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(100L, dateTimeZone8);
        mutableDateTime9.addYears(0);
        org.joda.time.Chronology chronology12 = mutableDateTime9.getChronology();
        try {
            org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime(12, (int) ' ', (int) ' ', 2000, (int) (byte) 100, 8, 86399999, chronology12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology3);
        mutableDateTime5.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration8 = null;
        mutableDateTime5.add(readableDuration8);
        jodaTimePermission1.checkGuard((java.lang.Object) readableDuration8);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.lang.String str6 = skipDateTimeField5.toString();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime(dateTimeZone9);
        int int11 = dateTime8.getMillisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime8.plusHours((int) '4');
        org.joda.time.DateTime dateTime16 = dateTime8.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.withZoneRetainFields(dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime16.yearOfEra();
        org.joda.time.DateTime dateTime21 = dateTime16.withMillis((-2678399900L));
        org.joda.time.DateTime dateTime23 = dateTime21.plusMonths(6);
        org.joda.time.DateTime dateTime25 = dateTime21.minusDays((int) ' ');
        org.joda.time.YearMonthDay yearMonthDay26 = dateTime21.toYearMonthDay();
        int[] intArray28 = null;
        try {
            int[] intArray30 = skipDateTimeField5.set((org.joda.time.ReadablePartial) yearMonthDay26, 960, intArray28, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[monthOfYear]" + "'", str6.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(yearMonthDay26);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime6.withMillisOfSecond((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
        try {
            org.joda.time.DateTime dateTime13 = dateTime10.withHourOfDay(86399999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(2440588L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5282475464d + "'", double1 == 2440587.5282475464d);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.dayOfYear();
//        org.joda.time.Instant instant10 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology12);
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.minuteOfDay();
//        int int16 = property15.get();
//        org.joda.time.MutableDateTime mutableDateTime18 = property15.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property15.getFieldType();
//        int int20 = instant10.get(dateTimeFieldType19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType19, 7);
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25, dateTimeFieldType26);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField25);
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology23);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfYear();
//        org.joda.time.TimeOfDay timeOfDay31 = dateTime29.toTimeOfDay();
//        int int32 = offsetDateTimeField22.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay31);
//        int[] intArray37 = new int[] { (byte) 1, '#', (short) 1 };
//        try {
//            int[] intArray39 = skipDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay31, 8, intArray37, 960);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(instant10);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 767 + "'", int20 == 767);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(timeOfDay31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
//        org.junit.Assert.assertNotNull(intArray37);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology7);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField12);
        java.lang.String str16 = skipDateTimeField15.toString();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, (org.joda.time.DateTimeField) skipDateTimeField15, (int) 'a');
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipDateTimeField18);
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = skipDateTimeField18.getAsText(19, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[monthOfYear]" + "'", str16.equals("DateTimeField[monthOfYear]"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        mutableDateTime3.setDate((long) (-1));
        try {
            mutableDateTime3.setWeekOfWeekyear((-63));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -63 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        try {
            long long7 = gregorianChronology1.getDateTimeMillis(0, 19, 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfYear();
        try {
            long long8 = gregorianChronology1.getDateTimeMillis(86399999, (int) (short) 1, 0, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int6 = skipDateTimeField5.getMinimumValue();
        int int7 = skipDateTimeField5.getMinimumValue();
        long long9 = skipDateTimeField5.roundCeiling(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        int int5 = property4.get();
        org.joda.time.MutableDateTime mutableDateTime7 = property4.add(2440588L);
        try {
            mutableDateTime7.setDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 24);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 3, 86399999, 57600072, 8, 2, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600072 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(1L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        int int7 = dateTime6.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        java.lang.String str5 = property4.getName();
        java.lang.String str6 = property4.getAsString();
        int int7 = property4.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "millisOfDay" + "'", str5.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 86399999 + "'", int7 == 86399999);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant2 = dateTime1.toInstant();
        long long3 = instant2.getMillis();
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int7 = skipDateTimeField5.getLeapAmount(10L);
        long long9 = skipDateTimeField5.roundFloor(28800000L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology1.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField18);
        java.lang.String str22 = skipDateTimeField21.toString();
        long long24 = skipDateTimeField21.remainder((long) (short) -1);
        int int25 = dateTime15.get((org.joda.time.DateTimeField) skipDateTimeField21);
        boolean boolean26 = skipDateTimeField21.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, (org.joda.time.DateTimeField) skipDateTimeField21, 960);
        int int29 = skipUndoDateTimeField28.getMinimumValue();
        int int31 = skipUndoDateTimeField28.get((long) 2000);
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipUndoDateTimeField28.getAsText((long) 100, locale33);
        int int35 = skipUndoDateTimeField28.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DateTimeField[monthOfYear]" + "'", str22.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2678399999L + "'", long24 == 2678399999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "January" + "'", str34.equals("January"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        long long8 = mutableDateTime3.getMillis();
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime3.copy();
        mutableDateTime3.setSecondOfDay(1971);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime3.millisOfDay();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58665600010L + "'", long8 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 0, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField4 = gJChronology1.eras();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsShortText(locale5);
        org.joda.time.MutableDateTime mutableDateTime7 = property4.roundFloor();
        try {
            mutableDateTime7.setMillisOfDay((-63));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -63 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 10, 12, 100, (-1), (int) (byte) 100, 0, 767);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add((long) 1, (long) 3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (short) -1);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.toDateTime(dateTimeZone15);
        int int17 = dateTime14.getMillisOfDay();
        org.joda.time.DateTime dateTime19 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTime dateTime22 = dateTime14.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.withZoneRetainFields(dateTimeZone23);
        org.joda.time.DateTime.Property property25 = dateTime22.yearOfEra();
        org.joda.time.DateTime dateTime27 = dateTime22.withMillis((-2678399900L));
        org.joda.time.DateTime dateTime29 = dateTime27.plusMonths(6);
        org.joda.time.DateTime dateTime31 = dateTime27.minusDays((int) ' ');
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime27.toYearMonthDay();
        java.util.Locale locale34 = null;
        try {
            java.lang.String str35 = skipDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay32, 86399999, locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 86399999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7776000001L + "'", long10 == 7776000001L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(yearMonthDay32);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) -1);
        java.lang.String str2 = mutableDateTime1.toString();
        try {
            mutableDateTime1.setDayOfYear((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31T23:59:59.999Z" + "'", str2.equals("1969-12-31T23:59:59.999Z"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        long long8 = mutableDateTime3.getMillis();
        int int9 = mutableDateTime3.getYear();
        int int10 = mutableDateTime3.getMillisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            mutableDateTime3.set(dateTimeFieldType11, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58665600010L + "'", long8 == 58665600010L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1971 + "'", int9 == 1971);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime6.plusYears(767);
        boolean boolean12 = dateTime6.isEqual((long) 'a');
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekDate();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("1969-12-31T15:59:59", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T15:59:59\" is malformed at \"-12-31T15:59:59\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(767, 0, 1971, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("1969-12-31T15:59:59.999-08:00");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1969-12-31T15:59:59.999-08:00/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField9 = gregorianChronology8.minutes();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.clockhourOfDay();
        org.joda.time.DurationField durationField11 = gregorianChronology8.eras();
        try {
            org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((int) (short) 0, 5, (int) '#', (int) (short) 1, 3, 57600010, 3, (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600010 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add((long) 1, (long) 3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (short) -1);
        org.joda.time.DateTimeField dateTimeField13 = gJChronology1.year();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7776000001L + "'", long10 == 7776000001L);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(26265600000L);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
//        long long5 = gJChronology0.add((long) (byte) 1, 2649599999L, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getShortName((long) (short) 0, locale8);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone6);
//        try {
//            long long15 = zonedChronology10.getDateTimeMillis(2, (int) (byte) 0, (int) (byte) 0, 2);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 26495999991L + "'", long5 == 26495999991L);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology10);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime6.plusYears(767);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.DateTime dateTime13 = dateTime6.withFieldAdded(durationFieldType11, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(dateTimeZone7);
//        int int9 = dateTime6.getMillisOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime6.plusHours((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getShortName((long) (short) 0, locale14);
//        org.joda.time.DateTime dateTime16 = dateTime11.withZoneRetainFields(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime11.withChronology((org.joda.time.Chronology) julianChronology18);
//        try {
//            org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(2000, 10, (int) '#', 1, 2, (org.joda.time.Chronology) julianChronology18);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withPivotYear((java.lang.Integer) 86399999);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant2 = dateTime1.toInstant();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.withPeriodAdded(readablePeriod3, 0);
        try {
            org.joda.time.DateTime dateTime9 = dateTime1.withDate(12, 960, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        try {
//            long long28 = remainderDateTimeField25.set((long) 0, 373);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 373 for minuteOfDay must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 767 + "'", int21 == 767);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        java.util.Locale locale7 = null;
        java.lang.String str8 = property4.getAsShortText(locale7);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfCeiling();
        int int6 = mutableDateTime5.getEra();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime3.getDayOfWeek();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMinutes((int) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime3.minusWeeks(57600072);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        mutableDateTime3.setDate((long) (-1));
        try {
            mutableDateTime3.setDayOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        try {
            org.joda.time.LocalTime localTime6 = dateTimeFormatter0.parseLocalTime("57600010");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"57600010\" is malformed at \"600010\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
//        long long5 = gJChronology0.add((long) (byte) 1, 2649599999L, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getShortName((long) (short) 0, locale8);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone6);
//        try {
//            long long16 = zonedChronology10.getDateTimeMillis((long) 24, 1971, 12, 0, 62);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1971 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 26495999991L + "'", long5 == 26495999991L);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology10);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        long long6 = delegatedDateTimeField3.add((long) 1, (long) 3);
        long long8 = delegatedDateTimeField3.roundHalfFloor((long) 3);
        java.lang.String str9 = delegatedDateTimeField3.getName();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7776000001L + "'", long6 == 7776000001L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("Coordinated Universal Time", true);
        java.util.TimeZone timeZone4 = dateTimeZone3.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology1.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField18);
        java.lang.String str22 = skipDateTimeField21.toString();
        long long24 = skipDateTimeField21.remainder((long) (short) -1);
        int int25 = dateTime15.get((org.joda.time.DateTimeField) skipDateTimeField21);
        boolean boolean26 = skipDateTimeField21.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, (org.joda.time.DateTimeField) skipDateTimeField21, 960);
        long long31 = skipUndoDateTimeField28.set((long) (byte) 0, 8);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DateTimeField[monthOfYear]" + "'", str22.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2678399999L + "'", long24 == 2678399999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 15638400000L + "'", long31 == 15638400000L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName((long) (short) 0, locale3);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone1);
//        java.lang.String str7 = dateTimeZone1.getName(58665600010L);
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int9 = mutableDateTime8.getYearOfCentury();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(0, 8, 97, 62, 0, (int) (byte) 0, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 62 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.halfdayOfDay();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        mutableDateTime3.addDays((int) (byte) 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
//        long long5 = gJChronology0.add((long) (byte) 1, 2649599999L, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getShortName((long) (short) 0, locale8);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone6);
//        try {
//            long long18 = zonedChronology10.getDateTimeMillis(0, 2000, (int) (short) 100, 767, (int) '#', 8, 2);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 767 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 26495999991L + "'", long5 == 26495999991L);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology10);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parsers supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        mutableDateTime3.setDate((long) (-1));
        try {
            mutableDateTime3.setDayOfWeek(767);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 767 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(100L, dateTimeZone2);
        mutableDateTime3.addYears(0);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime3);
        mutableDateTime3.setWeekyear((int) '#');
        int int11 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "millisOfDay", 62);
        int int12 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-63) + "'", int11 == (-63));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2000 + "'", int12 == 2000);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField14.getWrappedField();
//        long long18 = offsetDateTimeField14.add((long) 57600010, (long) 3);
//        int int20 = offsetDateTimeField14.getMaximumValue(316800010L);
//        long long22 = offsetDateTimeField14.roundCeiling((long) 767);
//        long long24 = offsetDateTimeField14.roundCeiling((-2678399900L));
//        org.joda.time.DurationField durationField25 = offsetDateTimeField14.getLeapDurationField();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 767 + "'", int12 == 767);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 316800010L + "'", long18 == 316800010L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 373 + "'", int20 == 373);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 86400000L + "'", long22 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-2592000000L) + "'", long24 == (-2592000000L));
//        org.junit.Assert.assertNull(durationField25);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType1, 960, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        int int6 = dateTime3.getMillisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime3.plusHours((int) '4');
        org.joda.time.DateTime dateTime11 = dateTime3.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime11.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime11.toDateTime();
        org.joda.time.DateTime dateTime17 = dateTime15.minusHours(0);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime(dateTimeZone20);
        int int22 = dateTime19.getMillisOfDay();
        org.joda.time.DateTime dateTime24 = dateTime19.plusHours((int) '4');
        org.joda.time.DateTime dateTime27 = dateTime19.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime.Property property30 = dateTime27.yearOfEra();
        org.joda.time.DateTime dateTime31 = dateTime27.toDateTime();
        int int32 = dateTime31.getCenturyOfEra();
        try {
            org.joda.time.chrono.LimitChronology limitChronology33 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) dateTime15, (org.joda.time.ReadableDateTime) dateTime31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 19 + "'", int32 == 19);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) 57600010);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology9.getZone();
        org.joda.time.DateTime dateTime13 = mutableDateTime8.toDateTime(dateTimeZone12);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((int) (byte) 100, (int) ' ', 12, 767, (int) (byte) 1, 960, (int) ' ', dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 767 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant7 = dateTime6.toInstant();
        boolean boolean8 = dateTime1.isEqual((org.joda.time.ReadableInstant) instant7);
        long long9 = instant7.getMillis();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = instant7.toMutableDateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = instant7.getZone();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 57600010);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology2.getZone();
        org.joda.time.DateTime dateTime6 = mutableDateTime1.toDateTime(dateTimeZone5);
        long long7 = mutableDateTime1.getMillis();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 57600010L + "'", long7 == 57600010L);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.toDateTime(dateTimeZone29);
//        int int31 = dateTime28.getMillisOfDay();
//        org.joda.time.DateTime dateTime33 = dateTime28.plusHours((int) '4');
//        org.joda.time.DateTime dateTime35 = dateTime33.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime37 = dateTime35.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay38 = dateTime37.toYearMonthDay();
//        boolean boolean39 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay38);
//        java.util.Locale locale40 = null;
//        try {
//            java.lang.String str41 = remainderDateTimeField25.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay38, locale40);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 767 + "'", int21 == 767);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(yearMonthDay38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField14.getWrappedField();
//        long long18 = offsetDateTimeField14.add((long) 57600010, (long) 3);
//        long long20 = offsetDateTimeField14.roundHalfEven((long) 5);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.toDateTime(dateTimeZone23);
//        int int25 = dateTime24.getDayOfWeek();
//        org.joda.time.YearMonthDay yearMonthDay26 = dateTime24.toYearMonthDay();
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField29 = gJChronology28.dayOfYear();
//        org.joda.time.Instant instant30 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField33 = gJChronology32.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology32);
//        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.minuteOfDay();
//        int int36 = property35.get();
//        org.joda.time.MutableDateTime mutableDateTime38 = property35.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property35.getFieldType();
//        int int40 = instant30.get(dateTimeFieldType39);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, dateTimeFieldType39, 7);
//        org.joda.time.DateTimeField dateTimeField43 = offsetDateTimeField42.getWrappedField();
//        long long45 = offsetDateTimeField42.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTime dateTime49 = dateTime47.toDateTime(dateTimeZone48);
//        int int50 = dateTime47.getMillisOfDay();
//        org.joda.time.DateTime dateTime52 = dateTime47.plusHours((int) '4');
//        org.joda.time.DateTime dateTime54 = dateTime52.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime56 = dateTime54.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay57 = dateTime56.toYearMonthDay();
//        int[] intArray63 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray65 = offsetDateTimeField42.addWrapField((org.joda.time.ReadablePartial) yearMonthDay57, (int) (byte) 0, intArray63, 4);
//        java.util.Locale locale67 = null;
//        try {
//            int[] intArray68 = offsetDateTimeField14.set((org.joda.time.ReadablePartial) yearMonthDay26, 97, intArray65, "4:00:00 PM", locale67);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"4:00:00 PM\" for minuteOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 767 + "'", int12 == 767);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 316800010L + "'", long18 == 316800010L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertNotNull(yearMonthDay26);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(instant30);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 767 + "'", int40 == 767);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2678400000L + "'", long45 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(yearMonthDay57);
//        org.junit.Assert.assertNotNull(intArray63);
//        org.junit.Assert.assertNotNull(intArray65);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField6);
        java.lang.String str10 = skipDateTimeField9.toString();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipDateTimeField9, (int) 'a');
        long long14 = skipDateTimeField12.roundHalfFloor((long) 960);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[monthOfYear]" + "'", str10.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant7 = dateTime6.toInstant();
        boolean boolean8 = dateTime1.isEqual((org.joda.time.ReadableInstant) instant7);
        long long9 = instant7.getMillis();
        org.joda.time.Instant instant11 = instant7.withMillis((long) 4);
        org.joda.time.Instant instant13 = instant11.withMillis(62L);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(instant13);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(100L, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.millisOfDay();
        int int4 = mutableDateTime2.getYear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfCeiling();
        mutableDateTime5.addMillis((-1));
        mutableDateTime5.addWeekyears(1971);
        mutableDateTime5.setMillisOfDay(12);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            int int11 = dateTime1.get(dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField14.getWrappedField();
//        long long17 = offsetDateTimeField14.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime(dateTimeZone20);
//        int int22 = dateTime19.getMillisOfDay();
//        org.joda.time.DateTime dateTime24 = dateTime19.plusHours((int) '4');
//        org.joda.time.DateTime dateTime26 = dateTime24.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime28 = dateTime26.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay29 = dateTime28.toYearMonthDay();
//        int[] intArray35 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray37 = offsetDateTimeField14.addWrapField((org.joda.time.ReadablePartial) yearMonthDay29, (int) (byte) 0, intArray35, 4);
//        int int39 = offsetDateTimeField14.getLeapAmount((long) 'a');
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 767 + "'", int12 == 767);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2678400000L + "'", long17 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(yearMonthDay29);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.joda.time.DateTime dateTime14 = dateTime9.withMillis((-2678399900L));
        org.joda.time.DateTime dateTime16 = dateTime14.plusMonths(6);
        org.joda.time.DateTime dateTime18 = dateTime14.minusDays((int) ' ');
        try {
            org.joda.time.DateTime dateTime22 = dateTime14.withDate((int) (short) -1, 97, 1971);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime();
        boolean boolean14 = dateTime13.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendDayOfMonth((-63));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        long long8 = mutableDateTime3.getMillis();
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime3.copy();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.centuryOfEra();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime9.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime12 = property11.getMutableDateTime();
        java.lang.String str13 = property11.toString();
        int int14 = property11.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58665600010L + "'", long8 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[yearOfEra]" + "'", str13.equals("Property[yearOfEra]"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField4 = gJChronology1.halfdays();
        long long7 = durationField4.subtract((long) (byte) 10, 960);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField10 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType8, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-41471999990L) + "'", long7 == (-41471999990L));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology3);
        mutableDateTime5.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration8 = null;
        mutableDateTime5.add(readableDuration8);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) mutableDateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.yearOfEra();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0, (int) (byte) 1, 0, (int) (byte) 0, (int) (short) 10, 767, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 767 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) -1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.Instant instant6 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology8);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.minuteOfDay();
//        int int12 = property11.get();
//        org.joda.time.MutableDateTime mutableDateTime14 = property11.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property11.getFieldType();
//        int int16 = instant6.get(dateTimeFieldType15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType15, 7);
//        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField18.getWrappedField();
//        int int21 = offsetDateTimeField18.get((long) (byte) 100);
//        try {
//            mutableDateTime2.setRounding((org.joda.time.DateTimeField) offsetDateTimeField18, 12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 12");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969-12-31T23:59:59" + "'", str3.equals("1969-12-31T23:59:59"));
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 767 + "'", int16 == 767);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 8 + "'", int21 == 8);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean9 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission8);
        boolean boolean10 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission6);
        java.lang.String str11 = jodaTimePermission6.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str11.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime6 = property4.roundCeilingCopy();
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumShortTextLength(locale7);
        org.joda.time.DateTimeField dateTimeField9 = property4.getField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "millisOfDay" + "'", str5.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology1.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField18);
        java.lang.String str22 = skipDateTimeField21.toString();
        long long24 = skipDateTimeField21.remainder((long) (short) -1);
        int int25 = dateTime15.get((org.joda.time.DateTimeField) skipDateTimeField21);
        boolean boolean26 = skipDateTimeField21.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, (org.joda.time.DateTimeField) skipDateTimeField21, 960);
        int int29 = skipUndoDateTimeField28.getMinimumValue();
        try {
            long long32 = skipUndoDateTimeField28.set(0L, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for monthOfYear must be in the range [2,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DateTimeField[monthOfYear]" + "'", str22.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2678399999L + "'", long24 == 2678399999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.lang.String str6 = skipDateTimeField5.toString();
        org.joda.time.DateTimeField dateTimeField7 = skipDateTimeField5.getWrappedField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[monthOfYear]" + "'", str6.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName((long) (short) 0, locale2);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone0);
//        java.lang.String str6 = dateTimeZone0.getName(58665600010L);
//        java.lang.String str7 = dateTimeZone0.getID();
//        java.lang.String str8 = dateTimeZone0.toString();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str11 = dateTimeZone0.getName((long) 5);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        mutableDateTime8.addWeeks((int) 'a');
        int int11 = property4.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
        int int12 = property4.getLeapAmount();
        int int13 = property4.getMinimumValueOverall();
        int int14 = property4.getMaximumValueOverall();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.toDateTime(dateTimeZone17);
        int int19 = dateTime16.getMillisOfDay();
        org.joda.time.DateTime dateTime21 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTime dateTime24 = dateTime16.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = dateTime24.withZoneRetainFields(dateTimeZone25);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfEra();
        org.joda.time.DateTime dateTime28 = dateTime24.toDateTime();
        org.joda.time.DateTime.Property property29 = dateTime28.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime28.toMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((long) (short) -1);
        java.lang.String str33 = mutableDateTime32.toString();
        mutableDateTime32.addWeeks((int) (short) 1);
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime30, (org.joda.time.ReadableInstant) mutableDateTime32);
        long long37 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime30);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86399999 + "'", int14 == 86399999);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1969-12-31T23:59:59.999Z" + "'", str33.equals("1969-12-31T23:59:59.999Z"));
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62L) + "'", long37 == (-62L));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        java.util.Set<java.lang.String> strSet2 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean3 = julianChronology1.equals((java.lang.Object) strSet2);
        java.lang.String str4 = julianChronology1.toString();
        try {
            long long9 = julianChronology1.getDateTimeMillis((int) (byte) 0, (int) (short) 100, (int) (byte) 100, 335);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JulianChronology[UTC]" + "'", str4.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withLocale(locale4);
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withLocale(locale6);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(7, 9, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("Coordinated Universal Time", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("PST", 9);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = dateTimeZoneBuilder6.setFixedSavings("GregorianChronology[UTC]", (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder9);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        long long6 = delegatedDateTimeField3.add((long) 1, (long) 3);
//        long long8 = delegatedDateTimeField3.roundHalfFloor((long) 3);
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField23.getWrappedField();
//        long long26 = offsetDateTimeField23.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.toDateTime(dateTimeZone29);
//        int int31 = dateTime28.getMillisOfDay();
//        org.joda.time.DateTime dateTime33 = dateTime28.plusHours((int) '4');
//        org.joda.time.DateTime dateTime35 = dateTime33.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime37 = dateTime35.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay38 = dateTime37.toYearMonthDay();
//        int[] intArray44 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray46 = offsetDateTimeField23.addWrapField((org.joda.time.ReadablePartial) yearMonthDay38, (int) (byte) 0, intArray44, 4);
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology48.dayOfYear();
//        org.joda.time.Instant instant50 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField53 = gJChronology52.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime54 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology52);
//        org.joda.time.MutableDateTime.Property property55 = mutableDateTime54.minuteOfDay();
//        int int56 = property55.get();
//        org.joda.time.MutableDateTime mutableDateTime58 = property55.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property55.getFieldType();
//        int int60 = instant50.get(dateTimeFieldType59);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, dateTimeFieldType59, 7);
//        org.joda.time.DateTimeField dateTimeField63 = offsetDateTimeField62.getWrappedField();
//        long long65 = offsetDateTimeField62.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone68 = null;
//        org.joda.time.DateTime dateTime69 = dateTime67.toDateTime(dateTimeZone68);
//        int int70 = dateTime67.getMillisOfDay();
//        org.joda.time.DateTime dateTime72 = dateTime67.plusHours((int) '4');
//        org.joda.time.DateTime dateTime74 = dateTime72.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime76 = dateTime74.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay77 = dateTime76.toYearMonthDay();
//        int[] intArray83 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray85 = offsetDateTimeField62.addWrapField((org.joda.time.ReadablePartial) yearMonthDay77, (int) (byte) 0, intArray83, 4);
//        java.util.Locale locale87 = null;
//        try {
//            int[] intArray88 = delegatedDateTimeField3.set((org.joda.time.ReadablePartial) yearMonthDay38, (int) (byte) -1, intArray85, "960", locale87);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7776000001L + "'", long6 == 7776000001L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 767 + "'", int21 == 767);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2678400000L + "'", long26 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(yearMonthDay38);
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(instant50);
//        org.junit.Assert.assertNotNull(gJChronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 767 + "'", int60 == 767);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 2678400000L + "'", long65 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 10 + "'", int70 == 10);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertNotNull(yearMonthDay77);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertNotNull(intArray85);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday(97);
        boolean boolean11 = dateTimeFormatterBuilder8.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime();
        org.joda.time.DateTime dateTime15 = dateTime13.minusMillis(12);
        boolean boolean16 = dateTime15.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("1969-12-31T23:59:59");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T23:59:59\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendTimeZoneOffset("57600010", false, 2, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.halfdayOfDay();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField4 = gJChronology1.eras();
        boolean boolean6 = gJChronology1.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 57600010);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology2.getZone();
        org.joda.time.DateTime dateTime6 = mutableDateTime1.toDateTime(dateTimeZone5);
        boolean boolean8 = dateTimeZone5.isStandardOffset(259200000L);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("+06:00");
        dateTimeFormatterBuilder0.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField4 = gJChronology1.eras();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField9);
        java.lang.String str13 = skipDateTimeField12.toString();
        long long15 = skipDateTimeField12.remainder((long) (short) -1);
        int int16 = dateTime6.get((org.joda.time.DateTimeField) skipDateTimeField12);
        org.joda.time.DateTime dateTime18 = dateTime6.withMillisOfDay(0);
        int int19 = dateTime18.getSecondOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[monthOfYear]" + "'", str13.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2678399999L + "'", long15 == 2678399999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.Chronology chronology3 = dateTimeFormatter1.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 2000, (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14000L + "'", long2 == 14000L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMinutes(3);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.plus(readableDuration5);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant2 = dateTime1.toInstant();
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTimeISO();
        org.joda.time.DateTime.Property property4 = dateTime1.hourOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withWeekyear(20);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.DateTime dateTime9 = dateTime6.withFieldAdded(durationFieldType7, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        boolean boolean11 = dateTime9.isAfter((long) 62);
        org.joda.time.DateTime dateTime13 = dateTime9.withMillis(316800010L);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        long long27 = remainderDateTimeField25.roundHalfCeiling(0L);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.plus(readablePeriod29);
//        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.dayOfYear();
//        org.joda.time.Instant instant35 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField38 = gJChronology37.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology37);
//        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.minuteOfDay();
//        int int41 = property40.get();
//        org.joda.time.MutableDateTime mutableDateTime43 = property40.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property40.getFieldType();
//        int int45 = instant35.get(dateTimeFieldType44);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType44, 7);
//        org.joda.time.DateTimeField dateTimeField48 = offsetDateTimeField47.getWrappedField();
//        long long50 = offsetDateTimeField47.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTime dateTime54 = dateTime52.toDateTime(dateTimeZone53);
//        int int55 = dateTime52.getMillisOfDay();
//        org.joda.time.DateTime dateTime57 = dateTime52.plusHours((int) '4');
//        org.joda.time.DateTime dateTime59 = dateTime57.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime61 = dateTime59.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay62 = dateTime61.toYearMonthDay();
//        int[] intArray68 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray70 = offsetDateTimeField47.addWrapField((org.joda.time.ReadablePartial) yearMonthDay62, (int) (byte) 0, intArray68, 4);
//        try {
//            int[] intArray72 = remainderDateTimeField25.set((org.joda.time.ReadablePartial) timeOfDay31, (int) (byte) -1, intArray68, 2);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2 for minuteOfDay must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 767 + "'", int21 == 767);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(timeOfDay31);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(instant35);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime43);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 767 + "'", int45 == 767);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2678400000L + "'", long50 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(yearMonthDay62);
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertNotNull(intArray70);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("Coordinated Universal Time", true);
        java.lang.String str5 = dateTimeZone3.getName((long) 57600010);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName((long) (short) 0, locale3);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone1);
//        java.lang.String str7 = dateTimeZone1.getName(58665600010L);
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("1970", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str6 = illegalFieldValueException2.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str8 = illegalFieldValueException2.toString();
        java.lang.String str9 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number10 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported" + "'", str8.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000011227d + "'", double1 == 2440587.5000011227d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((-63), 62, (int) (byte) -1, (int) (short) 10, (int) '4', 1970, (org.joda.time.Chronology) gJChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) '4');
        java.util.Locale locale7 = null;
        java.lang.String str8 = property4.getAsText(locale7);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10" + "'", str8.equals("10"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (short) -1);
        java.lang.String str4 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) mutableDateTime3);
        int int7 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "(\"org.joda.time.JodaTimePermission\" \"hi!\")", (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T23:59:59" + "'", str4.equals("1969-12-31T23:59:59"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-11) + "'", int7 == (-11));
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName((long) (short) 0, locale2);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(100L, dateTimeZone1);
        mutableDateTime2.setWeekyear((int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) mutableDateTime8);
        mutableDateTime8.addYears((-11));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(6);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology3.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        long long8 = dateTimeZone1.getMillisKeepLocal(dateTimeZone5, (long) 8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 21600008L + "'", long8 == 21600008L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.Instant instant2 = dateTime1.toInstant();
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTimeISO();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getShortName((long) (short) 0, locale6);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime9 = dateTime3.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTime.Property property10 = dateTime3.weekyear();
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.Chronology chronology4 = dateTimeFormatter0.getChronology();
        java.io.Writer writer5 = null;
        try {
            dateTimeFormatter0.printTo(writer5, (long) 57600010);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(3, (int) (byte) 100, 19, (int) 'a', 1970, (int) (byte) -1, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("960", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 960");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(100L, dateTimeZone1);
        mutableDateTime2.addYears(0);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime2);
        mutableDateTime2.setWeekyear((int) '#');
        mutableDateTime2.setMinuteOfDay(7);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        org.joda.time.DateTimeField dateTimeField7 = property4.getField();
        java.util.Locale locale8 = null;
        int int9 = property4.getMaximumShortTextLength(locale8);
        org.joda.time.MutableDateTime mutableDateTime10 = property4.getMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone11 = mutableDateTime10.getZone();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
        java.util.Locale locale17 = null;
        java.lang.String str18 = property16.getAsShortText(locale17);
        org.joda.time.MutableDateTime mutableDateTime19 = property16.roundFloor();
        int int20 = mutableDateTime19.getDayOfWeek();
        mutableDateTime10.setMillis((org.joda.time.ReadableInstant) mutableDateTime19);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) 767, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 767L + "'", long4 == 767L);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        java.lang.String str28 = remainderDateTimeField25.getAsShortText((-1L));
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime30.toDateTime(dateTimeZone31);
//        int int33 = dateTime30.getMillisOfDay();
//        org.joda.time.DateTime dateTime35 = dateTime30.plusHours((int) '4');
//        org.joda.time.DateTime dateTime37 = dateTime35.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime39 = dateTime37.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay40 = dateTime39.toYearMonthDay();
//        boolean boolean41 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay40);
//        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField44 = gJChronology43.dayOfYear();
//        org.joda.time.Instant instant45 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField48 = gJChronology47.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime49 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology47);
//        org.joda.time.MutableDateTime.Property property50 = mutableDateTime49.minuteOfDay();
//        int int51 = property50.get();
//        org.joda.time.MutableDateTime mutableDateTime53 = property50.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property50.getFieldType();
//        int int55 = instant45.get(dateTimeFieldType54);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, dateTimeFieldType54, 7);
//        org.joda.time.DateTimeField dateTimeField58 = offsetDateTimeField57.getWrappedField();
//        long long60 = offsetDateTimeField57.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone63 = null;
//        org.joda.time.DateTime dateTime64 = dateTime62.toDateTime(dateTimeZone63);
//        int int65 = dateTime62.getMillisOfDay();
//        org.joda.time.DateTime dateTime67 = dateTime62.plusHours((int) '4');
//        org.joda.time.DateTime dateTime69 = dateTime67.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime71 = dateTime69.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay72 = dateTime71.toYearMonthDay();
//        int[] intArray78 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray80 = offsetDateTimeField57.addWrapField((org.joda.time.ReadablePartial) yearMonthDay72, (int) (byte) 0, intArray78, 4);
//        try {
//            int[] intArray82 = remainderDateTimeField25.set((org.joda.time.ReadablePartial) yearMonthDay40, 0, intArray80, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfDay must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 767 + "'", int21 == 767);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(yearMonthDay40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(gJChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(instant45);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime53);
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 767 + "'", int55 == 767);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2678400000L + "'", long60 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 10 + "'", int65 == 10);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(yearMonthDay72);
//        org.junit.Assert.assertNotNull(intArray78);
//        org.junit.Assert.assertNotNull(intArray80);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        long long8 = mutableDateTime3.getMillis();
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime3.copy();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.centuryOfEra();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime9.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime9.toMutableDateTimeISO();
        mutableDateTime12.setDate((-210858379200000L));
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58665600010L + "'", long8 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
//        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime3.secondOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfDay();
//        org.joda.time.Instant instant7 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology9);
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.minuteOfDay();
//        int int13 = property12.get();
//        org.joda.time.MutableDateTime mutableDateTime15 = property12.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property12.getFieldType();
//        int int17 = instant7.get(dateTimeFieldType16);
//        try {
//            org.joda.time.DateTime dateTime19 = dateTime3.withField(dateTimeFieldType16, (-1));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfDay must be in the range [0,1439]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 767 + "'", int17 == 767);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField6);
        java.lang.String str10 = skipDateTimeField9.toString();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipDateTimeField9, (int) 'a');
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology14);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime18 = property17.roundHalfCeiling();
        mutableDateTime18.addMinutes(100);
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime18.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime23 = property21.addWrapField(0);
        org.joda.time.MutableDateTime mutableDateTime24 = property21.roundHalfFloor();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = dateTime26.toDateTime(dateTimeZone27);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.dayOfYear();
        org.joda.time.DateTime dateTime31 = dateTime28.withChronology((org.joda.time.Chronology) gJChronology29);
        try {
            org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology1, (org.joda.time.ReadableDateTime) mutableDateTime24, (org.joda.time.ReadableDateTime) dateTime28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[monthOfYear]" + "'", str10.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 4, dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add((long) 1, (long) 3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (short) -1);
        org.joda.time.DateTimeField dateTimeField13 = delegatedDateTimeField7.getWrappedField();
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField7.getAsShortText(0, locale15);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7776000001L + "'", long10 == 7776000001L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant2 = dateTime1.toInstant();
        org.joda.time.Instant instant4 = instant2.minus((long) 100);
        org.joda.time.Instant instant6 = instant2.minus((long) 6);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant2.minus(readableDuration7);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((-1));
        try {
            org.joda.time.LocalTime localTime6 = dateTimeFormatter2.parseLocalTime("(\"org.joda.time.JodaTimePermission\" \"hi!\")");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"(\"org.joda.time.JodaTimePermissi...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName((long) (short) 0, locale3);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone1);
//        java.lang.String str7 = dateTimeZone1.getName(58665600010L);
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        java.lang.String str10 = dateTimeZone1.getShortName(1L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName((long) (short) 0, locale3);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone1);
//        java.lang.String str7 = dateTimeZone1.getName(58665600010L);
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        mutableDateTime8.add((long) (short) 0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        java.lang.String str15 = skipDateTimeField14.toString();
        long long17 = skipDateTimeField14.remainder((long) (short) -1);
        int int18 = dateTime8.get((org.joda.time.DateTimeField) skipDateTimeField14);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime8.minus(readableDuration20);
        org.joda.time.DateTime dateTime23 = dateTime8.withWeekyear(97);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[monthOfYear]" + "'", str15.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2678399999L + "'", long17 == 2678399999L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField17);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology15);
//        org.joda.time.DateTime.Property property22 = dateTime21.dayOfYear();
//        org.joda.time.TimeOfDay timeOfDay23 = dateTime21.toTimeOfDay();
//        int int24 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay23);
//        int int26 = offsetDateTimeField14.getLeapAmount(100L);
//        int int28 = offsetDateTimeField14.get(58665600020L);
//        int int30 = offsetDateTimeField14.getLeapAmount((long) 12);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 767 + "'", int12 == 767);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(timeOfDay23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 322 + "'", int28 == 322);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        int int5 = property4.get();
        org.joda.time.MutableDateTime mutableDateTime7 = property4.add(2440588L);
        java.lang.String str8 = property4.toString();
        int int9 = property4.getLeapAmount();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[minuteOfDay]" + "'", str8.equals("Property[minuteOfDay]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) 57600072, (org.joda.time.Chronology) gJChronology1);
        java.lang.String str6 = mutableDateTime5.toString();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970-01-01T16:00:00.072Z" + "'", str6.equals("1970-01-01T16:00:00.072Z"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) -1);
        java.lang.String str2 = mutableDateTime1.toString();
        mutableDateTime1.addWeeks((int) (short) 1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
        long long11 = delegatedDateTimeField8.add((long) 1, (long) 3);
        long long13 = delegatedDateTimeField8.roundHalfFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField8.getType();
        try {
            mutableDateTime1.set(dateTimeFieldType14, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31T23:59:59.999Z" + "'", str2.equals("1969-12-31T23:59:59.999Z"));
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 7776000001L + "'", long11 == 7776000001L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField14.getWrappedField();
//        long long18 = offsetDateTimeField14.add((long) 57600010, (long) 3);
//        int int20 = offsetDateTimeField14.getMaximumValue(316800010L);
//        long long22 = offsetDateTimeField14.roundCeiling((long) 767);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.toDateTime(dateTimeZone25);
//        int int27 = dateTime24.getMillisOfDay();
//        org.joda.time.DateTime dateTime29 = dateTime24.plusHours((int) '4');
//        org.joda.time.DateTime dateTime32 = dateTime24.withDurationAdded(1L, 62);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime32.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTime.Property property35 = dateTime32.yearOfEra();
//        org.joda.time.DateTime dateTime37 = dateTime32.withMillis((-2678399900L));
//        org.joda.time.DateTime dateTime39 = dateTime37.plusMonths(6);
//        org.joda.time.DateTime dateTime41 = dateTime37.minusDays((int) ' ');
//        org.joda.time.YearMonthDay yearMonthDay42 = dateTime37.toYearMonthDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField45 = gJChronology44.dayOfYear();
//        org.joda.time.Instant instant46 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology48.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime50 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology48);
//        org.joda.time.MutableDateTime.Property property51 = mutableDateTime50.minuteOfDay();
//        int int52 = property51.get();
//        org.joda.time.MutableDateTime mutableDateTime54 = property51.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property51.getFieldType();
//        int int56 = instant46.get(dateTimeFieldType55);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, dateTimeFieldType55, 7);
//        org.joda.time.DateTimeField dateTimeField59 = offsetDateTimeField58.getWrappedField();
//        long long61 = offsetDateTimeField58.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone64 = null;
//        org.joda.time.DateTime dateTime65 = dateTime63.toDateTime(dateTimeZone64);
//        int int66 = dateTime63.getMillisOfDay();
//        org.joda.time.DateTime dateTime68 = dateTime63.plusHours((int) '4');
//        org.joda.time.DateTime dateTime70 = dateTime68.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime72 = dateTime70.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay73 = dateTime72.toYearMonthDay();
//        int[] intArray79 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray81 = offsetDateTimeField58.addWrapField((org.joda.time.ReadablePartial) yearMonthDay73, (int) (byte) 0, intArray79, 4);
//        try {
//            int[] intArray83 = offsetDateTimeField14.add((org.joda.time.ReadablePartial) yearMonthDay42, 3, intArray79, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Fields invalid for add");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 767 + "'", int12 == 767);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 316800010L + "'", long18 == 316800010L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 373 + "'", int20 == 373);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 86400000L + "'", long22 == 86400000L);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(yearMonthDay42);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(instant46);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 767 + "'", int56 == 767);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 2678400000L + "'", long61 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 10 + "'", int66 == 10);
//        org.junit.Assert.assertNotNull(dateTime68);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(yearMonthDay73);
//        org.junit.Assert.assertNotNull(intArray79);
//        org.junit.Assert.assertNotNull(intArray81);
//    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField14.getWrappedField();
//        long long17 = offsetDateTimeField14.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime(dateTimeZone20);
//        int int22 = dateTime19.getMillisOfDay();
//        org.joda.time.DateTime dateTime24 = dateTime19.plusHours((int) '4');
//        org.joda.time.DateTime dateTime26 = dateTime24.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime28 = dateTime26.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay29 = dateTime28.toYearMonthDay();
//        int[] intArray35 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray37 = offsetDateTimeField14.addWrapField((org.joda.time.ReadablePartial) yearMonthDay29, (int) (byte) 0, intArray35, 4);
//        org.joda.time.DurationField durationField38 = offsetDateTimeField14.getLeapDurationField();
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = offsetDateTimeField14.getAsText(0, locale40);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 767 + "'", int12 == 767);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2678400000L + "'", long17 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(yearMonthDay29);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertNull(durationField38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "0" + "'", str41.equals("0"));
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday(97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMinuteOfHour(1971);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder10.appendTimeZoneOffset("342", true, 767, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime3.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.addWrapField((int) (short) 1);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.dayOfYear();
        try {
            mutableDateTime7.setTime(57600072, 0, 20, 57600072);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600072 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported", (int) (byte) 10, 12, 57600072);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported must be in the range [12,57600072]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int7 = skipDateTimeField5.getLeapAmount(10L);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10, dateTimeFieldType11);
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField10);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTime.Property property15 = dateTime14.dayOfYear();
        org.joda.time.TimeOfDay timeOfDay16 = dateTime14.toTimeOfDay();
        int int17 = skipDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay16);
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = skipDateTimeField5.getAsText((int) '4', locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(timeOfDay16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        int int29 = remainderDateTimeField25.getDifference(58665600020L, (long) 9);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 767 + "'", int21 == 767);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 22 + "'", int29 == 22);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.year();
        int int5 = property4.getLeapAmount();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        java.lang.String str28 = remainderDateTimeField25.getAsShortText((-1L));
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField31 = gJChronology30.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31, dateTimeFieldType32);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology29, dateTimeField31);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology29);
//        org.joda.time.DateTime.Property property36 = dateTime35.dayOfYear();
//        org.joda.time.TimeOfDay timeOfDay37 = dateTime35.toTimeOfDay();
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.dayOfYear();
//        org.joda.time.Instant instant41 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField44 = gJChronology43.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime45 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology43);
//        org.joda.time.MutableDateTime.Property property46 = mutableDateTime45.minuteOfDay();
//        int int47 = property46.get();
//        org.joda.time.MutableDateTime mutableDateTime49 = property46.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = property46.getFieldType();
//        int int51 = instant41.get(dateTimeFieldType50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, dateTimeFieldType50, 7);
//        org.joda.time.DateTimeField dateTimeField54 = offsetDateTimeField53.getWrappedField();
//        long long56 = offsetDateTimeField53.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone59 = null;
//        org.joda.time.DateTime dateTime60 = dateTime58.toDateTime(dateTimeZone59);
//        int int61 = dateTime58.getMillisOfDay();
//        org.joda.time.DateTime dateTime63 = dateTime58.plusHours((int) '4');
//        org.joda.time.DateTime dateTime65 = dateTime63.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime67 = dateTime65.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay68 = dateTime67.toYearMonthDay();
//        int[] intArray74 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray76 = offsetDateTimeField53.addWrapField((org.joda.time.ReadablePartial) yearMonthDay68, (int) (byte) 0, intArray74, 4);
//        try {
//            int[] intArray78 = remainderDateTimeField25.set((org.joda.time.ReadablePartial) timeOfDay37, (int) ' ', intArray74, (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for minuteOfDay must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 767 + "'", int21 == 767);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(timeOfDay37);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(instant41);
//        org.junit.Assert.assertNotNull(gJChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 767 + "'", int51 == 767);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2678400000L + "'", long56 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(yearMonthDay68);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertNotNull(intArray76);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            int int9 = dateTime6.get(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.halfdayOfDay();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Chronology chronology4 = gJChronology0.withUTC();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = gJChronology0.get(readablePeriod5, (long) 'a', (-2649600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        int int5 = gregorianChronology1.getMinimumDaysInFirstWeek();
        java.lang.String str6 = gregorianChronology1.toString();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField9);
        java.lang.String str13 = skipDateTimeField12.toString();
        long long15 = skipDateTimeField12.remainder((long) (short) -1);
        org.joda.time.DurationField durationField16 = skipDateTimeField12.getDurationField();
        boolean boolean17 = skipDateTimeField12.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) skipDateTimeField12);
        boolean boolean20 = skipUndoDateTimeField18.isLeap(0L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[monthOfYear]" + "'", str13.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2678399999L + "'", long15 == 2678399999L);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.monthOfYear();
//        long long12 = gJChronology7.add((long) (byte) 1, 2649599999L, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) (short) 0, locale15);
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology7, dateTimeZone13);
//        try {
//            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(2, 6, 86399999, (-11), (int) (short) 10, (int) '4', 960, dateTimeZone13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -11 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 26495999991L + "'", long12 == 26495999991L);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology17);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        try {
            long long2 = dateTimeFormatter0.parseMillis("Property[yearOfEra]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[yearOfEra]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
//        java.util.Set<java.lang.String> strSet7 = org.joda.time.DateTimeZone.getAvailableIDs();
//        boolean boolean8 = julianChronology6.equals((java.lang.Object) strSet7);
//        org.joda.time.DurationField durationField9 = julianChronology6.years();
//        org.joda.time.DateTimeField dateTimeField10 = julianChronology6.weekyearOfCentury();
//        boolean boolean11 = mutableDateTime4.equals((java.lang.Object) dateTimeField10);
//        boolean boolean12 = mutableDateTime4.isEqualNow();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(strSet7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("57600010", 8, 12, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 8 for 57600010 must be in the range [12,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
//        org.joda.time.Chronology chronology4 = dateTimeFormatter0.getChronology();
//        java.lang.StringBuffer stringBuffer5 = null;
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfYear();
//        org.joda.time.Instant instant8 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology10);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.minuteOfDay();
//        int int14 = property13.get();
//        org.joda.time.MutableDateTime mutableDateTime16 = property13.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property13.getFieldType();
//        int int18 = instant8.get(dateTimeFieldType17);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType17, 7);
//        org.joda.time.DateTimeField dateTimeField21 = offsetDateTimeField20.getWrappedField();
//        long long23 = offsetDateTimeField20.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime25.toDateTime(dateTimeZone26);
//        int int28 = dateTime25.getMillisOfDay();
//        org.joda.time.DateTime dateTime30 = dateTime25.plusHours((int) '4');
//        org.joda.time.DateTime dateTime32 = dateTime30.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime34 = dateTime32.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay35 = dateTime34.toYearMonthDay();
//        int[] intArray41 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray43 = offsetDateTimeField20.addWrapField((org.joda.time.ReadablePartial) yearMonthDay35, (int) (byte) 0, intArray41, 4);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer5, (org.joda.time.ReadablePartial) yearMonthDay35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNull(chronology4);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(instant8);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 767 + "'", int18 == 767);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2678400000L + "'", long23 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(yearMonthDay35);
//        org.junit.Assert.assertNotNull(intArray41);
//        org.junit.Assert.assertNotNull(intArray43);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("millisOfDay");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: millisOfDay");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
//        int int4 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getShortName((long) (short) 0, locale9);
//        org.joda.time.DateTime dateTime11 = dateTime6.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = dateTime6.withChronology((org.joda.time.Chronology) julianChronology13);
//        int int15 = dateTime14.getDayOfWeek();
//        org.joda.time.Chronology chronology16 = dateTime14.getChronology();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(chronology16);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Coordinated Universal Time", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Coordinated Universal Time/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
        org.joda.time.TimeOfDay timeOfDay3 = dateTime2.toTimeOfDay();
        try {
            org.joda.time.DateTime dateTime5 = dateTime2.withEra(62);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 62 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(timeOfDay3);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("4:00:00 PM", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        int int5 = property4.get();
        org.joda.time.MutableDateTime mutableDateTime7 = property4.add(2440588L);
        java.lang.String str8 = property4.toString();
        org.joda.time.MutableDateTime mutableDateTime9 = property4.getMutableDateTime();
        java.util.Locale locale10 = null;
        int int11 = property4.getMaximumTextLength(locale10);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[minuteOfDay]" + "'", str8.equals("Property[minuteOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime6.withMillisOfSecond((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
        java.lang.String str12 = property11.getAsString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "19" + "'", str12.equals("19"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 15638400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology1.days();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField8 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField6);
        java.lang.String str10 = skipDateTimeField9.toString();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipDateTimeField9, (int) 'a');
        java.util.Locale locale15 = null;
        try {
            long long16 = skipDateTimeField9.set(14000L, "JulianChronology[America/Los_Angeles]", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"JulianChronology[America/Los_Angeles]\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[monthOfYear]" + "'", str10.equals("DateTimeField[monthOfYear]"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime();
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime3.add(readableDuration4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.weekyear();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        java.util.Locale locale29 = null;
//        try {
//            long long30 = remainderDateTimeField25.set((long) 7, "DateTimeField[monthOfYear]", locale29);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[monthOfYear]\" for minuteOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 767 + "'", int21 == 767);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("4:00:32 AM UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"4:00:32 AM UTC\" is malformed at \":00:32 AM UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getEra();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("", "hi!");
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException7);
        java.lang.Number number9 = illegalFieldValueException7.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException7.getDurationFieldType();
        java.lang.String str11 = illegalFieldValueException7.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = illegalFieldValueException7.getDateTimeFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = illegalFieldValueException7.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(dateTimeFieldType12);
        org.junit.Assert.assertNull(dateTimeFieldType14);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("Property[minuteOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[minuteOfDay]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 28800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(58665600010L);
        int int2 = mutableDateTime1.getMonthOfYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.lang.String str5 = iSOChronology4.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 0, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField17);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology15);
//        org.joda.time.DateTime.Property property22 = dateTime21.dayOfYear();
//        org.joda.time.TimeOfDay timeOfDay23 = dateTime21.toTimeOfDay();
//        int int24 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay23);
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField14.getMaximumShortTextLength(locale25);
//        long long28 = offsetDateTimeField14.roundFloor(316800010L);
//        long long30 = offsetDateTimeField14.roundHalfEven(14000L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 768 + "'", int12 == 768);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(timeOfDay23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 259200000L + "'", long28 == 259200000L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.StringBuffer stringBuffer4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfYear();
//        org.joda.time.Instant instant7 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology9);
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.minuteOfDay();
//        int int13 = property12.get();
//        org.joda.time.MutableDateTime mutableDateTime15 = property12.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property12.getFieldType();
//        int int17 = instant7.get(dateTimeFieldType16);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType16, 7);
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology20, dateTimeField22);
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology20);
//        org.joda.time.DateTime.Property property27 = dateTime26.dayOfYear();
//        org.joda.time.TimeOfDay timeOfDay28 = dateTime26.toTimeOfDay();
//        int int29 = offsetDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay28);
//        int int31 = offsetDateTimeField19.getLeapAmount(100L);
//        int int33 = offsetDateTimeField19.get(58665600020L);
//        long long35 = offsetDateTimeField19.roundHalfCeiling((long) 19);
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField38 = gJChronology37.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField38, dateTimeFieldType39);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField41 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology36, dateTimeField38);
//        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology36);
//        org.joda.time.DateTime.Property property43 = dateTime42.dayOfYear();
//        org.joda.time.TimeOfDay timeOfDay44 = dateTime42.toTimeOfDay();
//        int int45 = offsetDateTimeField19.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay44);
//        try {
//            dateTimeFormatter3.printTo(stringBuffer4, (org.joda.time.ReadablePartial) timeOfDay44);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 768 + "'", int17 == 768);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(timeOfDay28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 8 + "'", int29 == 8);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 322 + "'", int33 == 322);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(timeOfDay44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 373 + "'", int45 == 373);
//    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        long long27 = remainderDateTimeField25.roundHalfEven((-2592000000L));
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 768 + "'", int21 == 768);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2678400000L) + "'", long27 == (-2678400000L));
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.lang.String str6 = skipDateTimeField5.toString();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsText(9L, locale8);
        boolean boolean10 = skipDateTimeField5.isLenient();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[monthOfYear]" + "'", str6.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January" + "'", str9.equals("January"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(8, 97, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        int int5 = property4.getLeapAmount();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        long long8 = mutableDateTime3.getMillis();
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime3.copy();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = mutableDateTime3.toDateTime(dateTimeZone10);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology13 = gJChronology12.withUTC();
        org.joda.time.DateTime dateTime14 = mutableDateTime3.toDateTime(chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.withMinuteOfHour(0);
        org.joda.time.DateTime dateTime18 = dateTime14.minusYears((-1));
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58665600010L + "'", long8 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        long long27 = remainderDateTimeField25.roundHalfCeiling(0L);
//        long long29 = remainderDateTimeField25.remainder((long) 1971);
//        long long31 = remainderDateTimeField25.roundCeiling((-210865896000000L));
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 768 + "'", int21 == 768);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1971L + "'", long29 == 1971L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-210864124800000L) + "'", long31 == (-210864124800000L));
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 24, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
//        int int5 = property4.get();
//        org.joda.time.MutableDateTime mutableDateTime7 = property4.add(2440588L);
//        java.lang.Object obj8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getShortName((long) (short) 0, locale11);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone9);
//        java.lang.String str15 = dateTimeZone9.getName(58665600010L);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(obj8, dateTimeZone9);
//        mutableDateTime7.setZone(dateTimeZone9);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        long long28 = remainderDateTimeField25.roundHalfCeiling(2649599999L);
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.dayOfYear();
//        org.joda.time.Instant instant31 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology33);
//        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.minuteOfDay();
//        int int37 = property36.get();
//        org.joda.time.MutableDateTime mutableDateTime39 = property36.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property36.getFieldType();
//        int int41 = instant31.get(dateTimeFieldType40);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, dateTimeFieldType40, 7);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType40);
//        org.joda.time.DurationField durationField45 = dividedDateTimeField44.getDurationField();
//        try {
//            long long47 = dividedDateTimeField44.roundFloor((long) 1970);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 768 + "'", int21 == 768);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2678400000L + "'", long28 == 2678400000L);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(instant31);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 768 + "'", int41 == 768);
//        org.junit.Assert.assertNotNull(durationField45);
//    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField14.getWrappedField();
//        long long17 = offsetDateTimeField14.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime(dateTimeZone20);
//        int int22 = dateTime19.getMillisOfDay();
//        org.joda.time.DateTime dateTime24 = dateTime19.plusHours((int) '4');
//        org.joda.time.DateTime dateTime26 = dateTime24.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime28 = dateTime26.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay29 = dateTime28.toYearMonthDay();
//        int[] intArray35 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray37 = offsetDateTimeField14.addWrapField((org.joda.time.ReadablePartial) yearMonthDay29, (int) (byte) 0, intArray35, 4);
//        int int38 = offsetDateTimeField14.getMinimumValue();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 768 + "'", int12 == 768);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2678400000L + "'", long17 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(yearMonthDay29);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 8 + "'", int38 == 8);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        try {
//            long long17 = offsetDateTimeField14.set((-41471999990L), 57600072);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600072 for minuteOfDay must be in the range [8,373]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 768 + "'", int12 == 768);
//    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
//        int int4 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getShortName((long) (short) 0, locale9);
//        org.joda.time.DateTime dateTime11 = dateTime6.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = dateTime6.withChronology((org.joda.time.Chronology) julianChronology13);
//        org.joda.time.DurationFieldType durationFieldType15 = null;
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime6.withFieldAdded(durationFieldType15, 57600072);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField17);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology15);
//        org.joda.time.DateTime.Property property22 = dateTime21.dayOfYear();
//        org.joda.time.TimeOfDay timeOfDay23 = dateTime21.toTimeOfDay();
//        int int24 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay23);
//        int int26 = offsetDateTimeField14.getLeapAmount(100L);
//        int int28 = offsetDateTimeField14.get(58665600020L);
//        long long30 = offsetDateTimeField14.roundHalfCeiling((long) 19);
//        org.joda.time.DurationField durationField31 = offsetDateTimeField14.getLeapDurationField();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 768 + "'", int12 == 768);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(timeOfDay23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 322 + "'", int28 == 322);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNull(durationField31);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(768, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 768");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName((long) (short) 0, locale2);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone0);
//        java.lang.String str6 = dateTimeZone0.getName(58665600010L);
//        java.lang.String str7 = dateTimeZone0.getID();
//        java.lang.String str8 = dateTimeZone0.toString();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone0.getName((long) (-11), locale11);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField14.getWrappedField();
//        long long18 = offsetDateTimeField14.add((long) 57600010, (long) 3);
//        int int20 = offsetDateTimeField14.getMaximumValue(316800010L);
//        long long22 = offsetDateTimeField14.roundCeiling((long) 767);
//        try {
//            long long25 = offsetDateTimeField14.set((long) 10, "1970001T000000.100Z");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970001T000000.100Z\" for minuteOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 768 + "'", int12 == 768);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 316800010L + "'", long18 == 316800010L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 373 + "'", int20 == 373);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 86400000L + "'", long22 == 86400000L);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.joda.time.DateTime dateTime14 = dateTime9.withMillis((-2678399900L));
        org.joda.time.DateTime dateTime16 = dateTime14.plusMonths(6);
        org.joda.time.DateTime dateTime18 = dateTime14.minusDays((int) ' ');
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = dateTime18.toString("monthOfYear", locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.joda.time.DateTime dateTime14 = dateTime9.withMillis((-2678399900L));
        org.joda.time.DateTime dateTime16 = dateTime14.plusMonths(6);
        org.joda.time.DateTime dateTime18 = dateTime14.minusDays((int) ' ');
        org.joda.time.DateTime dateTime20 = dateTime14.minusMonths((int) (byte) -1);
        try {
            org.joda.time.DateTime dateTime22 = dateTime20.withMillisOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
//        int int4 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getShortName((long) (short) 0, locale9);
//        org.joda.time.DateTime dateTime11 = dateTime6.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = dateTime6.withChronology((org.joda.time.Chronology) julianChronology13);
//        try {
//            long long22 = julianChronology13.getDateTimeMillis((-63), 1970, 0, 0, (int) (short) 10, 97, 1971);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) -1);
        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(100L, dateTimeZone5);
        int int7 = mutableDateTime2.compareTo((org.joda.time.ReadableInstant) mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969-12-31T23:59:59" + "'", str3.equals("1969-12-31T23:59:59"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.halfdayOfDay();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = gJChronology0.get(readablePeriod3, (long) 20, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
//        long long5 = gJChronology0.add((long) (byte) 1, 2649599999L, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getShortName((long) (short) 0, locale8);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone11 = zonedChronology10.getZone();
//        org.joda.time.Chronology chronology12 = zonedChronology10.withUTC();
//        try {
//            long long20 = zonedChronology10.getDateTimeMillis(97, (int) (byte) -1, 1971, 72, 1971, 24, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 72 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 26495999991L + "'", long5 == 26495999991L);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(chronology12);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.halfdayOfDay();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime3.add(readableDuration4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.yearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        long long27 = remainderDateTimeField25.roundHalfCeiling(0L);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime29.toDateTime(dateTimeZone30);
//        int int32 = dateTime29.getMillisOfDay();
//        org.joda.time.DateTime dateTime34 = dateTime29.plusHours((int) '4');
//        org.joda.time.DateTime dateTime36 = dateTime34.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime38 = dateTime36.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay39 = dateTime38.toYearMonthDay();
//        int[] intArray42 = new int[] { 322 };
//        try {
//            int[] intArray44 = remainderDateTimeField25.addWrapPartial((org.joda.time.ReadablePartial) yearMonthDay39, (-1), intArray42, 57600072);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 768 + "'", int21 == 768);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(yearMonthDay39);
//        org.junit.Assert.assertNotNull(intArray42);
//    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        long long28 = remainderDateTimeField25.roundHalfCeiling(0L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.util.Locale locale31 = dateTimeFormatter30.getLocale();
//        org.joda.time.format.DateTimePrinter dateTimePrinter32 = dateTimeFormatter30.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder29.append(dateTimePrinter32);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder33.appendYearOfEra((int) (byte) 10, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder37.appendHourOfHalfday(97);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder39.appendMinuteOfHour(1971);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendYear(86399999, 1971);
//        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField47 = gJChronology46.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField47, dateTimeFieldType48);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField50 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology45, dateTimeField47);
//        int int51 = skipDateTimeField50.getMinimumValue();
//        int int52 = skipDateTimeField50.getMinimumValue();
//        boolean boolean53 = skipDateTimeField50.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField55 = gJChronology54.dayOfYear();
//        org.joda.time.Instant instant56 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField59 = gJChronology58.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime60 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology58);
//        org.joda.time.MutableDateTime.Property property61 = mutableDateTime60.minuteOfDay();
//        int int62 = property61.get();
//        org.joda.time.MutableDateTime mutableDateTime64 = property61.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType65 = property61.getFieldType();
//        int int66 = instant56.get(dateTimeFieldType65);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, dateTimeFieldType65, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField50, dateTimeFieldType65, 2);
//        int int71 = remainderDateTimeField70.getMinimumValue();
//        long long73 = remainderDateTimeField70.roundHalfCeiling(2649599999L);
//        org.joda.time.chrono.GJChronology gJChronology74 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField75 = gJChronology74.dayOfYear();
//        org.joda.time.Instant instant76 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology78 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField79 = gJChronology78.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime80 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology78);
//        org.joda.time.MutableDateTime.Property property81 = mutableDateTime80.minuteOfDay();
//        int int82 = property81.get();
//        org.joda.time.MutableDateTime mutableDateTime84 = property81.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType85 = property81.getFieldType();
//        int int86 = instant76.get(dateTimeFieldType85);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField88 = new org.joda.time.field.OffsetDateTimeField(dateTimeField75, dateTimeFieldType85, 7);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField89 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField70, dateTimeFieldType85);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder92 = dateTimeFormatterBuilder41.appendDecimal(dateTimeFieldType85, 960, 86399999);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField93 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType85);
//        try {
//            long long95 = dividedDateTimeField93.roundHalfCeiling((long) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 768 + "'", int21 == 768);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNull(locale31);
//        org.junit.Assert.assertNotNull(dateTimePrinter32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(gJChronology45);
//        org.junit.Assert.assertNotNull(gJChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(gJChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(instant56);
//        org.junit.Assert.assertNotNull(gJChronology58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime64);
//        org.junit.Assert.assertNotNull(dateTimeFieldType65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 768 + "'", int66 == 768);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 2678400000L + "'", long73 == 2678400000L);
//        org.junit.Assert.assertNotNull(gJChronology74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(instant76);
//        org.junit.Assert.assertNotNull(gJChronology78);
//        org.junit.Assert.assertNotNull(dateTimeField79);
//        org.junit.Assert.assertNotNull(property81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime84);
//        org.junit.Assert.assertNotNull(dateTimeFieldType85);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 768 + "'", int86 == 768);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder92);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        long long8 = mutableDateTime3.getMillis();
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime3.copy();
        org.joda.time.MutableDateTime mutableDateTime10 = mutableDateTime3.copy();
        mutableDateTime3.setSecondOfMinute((int) '4');
        org.joda.time.ReadableDuration readableDuration13 = null;
        mutableDateTime3.add(readableDuration13);
        org.joda.time.DurationFieldType durationFieldType15 = null;
        try {
            mutableDateTime3.add(durationFieldType15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58665600010L + "'", long8 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant2 = dateTime1.toInstant();
        org.joda.time.Instant instant4 = instant2.minus((long) 100);
        org.joda.time.Instant instant6 = instant2.minus((long) 6);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant2.plus(readableDuration7);
        org.joda.time.Instant instant11 = instant2.withDurationAdded((long) (-1), (int) '4');
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.roundCeilingCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.plusDays(24);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        mutableDateTime8.addWeeks((int) 'a');
        int int11 = property4.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime8.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime13 = property12.roundHalfCeiling();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(8);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        int int5 = dateTimeFormatter4.getDefaultYear();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology7 = gJChronology6.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.Instant instant9 = gJChronology6.getGregorianCutover();
        try {
            dateTimeFormatter2.printTo(stringBuffer3, (org.joda.time.ReadableInstant) instant9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2000 + "'", int5 == 2000);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime();
        try {
            org.joda.time.DateTime dateTime15 = dateTime13.withMonthOfYear(57600072);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600072 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField14.getWrappedField();
//        long long17 = offsetDateTimeField14.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime(dateTimeZone20);
//        int int22 = dateTime19.getMillisOfDay();
//        org.joda.time.DateTime dateTime24 = dateTime19.plusHours((int) '4');
//        org.joda.time.DateTime dateTime26 = dateTime24.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime28 = dateTime26.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay29 = dateTime28.toYearMonthDay();
//        int[] intArray35 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray37 = offsetDateTimeField14.addWrapField((org.joda.time.ReadablePartial) yearMonthDay29, (int) (byte) 0, intArray35, 4);
//        java.util.Locale locale38 = null;
//        int int39 = offsetDateTimeField14.getMaximumTextLength(locale38);
//        long long41 = offsetDateTimeField14.roundCeiling((-210858379200000L));
//        long long44 = offsetDateTimeField14.add(26265600000L, (long) (short) 0);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 768 + "'", int12 == 768);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2678400000L + "'", long17 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(yearMonthDay29);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3 + "'", int39 == 3);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-210858336000000L) + "'", long41 == (-210858336000000L));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 26265600000L + "'", long44 == 26265600000L);
//    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.toDateTime(dateTimeZone8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
//        org.joda.time.DateTime.Property property11 = dateTime9.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getShortName((long) (short) 0, locale14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone12);
//        java.lang.String str18 = dateTimeZone12.getName(58665600010L);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone12.getName(2678399999L, locale20);
//        org.joda.time.DateTime dateTime22 = dateTime9.withZoneRetainFields(dateTimeZone12);
//        try {
//            org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) -1, 4, 1970, 2000, dateTimeZone12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Coordinated Universal Time" + "'", str18.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Coordinated Universal Time" + "'", str21.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(322, 373, 11, 57600010);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 695 + "'", int4 == 695);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int6 = skipDateTimeField5.getMinimumValue();
        int int7 = skipDateTimeField5.getMinimumValue();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, 57600072);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add((long) 1, (long) 3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (short) -1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = delegatedDateTimeField7.getAsShortText((long) (byte) 10, locale14);
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = delegatedDateTimeField7.getAsText(52, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7776000001L + "'", long10 == 7776000001L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Jan" + "'", str15.equals("Jan"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        org.joda.time.DateTimeField dateTimeField7 = property4.getField();
        long long8 = property4.remainder();
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = property4.set("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[UTC]\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.lang.String str6 = skipDateTimeField5.toString();
        long long8 = skipDateTimeField5.roundFloor((long) 97);
        int int9 = skipDateTimeField5.getMinimumValue();
        long long11 = skipDateTimeField5.roundHalfEven((long) 4);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[monthOfYear]" + "'", str6.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int6 = skipDateTimeField5.getMinimumValue();
        int int7 = skipDateTimeField5.getMinimumValue();
        int int8 = skipDateTimeField5.getMaximumValue();
        org.joda.time.DurationField durationField9 = skipDateTimeField5.getRangeDurationField();
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipDateTimeField5.getAsShortText(57600010L, locale11);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Jan" + "'", str12.equals("Jan"));
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField14.getWrappedField();
//        long long18 = offsetDateTimeField14.add((long) 57600010, (long) 3);
//        int int20 = offsetDateTimeField14.getMaximumValue(316800010L);
//        long long22 = offsetDateTimeField14.roundCeiling((long) 767);
//        long long24 = offsetDateTimeField14.roundFloor((long) 322);
//        org.joda.time.DurationField durationField25 = offsetDateTimeField14.getLeapDurationField();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 768 + "'", int12 == 768);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 316800010L + "'", long18 == 316800010L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 373 + "'", int20 == 373);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 86400000L + "'", long22 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNull(durationField25);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        long long8 = mutableDateTime3.getMillis();
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime3.copy();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = mutableDateTime3.toDateTime(dateTimeZone10);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology13 = gJChronology12.withUTC();
        org.joda.time.DateTime dateTime14 = mutableDateTime3.toDateTime(chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.withMinuteOfHour(0);
        org.joda.time.DateTime dateTime18 = dateTime16.plusSeconds((int) ' ');
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58665600010L + "'", long8 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str5 = jodaTimePermission3.getActions();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("+06:00");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.append(dateTimePrinter9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMillisOfSecond((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField14.getWrappedField();
//        long long17 = offsetDateTimeField14.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime(dateTimeZone20);
//        int int22 = dateTime19.getMillisOfDay();
//        org.joda.time.DateTime dateTime24 = dateTime19.plusHours((int) '4');
//        org.joda.time.DateTime dateTime26 = dateTime24.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime28 = dateTime26.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay29 = dateTime28.toYearMonthDay();
//        int[] intArray35 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray37 = offsetDateTimeField14.addWrapField((org.joda.time.ReadablePartial) yearMonthDay29, (int) (byte) 0, intArray35, 4);
//        org.joda.time.DurationField durationField38 = offsetDateTimeField14.getLeapDurationField();
//        org.joda.time.DurationField durationField39 = offsetDateTimeField14.getRangeDurationField();
//        long long41 = offsetDateTimeField14.roundHalfCeiling((long) 0);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 768 + "'", int12 == 768);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2678400000L + "'", long17 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(yearMonthDay29);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertNull(durationField38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusYears(0);
        org.joda.time.DateTime dateTime6 = dateTime2.withMillisOfSecond((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        boolean boolean6 = jodaTimePermission3.equals((java.lang.Object) (-1.0f));
        jodaTimePermission3.checkGuard((java.lang.Object) 2000);
        java.lang.String str9 = jodaTimePermission3.getActions();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale12 = dateTimeFormatter11.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.append(dateTimePrinter13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendYearOfEra((int) (byte) 10, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendHourOfHalfday(97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendMinuteOfHour(1971);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendYear(86399999, 1971);
        boolean boolean26 = jodaTimePermission3.equals((java.lang.Object) 1971);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNull(locale12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime3.getDayOfWeek();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(6);
        java.lang.String str10 = dateTimeZone8.getName((long) 9);
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = dateTimeZone8.isLocalDateTimeGap(localDateTime11);
        long long14 = dateTimeZone8.convertUTCToLocal((long) 322);
        org.joda.time.DateTime dateTime15 = dateTime3.toDateTime(dateTimeZone8);
        int int16 = dateTime15.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+06:00" + "'", str10.equals("+06:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 21600322L + "'", long14 == 21600322L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant2 = dateTime1.toInstant();
        long long3 = dateTime1.getMillis();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.plus(readablePeriod4);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField17);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology15);
//        org.joda.time.DateTime.Property property22 = dateTime21.dayOfYear();
//        org.joda.time.TimeOfDay timeOfDay23 = dateTime21.toTimeOfDay();
//        int int24 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay23);
//        int int26 = offsetDateTimeField14.getLeapAmount(100L);
//        int int28 = offsetDateTimeField14.get(58665600020L);
//        long long31 = offsetDateTimeField14.addWrapField((long) 2000, 4);
//        int int33 = offsetDateTimeField14.getMaximumValue(15638400000L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 768 + "'", int12 == 768);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(timeOfDay23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 322 + "'", int28 == 322);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 345602000L + "'", long31 == 345602000L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 373 + "'", int33 == 373);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        long long8 = mutableDateTime3.getMillis();
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime3.copy();
        mutableDateTime3.setSecondOfDay(1971);
        mutableDateTime3.setTime(9L);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime3.minuteOfDay();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58665600010L + "'", long8 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("1969-12-01T00:00:00.100Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 1969-12-01T00:00:00.100Z");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        long long28 = remainderDateTimeField25.roundHalfCeiling(2649599999L);
//        long long30 = remainderDateTimeField25.roundCeiling(1971L);
//        int int31 = remainderDateTimeField25.getDivisor();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 768 + "'", int21 == 768);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2678400000L + "'", long28 == 2678400000L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2678400000L + "'", long30 == 2678400000L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
//    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
//        long long5 = gJChronology0.add((long) (byte) 1, 2649599999L, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getShortName((long) (short) 0, locale8);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone6);
//        try {
//            long long18 = zonedChronology10.getDateTimeMillis((int) (short) 1, 24, 4, (int) (short) 0, 5, 57600072, 1971);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600072 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 26495999991L + "'", long5 == 26495999991L);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology10);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        java.util.Set<java.lang.String> strSet2 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean3 = julianChronology1.equals((java.lang.Object) strSet2);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology1.yearOfEra();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfCeiling();
        mutableDateTime5.addMinutes(100);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.addWrapField(0);
        mutableDateTime10.setWeekOfWeekyear((int) '#');
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology7);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField12);
        java.lang.String str16 = skipDateTimeField15.toString();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, (org.joda.time.DateTimeField) skipDateTimeField15, (int) 'a');
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipDateTimeField18);
        java.lang.String str21 = skipDateTimeField19.getAsShortText(316800010L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[monthOfYear]" + "'", str16.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Jan" + "'", str21.equals("Jan"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendMinuteOfHour(52);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(100L, dateTimeZone1);
        mutableDateTime2.addDays(62);
        try {
            mutableDateTime2.setTime(0, 322, 0, 768);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 322 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        try {
            mutableDateTime3.setSecondOfMinute(322);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 322 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.lang.String str6 = skipDateTimeField5.toString();
        long long8 = skipDateTimeField5.remainder((long) (short) -1);
        org.joda.time.DurationField durationField9 = skipDateTimeField5.getDurationField();
        java.lang.String str11 = skipDateTimeField5.getAsShortText(1560343655006L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[monthOfYear]" + "'", str6.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2678399999L + "'", long8 == 2678399999L);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Jun" + "'", str11.equals("Jun"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 9, "1970-01-01T16:00:00.072Z");
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        long long8 = mutableDateTime3.getMillis();
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime3.copy();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.centuryOfEra();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime9.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime13 = property11.addWrapField(1971);
        mutableDateTime13.setMillisOfDay(12);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.minusYears(0);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime20.minus(readableDuration21);
        org.joda.time.DateTime.Property property23 = dateTime22.weekOfWeekyear();
        mutableDateTime13.setTime((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime22.toYearMonthDay();
        org.joda.time.DateTime dateTime27 = dateTime22.plusMinutes(3);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58665600010L + "'", long8 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(yearMonthDay25);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.DurationField durationField6 = gJChronology0.minutes();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime();
        org.joda.time.DateTime.Property property14 = dateTime13.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime13.toMutableDateTime();
        java.lang.Object obj16 = mutableDateTime15.clone();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(100L, dateTimeZone1);
        mutableDateTime2.addYears(0);
        mutableDateTime2.setDate(259200000L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("4:00:00 PM", "");
        illegalFieldValueException2.prependMessage("1969-12-31T15:59:59.999-08:00");
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number6 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1971L, (java.lang.Number) (byte) 1, (java.lang.Number) 26323200010L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        long long6 = delegatedDateTimeField3.add((long) 1, (long) 3);
        long long9 = delegatedDateTimeField3.add(0L, 8);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7776000001L + "'", long6 == 7776000001L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 20995200000L + "'", long9 == 20995200000L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add((long) 1, (long) 3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (short) -1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = delegatedDateTimeField7.getAsShortText((long) (byte) 10, locale14);
        long long17 = delegatedDateTimeField7.roundHalfFloor(0L);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7776000001L + "'", long10 == 7776000001L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Jan" + "'", str15.equals("Jan"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMinutes(3);
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withDayOfMonth(960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.yearOfCentury();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(12, 1971, 0, (-63), (-63), (-63), (org.joda.time.Chronology) gJChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -63 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
//        int int5 = gregorianChronology1.getMinimumDaysInFirstWeek();
//        java.lang.String str6 = gregorianChronology1.toString();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType10);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField9);
//        java.lang.String str13 = skipDateTimeField12.toString();
//        long long15 = skipDateTimeField12.remainder((long) (short) -1);
//        org.joda.time.DurationField durationField16 = skipDateTimeField12.getDurationField();
//        boolean boolean17 = skipDateTimeField12.isLenient();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) skipDateTimeField12);
//        long long20 = skipUndoDateTimeField18.roundFloor((long) 62);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.toDateTime(dateTimeZone23);
//        int int25 = dateTime22.getMillisOfDay();
//        org.joda.time.DateTime dateTime27 = dateTime22.plusHours((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = dateTimeZone28.getShortName((long) (short) 0, locale30);
//        org.joda.time.DateTime dateTime32 = dateTime27.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.TimeOfDay timeOfDay33 = dateTime32.toTimeOfDay();
//        int[] intArray35 = null;
//        try {
//            int[] intArray37 = skipUndoDateTimeField18.addWrapField((org.joda.time.ReadablePartial) timeOfDay33, (int) (byte) 100, intArray35, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[monthOfYear]" + "'", str13.equals("DateTimeField[monthOfYear]"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2678399999L + "'", long15 == 2678399999L);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UTC" + "'", str31.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(timeOfDay33);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.Chronology chronology2 = gJChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.yearOfCentury();
        org.joda.time.Instant instant4 = gJChronology0.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime3.hourOfDay();
        long long9 = property8.remainder();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.roundCeilingCopy();
        boolean boolean7 = dateTime6.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        java.lang.String str27 = skipDateTimeField5.getAsShortText((long) '4');
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 768 + "'", int21 == 768);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Jan" + "'", str27.equals("Jan"));
//    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getShortName((long) (short) 0, locale5);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone3);
//        java.lang.String str9 = dateTimeZone3.getName(58665600010L);
//        java.lang.String str10 = dateTimeZone3.getID();
//        boolean boolean12 = dateTimeZone3.isStandardOffset(345602000L);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.Instant instant15 = dateTime14.toInstant();
//        org.joda.time.DateTime dateTime16 = instant15.toDateTimeISO();
//        org.joda.time.DateTime dateTime17 = instant15.toDateTimeISO();
//        int int18 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.Chronology chronology19 = gregorianChronology2.withZone(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(chronology19);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendPattern("(\"org.joda.time.JodaTimePermission\" \"hi!\")");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) 57600072, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.hourOfDay();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        long long8 = mutableDateTime3.getMillis();
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime3.copy();
        org.joda.time.MutableDateTime mutableDateTime10 = mutableDateTime3.copy();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58665600010L + "'", long8 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime6.withMillisOfSecond((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
        org.joda.time.DateTime dateTime12 = property11.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.eras();
        try {
            long long7 = gJChronology1.getDateTimeMillis(97, 1970, 72, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday(97);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder8.appendTimeZoneOffset("0", true, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday(97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMinuteOfHour(1971);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1969-12-31T15:59:59.999-08:00");
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("4:00:00 PM", true);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("October", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
        org.joda.time.TimeOfDay timeOfDay8 = dateTime6.toTimeOfDay();
        org.joda.time.DateTime.Property property9 = dateTime6.weekyear();
        org.joda.time.DateTime dateTime10 = property9.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(timeOfDay8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("Coordinated Universal Time", true);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("1970-01-01T16:00:00.072Z", (int) (byte) 0, 768, 960, '#', 62, (int) (short) -1, 10, true, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        try {
            long long7 = gJChronology0.getDateTimeMillis((long) 100, 7, (int) (short) 100, 62, 57600072);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("Coordinated Universal Time", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 10, '4', 0, (int) (byte) 10, 2000, true, 3);
        java.io.DataOutput dataOutput13 = null;
        try {
            dateTimeZoneBuilder0.writeTo("(\"org.joda.time.JodaTimePermission\" \"hi!\")", dataOutput13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        long long8 = mutableDateTime3.getMillis();
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime3.copy();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.centuryOfEra();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime9.yearOfEra();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology12, dateTimeField14);
        int int18 = skipDateTimeField17.getMinimumValue();
        int int19 = skipDateTimeField17.getMinimumValue();
        boolean boolean20 = skipDateTimeField17.isLenient();
        boolean boolean21 = property11.equals((java.lang.Object) skipDateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58665600010L + "'", long8 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology1.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField18);
        java.lang.String str22 = skipDateTimeField21.toString();
        long long24 = skipDateTimeField21.remainder((long) (short) -1);
        int int25 = dateTime15.get((org.joda.time.DateTimeField) skipDateTimeField21);
        boolean boolean26 = skipDateTimeField21.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, (org.joda.time.DateTimeField) skipDateTimeField21, 960);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder29 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone32 = dateTimeZoneBuilder29.toDateTimeZone("4:00:00 PM", true);
        java.lang.String str33 = dateTimeZone32.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance(chronology8, dateTimeZone32);
        long long37 = dateTimeZone32.convertLocalToUTC((long) (short) 0, true);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DateTimeField[monthOfYear]" + "'", str22.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2678399999L + "'", long24 == 2678399999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "4:00:00 PM" + "'", str33.equals("4:00:00 PM"));
        org.junit.Assert.assertNotNull(zonedChronology34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.era();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfDay();
        try {
            long long9 = gregorianChronology1.getDateTimeMillis(768, 1971, (int) (short) -1, (-63));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -63 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("Coordinated Universal Time", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover(1, 'a', 1971, (int) (short) 10, 3, false, 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addCutover((int) (byte) -1, '4', (int) '4', (int) 'a', 10, false, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        long long28 = remainderDateTimeField25.roundHalfCeiling(0L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.util.Locale locale31 = dateTimeFormatter30.getLocale();
//        org.joda.time.format.DateTimePrinter dateTimePrinter32 = dateTimeFormatter30.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder29.append(dateTimePrinter32);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder33.appendYearOfEra((int) (byte) 10, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder37.appendHourOfHalfday(97);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder39.appendMinuteOfHour(1971);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendYear(86399999, 1971);
//        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField47 = gJChronology46.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField47, dateTimeFieldType48);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField50 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology45, dateTimeField47);
//        int int51 = skipDateTimeField50.getMinimumValue();
//        int int52 = skipDateTimeField50.getMinimumValue();
//        boolean boolean53 = skipDateTimeField50.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField55 = gJChronology54.dayOfYear();
//        org.joda.time.Instant instant56 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField59 = gJChronology58.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime60 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology58);
//        org.joda.time.MutableDateTime.Property property61 = mutableDateTime60.minuteOfDay();
//        int int62 = property61.get();
//        org.joda.time.MutableDateTime mutableDateTime64 = property61.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType65 = property61.getFieldType();
//        int int66 = instant56.get(dateTimeFieldType65);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, dateTimeFieldType65, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField50, dateTimeFieldType65, 2);
//        int int71 = remainderDateTimeField70.getMinimumValue();
//        long long73 = remainderDateTimeField70.roundHalfCeiling(2649599999L);
//        org.joda.time.chrono.GJChronology gJChronology74 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField75 = gJChronology74.dayOfYear();
//        org.joda.time.Instant instant76 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology78 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField79 = gJChronology78.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime80 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology78);
//        org.joda.time.MutableDateTime.Property property81 = mutableDateTime80.minuteOfDay();
//        int int82 = property81.get();
//        org.joda.time.MutableDateTime mutableDateTime84 = property81.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType85 = property81.getFieldType();
//        int int86 = instant76.get(dateTimeFieldType85);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField88 = new org.joda.time.field.OffsetDateTimeField(dateTimeField75, dateTimeFieldType85, 7);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField89 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField70, dateTimeFieldType85);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder92 = dateTimeFormatterBuilder41.appendDecimal(dateTimeFieldType85, 960, 86399999);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField93 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType85);
//        int int94 = remainderDateTimeField25.getMinimumValue();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 768 + "'", int21 == 768);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNull(locale31);
//        org.junit.Assert.assertNotNull(dateTimePrinter32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(gJChronology45);
//        org.junit.Assert.assertNotNull(gJChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(gJChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(instant56);
//        org.junit.Assert.assertNotNull(gJChronology58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime64);
//        org.junit.Assert.assertNotNull(dateTimeFieldType65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 768 + "'", int66 == 768);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 2678400000L + "'", long73 == 2678400000L);
//        org.junit.Assert.assertNotNull(gJChronology74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(instant76);
//        org.junit.Assert.assertNotNull(gJChronology78);
//        org.junit.Assert.assertNotNull(dateTimeField79);
//        org.junit.Assert.assertNotNull(property81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime84);
//        org.junit.Assert.assertNotNull(dateTimeFieldType85);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 768 + "'", int86 == 768);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder92);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("0", "GregorianChronology[UTC]");
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("monthOfYear");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: monthOfYear");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        long long7 = julianChronology1.getDateTimeMillis((long) (-63), 5, 6, 9, (int) (byte) 10);
        org.joda.time.DurationField durationField8 = julianChronology1.halfdays();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-68030990L) + "'", long7 == (-68030990L));
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("", "hi!");
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException7);
        java.lang.Number number9 = illegalFieldValueException7.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException7.getDurationFieldType();
        java.lang.String str11 = illegalFieldValueException7.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = illegalFieldValueException7.getDateTimeFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.String str14 = illegalFieldValueException2.toString();
        java.lang.String str15 = illegalFieldValueException2.getIllegalValueAsString();
        illegalFieldValueException2.prependMessage("1970");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported" + "'", str14.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) ' ', 5097600100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5097600068L) + "'", long2 == (-5097600068L));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime1.minus(readablePeriod7);
        try {
            org.joda.time.DateTime dateTime10 = dateTime1.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        mutableDateTime8.addWeeks((int) 'a');
        int int11 = property4.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime8.yearOfEra();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime8.hourOfDay();
        java.lang.String str14 = property13.toString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[hourOfDay]" + "'", str14.equals("Property[hourOfDay]"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DurationField durationField3 = gregorianChronology1.millis();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        int int5 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2000 + "'", int5 == 2000);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = julianChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        try {
            long long11 = julianChronology1.getDateTimeMillis((int) (byte) -1, (int) (short) 100, 24, 768, 1, (int) (short) 1, 1971);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 768 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField17);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology15);
//        org.joda.time.DateTime.Property property22 = dateTime21.dayOfYear();
//        org.joda.time.TimeOfDay timeOfDay23 = dateTime21.toTimeOfDay();
//        int int24 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay23);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27, dateTimeFieldType28);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.DateTime.Property property32 = dateTime31.dayOfYear();
//        org.joda.time.TimeOfDay timeOfDay33 = dateTime31.toTimeOfDay();
//        int int34 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay33);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 768 + "'", int12 == 768);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(timeOfDay23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(timeOfDay33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 373 + "'", int34 == 373);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfCeiling();
        mutableDateTime5.addMinutes(100);
        int int8 = mutableDateTime5.getEra();
        int int9 = mutableDateTime5.getDayOfWeek();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = julianChronology7.withUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(2, (int) (short) 10, 12, 0, (int) (short) 1, 4, dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.monthOfYear();
        long long17 = gJChronology12.add((long) (byte) 1, 2649599999L, (int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.Chronology chronology20 = julianChronology19.withUTC();
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology19.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.Chronology chronology23 = gJChronology12.withZone(dateTimeZone21);
        try {
            org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((java.lang.Object) iSOChronology11, (org.joda.time.Chronology) gJChronology12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 26495999991L + "'", long17 == 26495999991L);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(chronology23);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        long long28 = remainderDateTimeField25.roundHalfCeiling(0L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.util.Locale locale31 = dateTimeFormatter30.getLocale();
//        org.joda.time.format.DateTimePrinter dateTimePrinter32 = dateTimeFormatter30.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder29.append(dateTimePrinter32);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder33.appendYearOfEra((int) (byte) 10, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder37.appendHourOfHalfday(97);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder39.appendMinuteOfHour(1971);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendYear(86399999, 1971);
//        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField47 = gJChronology46.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField47, dateTimeFieldType48);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField50 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology45, dateTimeField47);
//        int int51 = skipDateTimeField50.getMinimumValue();
//        int int52 = skipDateTimeField50.getMinimumValue();
//        boolean boolean53 = skipDateTimeField50.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField55 = gJChronology54.dayOfYear();
//        org.joda.time.Instant instant56 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField59 = gJChronology58.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime60 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology58);
//        org.joda.time.MutableDateTime.Property property61 = mutableDateTime60.minuteOfDay();
//        int int62 = property61.get();
//        org.joda.time.MutableDateTime mutableDateTime64 = property61.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType65 = property61.getFieldType();
//        int int66 = instant56.get(dateTimeFieldType65);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, dateTimeFieldType65, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField50, dateTimeFieldType65, 2);
//        int int71 = remainderDateTimeField70.getMinimumValue();
//        long long73 = remainderDateTimeField70.roundHalfCeiling(2649599999L);
//        org.joda.time.chrono.GJChronology gJChronology74 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField75 = gJChronology74.dayOfYear();
//        org.joda.time.Instant instant76 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology78 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField79 = gJChronology78.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime80 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology78);
//        org.joda.time.MutableDateTime.Property property81 = mutableDateTime80.minuteOfDay();
//        int int82 = property81.get();
//        org.joda.time.MutableDateTime mutableDateTime84 = property81.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType85 = property81.getFieldType();
//        int int86 = instant76.get(dateTimeFieldType85);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField88 = new org.joda.time.field.OffsetDateTimeField(dateTimeField75, dateTimeFieldType85, 7);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField89 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField70, dateTimeFieldType85);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder92 = dateTimeFormatterBuilder41.appendDecimal(dateTimeFieldType85, 960, 86399999);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField93 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType85);
//        try {
//            long long96 = remainderDateTimeField25.set((long) (short) 0, "Jan");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Jan\" for minuteOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 768 + "'", int21 == 768);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNull(locale31);
//        org.junit.Assert.assertNotNull(dateTimePrinter32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(gJChronology45);
//        org.junit.Assert.assertNotNull(gJChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(gJChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(instant56);
//        org.junit.Assert.assertNotNull(gJChronology58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime64);
//        org.junit.Assert.assertNotNull(dateTimeFieldType65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 768 + "'", int66 == 768);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 2678400000L + "'", long73 == 2678400000L);
//        org.junit.Assert.assertNotNull(gJChronology74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(instant76);
//        org.junit.Assert.assertNotNull(gJChronology78);
//        org.junit.Assert.assertNotNull(dateTimeField79);
//        org.junit.Assert.assertNotNull(property81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime84);
//        org.junit.Assert.assertNotNull(dateTimeFieldType85);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 768 + "'", int86 == 768);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder92);
//    }
//}

