import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1969-12-31T15:59:59");
        org.joda.time.DateTime.Property property2 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        long long16 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 72L + "'", long16 == 72L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int6 = skipDateTimeField5.getMinimumValue();
        int int7 = skipDateTimeField5.getMinimumValue();
        int int8 = skipDateTimeField5.getMaximumValue();
        boolean boolean9 = skipDateTimeField5.isSupported();
        org.joda.time.DurationField durationField10 = skipDateTimeField5.getDurationField();
        long long13 = durationField10.subtract(316800010L, 70000L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-184053023999990L) + "'", long13 == (-184053023999990L));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        int int5 = gregorianChronology1.getMinimumDaysInFirstWeek();
        java.lang.String str6 = gregorianChronology1.toString();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
        long long13 = delegatedDateTimeField10.add((long) 1, (long) 3);
        int int15 = delegatedDateTimeField10.getMaximumValue(58665600010L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField10, 10);
        try {
            long long20 = delegatedDateTimeField10.set((-2678399900L), 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7776000001L + "'", long13 == 7776000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(7, 3, 22, (int) (short) 1, 52, 9);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime();
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours(0);
        org.joda.time.DateTime.Property property16 = dateTime13.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
        java.util.Locale locale19 = null;
        org.joda.time.DateTime dateTime20 = property16.setCopy("1969", locale19);
        org.joda.time.DateTime.Property property21 = dateTime20.hourOfDay();
        org.joda.time.DateTime dateTime22 = property21.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendLiteral("GregorianChronology[UTC]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendDayOfYear(0);
        try {
            org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatterBuilder10.toParser();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("35");
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test010");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField17);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology15);
//        org.joda.time.DateTime.Property property22 = dateTime21.dayOfYear();
//        org.joda.time.TimeOfDay timeOfDay23 = dateTime21.toTimeOfDay();
//        int int24 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay23);
//        int int26 = offsetDateTimeField14.getLeapAmount(100L);
//        long long29 = offsetDateTimeField14.add(0L, (long) 1);
//        long long31 = offsetDateTimeField14.roundHalfCeiling((long) (-32));
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 768 + "'", int12 == 768);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(timeOfDay23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 86400000L + "'", long29 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test011");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28, dateTimeFieldType29);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
//        int int32 = skipDateTimeField31.getMinimumValue();
//        int int33 = skipDateTimeField31.getMinimumValue();
//        boolean boolean34 = skipDateTimeField31.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology35.dayOfYear();
//        org.joda.time.Instant instant37 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology39);
//        org.joda.time.MutableDateTime.Property property42 = mutableDateTime41.minuteOfDay();
//        int int43 = property42.get();
//        org.joda.time.MutableDateTime mutableDateTime45 = property42.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property42.getFieldType();
//        int int47 = instant37.get(dateTimeFieldType46);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, dateTimeFieldType46, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField51 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField31, dateTimeFieldType46, 2);
//        long long53 = remainderDateTimeField51.roundHalfCeiling(0L);
//        long long55 = remainderDateTimeField51.remainder((long) 1971);
//        int int58 = remainderDateTimeField51.getDifference(316800010L, (long) 12);
//        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField61 = gJChronology60.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime62 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology60);
//        org.joda.time.MutableDateTime.Property property63 = mutableDateTime62.minuteOfDay();
//        int int64 = property63.get();
//        org.joda.time.MutableDateTime mutableDateTime66 = property63.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property63.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField51, dateTimeFieldType67);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType67);
//        long long72 = dividedDateTimeField69.addWrapField(5097600000L, 52);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 768 + "'", int21 == 768);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(instant37);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 768 + "'", int47 == 768);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1971L + "'", long55 == 1971L);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(gJChronology60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime66);
//        org.junit.Assert.assertNotNull(dateTimeFieldType67);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 20995200000L + "'", long72 == 20995200000L);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(604800010L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 604800010 + "'", int1 == 604800010);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test014");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField14.getWrappedField();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.toDateTime(dateTimeZone18);
//        int int20 = dateTime17.getMillisOfDay();
//        org.joda.time.DateTime dateTime22 = dateTime17.plusHours((int) '4');
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime17.minus(readablePeriod23);
//        org.joda.time.DateTime.Property property25 = dateTime24.minuteOfHour();
//        org.joda.time.DurationField durationField26 = property25.getLeapDurationField();
//        org.joda.time.DateTime dateTime28 = property25.addToCopy((int) '4');
//        org.joda.time.DurationField durationField29 = property25.getDurationField();
//        org.joda.time.DateTime dateTime30 = property25.roundHalfEvenCopy();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (-1), dateTimeZone32);
//        int int34 = dateTime33.getMonthOfYear();
//        org.joda.time.YearMonthDay yearMonthDay35 = dateTime33.toYearMonthDay();
//        org.joda.time.DateTime dateTime36 = dateTime30.withFields((org.joda.time.ReadablePartial) yearMonthDay35);
//        int int37 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay35);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 768 + "'", int12 == 768);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 12 + "'", int34 == 12);
//        org.junit.Assert.assertNotNull(yearMonthDay35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 8 + "'", int37 == 8);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundHalfEven();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        int int5 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday(97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.appendTimeZoneOffset("millisOfDay", "1969-12-01T00:00:00.100Z", true, (int) '#', 97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale21 = dateTimeFormatter20.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter22 = dateTimeFormatter20.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder19.append(dateTimePrinter22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatter24.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter22, dateTimeParser25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder12.append(dateTimePrinter22);
        org.joda.time.format.DateTimeParser dateTimeParser28 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter22, dateTimeParser28);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNull(locale21);
        org.junit.Assert.assertNotNull(dateTimePrinter22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test018");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        long long28 = remainderDateTimeField25.roundHalfCeiling(2649599999L);
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.dayOfYear();
//        org.joda.time.Instant instant31 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology33);
//        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.minuteOfDay();
//        int int37 = property36.get();
//        org.joda.time.MutableDateTime mutableDateTime39 = property36.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property36.getFieldType();
//        int int41 = instant31.get(dateTimeFieldType40);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, dateTimeFieldType40, 7);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType40);
//        org.joda.time.DurationField durationField45 = dividedDateTimeField44.getDurationField();
//        long long48 = dividedDateTimeField44.add((long) 335, (long) '4');
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 768 + "'", int21 == 768);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2678400000L + "'", long28 == 2678400000L);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(instant31);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 768 + "'", int41 == 768);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 273456000335L + "'", long48 == 273456000335L);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(22, 57600072, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.era();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        java.lang.String str3 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test022");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.Chronology chronology3 = julianChronology2.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology2.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 10, (org.joda.time.Chronology) iSOChronology5);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.dayOfYear();
//        org.joda.time.Instant instant9 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology11);
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.minuteOfDay();
//        int int15 = property14.get();
//        org.joda.time.MutableDateTime mutableDateTime17 = property14.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property14.getFieldType();
//        int int19 = instant9.get(dateTimeFieldType18);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType18, 7);
//        org.joda.time.DateTimeField dateTimeField22 = offsetDateTimeField21.getWrappedField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology5, (org.joda.time.DateTimeField) offsetDateTimeField21);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25, dateTimeFieldType26);
//        long long30 = delegatedDateTimeField27.add((long) 1, (long) 3);
//        long long32 = delegatedDateTimeField27.roundHalfFloor((long) 3);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField27.getType();
//        long long35 = delegatedDateTimeField27.roundCeiling(0L);
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.dayOfYear();
//        org.joda.time.Instant instant38 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology40);
//        org.joda.time.MutableDateTime.Property property43 = mutableDateTime42.minuteOfDay();
//        int int44 = property43.get();
//        org.joda.time.MutableDateTime mutableDateTime46 = property43.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
//        int int48 = instant38.get(dateTimeFieldType47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, dateTimeFieldType47, 7);
//        org.joda.time.DateTimeField dateTimeField51 = offsetDateTimeField50.getWrappedField();
//        long long53 = offsetDateTimeField50.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.DateTime dateTime57 = dateTime55.toDateTime(dateTimeZone56);
//        int int58 = dateTime55.getMillisOfDay();
//        org.joda.time.DateTime dateTime60 = dateTime55.plusHours((int) '4');
//        org.joda.time.DateTime dateTime62 = dateTime60.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime64 = dateTime62.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay65 = dateTime64.toYearMonthDay();
//        int[] intArray71 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray73 = offsetDateTimeField50.addWrapField((org.joda.time.ReadablePartial) yearMonthDay65, (int) (byte) 0, intArray71, 4);
//        java.util.Locale locale74 = null;
//        java.lang.String str75 = delegatedDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay65, locale74);
//        int[] intArray79 = new int[] { 59, 373, (short) 10 };
//        int int80 = offsetDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay65, intArray79);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(instant9);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 768 + "'", int19 == 768);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 7776000001L + "'", long30 == 7776000001L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(instant38);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime46);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 768 + "'", int48 == 768);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 2678400000L + "'", long53 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 10 + "'", int58 == 10);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(yearMonthDay65);
//        org.junit.Assert.assertNotNull(intArray71);
//        org.junit.Assert.assertNotNull(intArray73);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "Jan" + "'", str75.equals("Jan"));
//        org.junit.Assert.assertNotNull(intArray79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 8 + "'", int80 == 8);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test023");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField14.getWrappedField();
//        java.lang.String str17 = offsetDateTimeField14.getAsShortText((-2649600000L));
//        long long20 = offsetDateTimeField14.set((-62L), 24);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 768 + "'", int12 == 768);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "342" + "'", str17.equals("342"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-30067200062L) + "'", long20 == (-30067200062L));
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("+06:00");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfDay(335, 9);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfCeiling();
        mutableDateTime5.addMinutes(100);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.addWrapField(59);
        mutableDateTime10.setMillisOfSecond(20);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("342", (-2), 8, (-2));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2 for 342 must be in the range [8,-2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(22, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 2000");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday(97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfSecond((int) '4', 86399);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(322);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime6.plusYears(767);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(100);
        org.joda.time.DateTime.Property property13 = dateTime10.dayOfWeek();
        org.joda.time.DateTime dateTime15 = dateTime10.plus((long) 960);
        int int16 = dateTime15.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test031");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
//        mutableDateTime3.addWeeks((int) 'a');
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        mutableDateTime3.add(readableDuration6);
//        mutableDateTime3.setDate((long) (-1));
//        mutableDateTime3.addMinutes(24);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.toDateTime(dateTimeZone14);
//        org.joda.time.DateTime.Property property16 = dateTime15.millisOfDay();
//        org.joda.time.DateTime.Property property17 = dateTime15.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getShortName((long) (short) 0, locale20);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone18);
//        java.lang.String str24 = dateTimeZone18.getName(58665600010L);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone18.getName(2678399999L, locale26);
//        org.joda.time.DateTime dateTime28 = dateTime15.withZoneRetainFields(dateTimeZone18);
//        mutableDateTime3.setZoneRetainFields(dateTimeZone18);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UTC" + "'", str21.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Coordinated Universal Time" + "'", str24.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordinated Universal Time" + "'", str27.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 2);
        org.joda.time.Instant instant3 = instant1.withMillis((long) 0);
        org.joda.time.Chronology chronology4 = instant1.getChronology();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = julianChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTime(dateTimeZone8);
        int int10 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant13 = dateTime12.toInstant();
        boolean boolean14 = dateTime7.isEqual((org.joda.time.ReadableInstant) instant13);
        long long15 = instant13.getMillis();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.MutableDateTime mutableDateTime17 = instant13.toMutableDateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = instant13.toDateTimeISO();
        boolean boolean19 = buddhistChronology5.equals((java.lang.Object) dateTime18);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology5.weekyear();
        org.joda.time.Chronology chronology21 = buddhistChronology5.withUTC();
        try {
            long long29 = buddhistChronology5.getDateTimeMillis(3, 322, 10, 6, 4, 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 322 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(chronology21);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test034");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
//        int int4 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
//        org.joda.time.DateTime dateTime14 = dateTime9.withMillis((-2678399900L));
//        org.joda.time.DateTime dateTime16 = dateTime14.plusMonths(6);
//        org.joda.time.DateTime dateTime18 = dateTime14.minusDays((int) ' ');
//        org.joda.time.YearMonthDay yearMonthDay19 = dateTime14.toYearMonthDay();
//        org.joda.time.DateTime dateTime21 = dateTime14.plusSeconds(10);
//        org.joda.time.DateTime.Property property22 = dateTime21.minuteOfHour();
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider24 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone26);
//        java.util.Set<java.lang.String> strSet28 = org.joda.time.DateTimeZone.getAvailableIDs();
//        boolean boolean29 = julianChronology27.equals((java.lang.Object) strSet28);
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket(58665600020L, (org.joda.time.Chronology) julianChronology27, locale30, (java.lang.Integer) 72, 0);
//        long long34 = dateTimeParserBucket33.computeMillis();
//        java.util.Locale locale35 = dateTimeParserBucket33.getLocale();
//        java.lang.String str38 = defaultNameProvider24.getName(locale35, "8", "1970-01-01T16:00:00.072Z");
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology40);
//        mutableDateTime42.addWeeks((int) 'a');
//        org.joda.time.ReadableDuration readableDuration45 = null;
//        mutableDateTime42.add(readableDuration45);
//        mutableDateTime42.setDate((long) 3);
//        org.joda.time.ReadablePeriod readablePeriod49 = null;
//        mutableDateTime42.add(readablePeriod49);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime(100L, dateTimeZone52);
//        mutableDateTime53.setWeekyear((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale58 = null;
//        java.lang.String str59 = dateTimeZone56.getShortName((long) (short) 0, locale58);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now(dateTimeZone56);
//        mutableDateTime53.setZoneRetainFields(dateTimeZone56);
//        mutableDateTime42.setZone(dateTimeZone56);
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider64 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone dateTimeZone66 = null;
//        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone66);
//        java.util.Set<java.lang.String> strSet68 = org.joda.time.DateTimeZone.getAvailableIDs();
//        boolean boolean69 = julianChronology67.equals((java.lang.Object) strSet68);
//        java.util.Locale locale70 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket73 = new org.joda.time.format.DateTimeParserBucket(58665600020L, (org.joda.time.Chronology) julianChronology67, locale70, (java.lang.Integer) 72, 0);
//        long long74 = dateTimeParserBucket73.computeMillis();
//        java.util.Locale locale75 = dateTimeParserBucket73.getLocale();
//        java.lang.String str78 = defaultNameProvider64.getName(locale75, "8", "1970-01-01T16:00:00.072Z");
//        java.lang.String str79 = dateTimeZone56.getShortName((long) (byte) 100, locale75);
//        java.lang.String str82 = defaultNameProvider24.getShortName(locale75, "hi!", "960");
//        try {
//            org.joda.time.DateTime dateTime83 = property22.setCopy("Jun", locale75);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Jun\" for minuteOfHour is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(yearMonthDay19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(strSet28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 58665600020L + "'", long34 == 58665600020L);
//        org.junit.Assert.assertNotNull(locale35);
//        org.junit.Assert.assertNull(str38);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "UTC" + "'", str59.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(julianChronology67);
//        org.junit.Assert.assertNotNull(strSet68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 58665600020L + "'", long74 == 58665600020L);
//        org.junit.Assert.assertNotNull(locale75);
//        org.junit.Assert.assertNull(str78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "UTC" + "'", str79.equals("UTC"));
//        org.junit.Assert.assertNull(str82);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant2 = dateTime1.toInstant();
        org.joda.time.Instant instant4 = instant2.minus((long) 100);
        org.joda.time.MutableDateTime mutableDateTime5 = instant2.toMutableDateTimeISO();
        org.joda.time.Instant instant6 = instant2.toInstant();
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.field.FieldUtils.verifyValueBounds("October", 373, (-11), 1970);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test037");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        long long28 = remainderDateTimeField25.roundHalfCeiling(2649599999L);
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.dayOfYear();
//        org.joda.time.Instant instant31 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology33);
//        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.minuteOfDay();
//        int int37 = property36.get();
//        org.joda.time.MutableDateTime mutableDateTime39 = property36.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property36.getFieldType();
//        int int41 = instant31.get(dateTimeFieldType40);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, dateTimeFieldType40, 7);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType40);
//        org.joda.time.DurationField durationField45 = dividedDateTimeField44.getDurationField();
//        org.joda.time.DurationField durationField46 = dividedDateTimeField44.getDurationField();
//        org.joda.time.DurationFieldType durationFieldType47 = null;
//        try {
//            org.joda.time.field.DecoratedDurationField decoratedDurationField48 = new org.joda.time.field.DecoratedDurationField(durationField46, durationFieldType47);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 768 + "'", int21 == 768);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2678400000L + "'", long28 == 2678400000L);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(instant31);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 768 + "'", int41 == 768);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(durationField46);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str2 = gregorianChronology0.toString();
        java.lang.String str3 = gregorianChronology0.toString();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test039");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        long long6 = delegatedDateTimeField3.add((long) 1, (long) 3);
//        long long9 = delegatedDateTimeField3.add((long) (byte) 100, (int) (short) -1);
//        int int11 = delegatedDateTimeField3.getLeapAmount(0L);
//        org.joda.time.DurationField durationField12 = delegatedDateTimeField3.getLeapDurationField();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
//        org.joda.time.TimeOfDay timeOfDay16 = dateTime15.toTimeOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.halfdayOfDay();
//        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology18);
//        org.joda.time.Chronology chronology22 = gJChronology18.withUTC();
//        org.joda.time.DurationField durationField23 = gJChronology18.weeks();
//        org.joda.time.DurationField durationField24 = gJChronology18.days();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime25.plus(readablePeriod26);
//        org.joda.time.MutableDateTime mutableDateTime28 = dateTime25.toMutableDateTime();
//        org.joda.time.YearMonthDay yearMonthDay29 = dateTime25.toYearMonthDay();
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField31 = gJChronology30.dayOfYear();
//        org.joda.time.Instant instant32 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = gJChronology34.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology34);
//        org.joda.time.MutableDateTime.Property property37 = mutableDateTime36.minuteOfDay();
//        int int38 = property37.get();
//        org.joda.time.MutableDateTime mutableDateTime40 = property37.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property37.getFieldType();
//        int int42 = instant32.get(dateTimeFieldType41);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, dateTimeFieldType41, 7);
//        org.joda.time.DateTimeField dateTimeField45 = offsetDateTimeField44.getWrappedField();
//        long long47 = offsetDateTimeField44.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.DateTime dateTime51 = dateTime49.toDateTime(dateTimeZone50);
//        int int52 = dateTime49.getMillisOfDay();
//        org.joda.time.DateTime dateTime54 = dateTime49.plusHours((int) '4');
//        org.joda.time.DateTime dateTime56 = dateTime54.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime58 = dateTime56.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay59 = dateTime58.toYearMonthDay();
//        int[] intArray65 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray67 = offsetDateTimeField44.addWrapField((org.joda.time.ReadablePartial) yearMonthDay59, (int) (byte) 0, intArray65, 4);
//        gJChronology18.validate((org.joda.time.ReadablePartial) yearMonthDay29, intArray65);
//        try {
//            int[] intArray70 = delegatedDateTimeField3.add((org.joda.time.ReadablePartial) timeOfDay16, (int) '4', intArray65, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 39 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7776000001L + "'", long6 == 7776000001L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2678399900L) + "'", long9 == (-2678399900L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(timeOfDay16);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertNotNull(yearMonthDay29);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(instant32);
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime40);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 768 + "'", int42 == 768);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2678400000L + "'", long47 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(yearMonthDay59);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertNotNull(intArray67);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime6.plusYears(767);
        org.joda.time.DateTime dateTime12 = dateTime10.plusDays(322);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.util.Collection<org.joda.time.DateTimeFieldType> dateTimeFieldTypeCollection0 = null;
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.forFields(dateTimeFieldTypeCollection0, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 57600010);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.hourOfDay();
        mutableDateTime1.addYears(1970);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        java.util.Set<java.lang.String> strSet3 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean4 = julianChronology2.equals((java.lang.Object) strSet3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket(58665600020L, (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) 72, 0);
        long long9 = dateTimeParserBucket8.computeMillis();
        java.util.Locale locale10 = dateTimeParserBucket8.getLocale();
        long long12 = dateTimeParserBucket8.computeMillis(false);
        dateTimeParserBucket8.setOffset((java.lang.Integer) 4);
        org.joda.time.DateTimeZone dateTimeZone15 = dateTimeParserBucket8.getZone();
        int int16 = dateTimeParserBucket8.getOffset();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 58665600020L + "'", long9 == 58665600020L);
        org.junit.Assert.assertNotNull(locale10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 58665600020L + "'", long12 == 58665600020L);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test044");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (short) -1);
//        java.lang.String str10 = dateTimeFormatter7.print((org.joda.time.ReadableInstant) mutableDateTime9);
//        int int11 = mutableDateTime9.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getShortName((long) (short) 0, locale14);
//        mutableDateTime9.setZoneRetainFields(dateTimeZone12);
//        long long18 = dateTimeZone12.convertUTCToLocal(86400000L);
//        java.lang.String str20 = dateTimeZone12.getShortName(26323200010L);
//        try {
//            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(280, 0, 1971, (int) 'a', 0, 8, (int) (short) 1, dateTimeZone12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969-12-31T23:59:59" + "'", str10.equals("1969-12-31T23:59:59"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 86400000L + "'", long18 == 86400000L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField4 = gJChronology1.eras();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology1.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test046");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        boolean boolean26 = skipDateTimeField5.isLenient();
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider27 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
//        java.util.Set<java.lang.String> strSet31 = org.joda.time.DateTimeZone.getAvailableIDs();
//        boolean boolean32 = julianChronology30.equals((java.lang.Object) strSet31);
//        java.util.Locale locale33 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket36 = new org.joda.time.format.DateTimeParserBucket(58665600020L, (org.joda.time.Chronology) julianChronology30, locale33, (java.lang.Integer) 72, 0);
//        long long37 = dateTimeParserBucket36.computeMillis();
//        java.util.Locale locale38 = dateTimeParserBucket36.getLocale();
//        java.lang.String str41 = defaultNameProvider27.getName(locale38, "8", "1970-01-01T16:00:00.072Z");
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider42 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.chrono.JulianChronology julianChronology45 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone44);
//        java.util.Set<java.lang.String> strSet46 = org.joda.time.DateTimeZone.getAvailableIDs();
//        boolean boolean47 = julianChronology45.equals((java.lang.Object) strSet46);
//        java.util.Locale locale48 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket51 = new org.joda.time.format.DateTimeParserBucket(58665600020L, (org.joda.time.Chronology) julianChronology45, locale48, (java.lang.Integer) 72, 0);
//        long long52 = dateTimeParserBucket51.computeMillis();
//        java.util.Locale locale53 = dateTimeParserBucket51.getLocale();
//        java.lang.String str56 = defaultNameProvider42.getName(locale53, "8", "1970-01-01T16:00:00.072Z");
//        java.lang.String str59 = defaultNameProvider27.getName(locale53, "GregorianChronology[UTC]", "1969-12-31T15:59:59.999-08:00");
//        int int60 = skipDateTimeField5.getMaximumShortTextLength(locale53);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 768 + "'", int21 == 768);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(julianChronology30);
//        org.junit.Assert.assertNotNull(strSet31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 58665600020L + "'", long37 == 58665600020L);
//        org.junit.Assert.assertNotNull(locale38);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertNotNull(julianChronology45);
//        org.junit.Assert.assertNotNull(strSet46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 58665600020L + "'", long52 == 58665600020L);
//        org.junit.Assert.assertNotNull(locale53);
//        org.junit.Assert.assertNull(str56);
//        org.junit.Assert.assertNull(str59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        int int5 = gregorianChronology1.getMinimumDaysInFirstWeek();
        java.lang.String str6 = gregorianChronology1.toString();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
        long long13 = delegatedDateTimeField10.add((long) 1, (long) 3);
        int int15 = delegatedDateTimeField10.getMaximumValue(58665600010L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField10, 10);
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology1.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7776000001L + "'", long13 == 7776000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test048");
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        java.util.Set<java.lang.String> strSet4 = org.joda.time.DateTimeZone.getAvailableIDs();
//        boolean boolean5 = julianChronology3.equals((java.lang.Object) strSet4);
//        java.util.Locale locale6 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket(58665600020L, (org.joda.time.Chronology) julianChronology3, locale6, (java.lang.Integer) 72, 0);
//        long long10 = dateTimeParserBucket9.computeMillis();
//        java.util.Locale locale11 = dateTimeParserBucket9.getLocale();
//        java.lang.String str14 = defaultNameProvider0.getName(locale11, "8", "1970-01-01T16:00:00.072Z");
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.dayOfYear();
//        org.joda.time.Instant instant17 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology19);
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.minuteOfDay();
//        int int23 = property22.get();
//        org.joda.time.MutableDateTime mutableDateTime25 = property22.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        int int27 = instant17.get(dateTimeFieldType26);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, dateTimeFieldType26, 7);
//        org.joda.time.DateTimeField dateTimeField30 = offsetDateTimeField29.getWrappedField();
//        long long33 = offsetDateTimeField29.add((long) 57600010, (long) 3);
//        int int35 = offsetDateTimeField29.getMaximumValue(316800010L);
//        long long37 = offsetDateTimeField29.roundCeiling((long) 767);
//        java.lang.String str38 = offsetDateTimeField29.toString();
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.DateTime dateTime42 = dateTime40.toDateTime(dateTimeZone41);
//        int int43 = dateTime40.getMillisOfDay();
//        org.joda.time.DateTime dateTime45 = dateTime40.plusHours((int) '4');
//        org.joda.time.ReadablePeriod readablePeriod46 = null;
//        org.joda.time.DateTime dateTime47 = dateTime40.minus(readablePeriod46);
//        org.joda.time.DateTime.Property property48 = dateTime47.minuteOfHour();
//        org.joda.time.DurationField durationField49 = property48.getLeapDurationField();
//        org.joda.time.DateTime dateTime51 = property48.addToCopy((int) '4');
//        org.joda.time.DurationField durationField52 = property48.getDurationField();
//        org.joda.time.DateTime dateTime53 = property48.roundHalfEvenCopy();
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) (-1), dateTimeZone55);
//        int int57 = dateTime56.getMonthOfYear();
//        org.joda.time.YearMonthDay yearMonthDay58 = dateTime56.toYearMonthDay();
//        org.joda.time.DateTime dateTime59 = dateTime53.withFields((org.joda.time.ReadablePartial) yearMonthDay58);
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.chrono.JulianChronology julianChronology63 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone62);
//        java.util.Set<java.lang.String> strSet64 = org.joda.time.DateTimeZone.getAvailableIDs();
//        boolean boolean65 = julianChronology63.equals((java.lang.Object) strSet64);
//        java.util.Locale locale66 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket69 = new org.joda.time.format.DateTimeParserBucket(58665600020L, (org.joda.time.Chronology) julianChronology63, locale66, (java.lang.Integer) 72, 0);
//        long long70 = dateTimeParserBucket69.computeMillis();
//        java.util.Locale locale71 = dateTimeParserBucket69.getLocale();
//        java.lang.String str72 = offsetDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay58, 57600010, locale71);
//        java.lang.String str75 = defaultNameProvider0.getName(locale71, "1970", "Jan 3, 1970");
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(strSet4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 58665600020L + "'", long10 == 58665600020L);
//        org.junit.Assert.assertNotNull(locale11);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(instant17);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 768 + "'", int27 == 768);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 316800010L + "'", long33 == 316800010L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 373 + "'", int35 == 373);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 86400000L + "'", long37 == 86400000L);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "DateTimeField[minuteOfDay]" + "'", str38.equals("DateTimeField[minuteOfDay]"));
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNull(durationField49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 12 + "'", int57 == 12);
//        org.junit.Assert.assertNotNull(yearMonthDay58);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(julianChronology63);
//        org.junit.Assert.assertNotNull(strSet64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 58665600020L + "'", long70 == 58665600020L);
//        org.junit.Assert.assertNotNull(locale71);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "57600010" + "'", str72.equals("57600010"));
//        org.junit.Assert.assertNull(str75);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test049");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(100L, dateTimeZone1);
//        mutableDateTime2.addYears(0);
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime2);
//        mutableDateTime2.setWeekyear((int) '#');
//        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (short) -1);
//        java.lang.String str10 = mutableDateTime9.toString();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        mutableDateTime9.set(dateTimeFieldType20, (int) '#');
//        int int24 = mutableDateTime2.get(dateTimeFieldType20);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969-12-31T23:59:59.999Z" + "'", str10.equals("1969-12-31T23:59:59.999Z"));
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 768 + "'", int21 == 768);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.DateTime dateTime6 = instant5.toDateTimeISO();
        org.joda.time.Instant instant8 = instant5.withMillis((long) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.secondOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime8 = dateTime3.withYearOfCentury((int) 'a');
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology5 = iSOChronology4.withUTC();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology6.yearOfEra();
        org.joda.time.DurationField durationField13 = gJChronology6.days();
        boolean boolean14 = iSOChronology4.equals((java.lang.Object) durationField13);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.monthOfYear();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology15.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.halfdayOfDay();
        boolean boolean19 = iSOChronology4.equals((java.lang.Object) dateTimeField18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology4.era();
        org.joda.time.DurationField durationField21 = iSOChronology4.seconds();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        boolean boolean11 = dateTime9.isAfter((long) 62);
        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(97);
        org.joda.time.DateTime dateTime15 = dateTime13.minusWeeks((int) (byte) 1);
        org.joda.time.DateTime.Property property16 = dateTime13.weekyear();
        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
        org.joda.time.DateTime.Property property18 = dateTime17.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = gregorianChronology20.minutes();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology20.getZone();
        int int24 = gregorianChronology20.getMinimumDaysInFirstWeek();
        java.lang.String str25 = gregorianChronology20.toString();
        org.joda.time.DateTime dateTime26 = dateTime17.toDateTime((org.joda.time.Chronology) gregorianChronology20);
        boolean boolean27 = dateTime26.isEqualNow();
        org.joda.time.DateTime dateTime29 = dateTime26.minus((long) 373);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "GregorianChronology[UTC]" + "'", str25.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test055");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField17);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology15);
//        org.joda.time.DateTime.Property property22 = dateTime21.dayOfYear();
//        org.joda.time.TimeOfDay timeOfDay23 = dateTime21.toTimeOfDay();
//        int int24 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay23);
//        boolean boolean25 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay23);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 768 + "'", int12 == 768);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(timeOfDay23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = julianChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTime(dateTimeZone8);
        int int10 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant13 = dateTime12.toInstant();
        boolean boolean14 = dateTime7.isEqual((org.joda.time.ReadableInstant) instant13);
        long long15 = instant13.getMillis();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.MutableDateTime mutableDateTime17 = instant13.toMutableDateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = instant13.toDateTimeISO();
        boolean boolean19 = buddhistChronology5.equals((java.lang.Object) dateTime18);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.Chronology chronology21 = buddhistChronology5.withZone(dateTimeZone20);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime3.getDayOfWeek();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMinutes((int) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime3.minusDays(960);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology11 = julianChronology10.withUTC();
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology15);
        mutableDateTime17.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration20 = null;
        mutableDateTime17.add(readableDuration20);
        long long22 = mutableDateTime17.getMillis();
        org.joda.time.MutableDateTime mutableDateTime23 = mutableDateTime17.copy();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = mutableDateTime17.toDateTime(dateTimeZone24);
        mutableDateTime13.setDate((org.joda.time.ReadableInstant) mutableDateTime17);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime13.yearOfCentury();
        boolean boolean28 = julianChronology10.equals((java.lang.Object) property27);
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology10);
        org.joda.time.DateTime dateTime30 = dateTime8.withChronology((org.joda.time.Chronology) julianChronology10);
        org.joda.time.DateTime dateTime32 = dateTime30.plusSeconds(6);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 58665600010L + "'", long22 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test058");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28, dateTimeFieldType29);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
//        int int32 = skipDateTimeField31.getMinimumValue();
//        int int33 = skipDateTimeField31.getMinimumValue();
//        boolean boolean34 = skipDateTimeField31.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology35.dayOfYear();
//        org.joda.time.Instant instant37 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology39);
//        org.joda.time.MutableDateTime.Property property42 = mutableDateTime41.minuteOfDay();
//        int int43 = property42.get();
//        org.joda.time.MutableDateTime mutableDateTime45 = property42.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property42.getFieldType();
//        int int47 = instant37.get(dateTimeFieldType46);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, dateTimeFieldType46, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField51 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField31, dateTimeFieldType46, 2);
//        long long53 = remainderDateTimeField51.roundHalfCeiling(0L);
//        long long55 = remainderDateTimeField51.remainder((long) 1971);
//        int int58 = remainderDateTimeField51.getDifference(316800010L, (long) 12);
//        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField61 = gJChronology60.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime62 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology60);
//        org.joda.time.MutableDateTime.Property property63 = mutableDateTime62.minuteOfDay();
//        int int64 = property63.get();
//        org.joda.time.MutableDateTime mutableDateTime66 = property63.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property63.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField51, dateTimeFieldType67);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType67);
//        long long72 = dividedDateTimeField69.getDifferenceAsLong((long) 22, 0L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 768 + "'", int21 == 768);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(instant37);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 768 + "'", int47 == 768);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1971L + "'", long55 == 1971L);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(gJChronology60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime66);
//        org.junit.Assert.assertNotNull(dateTimeFieldType67);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology5 = iSOChronology4.withUTC();
        org.joda.time.DurationField durationField6 = iSOChronology4.minutes();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "DateTimeField[minuteOfDay]", (int) (short) 1, 0);
        long long6 = fixedDateTimeZone4.previousTransition((-2678399900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyearOfCentury();
        boolean boolean9 = fixedDateTimeZone4.equals((java.lang.Object) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.weekyear();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2678399900L) + "'", long6 == (-2678399900L));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfDay();
        try {
            long long10 = gregorianChronology1.getDateTimeMillis((int) (byte) -1, (int) '4', (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology3);
        mutableDateTime5.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration8 = null;
        mutableDateTime5.add(readableDuration8);
        long long10 = mutableDateTime5.getMillis();
        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime5.copy();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = mutableDateTime5.toDateTime(dateTimeZone12);
        mutableDateTime1.setDate((org.joda.time.ReadableInstant) mutableDateTime5);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime1.yearOfCentury();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime1.dayOfWeek();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology18);
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.minuteOfDay();
        int int22 = property21.get();
        org.joda.time.MutableDateTime mutableDateTime24 = property21.add(2440588L);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property21.getFieldType();
        org.joda.time.MutableDateTime mutableDateTime26 = property21.roundHalfCeiling();
        int int27 = property16.compareTo((org.joda.time.ReadableInstant) mutableDateTime26);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        java.util.Set<java.lang.String> strSet31 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean32 = julianChronology30.equals((java.lang.Object) strSet31);
        java.util.Locale locale33 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket36 = new org.joda.time.format.DateTimeParserBucket(58665600020L, (org.joda.time.Chronology) julianChronology30, locale33, (java.lang.Integer) 72, 0);
        long long37 = dateTimeParserBucket36.computeMillis();
        java.util.Locale locale38 = dateTimeParserBucket36.getLocale();
        org.joda.time.Chronology chronology39 = dateTimeParserBucket36.getChronology();
        mutableDateTime26.setChronology(chronology39);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 58665600010L + "'", long10 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(strSet31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 58665600020L + "'", long37 == 58665600020L);
        org.junit.Assert.assertNotNull(locale38);
        org.junit.Assert.assertNotNull(chronology39);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        java.util.Set<java.lang.String> strSet3 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean4 = julianChronology2.equals((java.lang.Object) strSet3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket(58665600020L, (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) 72, 0);
        long long9 = dateTimeParserBucket8.computeMillis();
        java.util.Locale locale10 = dateTimeParserBucket8.getLocale();
        long long12 = dateTimeParserBucket8.computeMillis(false);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology14);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
        long long23 = delegatedDateTimeField20.add((long) 1, (long) 3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, (org.joda.time.DateTimeField) delegatedDateTimeField20, (int) (short) -1);
        org.joda.time.DateTimeField dateTimeField26 = delegatedDateTimeField20.getWrappedField();
        boolean boolean27 = delegatedDateTimeField20.isLenient();
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology29);
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime31.minuteOfDay();
        int int33 = property32.get();
        org.joda.time.MutableDateTime mutableDateTime35 = property32.add(2440588L);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property32.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField20, dateTimeFieldType36, (int) (short) 100, 960, 24);
        java.util.Locale locale42 = null;
        dateTimeParserBucket8.saveField(dateTimeFieldType36, "1970001T000000.100Z", locale42);
        try {
            long long45 = dateTimeParserBucket8.computeMillis(true);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970001T000000.100Z\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 58665600020L + "'", long9 == 58665600020L);
        org.junit.Assert.assertNotNull(locale10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 58665600020L + "'", long12 == 58665600020L);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 7776000001L + "'", long23 == 7776000001L);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        int int3 = dateTime2.getMonthOfYear();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.withDurationAdded(readableDuration4, 960);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime(dateTimeZone9);
        int int11 = dateTime8.getMillisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime8.plusHours((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.withSecondOfMinute((int) ' ');
        int int16 = dateTime13.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime13.plus(readableDuration17);
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateTime13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday(97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMinuteOfHour(1971);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendYear(86399999, 1971);
        try {
            org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatterBuilder12.toParser();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        mutableDateTime8.addWeeks((int) 'a');
        int int11 = property4.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
        int int12 = property4.getLeapAmount();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant15 = dateTime14.toInstant();
        org.joda.time.DateTime dateTime16 = dateTime14.toDateTimeISO();
        boolean boolean17 = property4.equals((java.lang.Object) dateTime14);
        org.joda.time.DateTime dateTime19 = property4.setCopy((int) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar20 = dateTime19.toGregorianCalendar();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.toDateTime(dateTimeZone23);
        int int25 = dateTime24.getDayOfWeek();
        org.joda.time.YearMonthDay yearMonthDay26 = dateTime24.toYearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter27.withZone(dateTimeZone29);
        org.joda.time.DateTime dateTime31 = dateTime24.withZoneRetainFields(dateTimeZone29);
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((java.lang.Object) dateTime19, dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gregorianCalendar20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(yearMonthDay26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(julianChronology32);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test067");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        java.util.Set<java.lang.String> strSet3 = org.joda.time.DateTimeZone.getAvailableIDs();
//        boolean boolean4 = julianChronology2.equals((java.lang.Object) strSet3);
//        java.util.Locale locale5 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket(58665600020L, (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) 72, 0);
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
//        int int15 = skipDateTimeField14.getMinimumValue();
//        int int16 = skipDateTimeField14.getMinimumValue();
//        boolean boolean17 = skipDateTimeField14.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.dayOfYear();
//        org.joda.time.Instant instant20 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology22);
//        org.joda.time.MutableDateTime.Property property25 = mutableDateTime24.minuteOfDay();
//        int int26 = property25.get();
//        org.joda.time.MutableDateTime mutableDateTime28 = property25.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property25.getFieldType();
//        int int30 = instant20.get(dateTimeFieldType29);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, dateTimeFieldType29, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField14, dateTimeFieldType29, 2);
//        int int35 = remainderDateTimeField34.getMinimumValue();
//        long long37 = remainderDateTimeField34.roundHalfCeiling(2649599999L);
//        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField39 = gJChronology38.dayOfYear();
//        org.joda.time.Instant instant40 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = gJChronology42.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology42);
//        org.joda.time.MutableDateTime.Property property45 = mutableDateTime44.minuteOfDay();
//        int int46 = property45.get();
//        org.joda.time.MutableDateTime mutableDateTime48 = property45.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property45.getFieldType();
//        int int50 = instant40.get(dateTimeFieldType49);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, dateTimeFieldType49, 7);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField34, dateTimeFieldType49);
//        org.joda.time.DurationField durationField54 = dividedDateTimeField53.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = dividedDateTimeField53.getType();
//        dateTimeParserBucket8.saveField(dateTimeFieldType55, (int) (byte) 100);
//        java.util.Locale locale58 = dateTimeParserBucket8.getLocale();
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(strSet3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(instant20);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 769 + "'", int30 == 769);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2678400000L + "'", long37 == 2678400000L);
//        org.junit.Assert.assertNotNull(gJChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(instant40);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 769 + "'", int50 == 769);
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(locale58);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int6 = skipDateTimeField5.getMinimumValue();
        int int7 = skipDateTimeField5.getMinimumValue();
        int int8 = skipDateTimeField5.getMaximumValue();
        long long10 = skipDateTimeField5.roundCeiling(1560343655006L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561939200000L + "'", long10 == 1561939200000L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendLiteral("GregorianChronology[UTC]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendMinuteOfHour(8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime1.minus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant11 = dateTime10.toInstant();
        long long12 = dateTime10.getMillis();
        boolean boolean13 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime15 = dateTime8.withDayOfYear(100);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test071");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        long long28 = remainderDateTimeField25.roundHalfCeiling(2649599999L);
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.dayOfYear();
//        org.joda.time.Instant instant31 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology33);
//        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.minuteOfDay();
//        int int37 = property36.get();
//        org.joda.time.MutableDateTime mutableDateTime39 = property36.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property36.getFieldType();
//        int int41 = instant31.get(dateTimeFieldType40);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, dateTimeFieldType40, 7);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType40);
//        long long47 = dividedDateTimeField44.addWrapField(0L, (int) (short) 100);
//        int int50 = dividedDateTimeField44.getDifference((long) 5, 0L);
//        long long53 = dividedDateTimeField44.add((long) 20, (int) (byte) 0);
//        try {
//            long long55 = dividedDateTimeField44.roundHalfFloor(0L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 769 + "'", int21 == 769);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2678400000L + "'", long28 == 2678400000L);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(instant31);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 769 + "'", int41 == 769);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10368000000L + "'", long47 == 10368000000L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 20L + "'", long53 == 20L);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test072");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
//        int int5 = property4.get();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property4.getAsShortText(locale6);
//        java.lang.String str8 = property4.getAsText();
//        java.util.Locale locale10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = property4.set("0", locale10);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.dayOfYear();
//        org.joda.time.Instant instant14 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology16);
//        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.minuteOfDay();
//        int int20 = property19.get();
//        org.joda.time.MutableDateTime mutableDateTime22 = property19.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property19.getFieldType();
//        int int24 = instant14.get(dateTimeFieldType23);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType23, 7);
//        org.joda.time.DateTimeField dateTimeField27 = offsetDateTimeField26.getWrappedField();
//        long long30 = offsetDateTimeField26.add((long) 57600010, (long) 3);
//        mutableDateTime11.setRounding((org.joda.time.DateTimeField) offsetDateTimeField26);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 769 + "'", int24 == 769);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 316800010L + "'", long30 == 316800010L);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 604800010, (java.lang.Number) 695, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(21600008L, (long) 20);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 432000160L + "'", long2 == 432000160L);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test075");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.dayOfWeek();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology7);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.minuteOfDay();
//        int int11 = property10.get();
//        org.joda.time.MutableDateTime mutableDateTime13 = property10.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property10.getFieldType();
//        int int15 = instant5.get(dateTimeFieldType14);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType14, 7);
//        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField17.getWrappedField();
//        long long20 = offsetDateTimeField17.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.toDateTime(dateTimeZone23);
//        int int25 = dateTime22.getMillisOfDay();
//        org.joda.time.DateTime dateTime27 = dateTime22.plusHours((int) '4');
//        org.joda.time.DateTime dateTime29 = dateTime27.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime31 = dateTime29.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay32 = dateTime31.toYearMonthDay();
//        int[] intArray38 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray40 = offsetDateTimeField17.addWrapField((org.joda.time.ReadablePartial) yearMonthDay32, (int) (byte) 0, intArray38, 4);
//        java.util.Locale locale41 = null;
//        int int42 = offsetDateTimeField17.getMaximumTextLength(locale41);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) offsetDateTimeField17, 3);
//        long long47 = offsetDateTimeField17.add((-210858379200000L), 194);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 769 + "'", int15 == 769);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2678400000L + "'", long20 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(yearMonthDay32);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 3 + "'", int42 == 3);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-210841617600000L) + "'", long47 == (-210841617600000L));
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("4:00:00 PM", true);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("Jan 3, 1970", true);
        java.io.OutputStream outputStream8 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", outputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(19, 15, 10, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test079");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(2000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("");
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfYear();
//        org.joda.time.Instant instant7 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology9);
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.minuteOfDay();
//        int int13 = property12.get();
//        org.joda.time.MutableDateTime mutableDateTime15 = property12.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property12.getFieldType();
//        int int17 = instant7.get(dateTimeFieldType16);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType16, 7);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder4.appendFraction(dateTimeFieldType16, (int) (byte) 10, (int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.util.Locale locale25 = dateTimeFormatter24.getLocale();
//        org.joda.time.format.DateTimePrinter dateTimePrinter26 = dateTimeFormatter24.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder23.append(dateTimePrinter26);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
//        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter28.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter26, dateTimeParser29);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder4.append(dateTimeParser29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 769 + "'", int17 == 769);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNull(locale25);
//        org.junit.Assert.assertNotNull(dateTimePrinter26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(dateTimeParser29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime6 = property4.roundCeilingCopy();
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumShortTextLength(locale7);
        java.util.Locale locale9 = null;
        int int10 = property4.getMaximumTextLength(locale9);
        java.lang.String str11 = property4.getAsString();
        org.joda.time.DateTime dateTime12 = property4.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime14 = property4.addWrapFieldToCopy(1971);
        try {
            org.joda.time.DateTime dateTime16 = dateTime14.withYearOfCentury(322);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 322 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "millisOfDay" + "'", str5.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1969-12-31T15:59:59");
        org.joda.time.DateTime.Property property2 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((int) 'a');
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 57600010);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.millisOfDay();
        mutableDateTime1.add(864001970L);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant7 = dateTime6.toInstant();
        boolean boolean8 = dateTime1.isEqual((org.joda.time.ReadableInstant) instant7);
        org.joda.time.Instant instant10 = instant7.minus((long) (byte) 0);
        org.joda.time.Instant instant11 = instant7.toInstant();
        org.joda.time.MutableDateTime mutableDateTime12 = instant7.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test084");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        long long28 = remainderDateTimeField25.roundHalfCeiling(2649599999L);
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.dayOfYear();
//        org.joda.time.Instant instant31 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology33);
//        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.minuteOfDay();
//        int int37 = property36.get();
//        org.joda.time.MutableDateTime mutableDateTime39 = property36.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property36.getFieldType();
//        int int41 = instant31.get(dateTimeFieldType40);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, dateTimeFieldType40, 7);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType40);
//        try {
//            long long47 = dividedDateTimeField44.set((long) '#', 4714);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4714 for minuteOfDay must be in the range [0,6]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 769 + "'", int21 == 769);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2678400000L + "'", long28 == 2678400000L);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(instant31);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 769 + "'", int41 == 769);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test085");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.Instant instant2 = dateTime1.toInstant();
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTimeISO();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getShortName((long) (short) 0, locale6);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime9 = dateTime3.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTime dateTime10 = dateTime9.toDateTimeISO();
//        int int11 = dateTime10.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test086");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday(97);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMinuteOfHour(1971);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendYear(86399999, 1971);
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField18);
//        int int22 = skipDateTimeField21.getMinimumValue();
//        int int23 = skipDateTimeField21.getMinimumValue();
//        boolean boolean24 = skipDateTimeField21.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField26 = gJChronology25.dayOfYear();
//        org.joda.time.Instant instant27 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology29);
//        org.joda.time.MutableDateTime.Property property32 = mutableDateTime31.minuteOfDay();
//        int int33 = property32.get();
//        org.joda.time.MutableDateTime mutableDateTime35 = property32.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property32.getFieldType();
//        int int37 = instant27.get(dateTimeFieldType36);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, dateTimeFieldType36, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField21, dateTimeFieldType36, 2);
//        int int42 = remainderDateTimeField41.getMinimumValue();
//        long long44 = remainderDateTimeField41.roundHalfCeiling(2649599999L);
//        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField46 = gJChronology45.dayOfYear();
//        org.joda.time.Instant instant47 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField50 = gJChronology49.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime51 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology49);
//        org.joda.time.MutableDateTime.Property property52 = mutableDateTime51.minuteOfDay();
//        int int53 = property52.get();
//        org.joda.time.MutableDateTime mutableDateTime55 = property52.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property52.getFieldType();
//        int int57 = instant47.get(dateTimeFieldType56);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, dateTimeFieldType56, 7);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField60 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField41, dateTimeFieldType56);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType56, 960, 86399999);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder63.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder64.appendPattern("10");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder66.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder66.appendDayOfMonth(86399);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNull(locale2);
//        org.junit.Assert.assertNotNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(instant27);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 769 + "'", int37 == 769);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2678400000L + "'", long44 == 2678400000L);
//        org.junit.Assert.assertNotNull(gJChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(instant47);
//        org.junit.Assert.assertNotNull(gJChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime55);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 769 + "'", int57 == 769);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfEra((int) (short) 1);
        org.joda.time.YearMonthDay yearMonthDay11 = dateTime10.toYearMonthDay();
        try {
            org.joda.time.DateTime dateTime13 = dateTime10.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(yearMonthDay11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfHalfday((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendYear((int) '#', (int) (byte) 1);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.toDateTime(dateTimeZone16);
        int int18 = dateTime15.getMillisOfDay();
        org.joda.time.DateTime dateTime20 = dateTime15.plusHours((int) '4');
        org.joda.time.DateTime dateTime23 = dateTime15.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZoneRetainFields(dateTimeZone24);
        org.joda.time.DateTime.Property property26 = dateTime23.yearOfEra();
        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
        org.joda.time.DateTime dateTime29 = dateTime27.minusHours(0);
        org.joda.time.DateTime.Property property30 = dateTime27.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder13.appendFixedSignedDecimal(dateTimeFieldType31, 768);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test089");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday(97);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMinuteOfHour(1971);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendYear(86399999, 1971);
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField18);
//        int int22 = skipDateTimeField21.getMinimumValue();
//        int int23 = skipDateTimeField21.getMinimumValue();
//        boolean boolean24 = skipDateTimeField21.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField26 = gJChronology25.dayOfYear();
//        org.joda.time.Instant instant27 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology29);
//        org.joda.time.MutableDateTime.Property property32 = mutableDateTime31.minuteOfDay();
//        int int33 = property32.get();
//        org.joda.time.MutableDateTime mutableDateTime35 = property32.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property32.getFieldType();
//        int int37 = instant27.get(dateTimeFieldType36);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, dateTimeFieldType36, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField21, dateTimeFieldType36, 2);
//        int int42 = remainderDateTimeField41.getMinimumValue();
//        long long44 = remainderDateTimeField41.roundHalfCeiling(2649599999L);
//        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField46 = gJChronology45.dayOfYear();
//        org.joda.time.Instant instant47 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField50 = gJChronology49.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime51 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology49);
//        org.joda.time.MutableDateTime.Property property52 = mutableDateTime51.minuteOfDay();
//        int int53 = property52.get();
//        org.joda.time.MutableDateTime mutableDateTime55 = property52.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property52.getFieldType();
//        int int57 = instant47.get(dateTimeFieldType56);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, dateTimeFieldType56, 7);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField60 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField41, dateTimeFieldType56);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType56, 960, 86399999);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder63.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder64.appendPattern("10");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder66.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter69 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.util.Locale locale70 = dateTimeFormatter69.getLocale();
//        org.joda.time.format.DateTimePrinter dateTimePrinter71 = dateTimeFormatter69.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = dateTimeFormatterBuilder68.append(dateTimePrinter71);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder72.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder76 = dateTimeFormatterBuilder72.appendYearOfEra((int) (byte) 10, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder76.appendLiteral(' ');
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap79 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = dateTimeFormatterBuilder78.appendTimeZoneName(strMap79);
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap79);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder66.appendTimeZoneShortName(strMap79);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNull(locale2);
//        org.junit.Assert.assertNotNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(instant27);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 769 + "'", int37 == 769);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2678400000L + "'", long44 == 2678400000L);
//        org.junit.Assert.assertNotNull(gJChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(instant47);
//        org.junit.Assert.assertNotNull(gJChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime55);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 769 + "'", int57 == 769);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertNotNull(dateTimeFormatter69);
//        org.junit.Assert.assertNull(locale70);
//        org.junit.Assert.assertNotNull(dateTimePrinter71);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder72);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder76);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
//        org.junit.Assert.assertNotNull(strMap79);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder80);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test090");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.minuteOfDay();
//        int int8 = property7.get();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property7.getFieldType();
//        int int12 = instant2.get(dateTimeFieldType11);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 7);
//        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getLeapDurationField();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 769 + "'", int12 == 769);
//        org.junit.Assert.assertNull(durationField15);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1969-12-31T15:59:59");
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfSecond((int) (short) 0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours(1971);
        org.joda.time.DateTime dateTime7 = dateTime3.minusMinutes(960);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test092");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.dayOfWeek();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology7);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.minuteOfDay();
//        int int11 = property10.get();
//        org.joda.time.MutableDateTime mutableDateTime13 = property10.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property10.getFieldType();
//        int int15 = instant5.get(dateTimeFieldType14);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType14, 7);
//        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField17.getWrappedField();
//        long long20 = offsetDateTimeField17.roundCeiling(2678399999L);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.toDateTime(dateTimeZone23);
//        int int25 = dateTime22.getMillisOfDay();
//        org.joda.time.DateTime dateTime27 = dateTime22.plusHours((int) '4');
//        org.joda.time.DateTime dateTime29 = dateTime27.withSecondOfMinute((int) ' ');
//        org.joda.time.DateTime dateTime31 = dateTime29.withYearOfEra((int) (short) 1);
//        org.joda.time.YearMonthDay yearMonthDay32 = dateTime31.toYearMonthDay();
//        int[] intArray38 = new int[] { 767, (short) 1, (short) 10, 86399999 };
//        int[] intArray40 = offsetDateTimeField17.addWrapField((org.joda.time.ReadablePartial) yearMonthDay32, (int) (byte) 0, intArray38, 4);
//        java.util.Locale locale41 = null;
//        int int42 = offsetDateTimeField17.getMaximumTextLength(locale41);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) offsetDateTimeField17, 3);
//        long long47 = skipDateTimeField44.add((long) 30, 1971L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 769 + "'", int15 == 769);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2678400000L + "'", long20 == 2678400000L);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(yearMonthDay32);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 3 + "'", int42 == 3);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 170294400030L + "'", long47 == 170294400030L);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test093");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        long long28 = remainderDateTimeField25.roundHalfCeiling(0L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.util.Locale locale31 = dateTimeFormatter30.getLocale();
//        org.joda.time.format.DateTimePrinter dateTimePrinter32 = dateTimeFormatter30.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder29.append(dateTimePrinter32);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder33.appendYearOfEra((int) (byte) 10, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder37.appendHourOfHalfday(97);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder39.appendMinuteOfHour(1971);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendYear(86399999, 1971);
//        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField47 = gJChronology46.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField47, dateTimeFieldType48);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField50 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology45, dateTimeField47);
//        int int51 = skipDateTimeField50.getMinimumValue();
//        int int52 = skipDateTimeField50.getMinimumValue();
//        boolean boolean53 = skipDateTimeField50.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField55 = gJChronology54.dayOfYear();
//        org.joda.time.Instant instant56 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField59 = gJChronology58.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime60 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology58);
//        org.joda.time.MutableDateTime.Property property61 = mutableDateTime60.minuteOfDay();
//        int int62 = property61.get();
//        org.joda.time.MutableDateTime mutableDateTime64 = property61.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType65 = property61.getFieldType();
//        int int66 = instant56.get(dateTimeFieldType65);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, dateTimeFieldType65, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField50, dateTimeFieldType65, 2);
//        int int71 = remainderDateTimeField70.getMinimumValue();
//        long long73 = remainderDateTimeField70.roundHalfCeiling(2649599999L);
//        org.joda.time.chrono.GJChronology gJChronology74 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField75 = gJChronology74.dayOfYear();
//        org.joda.time.Instant instant76 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology78 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField79 = gJChronology78.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime80 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology78);
//        org.joda.time.MutableDateTime.Property property81 = mutableDateTime80.minuteOfDay();
//        int int82 = property81.get();
//        org.joda.time.MutableDateTime mutableDateTime84 = property81.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType85 = property81.getFieldType();
//        int int86 = instant76.get(dateTimeFieldType85);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField88 = new org.joda.time.field.OffsetDateTimeField(dateTimeField75, dateTimeFieldType85, 7);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField89 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField70, dateTimeFieldType85);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder92 = dateTimeFormatterBuilder41.appendDecimal(dateTimeFieldType85, 960, 86399999);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField93 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType85);
//        long long95 = remainderDateTimeField25.roundHalfCeiling(21600008L);
//        long long97 = remainderDateTimeField25.roundHalfEven((long) 373);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 769 + "'", int21 == 769);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNull(locale31);
//        org.junit.Assert.assertNotNull(dateTimePrinter32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(gJChronology45);
//        org.junit.Assert.assertNotNull(gJChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(gJChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(instant56);
//        org.junit.Assert.assertNotNull(gJChronology58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime64);
//        org.junit.Assert.assertNotNull(dateTimeFieldType65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 769 + "'", int66 == 769);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 2678400000L + "'", long73 == 2678400000L);
//        org.junit.Assert.assertNotNull(gJChronology74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(instant76);
//        org.junit.Assert.assertNotNull(gJChronology78);
//        org.junit.Assert.assertNotNull(dateTimeField79);
//        org.junit.Assert.assertNotNull(property81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime84);
//        org.junit.Assert.assertNotNull(dateTimeFieldType85);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 769 + "'", int86 == 769);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder92);
//        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 0L + "'", long95 == 0L);
//        org.junit.Assert.assertTrue("'" + long97 + "' != '" + 0L + "'", long97 == 0L);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime1.minus(readablePeriod7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateMidnight dateMidnight10 = dateTime8.toDateMidnight();
        int int11 = dateMidnight10.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        long long6 = delegatedDateTimeField3.add((long) 1, (long) 3);
        java.lang.String str7 = delegatedDateTimeField3.toString();
        long long9 = delegatedDateTimeField3.roundFloor((long) 322);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7776000001L + "'", long6 == 7776000001L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[monthOfYear]" + "'", str7.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = dateTimeFormatter0.parseMutableDateTime("DateTimeField[minuteOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[minuteOfDay]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test098");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28, dateTimeFieldType29);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
//        int int32 = skipDateTimeField31.getMinimumValue();
//        int int33 = skipDateTimeField31.getMinimumValue();
//        boolean boolean34 = skipDateTimeField31.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology35.dayOfYear();
//        org.joda.time.Instant instant37 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology39);
//        org.joda.time.MutableDateTime.Property property42 = mutableDateTime41.minuteOfDay();
//        int int43 = property42.get();
//        org.joda.time.MutableDateTime mutableDateTime45 = property42.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property42.getFieldType();
//        int int47 = instant37.get(dateTimeFieldType46);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, dateTimeFieldType46, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField51 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField31, dateTimeFieldType46, 2);
//        long long53 = remainderDateTimeField51.roundHalfCeiling(0L);
//        long long55 = remainderDateTimeField51.remainder((long) 1971);
//        int int58 = remainderDateTimeField51.getDifference(316800010L, (long) 12);
//        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField61 = gJChronology60.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime62 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology60);
//        org.joda.time.MutableDateTime.Property property63 = mutableDateTime62.minuteOfDay();
//        int int64 = property63.get();
//        org.joda.time.MutableDateTime mutableDateTime66 = property63.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property63.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField51, dateTimeFieldType67);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType67);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType67, 695, 0, 768);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 769 + "'", int21 == 769);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(instant37);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 769 + "'", int47 == 769);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1971L + "'", long55 == 1971L);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(gJChronology60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime66);
//        org.junit.Assert.assertNotNull(dateTimeFieldType67);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test099");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
//        long long5 = gJChronology0.add((long) (byte) 1, 2649599999L, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getShortName((long) (short) 0, locale8);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone11 = zonedChronology10.getZone();
//        org.joda.time.Chronology chronology12 = zonedChronology10.withUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withZone(dateTimeZone15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        org.joda.time.Chronology chronology18 = iSOChronology17.withUTC();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology20.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField21);
//        org.joda.time.DateTimeField dateTimeField25 = gJChronology19.yearOfEra();
//        org.joda.time.DurationField durationField26 = gJChronology19.days();
//        boolean boolean27 = iSOChronology17.equals((java.lang.Object) durationField26);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours(6);
//        org.joda.time.Chronology chronology31 = iSOChronology17.withZone(dateTimeZone30);
//        org.joda.time.Chronology chronology32 = zonedChronology10.withZone(dateTimeZone30);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 26495999991L + "'", long5 == 26495999991L);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(chronology32);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(316800010L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440591L + "'", long1 == 2440591L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add((long) 1, (long) 3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (short) -1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = delegatedDateTimeField7.getAsShortText((long) (byte) 10, locale14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField7.getAsText((int) (byte) 10, locale17);
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((java.lang.Object) locale17);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7776000001L + "'", long10 == 7776000001L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Jan" + "'", str15.equals("Jan"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "October" + "'", str18.equals("October"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test103");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
//        java.util.Set<java.lang.String> strSet31 = org.joda.time.DateTimeZone.getAvailableIDs();
//        boolean boolean32 = julianChronology30.equals((java.lang.Object) strSet31);
//        java.util.Locale locale33 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket36 = new org.joda.time.format.DateTimeParserBucket(58665600020L, (org.joda.time.Chronology) julianChronology30, locale33, (java.lang.Integer) 72, 0);
//        long long37 = dateTimeParserBucket36.computeMillis();
//        java.util.Locale locale38 = dateTimeParserBucket36.getLocale();
//        try {
//            long long39 = remainderDateTimeField25.set((long) (byte) -1, "April", locale38);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"April\" for minuteOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 769 + "'", int21 == 769);
//        org.junit.Assert.assertNotNull(julianChronology30);
//        org.junit.Assert.assertNotNull(strSet31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 58665600020L + "'", long37 == 58665600020L);
//        org.junit.Assert.assertNotNull(locale38);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        mutableDateTime8.addWeeks((int) 'a');
        int int11 = property4.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime8.yearOfEra();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime8.hourOfDay();
        try {
            mutableDateTime8.setHourOfDay(57600010);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600010 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(5L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test106");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendYear((int) '#', (int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendYearOfCentury(9, 59);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.toDateTime(dateTimeZone19);
//        int int21 = dateTime18.getMillisOfDay();
//        org.joda.time.DateTime dateTime23 = dateTime18.plusHours((int) '4');
//        org.joda.time.DateTime dateTime26 = dateTime18.withDurationAdded(1L, 62);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime26.withZoneRetainFields(dateTimeZone27);
//        org.joda.time.DateTime.Property property29 = dateTime26.yearOfEra();
//        org.joda.time.DateTime dateTime31 = dateTime26.withMillis((-2678399900L));
//        int int32 = dateTime31.getCenturyOfEra();
//        int int33 = dateTime31.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology35.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36, dateTimeFieldType37);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology34, dateTimeField36);
//        int int40 = skipDateTimeField39.getMinimumValue();
//        int int41 = skipDateTimeField39.getMinimumValue();
//        boolean boolean42 = skipDateTimeField39.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField44 = gJChronology43.dayOfYear();
//        org.joda.time.Instant instant45 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField48 = gJChronology47.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime49 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology47);
//        org.joda.time.MutableDateTime.Property property50 = mutableDateTime49.minuteOfDay();
//        int int51 = property50.get();
//        org.joda.time.MutableDateTime mutableDateTime53 = property50.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property50.getFieldType();
//        int int55 = instant45.get(dateTimeFieldType54);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, dateTimeFieldType54, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField39, dateTimeFieldType54, 2);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType54, (java.lang.Number) 334L, "PST");
//        org.joda.time.DateTime.Property property63 = dateTime31.property(dateTimeFieldType54);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder10.appendFixedDecimal(dateTimeFieldType54, 769);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNull(locale2);
//        org.junit.Assert.assertNotNull(dateTimePrinter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 19 + "'", int32 == 19);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 335 + "'", int33 == 335);
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(gJChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(instant45);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime53);
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 769 + "'", int55 == 769);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        mutableDateTime8.addWeeks((int) 'a');
        int int11 = property4.compareTo((org.joda.time.ReadableInstant) mutableDateTime8);
        int int12 = property4.getLeapAmount();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property4.getAsText(locale13);
        org.joda.time.DateTime dateTime16 = property4.addToCopy(30);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test108");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName((long) (short) 0, locale2);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone0);
//        java.lang.String str6 = dateTimeZone0.getName(58665600010L);
//        java.lang.String str7 = dateTimeZone0.getID();
//        boolean boolean9 = dateTimeZone0.isStandardOffset(345602000L);
//        boolean boolean11 = dateTimeZone0.isStandardOffset((long) 52);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = julianChronology7.withUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(2, (int) (short) 10, 12, 0, (int) (short) 1, 4, dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.millisOfSecond();
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str5 = dateTimeFormatter0.print(55094399999L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Sep 30, 1971" + "'", str5.equals("Sep 30, 1971"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.dayOfYear();
        org.joda.time.Instant instant5 = gJChronology0.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime3.getDayOfWeek();
        org.joda.time.DateTime dateTime6 = dateTime3.minus(767L);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.minus(readablePeriod7);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("4:00:00 PM", true);
        org.joda.time.DateTimeZone dateTimeZone15 = dateTimeZoneBuilder9.toDateTimeZone("Jan 3, 1970", true);
        org.joda.time.DateTime dateTime16 = dateTime3.toDateTime(dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime16.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant2 = dateTime1.toInstant();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.withPeriodAdded(readablePeriod3, 0);
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime5.toYearMonthDay();
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday(97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfSecond((int) '4', 86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendDayOfMonth(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology7);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField12);
        java.lang.String str16 = skipDateTimeField15.toString();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, (org.joda.time.DateTimeField) skipDateTimeField15, (int) 'a');
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipDateTimeField18);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology20, dateTimeField22);
        int int26 = skipDateTimeField25.getMinimumValue();
        int int27 = skipDateTimeField25.getMinimumValue();
        int int28 = skipDateTimeField25.getMaximumValue();
        boolean boolean29 = skipDateTimeField25.isSupported();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipDateTimeField25, (int) 'a');
        int int33 = skipUndoDateTimeField31.get(2246402000L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[monthOfYear]" + "'", str16.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        int int3 = dateTime2.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.Chronology chronology12 = gregorianChronology5.withZone(dateTimeZone10);
        org.joda.time.Chronology chronology13 = gregorianChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.Chronology chronology15 = gregorianChronology5.withUTC();
        org.joda.time.DateTime dateTime16 = dateTime2.withChronology(chronology15);
        int int17 = dateTime2.getDayOfYear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 86399 + "'", int3 == 86399);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 365 + "'", int17 == 365);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test119");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        java.util.Set<java.lang.String> strSet3 = org.joda.time.DateTimeZone.getAvailableIDs();
//        boolean boolean4 = julianChronology2.equals((java.lang.Object) strSet3);
//        java.util.Locale locale5 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket(58665600020L, (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) 72, 0);
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
//        int int15 = skipDateTimeField14.getMinimumValue();
//        int int16 = skipDateTimeField14.getMinimumValue();
//        boolean boolean17 = skipDateTimeField14.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.dayOfYear();
//        org.joda.time.Instant instant20 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology22);
//        org.joda.time.MutableDateTime.Property property25 = mutableDateTime24.minuteOfDay();
//        int int26 = property25.get();
//        org.joda.time.MutableDateTime mutableDateTime28 = property25.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property25.getFieldType();
//        int int30 = instant20.get(dateTimeFieldType29);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, dateTimeFieldType29, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField14, dateTimeFieldType29, 2);
//        int int35 = remainderDateTimeField34.getMinimumValue();
//        long long37 = remainderDateTimeField34.roundHalfCeiling(2649599999L);
//        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField39 = gJChronology38.dayOfYear();
//        org.joda.time.Instant instant40 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = gJChronology42.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology42);
//        org.joda.time.MutableDateTime.Property property45 = mutableDateTime44.minuteOfDay();
//        int int46 = property45.get();
//        org.joda.time.MutableDateTime mutableDateTime48 = property45.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property45.getFieldType();
//        int int50 = instant40.get(dateTimeFieldType49);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, dateTimeFieldType49, 7);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField34, dateTimeFieldType49);
//        org.joda.time.DurationField durationField54 = dividedDateTimeField53.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = dividedDateTimeField53.getType();
//        dateTimeParserBucket8.saveField(dateTimeFieldType55, (int) (byte) 100);
//        long long58 = dateTimeParserBucket8.computeMillis();
//        long long59 = dateTimeParserBucket8.computeMillis();
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(strSet3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(instant20);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 769 + "'", int30 == 769);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2678400000L + "'", long37 == 2678400000L);
//        org.junit.Assert.assertNotNull(gJChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(instant40);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 769 + "'", int50 == 769);
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 58671600020L + "'", long58 == 58671600020L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 58671600020L + "'", long59 == 58671600020L);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral(' ');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTimeZoneName(strMap11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale15 = dateTimeFormatter14.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter14.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.append(dateTimePrinter16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter16, dateTimeParser19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder12.append(dateTimeParser19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendDayOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendWeekyear((int) '#', (-2));
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(strMap11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNull(locale15);
        org.junit.Assert.assertNotNull(dateTimePrinter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("Coordinated Universal Time", true);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider5 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        java.util.Set<java.lang.String> strSet9 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean10 = julianChronology8.equals((java.lang.Object) strSet9);
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket(58665600020L, (org.joda.time.Chronology) julianChronology8, locale11, (java.lang.Integer) 72, 0);
        long long15 = dateTimeParserBucket14.computeMillis();
        java.util.Locale locale16 = dateTimeParserBucket14.getLocale();
        java.lang.String str19 = defaultNameProvider5.getName(locale16, "8", "1970-01-01T16:00:00.072Z");
        java.lang.String str20 = dateTimeZone3.getName(0L, locale16);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 58665600020L + "'", long15 == 58665600020L);
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00" + "'", str20.equals("+00:00"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        int int5 = property4.get();
        org.joda.time.MutableDateTime mutableDateTime7 = property4.add(2440588L);
        java.lang.String str8 = property4.toString();
        java.util.Locale locale9 = null;
        int int10 = property4.getMaximumShortTextLength(locale9);
        org.joda.time.Instant instant12 = new org.joda.time.Instant((long) 2);
        boolean boolean13 = property4.equals((java.lang.Object) 2);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.toDateTime(dateTimeZone16);
        int int18 = dateTime15.getMillisOfDay();
        org.joda.time.DateTime dateTime20 = dateTime15.plusHours((int) '4');
        org.joda.time.DateTime dateTime23 = dateTime15.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withZoneRetainFields(dateTimeZone24);
        org.joda.time.DateTime.Property property26 = dateTime23.yearOfEra();
        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
        long long28 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime27);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[minuteOfDay]" + "'", str8.equals("Property[minuteOfDay]"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2440587L + "'", long28 == 2440587L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime();
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours(0);
        org.joda.time.DateTime.Property property16 = dateTime15.dayOfYear();
        org.joda.time.DateTime dateTime17 = property16.getDateTime();
        org.joda.time.DateTime dateTime18 = property16.roundCeilingCopy();
        org.joda.time.DateTime dateTime20 = dateTime18.plusDays(9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt((-59009040000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -59009040000000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) 62);
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.Instant instant5 = new org.joda.time.Instant((java.lang.Object) dateTimeFormatter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12:00:00 AM" + "'", str2.equals("12:00:00 AM"));
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test128");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        long long28 = remainderDateTimeField25.roundHalfCeiling(2649599999L);
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.dayOfYear();
//        org.joda.time.Instant instant31 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology33);
//        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.minuteOfDay();
//        int int37 = property36.get();
//        org.joda.time.MutableDateTime mutableDateTime39 = property36.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property36.getFieldType();
//        int int41 = instant31.get(dateTimeFieldType40);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, dateTimeFieldType40, 7);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType40);
//        org.joda.time.DurationField durationField45 = dividedDateTimeField44.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = dividedDateTimeField44.getType();
//        int int49 = dividedDateTimeField44.getDifference(55094399999L, (long) '#');
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 769 + "'", int21 == 769);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2678400000L + "'", long28 == 2678400000L);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(instant31);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 769 + "'", int41 == 769);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "DateTimeField[minuteOfDay]", (int) (short) 1, 0);
        long long6 = fixedDateTimeZone4.previousTransition((-2678399900L));
        long long8 = fixedDateTimeZone4.previousTransition((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2678399900L) + "'", long6 == (-2678399900L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(72, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 72");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(86399999);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-86399999) + "'", int1 == (-86399999));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.joda.time.DateTime dateTime14 = dateTime9.withMillis((-2678399900L));
        org.joda.time.DateTime dateTime16 = dateTime14.plusMonths(6);
        org.joda.time.DateTime dateTime18 = dateTime14.minusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.withPeriodAdded(readablePeriod19, (int) '#');
        try {
            org.joda.time.DateTime dateTime23 = dateTime14.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(100L, dateTimeZone1);
        mutableDateTime2.setWeekyear((int) (short) 10);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.dayOfMonth();
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.DateTime dateTime6 = instant5.toDateTimeISO();
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfEra(194);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra((int) (byte) 10, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday(97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMinuteOfHour(1971);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendTwoDigitWeekyear(100);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology16);
        mutableDateTime18.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration21 = null;
        mutableDateTime18.add(readableDuration21);
        long long23 = mutableDateTime18.getMillis();
        org.joda.time.MutableDateTime mutableDateTime24 = mutableDateTime18.copy();
        org.joda.time.MutableDateTime mutableDateTime25 = mutableDateTime18.copy();
        mutableDateTime18.setSecondOfMinute((int) '4');
        mutableDateTime18.addSeconds((int) (short) 100);
        boolean boolean30 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 100, (java.lang.Object) mutableDateTime18);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 58665600010L + "'", long23 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfCeiling();
        mutableDateTime5.addMillis((-1));
        mutableDateTime5.addWeekyears(1971);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        mutableDateTime5.add(readablePeriod10);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        mutableDateTime3.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime3.add(readableDuration6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime3.hourOfDay();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime3.dayOfYear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("Coordinated Universal Time", true);
        long long5 = dateTimeZone3.convertUTCToLocal(28800000L);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28800000L + "'", long5 == 28800000L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = julianChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTime(dateTimeZone8);
        int int10 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant13 = dateTime12.toInstant();
        boolean boolean14 = dateTime7.isEqual((org.joda.time.ReadableInstant) instant13);
        long long15 = instant13.getMillis();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.MutableDateTime mutableDateTime17 = instant13.toMutableDateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = instant13.toDateTimeISO();
        boolean boolean19 = buddhistChronology5.equals((java.lang.Object) dateTime18);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology5.weekyear();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.toDateTime(dateTimeZone23);
        org.joda.time.DateTime.Property property25 = dateTime24.millisOfDay();
        java.lang.String str26 = property25.getName();
        org.joda.time.DateTime dateTime27 = property25.roundCeilingCopy();
        java.util.Locale locale28 = null;
        int int29 = property25.getMaximumShortTextLength(locale28);
        java.util.Locale locale30 = null;
        int int31 = property25.getMaximumTextLength(locale30);
        java.lang.String str32 = property25.getAsString();
        org.joda.time.DateTime dateTime33 = property25.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime35 = property25.addWrapFieldToCopy(1971);
        org.joda.time.DateTime.Property property36 = dateTime35.dayOfMonth();
        boolean boolean37 = buddhistChronology5.equals((java.lang.Object) dateTime35);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "millisOfDay" + "'", str26.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 8 + "'", int29 == 8);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 8 + "'", int31 == 8);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10" + "'", str32.equals("10"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 1970);
        try {
            long long6 = dateTimeFormatter4.parseMillis("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.DateTime dateTime6 = instant5.toDateTimeISO();
        org.joda.time.DateTime dateTime8 = dateTime6.minusDays(604800010);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(280);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-280) + "'", int1 == (-280));
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test145");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
//        long long5 = gJChronology0.add((long) (byte) 1, 2649599999L, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getShortName((long) (short) 0, locale8);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        boolean boolean12 = zonedChronology10.equals((java.lang.Object) dateTimeFormatter11);
//        try {
//            long long20 = zonedChronology10.getDateTimeMillis(72, (-2), 100, 4714, 2000, (int) (byte) -1, 280);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4714 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 26495999991L + "'", long5 == 26495999991L);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(zonedChronology10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "DateTimeField[minuteOfDay]", (int) (short) 1, 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) (short) 10);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime(dateTimeZone9);
        int int11 = dateTime8.getMillisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime8.plusHours((int) '4');
        org.joda.time.DateTime dateTime16 = dateTime8.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.withZoneRetainFields(dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime16.yearOfEra();
        org.joda.time.DateTime dateTime20 = dateTime16.toDateTime();
        org.joda.time.DateTime dateTime22 = dateTime20.minusHours(0);
        boolean boolean23 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.util.TimeZone timeZone24 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = dateTime26.toDateTime(dateTimeZone27);
        int int29 = dateTime26.getMillisOfDay();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant32 = dateTime31.toInstant();
        boolean boolean33 = dateTime26.isEqual((org.joda.time.ReadableInstant) instant32);
        org.joda.time.Instant instant35 = instant32.minus((long) (byte) 0);
        org.joda.time.Instant instant36 = instant32.toInstant();
        int int37 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) instant32);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTimeField[minuteOfDay]" + "'", str6.equals("DateTimeField[minuteOfDay]"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertNotNull(instant32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(instant35);
        org.junit.Assert.assertNotNull(instant36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 57600010);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology2.getZone();
        org.joda.time.DateTime dateTime6 = mutableDateTime1.toDateTime(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime1.copy();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime6.plusYears(767);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(100);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.era();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.minuteOfDay();
        org.joda.time.DateTime dateTime18 = dateTime10.toDateTime((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTime dateTime20 = dateTime18.withDayOfYear(4);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime6.plusYears(767);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(100);
        org.joda.time.DateTime dateTime14 = dateTime10.withWeekyear((-32));
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology16 = gJChronology15.withUTC();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology15.dayOfWeek();
        org.joda.time.DateTime dateTime18 = dateTime14.toDateTime((org.joda.time.Chronology) gJChronology15);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("", "hi!");
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException7);
        java.lang.Number number9 = illegalFieldValueException7.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException7.getDurationFieldType();
        java.lang.String str11 = illegalFieldValueException7.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = illegalFieldValueException7.getDateTimeFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.Throwable[] throwableArray14 = illegalFieldValueException7.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test151");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
//        int int4 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getShortName((long) (short) 0, locale9);
//        org.joda.time.DateTime dateTime11 = dateTime6.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.DateTime dateTime13 = dateTime6.withWeekOfWeekyear(12);
//        org.joda.time.DateTime.Property property14 = dateTime13.hourOfDay();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField9);
        java.lang.String str13 = skipDateTimeField12.toString();
        long long15 = skipDateTimeField12.remainder((long) (short) -1);
        int int16 = dateTime6.get((org.joda.time.DateTimeField) skipDateTimeField12);
        boolean boolean17 = skipDateTimeField12.isLenient();
        long long19 = skipDateTimeField12.roundHalfCeiling(70000L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[monthOfYear]" + "'", str13.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2678399999L + "'", long15 == 2678399999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        java.util.Set<java.lang.String> strSet2 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean3 = julianChronology1.equals((java.lang.Object) strSet2);
        org.joda.time.DurationField durationField4 = julianChronology1.years();
        java.lang.String str5 = julianChronology1.toString();
        java.lang.String str6 = julianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology1.getZone();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JulianChronology[UTC]" + "'", str5.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JulianChronology[UTC]" + "'", str6.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology1.getZone();
        int int5 = gregorianChronology1.getMinimumDaysInFirstWeek();
        java.lang.String str6 = gregorianChronology1.toString();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
        long long13 = delegatedDateTimeField10.add((long) 1, (long) 3);
        int int15 = delegatedDateTimeField10.getMaximumValue(58665600010L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField10, 10);
        org.joda.time.DateTimeField dateTimeField18 = delegatedDateTimeField10.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7776000001L + "'", long13 == 7776000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test155");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        org.joda.time.DateTimeField dateTimeField26 = remainderDateTimeField25.getWrappedField();
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField29 = gJChronology28.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology28.halfdayOfDay();
//        org.joda.time.MutableDateTime mutableDateTime31 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology28);
//        org.joda.time.Chronology chronology32 = gJChronology28.withUTC();
//        org.joda.time.DurationField durationField33 = gJChronology28.weeks();
//        java.util.Locale locale34 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket36 = new org.joda.time.format.DateTimeParserBucket((-1L), (org.joda.time.Chronology) gJChronology28, locale34, (java.lang.Integer) 20);
//        long long38 = dateTimeParserBucket36.computeMillis(true);
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology40);
//        org.joda.time.MutableDateTime.Property property43 = mutableDateTime42.minuteOfDay();
//        org.joda.time.MutableDateTime mutableDateTime44 = property43.roundHalfCeiling();
//        mutableDateTime44.addMillis((-1));
//        mutableDateTime44.addWeekyears(1971);
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime52 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology50);
//        org.joda.time.MutableDateTime.Property property53 = mutableDateTime52.minuteOfDay();
//        int int54 = property53.get();
//        org.joda.time.MutableDateTime mutableDateTime56 = property53.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property53.getFieldType();
//        mutableDateTime44.set(dateTimeFieldType57, 11);
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.chrono.JulianChronology julianChronology63 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone62);
//        java.util.Set<java.lang.String> strSet64 = org.joda.time.DateTimeZone.getAvailableIDs();
//        boolean boolean65 = julianChronology63.equals((java.lang.Object) strSet64);
//        java.util.Locale locale66 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket69 = new org.joda.time.format.DateTimeParserBucket(58665600020L, (org.joda.time.Chronology) julianChronology63, locale66, (java.lang.Integer) 72, 0);
//        long long70 = dateTimeParserBucket69.computeMillis();
//        java.util.Locale locale71 = dateTimeParserBucket69.getLocale();
//        dateTimeParserBucket36.saveField(dateTimeFieldType57, "1970W014", locale71);
//        int int73 = remainderDateTimeField25.getMaximumTextLength(locale71);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 769 + "'", int21 == 769);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-1L) + "'", long38 == (-1L));
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(mutableDateTime44);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime56);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertNotNull(julianChronology63);
//        org.junit.Assert.assertNotNull(strSet64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 58665600020L + "'", long70 == 58665600020L);
//        org.junit.Assert.assertNotNull(locale71);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) '4');
        org.joda.time.DateMidnight dateMidnight7 = dateTime6.toDateMidnight();
        try {
            org.joda.time.DateTime dateTime11 = dateTime6.withDate(24, 8, 373);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 373 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateMidnight7);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology9 = julianChronology8.withUTC();
        org.joda.time.DurationField durationField10 = julianChronology8.minutes();
        try {
            org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(53, 3, 767, 769, 7, 59, 10, (org.joda.time.Chronology) julianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 769 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = julianChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTime(dateTimeZone8);
        int int10 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant13 = dateTime12.toInstant();
        boolean boolean14 = dateTime7.isEqual((org.joda.time.ReadableInstant) instant13);
        long long15 = instant13.getMillis();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.MutableDateTime mutableDateTime17 = instant13.toMutableDateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = instant13.toDateTimeISO();
        boolean boolean19 = buddhistChronology5.equals((java.lang.Object) dateTime18);
        org.joda.time.Chronology chronology20 = buddhistChronology5.withUTC();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(1560343655006L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str6 = illegalFieldValueException2.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.joda.time.DateTime dateTime14 = dateTime9.withMillis((-2678399900L));
        org.joda.time.DateTime dateTime16 = dateTime14.plusMonths(6);
        org.joda.time.DateTime dateTime18 = dateTime14.minusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.withPeriodAdded(readablePeriod19, (int) '#');
        int int22 = dateTime21.getMinuteOfHour();
        org.joda.time.DateTime dateTime24 = dateTime21.minusYears(21);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = julianChronology1.withUTC();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        mutableDateTime8.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration11 = null;
        mutableDateTime8.add(readableDuration11);
        long long13 = mutableDateTime8.getMillis();
        org.joda.time.MutableDateTime mutableDateTime14 = mutableDateTime8.copy();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = mutableDateTime8.toDateTime(dateTimeZone15);
        mutableDateTime4.setDate((org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime4.yearOfCentury();
        boolean boolean19 = julianChronology1.equals((java.lang.Object) property18);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 58665600010L + "'", long13 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField4);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        java.lang.String str15 = skipDateTimeField14.toString();
        long long17 = skipDateTimeField14.remainder((long) (short) -1);
        int int18 = dateTime8.get((org.joda.time.DateTimeField) skipDateTimeField14);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime8.minus(readableDuration20);
        org.joda.time.DateTime dateTime23 = dateTime21.minusMillis(72);
        org.joda.time.DateTime.Property property24 = dateTime21.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[monthOfYear]" + "'", str15.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2678399999L + "'", long17 == 2678399999L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfMonth();
        java.lang.String str6 = iSOChronology4.toString();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[UTC]" + "'", str6.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 10);
        org.joda.time.Instant instant5 = dateTime4.toInstant();
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DateTime dateTime9 = dateTime4.withWeekyear(20);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology11);
        mutableDateTime13.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration16 = null;
        mutableDateTime13.add(readableDuration16);
        long long18 = mutableDateTime13.getMillis();
        org.joda.time.MutableDateTime mutableDateTime19 = mutableDateTime13.copy();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = mutableDateTime13.toDateTime(dateTimeZone20);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology23 = gJChronology22.withUTC();
        org.joda.time.DateTime dateTime24 = mutableDateTime13.toDateTime(chronology23);
        org.joda.time.DateTime dateTime26 = dateTime24.withMinuteOfHour(0);
        org.joda.time.chrono.LimitChronology limitChronology27 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.ReadableDateTime) dateTime4, (org.joda.time.ReadableDateTime) dateTime26);
        org.joda.time.DateTime dateTime28 = limitChronology27.getUpperLimit();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 58665600010L + "'", long18 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(limitChronology27);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusHours((int) '4');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = dateTime1.toDateTime(chronology7);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant10 = null;
        mutableDateTime9.setMillis(readableInstant10);
        mutableDateTime9.setMillisOfSecond(365);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test167");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.Instant instant2 = dateTime1.toInstant();
//        org.joda.time.DateTime dateTime3 = instant2.toDateTimeISO();
//        org.joda.time.Instant instant6 = instant2.withDurationAdded(0L, (int) (byte) -1);
//        org.joda.time.Chronology chronology7 = instant2.getChronology();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10, dateTimeFieldType11);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology8);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField17);
//        java.lang.String str21 = skipDateTimeField20.toString();
//        long long23 = skipDateTimeField20.remainder((long) (short) -1);
//        int int24 = dateTime14.get((org.joda.time.DateTimeField) skipDateTimeField20);
//        int int25 = dateTime14.getWeekOfWeekyear();
//        boolean boolean26 = instant2.isAfter((org.joda.time.ReadableInstant) dateTime14);
//        try {
//            org.joda.time.DateTime dateTime28 = dateTime14.withMillisOfDay((-11));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -11 for millisOfDay must be in the range [0,86399999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "DateTimeField[monthOfYear]" + "'", str21.equals("DateTimeField[monthOfYear]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2678399999L + "'", long23 == 2678399999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfDay();
        int int5 = property4.get();
        org.joda.time.MutableDateTime mutableDateTime7 = property4.add(2440588L);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology11);
        mutableDateTime13.addWeeks((int) 'a');
        org.joda.time.ReadableDuration readableDuration16 = null;
        mutableDateTime13.add(readableDuration16);
        long long18 = mutableDateTime13.getMillis();
        org.joda.time.MutableDateTime mutableDateTime19 = mutableDateTime13.copy();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = mutableDateTime13.toDateTime(dateTimeZone20);
        mutableDateTime9.setDate((org.joda.time.ReadableInstant) mutableDateTime13);
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime9.yearOfCentury();
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime9.dayOfWeek();
        long long25 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime9);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 58665600010L + "'", long18 == 58665600010L);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1461388L + "'", long25 == 1461388L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter6.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test170");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) 334L, "PST");
//        java.lang.String str29 = illegalFieldValueException28.getIllegalValueAsString();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 769 + "'", int21 == 769);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "334" + "'", str29.equals("334"));
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(2440591L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866846400000L) + "'", long1 == (-210866846400000L));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        java.util.Set<java.lang.String> strSet2 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean3 = julianChronology1.equals((java.lang.Object) strSet2);
        org.joda.time.DurationField durationField4 = julianChronology1.years();
        java.lang.String str5 = julianChronology1.toString();
        java.lang.String str6 = julianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology1.monthOfYear();
        org.joda.time.DurationField durationField8 = julianChronology1.millis();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JulianChronology[UTC]" + "'", str5.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JulianChronology[UTC]" + "'", str6.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(dateTimeZone7);
        int int9 = dateTime6.getMillisOfDay();
        org.joda.time.DateTime dateTime11 = dateTime6.plusHours((int) '4');
        org.joda.time.DateTime dateTime14 = dateTime6.withDurationAdded(1L, 62);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.withZoneRetainFields(dateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime14.yearOfEra();
        org.joda.time.DateTime dateTime18 = dateTime14.toDateTime();
        org.joda.time.ReadableDateTime readableDateTime19 = null;
        org.joda.time.chrono.LimitChronology limitChronology20 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology2, (org.joda.time.ReadableDateTime) dateTime14, readableDateTime19);
        java.lang.String str21 = limitChronology20.toString();
        org.joda.time.Chronology chronology22 = limitChronology20.withUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(limitChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "LimitChronology[GJChronology[UTC], 1970-01-01T00:00:00.072Z, NoLimit]" + "'", str21.equals("LimitChronology[GJChronology[UTC], 1970-01-01T00:00:00.072Z, NoLimit]"));
        org.junit.Assert.assertNotNull(chronology22);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test175");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gJChronology1.days();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
//        int int9 = skipDateTimeField8.getMinimumValue();
//        int int10 = skipDateTimeField8.getMinimumValue();
//        boolean boolean11 = skipDateTimeField8.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.dayOfYear();
//        org.joda.time.Instant instant14 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology16);
//        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.minuteOfDay();
//        int int20 = property19.get();
//        org.joda.time.MutableDateTime mutableDateTime22 = property19.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property19.getFieldType();
//        int int24 = instant14.get(dateTimeFieldType23);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType23, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8, dateTimeFieldType23, 2);
//        int int29 = remainderDateTimeField28.getMinimumValue();
//        long long31 = remainderDateTimeField28.roundHalfCeiling(2649599999L);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) remainderDateTimeField28);
//        int int33 = skipUndoDateTimeField32.getMinimumValue();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime();
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.plus(readablePeriod35);
//        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTime();
//        org.joda.time.YearMonthDay yearMonthDay38 = dateTime34.toYearMonthDay();
//        int int39 = skipUndoDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay38);
//        int int40 = skipUndoDateTimeField32.getMinimumValue();
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 769 + "'", int24 == 769);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2678400000L + "'", long31 == 2678400000L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(mutableDateTime37);
//        org.junit.Assert.assertNotNull(yearMonthDay38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test176");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int6 = skipDateTimeField5.getMinimumValue();
//        int int7 = skipDateTimeField5.getMinimumValue();
//        boolean boolean8 = skipDateTimeField5.isLenient();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfYear();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.minuteOfDay();
//        int int17 = property16.get();
//        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(2440588L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        int int21 = instant11.get(dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType20, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, dateTimeFieldType20, 2);
//        int int26 = remainderDateTimeField25.getMinimumValue();
//        long long28 = remainderDateTimeField25.roundHalfCeiling(2649599999L);
//        int int30 = remainderDateTimeField25.get(0L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 769 + "'", int21 == 769);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2678400000L + "'", long28 == 2678400000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//    }
//}

