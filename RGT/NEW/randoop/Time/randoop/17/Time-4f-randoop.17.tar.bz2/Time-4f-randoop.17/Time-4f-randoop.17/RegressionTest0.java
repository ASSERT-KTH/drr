import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Date date0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "hi!", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test004");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560639354053L + "'", long1 == 1560639354053L);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) '4', 0, (int) (short) 10, (int) (short) -1, (int) (byte) -1, (int) '#', chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        try {
            long long8 = copticChronology0.getDateTimeMillis((long) 100, 1, (int) (byte) 0, (-1), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) '4', (-1), (int) ' ', 0, 0, (int) (byte) 10, 10, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField6 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType4, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField11 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType0 };
        int[] intArray6 = new int[] { 10, (byte) -1, (byte) 1, 100 };
        try {
            org.joda.time.Partial partial7 = new org.joda.time.Partial(dateTimeFieldTypeArray1, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1L, (java.lang.Number) 100L, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (byte) 100, number2, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withHourOfDay((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeDivide((long) '#', (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "2019-W24-6T15:55:55.998-07:00", (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType5, 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter3.withOffsetParsed();
        try {
            org.joda.time.Instant instant5 = org.joda.time.Instant.parse("", dateTimeFormatter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) ' ');
        try {
            java.lang.String str10 = dateTime5.toString("2019-W24-6T15:55:55.998-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) '4', 82557322, 0, 292272708);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 82557374 + "'", int4 == 82557374);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2019-W24-6T15:55:55.998-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.year();
        try {
            long long12 = copticChronology0.getDateTimeMillis((int) ' ', (int) (short) 0, 292272708, 10, (int) '4', (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.DateTime.Property property7 = dateTime5.property(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 1, 292272808, 292272808, (int) (byte) 10, 82557374, 0, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82557374 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) -1);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.minusYears(82557374);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) ' ');
//        org.joda.time.DateTime dateTime10 = dateTime8.minusDays((int) (short) 0);
//        int int11 = dateTime10.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57 + "'", int11 == 57);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.util.Locale locale8 = null;
        try {
            long long9 = offsetDateTimeField5.set((long) 82557322, "2019-W24-6T15:55:55.998-07:00", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-W24-6T15:55:55.998-07:00\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("2019-W24-6T15:55:55.998-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-W24-6T15:55:55.998-07:00\" is malformed at \"-W24-6T15:55:55.998-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.Throwable throwable0 = null;
        try {
            boolean boolean1 = org.joda.time.IllegalInstantException.isIllegalInstant(throwable0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withHourOfDay(292272708);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292272708 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DurationField durationField3 = copticChronology0.years();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1786");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1786' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
//        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = property6.getAsShortText(locale7);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property6.getAsText(locale9);
//        java.util.Locale locale12 = null;
//        try {
//            org.joda.time.DateTime dateTime13 = property6.setCopy("", locale12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "68158950" + "'", str8.equals("68158950"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "68158950" + "'", str10.equals("68158950"));
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, (int) '4', (int) (byte) 1, (int) (short) 100, 0, (int) '#', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes((int) (short) 100);
        boolean boolean9 = dateTime7.isEqual((long) 0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DurationField durationField3 = copticChronology0.years();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(292272708, 82559, 0, 0, (int) (byte) 10, (int) (byte) -1, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
//        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = property6.getAsShortText(locale7);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property6.getAsText(locale9);
//        java.lang.String str11 = property6.getName();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "68159506" + "'", str8.equals("68159506"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "68159506" + "'", str10.equals("68159506"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long8 = gJChronology0.getDateTimeMillis(292272708, 82558, 1, 292272708, 82559, (int) (byte) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292272708 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DurationField durationField3 = copticChronology0.years();
        try {
            long long6 = durationField3.subtract((long) (byte) 10, (long) 82558);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) 1735, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.plusDays((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusMinutes((int) (short) 100);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.Chronology chronology12 = copticChronology10.withZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology10);
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours((int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, (int) '#');
        boolean boolean19 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime15);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) (-292269338));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        java.lang.String str11 = skipDateTimeField8.toString();
        int int13 = skipDateTimeField8.getLeapAmount((long) (-1));
        java.util.Locale locale16 = null;
        try {
            long long17 = skipDateTimeField8.set(1560639354053L, "2019-W24-6T15:55:55.998-07:00", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-W24-6T15:55:55.998-07:00\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTimeField[year]" + "'", str11.equals("DateTimeField[year]"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
        int int14 = skipDateTimeField8.getMinimumValue((long) 82557322);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292269337) + "'", int14 == (-292269337));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 82557374);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560639361448L + "'", long0 == 1560639361448L);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 82559);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField8.getWrappedField();
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology14.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology14);
        org.joda.time.DateTime dateTime19 = dateTime17.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) ' ');
        org.joda.time.DateTime dateTime24 = dateTime22.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay25 = dateTime22.toTimeOfDay();
        int int26 = skipDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay25);
        try {
            org.joda.time.DateTimeField dateTimeField28 = timeOfDay25.getField(82559);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 82559");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(timeOfDay25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-292269338) + "'", int26 == (-292269338));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        java.lang.String str11 = skipDateTimeField8.toString();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField8.getAsShortText(82557322, locale13);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = copticChronology15.year();
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.Chronology chronology21 = copticChronology19.withZone(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = copticChronology19.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology15, dateTimeField22);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = skipDateTimeField23.getMaximumValue(readablePartial24);
        long long27 = skipDateTimeField23.roundFloor((long) (byte) 1);
        org.joda.time.DateTimeField dateTimeField28 = skipDateTimeField23.getWrappedField();
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.Chronology chronology31 = copticChronology29.withZone(dateTimeZone30);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology29);
        org.joda.time.DateTime dateTime34 = dateTime32.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime37 = dateTime34.withPeriodAdded(readablePeriod35, (int) ' ');
        org.joda.time.DateTime dateTime39 = dateTime37.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay40 = dateTime37.toTimeOfDay();
        int int41 = skipDateTimeField23.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay40);
        java.util.Locale locale42 = null;
        try {
            java.lang.String str43 = skipDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) timeOfDay40, locale42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTimeField[year]" + "'", str11.equals("DateTimeField[year]"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "82557322" + "'", str14.equals("82557322"));
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 292272708 + "'", int25 == 292272708);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-9676800000L) + "'", long27 == (-9676800000L));
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(timeOfDay40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-292269338) + "'", int41 == (-292269338));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(57, 86399999, (int) (byte) 0, 82557374, 82559);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82557374 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(292272808, 6);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.append(dateTimePrinter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology2 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfEra(82557322, (-292269338));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, 82557374, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 10, 9, (int) (byte) 10, 100, (int) (short) 100, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(6, 0, 82557374, 292272808, 36, 292272708, 82557322, (org.joda.time.Chronology) julianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292272808 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology8);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        try {
            int[] intArray13 = copticChronology0.get(readablePeriod11, (-9676800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("68157617");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"68157617/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 1136);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(292272708, (int) (short) 100, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.plusDays((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.withZone(dateTimeZone8);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology2);
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            boolean boolean5 = partial3.isMatch(readablePartial4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "68157617");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfWeek();
        java.util.Locale locale5 = null;
        try {
            org.joda.time.DateTime dateTime6 = property3.setCopy("68159968", locale5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"68159968\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) 'a');
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType5, (int) (short) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 9, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-91L) + "'", long2 == (-91L));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter0.parseLocalDate("68159506");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"68159506\" is malformed at \"6\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendOptional(dateTimeParser3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusYears(0);
        try {
            org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusYears(0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears((int) (short) 100);
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.DurationField durationField5 = copticChronology0.eras();
        try {
            long long11 = copticChronology0.getDateTimeMillis((long) 1735, (-292269337), (int) (byte) 100, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269337 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.DurationField durationField11 = copticChronology0.centuries();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology0);
        try {
            org.joda.time.LocalDate localDate14 = localDate12.withDayOfYear((-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for dayOfYear must be in the range [1,366]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = copticChronology13.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology13);
        org.joda.time.DateTime dateTime18 = dateTime16.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.withPeriodAdded(readablePeriod19, (int) ' ');
        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay24 = dateTime21.toTimeOfDay();
        int[] intArray28 = new int[] { (short) 0, 82558, 82557322 };
        int int29 = skipDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay24, intArray28);
        try {
            org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) timeOfDay24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.TimeOfDay");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(timeOfDay24);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292272708 + "'", int29 == 292272708);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Partial partial6 = partial3.withFieldAdded(durationFieldType4, 1735);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(292272808, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendPattern("DateTimeField[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "68165409");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
//        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
//        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField8.getWrappedField();
//        org.joda.time.Partial partial14 = new org.joda.time.Partial();
//        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((int) (byte) 100);
//        org.joda.time.DateTime.Property property21 = dateTime20.millisOfDay();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = property21.getAsShortText(locale22);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = property21.getAsText(locale24);
//        int int26 = property21.getMaximumValueOverall();
//        int int27 = property21.getLeapAmount();
//        java.lang.String str28 = property21.getAsShortText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property21.getFieldType();
//        int int30 = partial14.indexOf(dateTimeFieldType29);
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField31 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8, dateTimeFieldType29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(copticChronology15);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "68167649" + "'", str23.equals("68167649"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "68167649" + "'", str25.equals("68167649"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 86399999 + "'", int26 == 86399999);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "68167649" + "'", str28.equals("68167649"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded(readableDuration6, (int) (short) 100);
        org.joda.time.DateTime dateTime10 = dateTime3.plusMonths(0);
        try {
            org.joda.time.DateTime dateTime12 = dateTime3.withMillisOfSecond(292272708);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292272708 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        try {
            long long12 = gregorianChronology0.getDateTimeMillis((int) '#', 0, (int) (short) 1, 0, 86399999, 82557374, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = copticChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.year();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = copticChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology5.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = skipDateTimeField9.getMaximumValue(readablePartial10);
        long long13 = skipDateTimeField9.roundFloor((long) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = skipDateTimeField9.getWrappedField();
        org.joda.time.DurationField durationField15 = skipDateTimeField9.getLeapDurationField();
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.Chronology chronology18 = copticChronology16.withZone(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = copticChronology16.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) 100);
        long long24 = offsetDateTimeField21.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField21.getAsText((long) '#', locale26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField21.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField15, dateTimeFieldType28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 292272708 + "'", int11 == 292272708);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-9676800000L) + "'", long13 == (-9676800000L));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1786" + "'", str27.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.DurationField durationField11 = copticChronology0.centuries();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology0);
        try {
            org.joda.time.LocalDate localDate14 = localDate12.withDayOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,366]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded(readableDuration6, (int) (short) 100);
        org.joda.time.DateTime.Property property9 = dateTime3.dayOfYear();
        org.joda.time.DurationField durationField10 = property9.getRangeDurationField();
        java.util.Locale locale12 = null;
        try {
            org.joda.time.DateTime dateTime13 = property9.setCopy("68161520", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 68161520 for dayOfYear must be in the range [1,366]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(durationField10);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = julianChronology1.toString();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        try {
            long long13 = skipDateTimeField8.add((long) 57, (-292269337));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField8.getWrappedField();
        try {
            long long16 = skipDateTimeField8.set(1L, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) -1);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = copticChronology11.withZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology11);
        org.joda.time.DateTime dateTime16 = dateTime14.minusHours((int) (byte) 100);
        boolean boolean17 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime19 = dateTime14.plus(readableDuration18);
        try {
            org.joda.time.DateTime dateTime21 = dateTime19.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime19);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
//        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
//        java.lang.String str7 = property6.getAsShortText();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "68168620" + "'", str7.equals("68168620"));
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        try {
            org.joda.time.LocalDate localDate11 = localDate7.withMonthOfYear((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded(readableDuration6, (int) (short) 100);
        org.joda.time.DateTime dateTime10 = dateTime3.plusMonths(0);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime13 = dateTime10.withEra((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [1,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withSecondOfMinute(86399999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) -1, (int) (byte) 1, (int) (byte) -1, 86399999, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.Chronology chronology10 = copticChronology8.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology8.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology4, dateTimeField11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = skipDateTimeField12.getMaximumValue(readablePartial13);
        long long16 = skipDateTimeField12.roundFloor((long) (byte) 1);
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.Chronology chronology19 = copticChronology17.withZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology17);
        org.joda.time.DateTime dateTime22 = dateTime20.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.withPeriodAdded(readablePeriod23, (int) ' ');
        org.joda.time.DateTime dateTime27 = dateTime25.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay28 = dateTime25.toTimeOfDay();
        int[] intArray32 = new int[] { (short) 0, 82558, 82557322 };
        int int33 = skipDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay28, intArray32);
        try {
            boolean boolean34 = partial3.isEqual((org.joda.time.ReadablePartial) timeOfDay28);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 292272708 + "'", int14 == 292272708);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-9676800000L) + "'", long16 == (-9676800000L));
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(timeOfDay28);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 292272708 + "'", int33 == 292272708);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
//        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
//        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField8.getWrappedField();
//        org.joda.time.Partial partial14 = new org.joda.time.Partial();
//        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((int) (byte) 100);
//        org.joda.time.DateTime.Property property21 = dateTime20.millisOfDay();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = property21.getAsShortText(locale22);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = property21.getAsText(locale24);
//        int int26 = property21.getMaximumValueOverall();
//        int int27 = property21.getLeapAmount();
//        java.lang.String str28 = property21.getAsShortText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property21.getFieldType();
//        int int30 = partial14.indexOf(dateTimeFieldType29);
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.Partial partial32 = partial14.plus(readablePeriod31);
//        java.util.Locale locale33 = null;
//        try {
//            java.lang.String str34 = skipDateTimeField8.getAsText((org.joda.time.ReadablePartial) partial14, locale33);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(copticChronology15);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "68169295" + "'", str23.equals("68169295"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "68169295" + "'", str25.equals("68169295"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 86399999 + "'", int26 == 86399999);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "68169295" + "'", str28.equals("68169295"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(partial32);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(82557374, 57, 18, (int) ' ', (int) '#', 0, (int) (byte) 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("68166935");
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866673600000L) + "'", long1 == (-210866673600000L));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("Property[dayOfWeek]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'Property[dayOfWeek]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
        try {
            org.joda.time.DateTime dateTime4 = dateTime1.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusYears(0);
//        long long4 = dateTime1.getMillis();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560639369835L + "'", long4 == 1560639369835L);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField5.getMaximumValue(readablePartial6);
        java.lang.String str9 = offsetDateTimeField5.getAsText((long) 'a');
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getLeapDurationField();
        try {
            long long13 = offsetDateTimeField5.add((-210866673600000L), (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292272808 + "'", int7 == 292272808);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1786" + "'", str9.equals("1786"));
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime1.era();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField5.getAsText((long) (short) 100, locale7);
        long long10 = offsetDateTimeField5.roundCeiling((long) 1136);
        org.joda.time.DurationField durationField11 = offsetDateTimeField5.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.Chronology chronology14 = dateTime13.getChronology();
        org.joda.time.Partial partial15 = new org.joda.time.Partial(chronology14);
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.Chronology chronology19 = copticChronology17.withZone(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology17.year();
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology21.withZone(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = copticChronology21.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology17, dateTimeField24);
        org.joda.time.ReadablePartial readablePartial26 = null;
        int int27 = skipDateTimeField25.getMaximumValue(readablePartial26);
        long long29 = skipDateTimeField25.roundFloor((long) (byte) 1);
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.Chronology chronology32 = copticChronology30.withZone(dateTimeZone31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology30);
        org.joda.time.DateTime dateTime35 = dateTime33.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime35.withPeriodAdded(readablePeriod36, (int) ' ');
        org.joda.time.DateTime dateTime40 = dateTime38.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay41 = dateTime38.toTimeOfDay();
        int[] intArray45 = new int[] { (short) 0, 82558, 82557322 };
        int int46 = skipDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay41, intArray45);
        try {
            int[] intArray48 = offsetDateTimeField5.addWrapField((org.joda.time.ReadablePartial) partial15, (int) '#', intArray45, 82557322);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1786" + "'", str8.equals("1786"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 21859200000L + "'", long10 == 21859200000L);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 292272708 + "'", int27 == 292272708);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-9676800000L) + "'", long29 == (-9676800000L));
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(timeOfDay41);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 292272708 + "'", int46 == 292272708);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.DurationField durationField11 = copticChronology0.centuries();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology0);
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        org.joda.time.DateMidnight dateMidnight15 = localDate12.toDateMidnight(dateTimeZone14);
        try {
            java.lang.String str17 = localDate12.toString("millisOfDay");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateMidnight15);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 18);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate.Property property10 = localDate9.year();
        int int11 = property10.getMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-292269337) + "'", int11 == (-292269337));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.plusDays((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusMinutes((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        boolean boolean9 = dateTime7.isAfter((long) 1735);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (byte) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 9, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property6.addToCopy(0L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField5.getMaximumValue(readablePartial6);
        java.lang.String str9 = offsetDateTimeField5.getAsText((long) 'a');
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField5.getAsShortText((long) 82557322, locale11);
        long long15 = offsetDateTimeField5.set((-91L), 292272808);
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.Chronology chronology18 = copticChronology16.withZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology16);
        org.joda.time.DateTime dateTime21 = dateTime19.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime22 = dateTime21.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate25 = localDate23.plus(readablePeriod24);
        org.joda.time.LocalDate.Property property26 = localDate25.dayOfWeek();
        org.joda.time.DateTime dateTime27 = localDate25.toDateTimeAtMidnight();
        int[] intArray33 = new int[] { (byte) 1, (-28800000), 292272808, 4 };
        try {
            int[] intArray35 = offsetDateTimeField5.set((org.joda.time.ReadablePartial) localDate25, (-292269337), intArray33, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -292269337");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292272808 + "'", int7 == 292272808);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1786" + "'", str9.equals("1786"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1786" + "'", str12.equals("1786"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372003910399909L + "'", long15 == 9223372003910399909L);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitYear(82557322);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHourOfHalfday((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = copticChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfDay();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property7.getAsShortText(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        int int12 = property7.getMaximumValueOverall();
        int int13 = property7.getLeapAmount();
        java.lang.String str14 = property7.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property7.getFieldType();
        int int16 = partial0.indexOf(dateTimeFieldType15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.Partial partial18 = partial0.plus(readablePeriod17);
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.Chronology chronology21 = copticChronology19.withZone(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = copticChronology19.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 100);
        long long27 = offsetDateTimeField24.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField24.getAsText((long) '#', locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField24.getType();
        try {
            org.joda.time.Partial partial33 = partial0.withField(dateTimeFieldType31, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "72000018" + "'", str9.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "72000018" + "'", str11.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399999 + "'", int12 == 86399999);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "72000018" + "'", str14.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(partial18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1786" + "'", str30.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitYear(82557322);
        org.joda.time.format.DateTimeParser dateTimeParser7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.append(dateTimeParser7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "68159506");
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsShortText(locale7);
        java.util.Locale locale9 = null;
        java.lang.String str10 = property6.getAsText(locale9);
        org.joda.time.DurationField durationField11 = property6.getRangeDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "72000018" + "'", str8.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "72000018" + "'", str10.equals("72000018"));
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundHalfEven((long) 292272708);
        java.lang.String str13 = skipDateTimeField8.toString();
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property21 = dateTime20.millisOfDay();
        java.util.Locale locale22 = null;
        java.lang.String str23 = property21.getAsShortText(locale22);
        java.util.Locale locale24 = null;
        java.lang.String str25 = property21.getAsText(locale24);
        int int26 = property21.getMaximumValueOverall();
        int int27 = property21.getLeapAmount();
        java.lang.String str28 = property21.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property21.getFieldType();
        int int30 = partial14.indexOf(dateTimeFieldType29);
        java.util.Locale locale31 = null;
        try {
            java.lang.String str32 = skipDateTimeField8.getAsText((org.joda.time.ReadablePartial) partial14, locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[year]" + "'", str13.equals("DateTimeField[year]"));
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "72000018" + "'", str23.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "72000018" + "'", str25.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 86399999 + "'", int26 == 86399999);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "72000018" + "'", str28.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = copticChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology5);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.withDurationAdded(readableDuration18, (int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime15.plusMonths(0);
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology4, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime22);
        java.lang.String str25 = dateTime11.toString("68162380");
        org.joda.time.DateTime dateTime27 = dateTime11.withWeekyear(9);
        java.util.Locale locale29 = null;
        java.lang.String str30 = dateTime27.toString("68162380", locale29);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(limitChronology23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "68162380" + "'", str25.equals("68162380"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "68162380" + "'", str30.equals("68162380"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.Object obj0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTime();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        try {
            org.joda.time.LocalDate localDate11 = localDate7.minusMonths(57370);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded(readableDuration6, (int) (short) 100);
        org.joda.time.DateTime.Property property9 = dateTime3.dayOfYear();
        int int10 = property9.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) '#', locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        org.joda.time.Partial partial13 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology14.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology14);
        org.joda.time.DateTime dateTime19 = dateTime17.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property20 = dateTime19.millisOfDay();
        java.util.Locale locale21 = null;
        java.lang.String str22 = property20.getAsShortText(locale21);
        java.util.Locale locale23 = null;
        java.lang.String str24 = property20.getAsText(locale23);
        int int25 = property20.getMaximumValueOverall();
        int int26 = property20.getLeapAmount();
        java.lang.String str27 = property20.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property20.getFieldType();
        int int29 = partial13.indexOf(dateTimeFieldType28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.Partial partial31 = partial13.plus(readablePeriod30);
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.Chronology chronology34 = copticChronology32.withZone(dateTimeZone33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology32);
        org.joda.time.DateTime dateTime37 = dateTime35.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property38 = dateTime37.millisOfDay();
        java.util.Locale locale39 = null;
        java.lang.String str40 = property38.getAsShortText(locale39);
        java.util.Locale locale41 = null;
        java.lang.String str42 = property38.getAsText(locale41);
        int int43 = property38.getMaximumValueOverall();
        int int44 = property38.getLeapAmount();
        java.lang.String str45 = property38.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property38.getFieldType();
        org.joda.time.Partial partial47 = partial31.without(dateTimeFieldType46);
        org.joda.time.chrono.CopticChronology copticChronology48 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.Chronology chronology50 = copticChronology48.withZone(dateTimeZone49);
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology48);
        org.joda.time.DateTime dateTime53 = dateTime51.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property54 = dateTime53.millisOfDay();
        java.util.Locale locale55 = null;
        java.lang.String str56 = property54.getAsShortText(locale55);
        java.util.Locale locale57 = null;
        java.lang.String str58 = property54.getAsText(locale57);
        int int59 = property54.getMaximumValueOverall();
        int int60 = property54.getLeapAmount();
        java.lang.String str61 = property54.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property54.getFieldType();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray63 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType12, dateTimeFieldType46, dateTimeFieldType62 };
        org.joda.time.chrono.CopticChronology copticChronology64 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.Chronology chronology66 = copticChronology64.withZone(dateTimeZone65);
        org.joda.time.DateTimeField dateTimeField67 = copticChronology64.year();
        org.joda.time.chrono.CopticChronology copticChronology68 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone69 = null;
        org.joda.time.Chronology chronology70 = copticChronology68.withZone(dateTimeZone69);
        org.joda.time.DateTimeField dateTimeField71 = copticChronology68.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField72 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology64, dateTimeField71);
        org.joda.time.ReadablePartial readablePartial73 = null;
        int int74 = skipDateTimeField72.getMaximumValue(readablePartial73);
        long long76 = skipDateTimeField72.roundFloor((long) (byte) 1);
        org.joda.time.chrono.CopticChronology copticChronology77 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone78 = null;
        org.joda.time.Chronology chronology79 = copticChronology77.withZone(dateTimeZone78);
        org.joda.time.DateTime dateTime80 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology77);
        org.joda.time.DateTime dateTime82 = dateTime80.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod83 = null;
        org.joda.time.DateTime dateTime85 = dateTime82.withPeriodAdded(readablePeriod83, (int) ' ');
        org.joda.time.DateTime dateTime87 = dateTime85.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay88 = dateTime85.toTimeOfDay();
        int[] intArray92 = new int[] { (short) 0, 82558, 82557322 };
        int int93 = skipDateTimeField72.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay88, intArray92);
        try {
            org.joda.time.Partial partial94 = new org.joda.time.Partial(dateTimeFieldTypeArray63, intArray92);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not contain duplicate: millisOfDay");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1786" + "'", str11.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "72000018" + "'", str22.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "72000018" + "'", str24.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 86399999 + "'", int25 == 86399999);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "72000018" + "'", str27.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(partial31);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "72000018" + "'", str40.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "72000018" + "'", str42.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 86399999 + "'", int43 == 86399999);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "72000018" + "'", str45.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(partial47);
        org.junit.Assert.assertNotNull(copticChronology48);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "72000018" + "'", str56.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "72000018" + "'", str58.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 86399999 + "'", int59 == 86399999);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "72000018" + "'", str61.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray63);
        org.junit.Assert.assertNotNull(copticChronology64);
        org.junit.Assert.assertNotNull(chronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(copticChronology68);
        org.junit.Assert.assertNotNull(chronology70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 292272708 + "'", int74 == 292272708);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-9676800000L) + "'", long76 == (-9676800000L));
        org.junit.Assert.assertNotNull(copticChronology77);
        org.junit.Assert.assertNotNull(chronology79);
        org.junit.Assert.assertNotNull(dateTime82);
        org.junit.Assert.assertNotNull(dateTime85);
        org.junit.Assert.assertNotNull(dateTime87);
        org.junit.Assert.assertNotNull(timeOfDay88);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 292272708 + "'", int93 == 292272708);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(57367, true);
        boolean boolean7 = dateTimeFormatterBuilder6.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((java.lang.Object) gJChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(1, 82563);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 82563");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField8.getWrappedField();
        org.joda.time.DurationField durationField14 = skipDateTimeField8.getLeapDurationField();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        long long24 = copticChronology15.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology15.year();
        org.joda.time.DurationField durationField26 = copticChronology15.centuries();
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology15);
        java.util.TimeZone timeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forTimeZone(timeZone28);
        org.joda.time.DateMidnight dateMidnight30 = localDate27.toDateMidnight(dateTimeZone29);
        java.util.Locale locale31 = null;
        java.lang.String str32 = skipDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate27, locale31);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.Chronology chronology35 = copticChronology33.withZone(dateTimeZone34);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology33);
        org.joda.time.DateTime dateTime38 = dateTime36.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime38.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate40 = dateTime39.toLocalDate();
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.Chronology chronology44 = copticChronology42.withZone(dateTimeZone43);
        org.joda.time.DateTimeField dateTimeField45 = copticChronology42.year();
        org.joda.time.chrono.CopticChronology copticChronology46 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.Chronology chronology48 = copticChronology46.withZone(dateTimeZone47);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology46.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField50 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology42, dateTimeField49);
        org.joda.time.ReadablePartial readablePartial51 = null;
        int int52 = skipDateTimeField50.getMaximumValue(readablePartial51);
        long long54 = skipDateTimeField50.roundFloor((long) (byte) 1);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.Chronology chronology57 = copticChronology55.withZone(dateTimeZone56);
        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology55);
        org.joda.time.DateTime dateTime60 = dateTime58.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod61 = null;
        org.joda.time.DateTime dateTime63 = dateTime60.withPeriodAdded(readablePeriod61, (int) ' ');
        org.joda.time.DateTime dateTime65 = dateTime63.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay66 = dateTime63.toTimeOfDay();
        int[] intArray70 = new int[] { (short) 0, 82558, 82557322 };
        int int71 = skipDateTimeField50.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay66, intArray70);
        java.util.Locale locale73 = null;
        try {
            int[] intArray74 = skipDateTimeField8.set((org.joda.time.ReadablePartial) localDate40, 86399999, intArray70, "org.joda.time.IllegalFieldValueException: Value 100 for GregorianChronology[UTC] must be in the range [292272708,-1]", locale73);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value 100 for GregorianChronology[UTC] must be in the range [292272708,-1]\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3121000L + "'", long24 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateMidnight30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1686" + "'", str32.equals("1686"));
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(copticChronology46);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 292272708 + "'", int52 == 292272708);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-9676800000L) + "'", long54 == (-9676800000L));
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(timeOfDay66);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 292272708 + "'", int71 == 292272708);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsShortText(locale7);
        org.joda.time.DateTime dateTime9 = property6.withMaximumValue();
        org.joda.time.DateTimeField dateTimeField10 = property6.getField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "72000018" + "'", str8.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        org.joda.time.DateTime dateTime15 = dateTime11.toDateTime(dateTimeZone14);
//        int int17 = dateTimeZone14.getOffsetFromLocal((long) (byte) 100);
//        org.joda.time.DateTime dateTime18 = localDate7.toDateTimeAtStartOfDay(dateTimeZone14);
//        try {
//            org.joda.time.LocalDate localDate20 = localDate7.withWeekyear(292272808);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292272808 for weekyear must be in the range [-292269338,292272708]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.DurationField durationField5 = copticChronology0.eras();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.minuteOfHour();
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.Chronology chronology9 = copticChronology7.withZone(dateTimeZone8);
        org.joda.time.DurationField durationField10 = copticChronology7.weeks();
        org.joda.time.Partial partial11 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTime dateTime17 = dateTime15.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property18 = dateTime17.millisOfDay();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsShortText(locale19);
        java.util.Locale locale21 = null;
        java.lang.String str22 = property18.getAsText(locale21);
        int int23 = property18.getMaximumValueOverall();
        int int24 = property18.getLeapAmount();
        java.lang.String str25 = property18.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property18.getFieldType();
        int int27 = partial11.indexOf(dateTimeFieldType26);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField6, durationField10, dateTimeFieldType26, (-292269337));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "72000018" + "'", str20.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "72000018" + "'", str22.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 86399999 + "'", int23 == 86399999);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "72000018" + "'", str25.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 1);
//        java.lang.Appendable appendable3 = null;
//        try {
//            dateTimeFormatter0.printTo(appendable3, (long) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970W013T160000-0800" + "'", str2.equals("1970W013T160000-0800"));
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial3.minus(readablePeriod4);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(partial5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField5.getMaximumValue(readablePartial6);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '#', 9, 292272808);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime18 = dateTime17.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate19 = dateTime18.toLocalDate();
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology21.withZone(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = copticChronology21.year();
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.Chronology chronology27 = copticChronology25.withZone(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = copticChronology25.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology21, dateTimeField28);
        org.joda.time.ReadablePartial readablePartial30 = null;
        int int31 = skipDateTimeField29.getMaximumValue(readablePartial30);
        long long33 = skipDateTimeField29.roundFloor((long) (byte) 1);
        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.Chronology chronology36 = copticChronology34.withZone(dateTimeZone35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology34);
        org.joda.time.DateTime dateTime39 = dateTime37.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.DateTime dateTime42 = dateTime39.withPeriodAdded(readablePeriod40, (int) ' ');
        org.joda.time.DateTime dateTime44 = dateTime42.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay45 = dateTime42.toTimeOfDay();
        int[] intArray49 = new int[] { (short) 0, 82558, 82557322 };
        int int50 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay45, intArray49);
        try {
            int[] intArray52 = offsetDateTimeField5.addWrapField((org.joda.time.ReadablePartial) localDate19, (-292269338), intArray49, (-292269337));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -292269338");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292272808 + "'", int7 == 292272808);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 292272708 + "'", int31 == 292272708);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-9676800000L) + "'", long33 == (-9676800000L));
        org.junit.Assert.assertNotNull(copticChronology34);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(timeOfDay45);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 292272708 + "'", int50 == 292272708);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = copticChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfDay();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property7.getAsShortText(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        int int12 = property7.getMaximumValueOverall();
        int int13 = property7.getLeapAmount();
        java.lang.String str14 = property7.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property7.getFieldType();
        int int16 = partial0.indexOf(dateTimeFieldType15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.Partial partial18 = partial0.plus(readablePeriod17);
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.Chronology chronology21 = copticChronology19.withZone(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = copticChronology19.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 100);
        long long27 = offsetDateTimeField24.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField24.getAsText((long) '#', locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField24.getType();
        try {
            org.joda.time.Partial.Property property32 = partial0.property(dateTimeFieldType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "72000018" + "'", str9.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "72000018" + "'", str11.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399999 + "'", int12 == 86399999);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "72000018" + "'", str14.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(partial18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1786" + "'", str30.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("DateTimeField[year]", 1200, (int) '4', (-292269337));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1200 for DateTimeField[year] must be in the range [52,-292269337]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.ReadablePartial readablePartial11 = null;
        try {
            boolean boolean12 = localDate9.isAfter(readablePartial11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsShortText(locale7);
        org.joda.time.DateTime dateTime9 = property6.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime10 = property6.roundCeilingCopy();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "72000018" + "'", str8.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (byte) 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText((long) '#', locale12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7);
        java.util.Locale locale17 = null;
        try {
            long long18 = offsetDateTimeField7.set((long) 36, "Pacific Standard Time", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Pacific Standard Time\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1786" + "'", str13.equals("1786"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (byte) 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText((long) '#', locale12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = copticChronology15.year();
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.Chronology chronology21 = copticChronology19.withZone(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = copticChronology19.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology15, dateTimeField22);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = skipDateTimeField23.getMaximumValue(readablePartial24);
        long long27 = skipDateTimeField23.roundFloor((long) (byte) 1);
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.Chronology chronology30 = copticChronology28.withZone(dateTimeZone29);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology28);
        org.joda.time.DateTime dateTime33 = dateTime31.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.DateTime dateTime36 = dateTime33.withPeriodAdded(readablePeriod34, (int) ' ');
        org.joda.time.DateTime dateTime38 = dateTime36.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay39 = dateTime36.toTimeOfDay();
        int[] intArray43 = new int[] { (short) 0, 82558, 82557322 };
        int int44 = skipDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay39, intArray43);
        org.joda.time.Partial partial46 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology47 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.Chronology chronology49 = copticChronology47.withZone(dateTimeZone48);
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology47);
        org.joda.time.DateTime dateTime52 = dateTime50.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property53 = dateTime52.millisOfDay();
        java.util.Locale locale54 = null;
        java.lang.String str55 = property53.getAsShortText(locale54);
        java.util.Locale locale56 = null;
        java.lang.String str57 = property53.getAsText(locale56);
        int int58 = property53.getMaximumValueOverall();
        int int59 = property53.getLeapAmount();
        java.lang.String str60 = property53.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = property53.getFieldType();
        int int62 = partial46.indexOf(dateTimeFieldType61);
        org.joda.time.ReadablePeriod readablePeriod63 = null;
        org.joda.time.Partial partial64 = partial46.plus(readablePeriod63);
        org.joda.time.chrono.CopticChronology copticChronology65 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.Chronology chronology67 = copticChronology65.withZone(dateTimeZone66);
        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology65);
        org.joda.time.DateTime dateTime70 = dateTime68.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property71 = dateTime70.millisOfDay();
        java.util.Locale locale72 = null;
        java.lang.String str73 = property71.getAsShortText(locale72);
        java.util.Locale locale74 = null;
        java.lang.String str75 = property71.getAsText(locale74);
        int int76 = property71.getMaximumValueOverall();
        int int77 = property71.getLeapAmount();
        java.lang.String str78 = property71.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = property71.getFieldType();
        org.joda.time.Partial partial80 = partial64.without(dateTimeFieldType79);
        int[] intArray81 = partial64.getValues();
        try {
            int[] intArray83 = offsetDateTimeField7.addWrapField((org.joda.time.ReadablePartial) timeOfDay39, 36, intArray81, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 36");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1786" + "'", str13.equals("1786"));
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 292272708 + "'", int25 == 292272708);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-9676800000L) + "'", long27 == (-9676800000L));
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(timeOfDay39);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 292272708 + "'", int44 == 292272708);
        org.junit.Assert.assertNotNull(copticChronology47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "72000018" + "'", str55.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "72000018" + "'", str57.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 86399999 + "'", int58 == 86399999);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "72000018" + "'", str60.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(partial64);
        org.junit.Assert.assertNotNull(copticChronology65);
        org.junit.Assert.assertNotNull(chronology67);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(property71);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "72000018" + "'", str73.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "72000018" + "'", str75.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 86399999 + "'", int76 == 86399999);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "72000018" + "'", str78.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertNotNull(partial80);
        org.junit.Assert.assertNotNull(intArray81);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "68166935");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.DurationField durationField11 = copticChronology0.centuries();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField13 = new org.joda.time.field.DecoratedDurationField(durationField11, durationFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology2);
        org.joda.time.Chronology chronology4 = partial3.getChronology();
        java.util.Locale locale6 = null;
        try {
            java.lang.String str7 = partial3.toString("year", locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral("");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        java.lang.Appendable appendable4 = null;
        try {
            dateTimeFormatter2.printTo(appendable4, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("68168988");
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra(0);
        try {
            org.joda.time.LocalDate localDate5 = localDate3.withWeekOfWeekyear(1686);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1686 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField5.getMaximumValue(readablePartial6);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField5.getMaximumShortTextLength(locale8);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.parse("68168988");
        int[] intArray15 = new int[] { (-292269337), '4' };
        java.util.Locale locale17 = null;
        try {
            int[] intArray18 = offsetDateTimeField5.set((org.joda.time.ReadablePartial) localDate11, (int) (byte) 10, intArray15, "millisOfDay", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"millisOfDay\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292272808 + "'", int7 == 292272808);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(intArray15);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        org.joda.time.DateTime dateTime15 = dateTime11.toDateTime(dateTimeZone14);
//        int int17 = dateTimeZone14.getOffsetFromLocal((long) (byte) 100);
//        org.joda.time.DateTime dateTime18 = localDate7.toDateTimeAtStartOfDay(dateTimeZone14);
//        try {
//            org.joda.time.DateTimeFieldType dateTimeFieldType20 = localDate7.getFieldType((-292269337));
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: -292269337");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology2.withZone(dateTimeZone5);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.Chronology chronology9 = copticChronology7.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology7);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime13 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology14.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology14);
        org.joda.time.DateTime dateTime19 = dateTime17.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime22 = dateTime17.withDurationAdded(readableDuration20, (int) (short) 100);
        org.joda.time.DateTime dateTime24 = dateTime17.plusMonths(0);
        org.joda.time.chrono.LimitChronology limitChronology25 = org.joda.time.chrono.LimitChronology.getInstance(chronology6, (org.joda.time.ReadableDateTime) dateTime13, (org.joda.time.ReadableDateTime) dateTime24);
        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.Chronology chronology28 = copticChronology26.withZone(dateTimeZone27);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology26);
        org.joda.time.DateTime dateTime31 = dateTime29.plusDays((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
        org.joda.time.chrono.LimitChronology limitChronology34 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, (org.joda.time.ReadableDateTime) dateTime13, (org.joda.time.ReadableDateTime) dateTime33);
        int int35 = dateTime33.getCenturyOfEra();
        try {
            org.joda.time.DateTime dateTime37 = dateTime33.withWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(limitChronology25);
        org.junit.Assert.assertNotNull(copticChronology26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(limitChronology34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 17 + "'", int35 == 17);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField5.getAsText((long) (short) 100, locale7);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getRangeDurationField();
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.DurationField durationField11 = offsetDateTimeField5.getRangeDurationField();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTime dateTime17 = dateTime15.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) ' ');
        org.joda.time.DateTime dateTime22 = dateTime20.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime20.toTimeOfDay();
        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.Chronology chronology26 = copticChronology24.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology24);
        org.joda.time.DateTime dateTime29 = dateTime27.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) ' ');
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) -1);
        boolean boolean35 = timeOfDay23.equals((java.lang.Object) (short) -1);
        int[] intArray37 = new int[] {};
        java.util.Locale locale39 = null;
        try {
            int[] intArray40 = offsetDateTimeField5.set((org.joda.time.ReadablePartial) timeOfDay23, 9, intArray37, "", locale39);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1786" + "'", str8.equals("1786"));
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertNotNull(copticChronology24);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("68159968");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '68159968' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsShortText(locale7);
        int int9 = property6.get();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "72000018" + "'", str8.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 72000018 + "'", int9 == 72000018);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean3 = gJChronology0.equals((java.lang.Object) dateTimeZone1);
        try {
            long long11 = gJChronology0.getDateTimeMillis((int) (byte) 1, 35, 292272708, 10, 9, 1735, (-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1735 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField8.getWrappedField();
        boolean boolean14 = skipDateTimeField8.isLenient();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8);
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.Chronology chronology18 = copticChronology16.withZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology16);
        org.joda.time.DateTime dateTime21 = dateTime19.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime22 = dateTime21.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate25 = localDate23.plus(readablePeriod24);
        int[] intArray28 = new int[] { 1686 };
        try {
            int[] intArray30 = delegatedDateTimeField15.addWrapField((org.joda.time.ReadablePartial) localDate23, 82557374, intArray28, 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 82557374");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Property[dayOfWeek]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Property[dayOfWeek]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) -1);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = copticChronology11.withZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology11);
        org.joda.time.DateTime dateTime16 = dateTime14.minusHours((int) (byte) 100);
        boolean boolean17 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime14);
        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime10);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2764801018L + "'", long18 == 2764801018L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime5 = dateTime1.withDayOfMonth(1686);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1686 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("68164274");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"68164274\" is malformed at \"4\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 35, (-292269338));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.DurationField durationField11 = copticChronology0.centuries();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology0);
        int int13 = localDate12.getYear();
        java.util.Date date14 = localDate12.toDate();
        org.joda.time.Interval interval15 = localDate12.toInterval();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1686 + "'", int13 == 1686);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(interval15);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = dateTimeFormatter3.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 1560639354053L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "68168620");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (byte) 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText((long) '#', locale12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7);
        try {
            int int16 = skipDateTimeField14.get((-210866673600000L));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1786" + "'", str13.equals("1786"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsShortText(locale7);
        org.joda.time.DateTime dateTime9 = property6.roundHalfFloorCopy();
        int int10 = dateTime9.getMinuteOfDay();
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = copticChronology11.withZone(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology11.year();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = copticChronology15.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology11, dateTimeField18);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.Chronology chronology21 = copticChronology11.withZone(dateTimeZone20);
        org.joda.time.DurationField durationField22 = copticChronology11.days();
        org.joda.time.DateTime dateTime23 = dateTime9.withChronology((org.joda.time.Chronology) copticChronology11);
        int int24 = dateTime23.getEra();
        try {
            org.joda.time.DateTime dateTime28 = dateTime23.withDate(35, (-1), 1136);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "72000018" + "'", str8.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1200 + "'", int10 == 1200);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "68159506");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("68168988");
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra(0);
        try {
            org.joda.time.LocalDate localDate5 = localDate1.withWeekOfWeekyear(1200);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1200 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 1560639354053L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        try {
            org.joda.time.LocalDate localDate12 = localDate9.withYearOfCentury((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfCentury must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(292272808, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendPattern("");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder7.appendTimeZoneOffset("68158846", "68157617", false, 57, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.seconds();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 292272708);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440591L + "'", long1 == 2440591L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (-1), (long) (-292269339));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 292269338L + "'", long2 == 292269338L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DurationField durationField3 = copticChronology0.weeks();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (byte) 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText((long) '#', locale12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1786" + "'", str13.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField5.getMaximumValue(readablePartial6);
        try {
            long long10 = offsetDateTimeField5.set((long) (byte) -1, "Property[dayOfWeek]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[dayOfWeek]\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292272808 + "'", int7 == 292272808);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = copticChronology13.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology13);
        org.joda.time.DateTime dateTime18 = dateTime16.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.withPeriodAdded(readablePeriod19, (int) ' ');
        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay24 = dateTime21.toTimeOfDay();
        int[] intArray28 = new int[] { (short) 0, 82558, 82557322 };
        int int29 = skipDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay24, intArray28);
        org.joda.time.Partial partial30 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology31 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.Chronology chronology33 = copticChronology31.withZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology31);
        org.joda.time.DateTime dateTime36 = dateTime34.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property37 = dateTime36.millisOfDay();
        java.util.Locale locale38 = null;
        java.lang.String str39 = property37.getAsShortText(locale38);
        java.util.Locale locale40 = null;
        java.lang.String str41 = property37.getAsText(locale40);
        int int42 = property37.getMaximumValueOverall();
        int int43 = property37.getLeapAmount();
        java.lang.String str44 = property37.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property37.getFieldType();
        int int46 = partial30.indexOf(dateTimeFieldType45);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.Partial partial48 = partial30.plus(readablePeriod47);
        org.joda.time.chrono.CopticChronology copticChronology49 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology49.withZone(dateTimeZone50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology49);
        org.joda.time.DateTime dateTime54 = dateTime52.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property55 = dateTime54.millisOfDay();
        java.util.Locale locale56 = null;
        java.lang.String str57 = property55.getAsShortText(locale56);
        java.util.Locale locale58 = null;
        java.lang.String str59 = property55.getAsText(locale58);
        int int60 = property55.getMaximumValueOverall();
        int int61 = property55.getLeapAmount();
        java.lang.String str62 = property55.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = property55.getFieldType();
        org.joda.time.Partial partial64 = partial48.without(dateTimeFieldType63);
        org.joda.time.chrono.CopticChronology copticChronology66 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone67 = null;
        org.joda.time.Chronology chronology68 = copticChronology66.withZone(dateTimeZone67);
        org.joda.time.DateTimeField dateTimeField69 = copticChronology66.year();
        org.joda.time.chrono.CopticChronology copticChronology70 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.Chronology chronology72 = copticChronology70.withZone(dateTimeZone71);
        org.joda.time.DateTimeField dateTimeField73 = copticChronology70.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField74 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology66, dateTimeField73);
        org.joda.time.ReadablePartial readablePartial75 = null;
        int int76 = skipDateTimeField74.getMaximumValue(readablePartial75);
        long long78 = skipDateTimeField74.roundFloor((long) (byte) 1);
        org.joda.time.chrono.CopticChronology copticChronology79 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone80 = null;
        org.joda.time.Chronology chronology81 = copticChronology79.withZone(dateTimeZone80);
        org.joda.time.DateTime dateTime82 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology79);
        org.joda.time.DateTime dateTime84 = dateTime82.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod85 = null;
        org.joda.time.DateTime dateTime87 = dateTime84.withPeriodAdded(readablePeriod85, (int) ' ');
        org.joda.time.DateTime dateTime89 = dateTime87.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay90 = dateTime87.toTimeOfDay();
        int[] intArray94 = new int[] { (short) 0, 82558, 82557322 };
        int int95 = skipDateTimeField74.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay90, intArray94);
        try {
            int[] intArray97 = skipDateTimeField8.addWrapField((org.joda.time.ReadablePartial) partial48, (int) (byte) 10, intArray94, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(timeOfDay24);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292272708 + "'", int29 == 292272708);
        org.junit.Assert.assertNotNull(copticChronology31);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "72000018" + "'", str39.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "72000018" + "'", str41.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86399999 + "'", int42 == 86399999);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "72000018" + "'", str44.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(partial48);
        org.junit.Assert.assertNotNull(copticChronology49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "72000018" + "'", str57.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "72000018" + "'", str59.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 86399999 + "'", int60 == 86399999);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "72000018" + "'", str62.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType63);
        org.junit.Assert.assertNotNull(partial64);
        org.junit.Assert.assertNotNull(copticChronology66);
        org.junit.Assert.assertNotNull(chronology68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertNotNull(copticChronology70);
        org.junit.Assert.assertNotNull(chronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 292272708 + "'", int76 == 292272708);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + (-9676800000L) + "'", long78 == (-9676800000L));
        org.junit.Assert.assertNotNull(copticChronology79);
        org.junit.Assert.assertNotNull(chronology81);
        org.junit.Assert.assertNotNull(dateTime84);
        org.junit.Assert.assertNotNull(dateTime87);
        org.junit.Assert.assertNotNull(dateTime89);
        org.junit.Assert.assertNotNull(timeOfDay90);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 292272708 + "'", int95 == 292272708);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = copticChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology5);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.withDurationAdded(readableDuration18, (int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime15.plusMonths(0);
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology4, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime22);
        try {
            long long28 = limitChronology23.getDateTimeMillis((-28800000), (int) ' ', 72000018, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(limitChronology23);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000116d + "'", double1 == 2440587.500000116d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded(readableDuration6, (int) (short) 100);
        int int9 = dateTime8.getDayOfWeek();
        org.joda.time.DateTime dateTime11 = dateTime8.withCenturyOfEra(3);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        long long2 = org.joda.time.field.FieldUtils.safeDivide(1L, (long) 57600);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long5 = gJChronology0.getDateTimeMillis(1200, 0, 57370, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.DurationField durationField11 = copticChronology0.centuries();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology0);
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        org.joda.time.DateMidnight dateMidnight15 = localDate12.toDateMidnight(dateTimeZone14);
        int int16 = localDate12.getMonthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        try {
            org.joda.time.LocalDate.Property property18 = localDate12.property(dateTimeFieldType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateMidnight15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        boolean boolean2 = gJChronology0.equals((java.lang.Object) (-9676800000L));
        org.joda.time.DurationField durationField3 = gJChronology0.millis();
        try {
            long long11 = gJChronology0.getDateTimeMillis(1686, (-1), 0, (int) (short) 1, (int) 'a', (int) (byte) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) '#', locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "millisOfDay");
        java.lang.String str15 = illegalFieldValueException14.getFieldName();
        illegalFieldValueException14.prependMessage("1970W013T160000-0800");
        java.lang.Number number18 = illegalFieldValueException14.getUpperBound();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1786" + "'", str11.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "year" + "'", str15.equals("year"));
        org.junit.Assert.assertNull(number18);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (-91L), 1686);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Chronology chronology5 = copticChronology3.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology3);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime11 = dateTime6.withDurationAdded(readableDuration9, (int) (short) 100);
        org.joda.time.DateTime.Property property12 = dateTime6.dayOfYear();
        org.joda.time.DurationField durationField13 = property12.getRangeDurationField();
        org.joda.time.DateTime dateTime15 = property12.setCopy((int) (short) 10);
        try {
            org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime15, (-292269238));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -292269238");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendYear(0, 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime4 = dateTime1.withWeekOfWeekyear(82557322);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82557322 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) ' ');
        boolean boolean10 = dateTime5.isAfter((long) 57600);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) -1);
        java.util.GregorianCalendar gregorianCalendar11 = dateTime8.toGregorianCalendar();
        int int12 = dateTime8.getEra();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianCalendar11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology2.withZone(dateTimeZone5);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.Chronology chronology9 = copticChronology7.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology7);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime13 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology14.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology14);
        org.joda.time.DateTime dateTime19 = dateTime17.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime22 = dateTime17.withDurationAdded(readableDuration20, (int) (short) 100);
        org.joda.time.DateTime dateTime24 = dateTime17.plusMonths(0);
        org.joda.time.chrono.LimitChronology limitChronology25 = org.joda.time.chrono.LimitChronology.getInstance(chronology6, (org.joda.time.ReadableDateTime) dateTime13, (org.joda.time.ReadableDateTime) dateTime24);
        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.Chronology chronology28 = copticChronology26.withZone(dateTimeZone27);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology26);
        org.joda.time.DateTime dateTime31 = dateTime29.plusDays((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
        org.joda.time.chrono.LimitChronology limitChronology34 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology1, (org.joda.time.ReadableDateTime) dateTime13, (org.joda.time.ReadableDateTime) dateTime33);
        try {
            long long42 = julianChronology1.getDateTimeMillis(1, 82558, (-1), (int) (short) 0, 6, (int) '#', 82557374);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82557374 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(limitChronology25);
        org.junit.Assert.assertNotNull(copticChronology26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(limitChronology34);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone7);
//        int int10 = dateTimeZone7.getOffsetFromLocal((long) (byte) 100);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.millisOfSecond();
//        java.util.TimeZone timeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTime(dateTimeZone16);
//        int int19 = dateTimeZone16.getOffsetFromLocal((long) (byte) 100);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone16);
//        int int21 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.DateTime.Property property25 = dateTime24.millisOfSecond();
//        int int26 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone7);
//        try {
//            long long33 = zonedChronology27.getDateTimeMillis((long) 57, 82557374, 35, 17, 36);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82557374 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-28800000) + "'", int26 == (-28800000));
//        org.junit.Assert.assertNotNull(zonedChronology27);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (byte) 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText((long) '#', locale12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7);
        int int17 = skipDateTimeField14.getDifference((long) 1, (long) 82563);
        long long20 = skipDateTimeField14.addWrapField((long) 1200, 35);
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = copticChronology21.withZone(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.Chronology chronology25 = copticChronology21.withZone(dateTimeZone24);
        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.Chronology chronology28 = copticChronology26.withZone(dateTimeZone27);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology26);
        org.joda.time.DateTime dateTime31 = dateTime29.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime32 = dateTime31.withLaterOffsetAtOverlap();
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.Chronology chronology35 = copticChronology33.withZone(dateTimeZone34);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology33);
        org.joda.time.DateTime dateTime38 = dateTime36.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime36.withDurationAdded(readableDuration39, (int) (short) 100);
        org.joda.time.DateTime dateTime43 = dateTime36.plusMonths(0);
        org.joda.time.chrono.LimitChronology limitChronology44 = org.joda.time.chrono.LimitChronology.getInstance(chronology25, (org.joda.time.ReadableDateTime) dateTime32, (org.joda.time.ReadableDateTime) dateTime43);
        java.lang.String str46 = dateTime32.toString("68162380");
        org.joda.time.DateTime dateTime48 = dateTime32.minusMonths((-28800000));
        org.joda.time.DateTime dateTime50 = dateTime48.plusSeconds((int) 'a');
        org.joda.time.YearMonthDay yearMonthDay51 = dateTime48.toYearMonthDay();
        java.util.Locale locale53 = null;
        java.lang.String str54 = skipDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay51, 3, locale53);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1786" + "'", str13.equals("1786"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1104537601200L + "'", long20 == 1104537601200L);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(copticChronology26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(limitChronology44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "68162380" + "'", str46.equals("68162380"));
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(yearMonthDay51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "3" + "'", str54.equals("3"));
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime6.toDateTime(dateTimeZone9);
//        int int12 = dateTimeZone9.getOffsetFromLocal((long) (byte) 100);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        try {
//            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(0, 0, 1136, 18, (int) (byte) 1, dateTimeZone9);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-28800000) + "'", int12 == (-28800000));
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField5.getMaximumValue(readablePartial6);
        java.lang.String str9 = offsetDateTimeField5.getAsText((long) 'a');
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getLeapDurationField();
        java.lang.String str12 = offsetDateTimeField5.getAsText(3121000L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 10);
        boolean boolean16 = offsetDateTimeField5.isLeap((long) 1735);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292272808 + "'", int7 == 292272808);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1786" + "'", str9.equals("1786"));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1786" + "'", str12.equals("1786"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = copticChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology5);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.withDurationAdded(readableDuration18, (int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime15.plusMonths(0);
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology4, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime22);
        java.lang.String str25 = dateTime11.toString("68162380");
        org.joda.time.DateTime dateTime27 = dateTime11.minusMonths((-28800000));
        org.joda.time.DateTime dateTime29 = dateTime11.plusSeconds(82557374);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(limitChronology23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "68162380" + "'", str25.equals("68162380"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone4);
//        int int6 = dateTime5.getSecondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.String str8 = gregorianChronology7.toString();
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.joda.time.Chronology chronology11 = gregorianChronology7.withZone(dateTimeZone10);
//        org.joda.time.DateTime dateTime12 = dateTime5.withZoneRetainFields(dateTimeZone10);
//        boolean boolean14 = dateTime12.isAfter(10L);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600 + "'", int6 == 57600);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(292272808, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.append(dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 100);
        boolean boolean4 = dateTimeFormatter3.isParser();
        try {
            org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.parse("68164274", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"68164274\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded(readableDuration6, (int) (short) 100);
        org.joda.time.DateTime.Property property9 = dateTime3.dayOfYear();
        org.joda.time.DurationField durationField10 = property9.getRangeDurationField();
        org.joda.time.DateTime dateTime12 = property9.setCopy((int) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime12.plusYears(57370);
        int int15 = dateTime12.getSecondOfMinute();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = copticChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfDay();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property7.getAsShortText(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        int int12 = property7.getMaximumValueOverall();
        int int13 = property7.getLeapAmount();
        java.lang.String str14 = property7.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property7.getFieldType();
        int int16 = partial0.indexOf(dateTimeFieldType15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.Partial partial18 = partial0.plus(readablePeriod17);
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.Chronology chronology21 = copticChronology19.withZone(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology19);
        org.joda.time.DateTime dateTime24 = dateTime22.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property25 = dateTime24.millisOfDay();
        java.util.Locale locale26 = null;
        java.lang.String str27 = property25.getAsShortText(locale26);
        java.util.Locale locale28 = null;
        java.lang.String str29 = property25.getAsText(locale28);
        int int30 = property25.getMaximumValueOverall();
        int int31 = property25.getLeapAmount();
        java.lang.String str32 = property25.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property25.getFieldType();
        org.joda.time.Partial partial34 = partial18.without(dateTimeFieldType33);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 100.0d, "82557322");
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "72000018" + "'", str9.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "72000018" + "'", str11.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399999 + "'", int12 == 86399999);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "72000018" + "'", str14.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(partial18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "72000018" + "'", str27.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "72000018" + "'", str29.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 86399999 + "'", int30 == 86399999);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "72000018" + "'", str32.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(partial34);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime1.plus((long) 1);
        boolean boolean9 = dateTime1.isBefore(1560639361448L);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField5.getAsText((long) (short) 100, locale7);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getRangeDurationField();
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getLeapDurationField();
        long long13 = offsetDateTimeField5.getDifferenceAsLong((long) (-25200000), 18L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1786" + "'", str8.equals("1786"));
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond((-292269337));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269337 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        int int12 = skipDateTimeField8.get(2440591L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1686 + "'", int12 == 1686);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField5.getMaximumValue(readablePartial6);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField5.getMaximumShortTextLength(locale8);
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getRangeDurationField();
        java.lang.String str12 = offsetDateTimeField5.getAsShortText((long) '#');
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292272808 + "'", int7 == 292272808);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1786" + "'", str12.equals("1786"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded(readableDuration6, (int) (short) 100);
        org.joda.time.DateTime.Property property9 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime11 = dateTime3.minusMinutes((int) (short) 100);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.minusHours(72000018);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean3 = gJChronology0.equals((java.lang.Object) dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.millisOfSecond();
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.DateTime dateTime9 = dateTime5.toDateTime(dateTimeZone8);
//        org.joda.time.Chronology chronology10 = gJChronology0.withZone(dateTimeZone8);
//        java.lang.String str11 = dateTimeZone8.getID();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        org.joda.time.Instant instant7 = dateTime5.toInstant();
        org.joda.time.Instant instant9 = instant7.plus((long) (-292269339));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField5.getMaximumValue(readablePartial6);
        java.lang.String str9 = offsetDateTimeField5.getAsText((long) 'a');
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getLeapDurationField();
        long long12 = offsetDateTimeField5.roundHalfFloor((long) 18);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292272808 + "'", int7 == 292272808);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1786" + "'", str9.equals("1786"));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        try {
            org.joda.time.DateTime dateTime10 = dateTime5.withTime(86, 6, 57367, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField5.getMaximumValue(readablePartial6);
        int int8 = offsetDateTimeField5.getOffset();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsShortText((-292269238), locale10);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292272808 + "'", int7 == 292272808);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-292269238" + "'", str11.equals("-292269238"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        try {
            int[] intArray13 = copticChronology0.get(readablePeriod10, 0L, (long) 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfEra(86, 82557322);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay11 = dateTime8.toTimeOfDay();
        org.joda.time.DateTimeField[] dateTimeFieldArray12 = timeOfDay11.getFields();
        java.lang.Class<?> wildcardClass13 = dateTimeFieldArray12.getClass();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(timeOfDay11);
        org.junit.Assert.assertNotNull(dateTimeFieldArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsShortText(locale7);
        org.joda.time.DateTime dateTime9 = property6.roundHalfFloorCopy();
        java.lang.String str10 = property6.getAsString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "72000018" + "'", str8.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "72000018" + "'", str10.equals("72000018"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.DurationField durationField11 = copticChronology0.centuries();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTimeField dateTimeField16 = copticChronology12.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField16, 0);
        boolean boolean20 = copticChronology0.equals((java.lang.Object) (-292269339));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) dateTimeFormatter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.year();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) (byte) -1, 86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = partial0.getFieldTypes();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology2);
        long long11 = copticChronology2.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology2.year();
        org.joda.time.DurationField durationField13 = copticChronology2.centuries();
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology2);
        int int15 = localDate14.getYear();
        java.util.Date date16 = localDate14.toDate();
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.Chronology chronology19 = copticChronology17.withZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology17);
        org.joda.time.DateTime dateTime22 = dateTime20.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime23 = dateTime22.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate24 = dateTime23.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.LocalDate localDate26 = localDate24.plus(readablePeriod25);
        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.Chronology chronology29 = copticChronology27.withZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology27);
        org.joda.time.DateTime dateTime32 = dateTime30.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property33 = dateTime32.millisOfDay();
        java.util.Locale locale34 = null;
        java.lang.String str35 = property33.getAsShortText(locale34);
        java.util.Locale locale36 = null;
        java.lang.String str37 = property33.getAsText(locale36);
        int int38 = property33.getMaximumValueOverall();
        int int39 = property33.getLeapAmount();
        java.lang.String str40 = property33.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property33.getFieldType();
        boolean boolean42 = localDate24.isSupported(dateTimeFieldType41);
        org.joda.time.LocalDate localDate43 = localDate14.withFields((org.joda.time.ReadablePartial) localDate24);
        org.joda.time.LocalDate localDate45 = localDate24.withCenturyOfEra(36);
        org.joda.time.LocalDate localDate47 = localDate24.withWeekyear((int) ' ');
        try {
            boolean boolean48 = partial0.isEqual((org.joda.time.ReadablePartial) localDate47);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3121000L + "'", long11 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1686 + "'", int15 == 1686);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(copticChronology27);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "72000018" + "'", str35.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "72000018" + "'", str37.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 86399999 + "'", int38 == 86399999);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "72000018" + "'", str40.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertNotNull(localDate47);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded(readableDuration6, (int) (short) 100);
        org.joda.time.DateTime dateTime10 = dateTime3.plusMonths(0);
        int int11 = dateTime3.getDayOfWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField5.getMaximumValue(readablePartial6);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField5.getMaximumShortTextLength(locale8);
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getRangeDurationField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField5.getMaximumShortTextLength(locale12);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292272808 + "'", int7 == 292272808);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendTimeZoneOffset("millisOfDay", false, 292272708, 82557322);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = copticChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfDay();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property7.getAsShortText(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        int int12 = property7.getMaximumValueOverall();
        int int13 = property7.getLeapAmount();
        java.lang.String str14 = property7.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property7.getFieldType();
        int int16 = partial0.indexOf(dateTimeFieldType15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.Partial partial18 = partial0.plus(readablePeriod17);
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.Chronology chronology21 = copticChronology19.withZone(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology19);
        org.joda.time.DateTime dateTime24 = dateTime22.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property25 = dateTime24.millisOfDay();
        java.util.Locale locale26 = null;
        java.lang.String str27 = property25.getAsShortText(locale26);
        java.util.Locale locale28 = null;
        java.lang.String str29 = property25.getAsText(locale28);
        int int30 = property25.getMaximumValueOverall();
        int int31 = property25.getLeapAmount();
        java.lang.String str32 = property25.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property25.getFieldType();
        org.joda.time.Partial partial34 = partial18.without(dateTimeFieldType33);
        int[] intArray35 = partial18.getValues();
        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.Chronology chronology38 = copticChronology36.withZone(dateTimeZone37);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.Chronology chronology40 = copticChronology36.withZone(dateTimeZone39);
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.Chronology chronology43 = copticChronology41.withZone(dateTimeZone42);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology41);
        org.joda.time.DateTime dateTime46 = dateTime44.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime47 = dateTime46.withLaterOffsetAtOverlap();
        org.joda.time.chrono.CopticChronology copticChronology48 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.Chronology chronology50 = copticChronology48.withZone(dateTimeZone49);
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology48);
        org.joda.time.DateTime dateTime53 = dateTime51.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration54 = null;
        org.joda.time.DateTime dateTime56 = dateTime51.withDurationAdded(readableDuration54, (int) (short) 100);
        org.joda.time.DateTime dateTime58 = dateTime51.plusMonths(0);
        org.joda.time.chrono.LimitChronology limitChronology59 = org.joda.time.chrono.LimitChronology.getInstance(chronology40, (org.joda.time.ReadableDateTime) dateTime47, (org.joda.time.ReadableDateTime) dateTime58);
        java.lang.String str61 = dateTime47.toString("68162380");
        org.joda.time.DateTime dateTime63 = dateTime47.minusMonths((-28800000));
        org.joda.time.Partial partial64 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology65 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.Chronology chronology67 = copticChronology65.withZone(dateTimeZone66);
        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology65);
        org.joda.time.DateTime dateTime70 = dateTime68.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property71 = dateTime70.millisOfDay();
        java.util.Locale locale72 = null;
        java.lang.String str73 = property71.getAsShortText(locale72);
        java.util.Locale locale74 = null;
        java.lang.String str75 = property71.getAsText(locale74);
        int int76 = property71.getMaximumValueOverall();
        int int77 = property71.getLeapAmount();
        java.lang.String str78 = property71.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = property71.getFieldType();
        int int80 = partial64.indexOf(dateTimeFieldType79);
        int int81 = dateTime47.get(dateTimeFieldType79);
        try {
            org.joda.time.Partial.Property property82 = partial18.property(dateTimeFieldType79);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "72000018" + "'", str9.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "72000018" + "'", str11.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399999 + "'", int12 == 86399999);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "72000018" + "'", str14.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(partial18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "72000018" + "'", str27.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "72000018" + "'", str29.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 86399999 + "'", int30 == 86399999);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "72000018" + "'", str32.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(partial34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(copticChronology36);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(copticChronology48);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(limitChronology59);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "68162380" + "'", str61.equals("68162380"));
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(copticChronology65);
        org.junit.Assert.assertNotNull(chronology67);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(property71);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "72000018" + "'", str73.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "72000018" + "'", str75.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 86399999 + "'", int76 == 86399999);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "72000018" + "'", str78.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 18 + "'", int81 == 18);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.millisOfSecond();
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.DateTime dateTime9 = dateTime5.toDateTime(dateTimeZone8);
//        int int11 = dateTimeZone8.getOffsetFromLocal((long) (byte) 100);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.Chronology chronology13 = iSOChronology3.withZone(dateTimeZone8);
//        try {
//            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone2, dateTimeZone8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.CachedDateTimeZone");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology13);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 292272708);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = copticChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology5);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.withDurationAdded(readableDuration18, (int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime15.plusMonths(0);
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology4, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime22);
        org.joda.time.DateTime dateTime24 = limitChronology23.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField25 = limitChronology23.monthOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(limitChronology23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.LocalDate.Property property8 = localDate7.year();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.LocalDate localDate11 = property8.addToCopy(1);
        try {
            org.joda.time.LocalDate localDate13 = localDate11.withDayOfWeek(9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField5.getMaximumValue(readablePartial6);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField5.getMaximumShortTextLength(locale8);
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getRangeDurationField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5);
        int int13 = delegatedDateTimeField11.get((long) 82563);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292272808 + "'", int7 == 292272808);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1786 + "'", int13 == 1786);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) -1);
        int int11 = dateTime10.getMinuteOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = copticChronology1.withZone(dateTimeZone2);
        org.joda.time.DurationField durationField4 = copticChronology1.weeks();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) copticChronology1);
        try {
            long long10 = copticChronology1.getDateTimeMillis(82558, 82559, 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82559 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology0.add(readablePeriod3, (long) (byte) 100, 1735);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("1786");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1786\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (-292269337));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-292269337) + "'", int1 == (-292269337));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone4);
        org.joda.time.Chronology chronology6 = dateTime5.getChronology();
        org.joda.time.DateTime.Property property7 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime8 = property7.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        long long2 = org.joda.time.field.FieldUtils.safeDivide((long) (-292269338), 116553600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.LocalDate.Property property8 = localDate7.year();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.LocalDate localDate11 = property8.addToCopy(1);
        boolean boolean12 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate11);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 100);
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        java.lang.String str4 = dateTimeFormatter0.print(readableInstant3);
//        java.io.Writer writer5 = null;
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.Chronology chronology8 = copticChronology6.withZone(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology6);
//        org.joda.time.DateTime dateTime11 = dateTime9.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime9.withDurationAdded(readableDuration12, (int) (short) 100);
//        org.joda.time.DateTime.Property property15 = dateTime9.dayOfYear();
//        try {
//            dateTimeFormatter0.printTo(writer5, (org.joda.time.ReadableInstant) dateTime9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-W01-3T16:00:00.018-08:00" + "'", str4.equals("1970-W01-3T16:00:00.018-08:00"));
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 57);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 57600);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500666667d + "'", double1 == 2440587.500666667d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) -1);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = copticChronology11.withZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology11);
        org.joda.time.DateTime dateTime16 = dateTime14.minusHours((int) (byte) 100);
        boolean boolean17 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property18 = dateTime10.dayOfMonth();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneOffset("82557322", "2019-W24-6T15:55:55.998-07:00", true, 0, 1200);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsShortText(locale7);
        java.util.Locale locale9 = null;
        java.lang.String str10 = property6.getAsText(locale9);
        int int11 = property6.getMaximumValueOverall();
        int int12 = property6.getLeapAmount();
        java.lang.String str13 = property6.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property6.getFieldType();
        java.util.Locale locale15 = null;
        int int16 = property6.getMaximumShortTextLength(locale15);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "72000018" + "'", str8.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "72000018" + "'", str10.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 86399999 + "'", int11 == 86399999);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "72000018" + "'", str13.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        boolean boolean6 = gJChronology3.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfSecond();
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        org.joda.time.DateTime dateTime12 = dateTime8.toDateTime(dateTimeZone11);
        org.joda.time.Chronology chronology13 = gJChronology3.withZone(dateTimeZone11);
        org.joda.time.Chronology chronology14 = julianChronology1.withZone(dateTimeZone11);
        try {
            long long19 = julianChronology1.getDateTimeMillis(9, 0, 1, (-292269338));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269338 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate.Property property10 = localDate9.year();
        try {
            org.joda.time.LocalDate localDate12 = localDate9.withDayOfYear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitYear(82557322);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 292272708);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(18, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72 + "'", int2 == 72);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 1136);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500013148d + "'", double1 == 2440587.500013148d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField5.getAsText((long) (short) 100, locale7);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getLeapDurationField();
        long long11 = offsetDateTimeField5.roundHalfEven((long) 'a');
        int int14 = offsetDateTimeField5.getDifference(2605490150400000L, 0L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1786" + "'", str8.equals("1786"));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9676800000L) + "'", long11 == (-9676800000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 82563 + "'", int14 == 82563);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 1, 0, (-28800000), (int) (byte) 100, (-25200000), chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        boolean boolean6 = gJChronology3.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfSecond();
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        org.joda.time.DateTime dateTime12 = dateTime8.toDateTime(dateTimeZone11);
        org.joda.time.Chronology chronology13 = gJChronology3.withZone(dateTimeZone11);
        org.joda.time.Chronology chronology14 = julianChronology1.withZone(dateTimeZone11);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        org.joda.time.DateTime dateTime20 = dateTime18.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime21 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.LocalDate localDate24 = localDate22.plus(readablePeriod23);
        org.joda.time.LocalDate.Property property25 = localDate24.dayOfWeek();
        org.joda.time.DateTime dateTime26 = localDate24.toDateTimeAtMidnight();
        org.joda.time.DateTime dateTime27 = localDate24.toDateTimeAtStartOfDay();
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.Chronology chronology30 = copticChronology28.withZone(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = copticChronology28.year();
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.Chronology chronology34 = copticChronology32.withZone(dateTimeZone33);
        org.joda.time.DateTimeField dateTimeField35 = copticChronology32.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology28, dateTimeField35);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int int38 = skipDateTimeField36.getMaximumValue(readablePartial37);
        long long40 = skipDateTimeField36.roundFloor((long) (byte) 1);
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.Chronology chronology43 = copticChronology41.withZone(dateTimeZone42);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology41);
        org.joda.time.DateTime dateTime46 = dateTime44.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.DateTime dateTime49 = dateTime46.withPeriodAdded(readablePeriod47, (int) ' ');
        org.joda.time.DateTime dateTime51 = dateTime49.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay52 = dateTime49.toTimeOfDay();
        int[] intArray56 = new int[] { (short) 0, 82558, 82557322 };
        int int57 = skipDateTimeField36.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay52, intArray56);
        try {
            julianChronology1.validate((org.joda.time.ReadablePartial) localDate24, intArray56);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82558 for monthOfYear must not be larger than 13");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 292272708 + "'", int38 == 292272708);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-9676800000L) + "'", long40 == (-9676800000L));
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(timeOfDay52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 292272708 + "'", int57 == 292272708);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsShortText(locale7);
        java.util.Locale locale9 = null;
        java.lang.String str10 = property6.getAsText(locale9);
        int int11 = property6.getMaximumValueOverall();
        int int12 = property6.getLeapAmount();
        java.lang.String str13 = property6.getAsShortText();
        org.joda.time.DateTimeField dateTimeField14 = property6.getField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "72000018" + "'", str8.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "72000018" + "'", str10.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 86399999 + "'", int11 == 86399999);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "72000018" + "'", str13.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("68161219", "68161520", (int) (short) 0, 18);
        long long6 = fixedDateTimeZone4.nextTransition((long) 6);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.Chronology chronology9 = copticChronology7.withZone(dateTimeZone8);
        org.joda.time.DurationField durationField10 = copticChronology7.years();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology7.era();
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeField11);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 6L + "'", long6 == 6L);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Chronology chronology5 = copticChronology3.withZone(dateTimeZone4);
        int int6 = copticChronology3.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(1786, (-292269339), 0, (org.joda.time.Chronology) copticChronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269339 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.DateTime.Property property4 = dateTime3.millisOfSecond();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
//        int int9 = dateTimeZone6.getOffsetFromLocal((long) (byte) 100);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.DateTime.Property property13 = dateTime12.millisOfSecond();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        org.joda.time.DateTime dateTime16 = dateTime12.toDateTime(dateTimeZone15);
//        int int18 = dateTimeZone15.getOffsetFromLocal((long) (byte) 100);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone15);
//        int int20 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        org.joda.time.DateTime.Property property24 = dateTime23.millisOfSecond();
//        int int25 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime23);
//        java.lang.String str27 = dateTimeZone6.getName((long) 6);
//        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone6);
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = dateTimeZone6.getName((long) (-28800000), locale30);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-28800000) + "'", int25 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Pacific Standard Time" + "'", str31.equals("Pacific Standard Time"));
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField8.getWrappedField();
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology14.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology14);
        org.joda.time.DateTime dateTime19 = dateTime17.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) ' ');
        org.joda.time.DateTime dateTime24 = dateTime22.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay25 = dateTime22.toTimeOfDay();
        int int26 = skipDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay25);
        boolean boolean28 = skipDateTimeField8.isLeap((-9676800000L));
        org.joda.time.LocalDate localDate30 = org.joda.time.LocalDate.parse("68168988");
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.Chronology chronology35 = copticChronology33.withZone(dateTimeZone34);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology33);
        long long42 = copticChronology33.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField43 = copticChronology33.year();
        org.joda.time.DurationField durationField44 = copticChronology33.centuries();
        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology33);
        int int46 = localDate45.getYear();
        java.util.Date date47 = localDate45.toDate();
        org.joda.time.chrono.CopticChronology copticChronology48 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.Chronology chronology50 = copticChronology48.withZone(dateTimeZone49);
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology48);
        org.joda.time.DateTime dateTime53 = dateTime51.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime54 = dateTime53.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate55 = dateTime54.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod56 = null;
        org.joda.time.LocalDate localDate57 = localDate55.plus(readablePeriod56);
        org.joda.time.chrono.CopticChronology copticChronology58 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.Chronology chronology60 = copticChronology58.withZone(dateTimeZone59);
        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology58);
        org.joda.time.DateTime dateTime63 = dateTime61.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property64 = dateTime63.millisOfDay();
        java.util.Locale locale65 = null;
        java.lang.String str66 = property64.getAsShortText(locale65);
        java.util.Locale locale67 = null;
        java.lang.String str68 = property64.getAsText(locale67);
        int int69 = property64.getMaximumValueOverall();
        int int70 = property64.getLeapAmount();
        java.lang.String str71 = property64.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType72 = property64.getFieldType();
        boolean boolean73 = localDate55.isSupported(dateTimeFieldType72);
        org.joda.time.LocalDate localDate74 = localDate45.withFields((org.joda.time.ReadablePartial) localDate55);
        org.joda.time.LocalDate localDate76 = localDate55.withCenturyOfEra(36);
        int[] intArray78 = iSOChronology32.get((org.joda.time.ReadablePartial) localDate76, 0L);
        try {
            int[] intArray80 = skipDateTimeField8.addWrapPartial((org.joda.time.ReadablePartial) localDate30, 8, intArray78, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(timeOfDay25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-292269338) + "'", int26 == (-292269338));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3121000L + "'", long42 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1686 + "'", int46 == 1686);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(copticChronology48);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(localDate57);
        org.junit.Assert.assertNotNull(copticChronology58);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "72000018" + "'", str66.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "72000018" + "'", str68.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 86399999 + "'", int69 == 86399999);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "72000018" + "'", str71.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(localDate74);
        org.junit.Assert.assertNotNull(localDate76);
        org.junit.Assert.assertNotNull(intArray78);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 1200);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500013889d + "'", double1 == 2440587.500013889d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("hi!");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.DateTime dateTime4 = dateTime1.withFieldAdded(durationFieldType2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        org.joda.time.Instant instant7 = dateTime5.toInstant();
        try {
            org.joda.time.DateTime dateTime9 = dateTime5.withYearOfCentury((-292269338));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269338 for yearOfCentury must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = copticChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) 100);
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField4);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        long long10 = skipDateTimeField7.roundHalfCeiling((long) 3);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-9676800000L) + "'", long10 == (-9676800000L));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsShortText(locale7);
        try {
            org.joda.time.DateTime dateTime10 = property6.setCopy("000000.018Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"000000.018Z\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "72000018" + "'", str8.equals("72000018"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField8.getWrappedField();
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology14.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology14);
        org.joda.time.DateTime dateTime19 = dateTime17.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) ' ');
        org.joda.time.DateTime dateTime24 = dateTime22.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay25 = dateTime22.toTimeOfDay();
        int int26 = skipDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay25);
        boolean boolean28 = skipDateTimeField8.isLeap((-9676800000L));
        int int30 = skipDateTimeField8.getLeapAmount(1104537601200L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(timeOfDay25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-292269338) + "'", int26 == (-292269338));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField8.getWrappedField();
        org.joda.time.DurationField durationField14 = skipDateTimeField8.getLeapDurationField();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        long long24 = copticChronology15.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology15.year();
        org.joda.time.DurationField durationField26 = copticChronology15.centuries();
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology15);
        java.util.TimeZone timeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forTimeZone(timeZone28);
        org.joda.time.DateMidnight dateMidnight30 = localDate27.toDateMidnight(dateTimeZone29);
        java.util.Locale locale31 = null;
        java.lang.String str32 = skipDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate27, locale31);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
        org.joda.time.DateTime dateTime36 = dateTime34.plusYears(0);
        org.joda.time.DateTime dateTime38 = dateTime36.plusYears((int) (short) 100);
        org.joda.time.LocalTime localTime39 = dateTime36.toLocalTime();
        try {
            org.joda.time.LocalDateTime localDateTime40 = localDate27.toLocalDateTime(localTime39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The chronology of the time does not match");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3121000L + "'", long24 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateMidnight30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1686" + "'", str32.equals("1686"));
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(localTime39);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = copticChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfDay();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property7.getAsShortText(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        int int12 = property7.getMaximumValueOverall();
        int int13 = property7.getLeapAmount();
        java.lang.String str14 = property7.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property7.getFieldType();
        int int16 = partial0.indexOf(dateTimeFieldType15);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        try {
            org.joda.time.Partial partial19 = partial0.withFieldAdded(durationFieldType17, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "72000018" + "'", str9.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "72000018" + "'", str11.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399999 + "'", int12 == 86399999);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "72000018" + "'", str14.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) '#', locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "millisOfDay");
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        long long24 = copticChronology15.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology15.year();
        org.joda.time.DurationField durationField26 = copticChronology15.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField26);
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.Chronology chronology30 = copticChronology28.withZone(dateTimeZone29);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology28);
        org.joda.time.DateTime dateTime33 = dateTime31.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime34 = dateTime33.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate35 = dateTime34.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.LocalDate localDate37 = localDate35.plus(readablePeriod36);
        org.joda.time.LocalDate.Property property38 = localDate37.dayOfWeek();
        org.joda.time.LocalDate localDate39 = property38.withMinimumValue();
        int int40 = localDate39.getEra();
        int[] intArray48 = new int[] { 82563, (byte) 0, (short) 0, ' ', 6, (-292269339) };
        try {
            int[] intArray50 = unsupportedDateTimeField27.add((org.joda.time.ReadablePartial) localDate39, 6, intArray48, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1786" + "'", str11.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3121000L + "'", long24 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(intArray48);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 100 for GregorianChronology[UTC] must be in the range [292272708,-1]", "1");
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate.Property property11 = localDate9.yearOfEra();
        try {
            org.joda.time.LocalDate localDate13 = localDate9.withWeekOfWeekyear(82563);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82563 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate localDate11 = property10.withMinimumValue();
        int int12 = localDate11.getEra();
        try {
            org.joda.time.LocalDate localDate14 = localDate11.withDayOfWeek(1686);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1686 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 100);
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        java.lang.String str4 = dateTimeFormatter0.print(readableInstant3);
//        org.joda.time.Chronology chronology5 = dateTimeFormatter0.getChronolgy();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-W01-3T16:00:00.018-08:00" + "'", str4.equals("1970-W01-3T16:00:00.018-08:00"));
//        org.junit.Assert.assertNull(chronology5);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) '#', locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "millisOfDay");
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        long long24 = copticChronology15.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology15.year();
        org.joda.time.DurationField durationField26 = copticChronology15.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField26);
        java.util.Locale locale29 = null;
        try {
            java.lang.String str30 = unsupportedDateTimeField27.getAsText(57, locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1786" + "'", str11.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3121000L + "'", long24 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral('#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField5.getAsText((long) (short) 100, locale7);
        long long10 = offsetDateTimeField5.roundCeiling((long) 1136);
        boolean boolean11 = offsetDateTimeField5.isSupported();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1786" + "'", str8.equals("1786"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 21859200000L + "'", long10 == 21859200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (byte) 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText((long) '#', locale12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7);
        long long16 = offsetDateTimeField7.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1786" + "'", str13.equals("1786"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-9676800000L) + "'", long16 == (-9676800000L));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime5.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusYears(0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears((int) (short) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.monthOfYear();
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("68157617");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '68157617' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField5.getAsText((long) (short) 100, locale7);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.Chronology chronology12 = copticChronology10.withZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology10);
        org.joda.time.DateTime dateTime15 = dateTime13.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime16 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
        org.joda.time.LocalDate.Property property18 = localDate17.year();
        org.joda.time.LocalDate localDate19 = property18.roundHalfFloorCopy();
        int[] intArray26 = new int[] { 1735, 1136, 86399999, 1786, 1786 };
        try {
            int[] intArray28 = offsetDateTimeField5.addWrapField((org.joda.time.ReadablePartial) localDate19, (int) 'a', intArray26, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1786" + "'", str8.equals("1786"));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(292272808, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendPattern("");
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.Chronology chronology10 = copticChronology8.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology8.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) 100);
        long long16 = offsetDateTimeField13.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField13.getAsText((long) '#', locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) 1104537601200L, (java.lang.Number) 292272808, (java.lang.Number) 72000018);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendFixedDecimal(dateTimeFieldType20, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1786" + "'", str19.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.DurationField durationField11 = copticChronology0.centuries();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology0);
        int int13 = localDate12.getYear();
        java.util.Date date14 = localDate12.toDate();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        org.joda.time.DateTime dateTime20 = dateTime18.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime21 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.LocalDate localDate24 = localDate22.plus(readablePeriod23);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.Chronology chronology27 = copticChronology25.withZone(dateTimeZone26);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology25);
        org.joda.time.DateTime dateTime30 = dateTime28.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property31 = dateTime30.millisOfDay();
        java.util.Locale locale32 = null;
        java.lang.String str33 = property31.getAsShortText(locale32);
        java.util.Locale locale34 = null;
        java.lang.String str35 = property31.getAsText(locale34);
        int int36 = property31.getMaximumValueOverall();
        int int37 = property31.getLeapAmount();
        java.lang.String str38 = property31.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property31.getFieldType();
        boolean boolean40 = localDate22.isSupported(dateTimeFieldType39);
        org.joda.time.LocalDate localDate41 = localDate12.withFields((org.joda.time.ReadablePartial) localDate22);
        org.joda.time.LocalDate localDate43 = localDate41.plusDays(1);
        org.joda.time.LocalDate.Property property44 = localDate43.monthOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1686 + "'", int13 == 1686);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "72000018" + "'", str33.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "72000018" + "'", str35.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 86399999 + "'", int36 == 86399999);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "72000018" + "'", str38.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(property44);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField5.getAsText((long) (short) 100, locale7);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getRangeDurationField();
        int int11 = offsetDateTimeField5.getMaximumValue(0L);
        long long14 = offsetDateTimeField5.getDifferenceAsLong((long) (-1), 1L);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, 0, 292272708, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year must be in the range [292272708,9]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1786" + "'", str8.equals("1786"));
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 292272808 + "'", int11 == 292272808);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded(readableDuration6, (int) (short) 100);
        org.joda.time.DateTime.Property property9 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime11 = dateTime3.minusMinutes((int) (short) 100);
        try {
            org.joda.time.DateTime dateTime13 = dateTime3.withSecondOfMinute(86399999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("000000.018Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"000000.018Z\" is malformed at \".018Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (byte) 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText((long) '#', locale12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        org.joda.time.DateTime dateTime20 = dateTime18.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime21 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.LocalDate localDate24 = localDate22.plus(readablePeriod23);
        int int25 = localDate24.getYearOfEra();
        int[] intArray28 = new int[] { 'a' };
        try {
            int[] intArray30 = offsetDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) localDate24, (int) ' ', intArray28, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1786" + "'", str13.equals("1786"));
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1686 + "'", int25 == 1686);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.lang.Object obj0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.Chronology chronology4 = instant3.getChronology();
        org.joda.time.Instant instant6 = instant3.plus(0L);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant3.plus(readableDuration7);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) '#', locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "millisOfDay");
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        long long24 = copticChronology15.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology15.year();
        org.joda.time.DurationField durationField26 = copticChronology15.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField26);
        org.joda.time.DurationField durationField28 = unsupportedDateTimeField27.getLeapDurationField();
        java.util.Locale locale30 = null;
        try {
            java.lang.String str31 = unsupportedDateTimeField27.getAsText(82557374, locale30);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1786" + "'", str11.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3121000L + "'", long24 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
        org.junit.Assert.assertNull(durationField28);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDateTime localDateTime7 = dateTime6.toLocalDateTime();
        org.joda.time.DateTime.Property property8 = dateTime6.dayOfYear();
        java.util.Locale locale9 = null;
        int int10 = property8.getMaximumTextLength(locale9);
        int int11 = property8.getLeapAmount();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = copticChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology5);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.withDurationAdded(readableDuration18, (int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime15.plusMonths(0);
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology4, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime22);
        org.joda.time.DateTimeField dateTimeField24 = limitChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField25 = limitChronology23.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType26, 10, (int) (byte) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(limitChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField5.getMaximumValue(readablePartial6);
        java.lang.String str9 = offsetDateTimeField5.getAsText((long) 'a');
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getLeapDurationField();
        java.lang.String str12 = offsetDateTimeField5.getAsText(3121000L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 10);
        try {
            long long17 = offsetDateTimeField14.add((long) 6, (-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292272808 + "'", int7 == 292272808);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1786" + "'", str9.equals("1786"));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1786" + "'", str12.equals("1786"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundHalfEven((long) 292272708);
        java.lang.String str13 = skipDateTimeField8.toString();
        java.lang.String str14 = skipDateTimeField8.getName();
        long long16 = skipDateTimeField8.roundHalfCeiling(6L);
        java.lang.String str18 = skipDateTimeField8.getAsText((long) ' ');
        org.joda.time.DateTimeField dateTimeField19 = skipDateTimeField8.getWrappedField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[year]" + "'", str13.equals("DateTimeField[year]"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "year" + "'", str14.equals("year"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-9676800000L) + "'", long16 == (-9676800000L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1686" + "'", str18.equals("1686"));
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        java.lang.String str11 = skipDateTimeField8.toString();
        int int13 = skipDateTimeField8.get(0L);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology14.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology14);
        org.joda.time.DateTime dateTime19 = dateTime17.plusDays((int) ' ');
        org.joda.time.DateTime dateTime21 = dateTime19.plusMinutes((int) (short) 100);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.Chronology chronology24 = copticChronology22.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology22);
        org.joda.time.DateTime dateTime27 = dateTime25.minusHours((int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.withDurationAdded(readableDuration28, (int) '#');
        boolean boolean31 = dateTime19.isEqual((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime19.toYearMonthDay();
        java.util.Locale locale34 = null;
        java.lang.String str35 = skipDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay32, 82557322, locale34);
        boolean boolean37 = skipDateTimeField8.isLeap(18L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTimeField[year]" + "'", str11.equals("DateTimeField[year]"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1686 + "'", int13 == 1686);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "82557322" + "'", str35.equals("82557322"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology6.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology6);
        org.joda.time.DateTime dateTime11 = dateTime9.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime9.withDurationAdded(readableDuration12, (int) (short) 100);
        org.joda.time.DateTime dateTime16 = dateTime9.plusMonths(0);
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
        boolean boolean18 = dateTime5.equals((java.lang.Object) dateTime16);
        org.joda.time.DateTime dateTime19 = dateTime16.toDateTime();
        org.joda.time.DateTime dateTime21 = dateTime16.withHourOfDay(0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHourOfHalfday((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str10 = gregorianChronology9.toString();
        org.joda.time.DurationField durationField11 = gregorianChronology9.days();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.millisOfSecond();
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = copticChronology13.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = copticChronology13.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) (byte) 100);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField18.getAsText((long) (short) 100, locale20);
        long long23 = offsetDateTimeField18.roundCeiling((long) 1136);
        org.joda.time.DurationField durationField24 = offsetDateTimeField18.getDurationField();
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.Chronology chronology27 = copticChronology25.withZone(dateTimeZone26);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology25);
        org.joda.time.DateTime dateTime30 = dateTime28.plusDays((int) ' ');
        org.joda.time.chrono.CopticChronology copticChronology31 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.Chronology chronology33 = copticChronology31.withZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology31);
        org.joda.time.DateTime dateTime36 = dateTime34.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration37 = null;
        org.joda.time.DateTime dateTime39 = dateTime34.withDurationAdded(readableDuration37, (int) (short) 100);
        org.joda.time.DateTime dateTime41 = dateTime34.plusMonths(0);
        org.joda.time.DateTime.Property property42 = dateTime41.millisOfSecond();
        boolean boolean43 = dateTime30.equals((java.lang.Object) dateTime41);
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.Chronology chronology46 = copticChronology44.withZone(dateTimeZone45);
        org.joda.time.DateTimeField dateTimeField47 = copticChronology44.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) (byte) 100);
        long long52 = offsetDateTimeField49.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField49.getAsText((long) '#', locale54);
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = offsetDateTimeField49.getType();
        boolean boolean57 = dateTime41.isSupported(dateTimeFieldType56);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField58 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, durationField24, dateTimeFieldType56);
        org.joda.time.chrono.CopticChronology copticChronology59 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.Chronology chronology61 = copticChronology59.withZone(dateTimeZone60);
        org.joda.time.DateTimeField dateTimeField62 = copticChronology59.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField(dateTimeField62, (int) (byte) 100);
        long long67 = offsetDateTimeField64.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale69 = null;
        java.lang.String str70 = offsetDateTimeField64.getAsText((long) '#', locale69);
        org.joda.time.DateTimeFieldType dateTimeFieldType71 = offsetDateTimeField64.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType71, "millisOfDay");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField74 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField58, dateTimeFieldType71);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder8.appendFraction(dateTimeFieldType71, (-292269337), 57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[UTC]" + "'", str10.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1786" + "'", str21.equals("1786"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 21859200000L + "'", long23 == 21859200000L);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(copticChronology31);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1786" + "'", str55.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(copticChronology59);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "1786" + "'", str70.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType71);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundHalfEven((long) 292272708);
        java.lang.String str13 = skipDateTimeField8.toString();
        java.lang.String str14 = skipDateTimeField8.getName();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        org.joda.time.DateTime dateTime20 = dateTime18.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime21 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.LocalDate localDate24 = localDate22.plus(readablePeriod23);
        org.joda.time.LocalDate.Property property25 = localDate24.year();
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate27 = localDate24.minus(readablePeriod26);
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) localDate24, 57600, locale29);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[year]" + "'", str13.equals("DateTimeField[year]"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "year" + "'", str14.equals("year"));
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "57600" + "'", str30.equals("57600"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
        boolean boolean4 = julianChronology0.equals((java.lang.Object) dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded(readableDuration6, (int) (short) 100);
        org.joda.time.DateTime.Property property9 = dateTime3.dayOfYear();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.Chronology chronology12 = copticChronology10.withZone(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = copticChronology10.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) (byte) 100);
        long long18 = offsetDateTimeField15.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField15.getAsText((long) '#', locale20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, "millisOfDay");
        int int25 = dateTime3.get(dateTimeFieldType22);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str27 = gregorianChronology26.toString();
        org.joda.time.DurationField durationField28 = gregorianChronology26.centuries();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str30 = gregorianChronology29.toString();
        int int31 = gregorianChronology29.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField32 = gregorianChronology29.millis();
        org.joda.time.DurationField durationField33 = gregorianChronology29.months();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField34 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType22, durationField28, durationField33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1786" + "'", str21.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1686 + "'", int25 == 1686);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "GregorianChronology[UTC]" + "'", str27.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "GregorianChronology[UTC]" + "'", str30.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(durationField33);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfEra();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        java.lang.String str12 = property10.toString();
        boolean boolean13 = julianChronology0.equals((java.lang.Object) str12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = copticChronology14.getZone();
        java.util.TimeZone timeZone16 = dateTimeZone15.toTimeZone();
        org.joda.time.Chronology chronology17 = julianChronology0.withZone(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[yearOfEra]" + "'", str12.equals("Property[yearOfEra]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = copticChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology1);
        long long10 = copticChronology1.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 100, (org.joda.time.Chronology) copticChronology1);
        int int12 = dateTime11.getCenturyOfEra();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3121000L + "'", long10 == 3121000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 17 + "'", int12 == 17);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Partial partial6 = partial3.withFieldAddWrapped(durationFieldType4, 82559);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) '#', locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "millisOfDay");
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        long long24 = copticChronology15.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology15.year();
        org.joda.time.DurationField durationField26 = copticChronology15.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField26);
        org.joda.time.DurationField durationField28 = unsupportedDateTimeField27.getLeapDurationField();
        try {
            java.lang.String str30 = unsupportedDateTimeField27.getAsText(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1786" + "'", str11.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3121000L + "'", long24 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
        org.junit.Assert.assertNull(durationField28);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear(10);
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withWeekOfWeekyear(1136);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1136 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.DurationField durationField11 = copticChronology0.centuries();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate.Property property13 = localDate12.weekOfWeekyear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = copticChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfDay();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property7.getAsShortText(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        int int12 = property7.getMaximumValueOverall();
        int int13 = property7.getLeapAmount();
        java.lang.String str14 = property7.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property7.getFieldType();
        int int16 = partial0.indexOf(dateTimeFieldType15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.Partial partial18 = partial0.plus(readablePeriod17);
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.Chronology chronology21 = copticChronology19.withZone(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology19);
        org.joda.time.DateTime dateTime24 = dateTime22.plusDays((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = dateTime22.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime28 = dateTime26.withWeekyear(10);
        boolean boolean29 = partial18.isMatch((org.joda.time.ReadableInstant) dateTime26);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "72000018" + "'", str9.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "72000018" + "'", str11.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399999 + "'", int12 == 86399999);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "72000018" + "'", str14.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(partial18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendSecondOfMinute(82557374);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter6.getParser();
        java.lang.String str8 = dateTime3.toString(dateTimeFormatter6);
        org.joda.time.Partial partial9 = new org.joda.time.Partial();
        java.lang.String str10 = dateTimeFormatter6.print((org.joda.time.ReadablePartial) partial9);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "000000.018Z" + "'", str8.equals("000000.018Z"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "������.000" + "'", str10.equals("������.000"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtMidnight();
        boolean boolean12 = dateTime11.isAfterNow();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) '#', locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "millisOfDay");
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        long long24 = copticChronology15.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology15.year();
        org.joda.time.DurationField durationField26 = copticChronology15.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField26);
        org.joda.time.DurationField durationField28 = unsupportedDateTimeField27.getLeapDurationField();
        try {
            long long30 = unsupportedDateTimeField27.remainder((long) 86);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1786" + "'", str11.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3121000L + "'", long24 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
        org.junit.Assert.assertNull(durationField28);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, 21859200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsShortText(locale7);
        org.joda.time.DateTime dateTime9 = property6.roundHalfFloorCopy();
        int int10 = dateTime9.getMinuteOfDay();
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = copticChronology11.withZone(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology11.year();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = copticChronology15.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology11, dateTimeField18);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.Chronology chronology21 = copticChronology11.withZone(dateTimeZone20);
        org.joda.time.DurationField durationField22 = copticChronology11.days();
        org.joda.time.DateTime dateTime23 = dateTime9.withChronology((org.joda.time.Chronology) copticChronology11);
        org.joda.time.LocalDate localDate24 = dateTime23.toLocalDate();
        try {
            org.joda.time.LocalDate localDate26 = localDate24.withWeekOfWeekyear(82559);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82559 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "72000018" + "'", str8.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1200 + "'", int10 == 1200);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDate24);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtMidnight();
        int int12 = localDate9.getDayOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(292272808, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfMinute(72000018);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfDay((int) (byte) 0);
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatterBuilder10.toPrinter();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray12 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.append(dateTimePrinter11, dateTimeParserArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parsers supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = copticChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology5);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.withDurationAdded(readableDuration18, (int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime15.plusMonths(0);
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology4, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime22);
        java.lang.String str25 = dateTime11.toString("68162380");
        org.joda.time.DateTime dateTime27 = dateTime11.minusMonths((-28800000));
        org.joda.time.Partial partial28 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.Chronology chronology31 = copticChronology29.withZone(dateTimeZone30);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology29);
        org.joda.time.DateTime dateTime34 = dateTime32.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property35 = dateTime34.millisOfDay();
        java.util.Locale locale36 = null;
        java.lang.String str37 = property35.getAsShortText(locale36);
        java.util.Locale locale38 = null;
        java.lang.String str39 = property35.getAsText(locale38);
        int int40 = property35.getMaximumValueOverall();
        int int41 = property35.getLeapAmount();
        java.lang.String str42 = property35.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property35.getFieldType();
        int int44 = partial28.indexOf(dateTimeFieldType43);
        int int45 = dateTime11.get(dateTimeFieldType43);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType43, 57367, (int) (short) -1, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57367 for millisOfDay must be in the range [-1,6]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(limitChronology23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "68162380" + "'", str25.equals("68162380"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "72000018" + "'", str37.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "72000018" + "'", str39.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 86399999 + "'", int40 == 86399999);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "72000018" + "'", str42.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 18 + "'", int45 == 18);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DurationField durationField3 = copticChronology0.years();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.DurationField durationField11 = copticChronology0.centuries();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology0);
        int int13 = localDate12.getYear();
        java.util.Date date14 = localDate12.toDate();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        org.joda.time.DateTime dateTime20 = dateTime18.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime21 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.LocalDate localDate24 = localDate22.plus(readablePeriod23);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.Chronology chronology27 = copticChronology25.withZone(dateTimeZone26);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology25);
        org.joda.time.DateTime dateTime30 = dateTime28.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property31 = dateTime30.millisOfDay();
        java.util.Locale locale32 = null;
        java.lang.String str33 = property31.getAsShortText(locale32);
        java.util.Locale locale34 = null;
        java.lang.String str35 = property31.getAsText(locale34);
        int int36 = property31.getMaximumValueOverall();
        int int37 = property31.getLeapAmount();
        java.lang.String str38 = property31.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property31.getFieldType();
        boolean boolean40 = localDate22.isSupported(dateTimeFieldType39);
        org.joda.time.LocalDate localDate41 = localDate12.withFields((org.joda.time.ReadablePartial) localDate22);
        org.joda.time.LocalDate localDate43 = localDate41.plusDays(1);
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.Chronology chronology46 = copticChronology44.withZone(dateTimeZone45);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology44);
        long long53 = copticChronology44.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField54 = copticChronology44.year();
        org.joda.time.DurationField durationField55 = copticChronology44.centuries();
        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology44);
        int int57 = localDate56.getYear();
        org.joda.time.LocalDate.Property property58 = localDate56.era();
        boolean boolean59 = localDate41.isBefore((org.joda.time.ReadablePartial) localDate56);
        org.joda.time.DateMidnight dateMidnight60 = localDate41.toDateMidnight();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1686 + "'", int13 == 1686);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "72000018" + "'", str33.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "72000018" + "'", str35.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 86399999 + "'", int36 == 86399999);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "72000018" + "'", str38.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 3121000L + "'", long53 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1686 + "'", int57 == 1686);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(dateMidnight60);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Partial partial1 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property8.getAsShortText(locale9);
        java.util.Locale locale11 = null;
        java.lang.String str12 = property8.getAsText(locale11);
        int int13 = property8.getMaximumValueOverall();
        int int14 = property8.getLeapAmount();
        java.lang.String str15 = property8.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property8.getFieldType();
        int int17 = partial1.indexOf(dateTimeFieldType16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial1.plus(readablePeriod18);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.Chronology chronology22 = copticChronology20.withZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology20);
        org.joda.time.DateTime dateTime25 = dateTime23.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property26 = dateTime25.millisOfDay();
        java.util.Locale locale27 = null;
        java.lang.String str28 = property26.getAsShortText(locale27);
        java.util.Locale locale29 = null;
        java.lang.String str30 = property26.getAsText(locale29);
        int int31 = property26.getMaximumValueOverall();
        int int32 = property26.getLeapAmount();
        java.lang.String str33 = property26.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property26.getFieldType();
        org.joda.time.Partial partial35 = partial19.without(dateTimeFieldType34);
        int[] intArray36 = null;
        buddhistChronology0.validate((org.joda.time.ReadablePartial) partial19, intArray36);
        org.joda.time.DateTimeField dateTimeField38 = buddhistChronology0.year();
        org.joda.time.DateTimeField dateTimeField39 = buddhistChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "72000018" + "'", str10.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "72000018" + "'", str12.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399999 + "'", int13 == 86399999);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "72000018" + "'", str15.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "72000018" + "'", str28.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "72000018" + "'", str30.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 86399999 + "'", int31 == 86399999);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "72000018" + "'", str33.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(partial35);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210862267200000L) + "'", long1 == (-210862267200000L));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Partial partial1 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property8.getAsShortText(locale9);
        java.util.Locale locale11 = null;
        java.lang.String str12 = property8.getAsText(locale11);
        int int13 = property8.getMaximumValueOverall();
        int int14 = property8.getLeapAmount();
        java.lang.String str15 = property8.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property8.getFieldType();
        int int17 = partial1.indexOf(dateTimeFieldType16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial1.plus(readablePeriod18);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.Chronology chronology22 = copticChronology20.withZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology20);
        org.joda.time.DateTime dateTime25 = dateTime23.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property26 = dateTime25.millisOfDay();
        java.util.Locale locale27 = null;
        java.lang.String str28 = property26.getAsShortText(locale27);
        java.util.Locale locale29 = null;
        java.lang.String str30 = property26.getAsText(locale29);
        int int31 = property26.getMaximumValueOverall();
        int int32 = property26.getLeapAmount();
        java.lang.String str33 = property26.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property26.getFieldType();
        org.joda.time.Partial partial35 = partial19.without(dateTimeFieldType34);
        int[] intArray36 = null;
        buddhistChronology0.validate((org.joda.time.ReadablePartial) partial19, intArray36);
        org.joda.time.Chronology chronology38 = partial19.getChronology();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "72000018" + "'", str10.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "72000018" + "'", str12.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399999 + "'", int13 == 86399999);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "72000018" + "'", str15.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "72000018" + "'", str28.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "72000018" + "'", str30.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 86399999 + "'", int31 == 86399999);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "72000018" + "'", str33.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(partial35);
        org.junit.Assert.assertNotNull(chronology38);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
        org.joda.time.Partial partial3 = new org.joda.time.Partial(chronology2);
        org.joda.time.Chronology chronology4 = partial3.getChronology();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.Partial partial7 = partial3.withFieldAdded(durationFieldType5, 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("68161219", "1970W013T160000-0800");
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) '#', locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "millisOfDay");
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        long long24 = copticChronology15.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology15.year();
        org.joda.time.DurationField durationField26 = copticChronology15.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField26);
        try {
            int int29 = unsupportedDateTimeField27.get(2440588L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1786" + "'", str11.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3121000L + "'", long24 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.DurationField durationField5 = copticChronology0.eras();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.DurationField durationField11 = copticChronology0.centuries();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology0);
        int int13 = localDate12.getYear();
        java.util.Date date14 = localDate12.toDate();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        org.joda.time.DateTime dateTime20 = dateTime18.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime21 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.LocalDate localDate24 = localDate22.plus(readablePeriod23);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.Chronology chronology27 = copticChronology25.withZone(dateTimeZone26);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology25);
        org.joda.time.DateTime dateTime30 = dateTime28.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property31 = dateTime30.millisOfDay();
        java.util.Locale locale32 = null;
        java.lang.String str33 = property31.getAsShortText(locale32);
        java.util.Locale locale34 = null;
        java.lang.String str35 = property31.getAsText(locale34);
        int int36 = property31.getMaximumValueOverall();
        int int37 = property31.getLeapAmount();
        java.lang.String str38 = property31.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property31.getFieldType();
        boolean boolean40 = localDate22.isSupported(dateTimeFieldType39);
        org.joda.time.LocalDate localDate41 = localDate12.withFields((org.joda.time.ReadablePartial) localDate22);
        org.joda.time.LocalDate localDate43 = localDate41.plusDays(1);
        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.Chronology chronology46 = copticChronology44.withZone(dateTimeZone45);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology44);
        long long53 = copticChronology44.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField54 = copticChronology44.year();
        org.joda.time.DurationField durationField55 = copticChronology44.centuries();
        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology44);
        int int57 = localDate56.getYear();
        org.joda.time.LocalDate.Property property58 = localDate56.era();
        boolean boolean59 = localDate41.isBefore((org.joda.time.ReadablePartial) localDate56);
        int int60 = localDate56.getYearOfEra();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1686 + "'", int13 == 1686);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "72000018" + "'", str33.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "72000018" + "'", str35.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 86399999 + "'", int36 == 86399999);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "72000018" + "'", str38.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(copticChronology44);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 3121000L + "'", long53 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1686 + "'", int57 == 1686);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1686 + "'", int60 == 1686);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.DateTime.Property property4 = dateTime3.millisOfSecond();
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
//        int int9 = dateTimeZone6.getOffsetFromLocal((long) (byte) 100);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.DateTime.Property property13 = dateTime12.millisOfSecond();
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        org.joda.time.DateTime dateTime16 = dateTime12.toDateTime(dateTimeZone15);
//        int int18 = dateTimeZone15.getOffsetFromLocal((long) (byte) 100);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone15);
//        int int20 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        org.joda.time.DateTime.Property property24 = dateTime23.millisOfSecond();
//        int int25 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime23);
//        java.lang.String str27 = dateTimeZone6.getName((long) 6);
//        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone6);
//        int int29 = julianChronology1.getMinimumDaysInFirstWeek();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-28800000) + "'", int25 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("72000018", false);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.plusYears(0);
        int int11 = dateTime10.getWeekOfWeekyear();
        int int12 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property13 = dateTime5.secondOfDay();
        int int14 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime1.plus((long) 1);
//        int int8 = dateTime7.getSecondOfDay();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600 + "'", int8 == 57600);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) '#', locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "millisOfDay");
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        long long24 = copticChronology15.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology15.year();
        org.joda.time.DurationField durationField26 = copticChronology15.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField26);
        org.joda.time.DurationField durationField28 = unsupportedDateTimeField27.getLeapDurationField();
        long long31 = unsupportedDateTimeField27.add(0L, 0);
        try {
            long long33 = unsupportedDateTimeField27.roundHalfFloor(3121000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1786" + "'", str11.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3121000L + "'", long24 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
        org.junit.Assert.assertNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate.Property property11 = localDate9.yearOfEra();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.LocalDate localDate13 = localDate9.minus(readablePeriod12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology14.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology14);
        org.joda.time.DateTime dateTime19 = dateTime17.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime22 = dateTime17.withDurationAdded(readableDuration20, (int) (short) 100);
        org.joda.time.DateTime.Property property23 = dateTime17.dayOfYear();
        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.Chronology chronology26 = copticChronology24.withZone(dateTimeZone25);
        org.joda.time.DateTimeField dateTimeField27 = copticChronology24.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, (int) (byte) 100);
        long long32 = offsetDateTimeField29.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField29.getAsText((long) '#', locale34);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField29.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, "millisOfDay");
        int int39 = dateTime17.get(dateTimeFieldType36);
        try {
            org.joda.time.LocalDate localDate41 = localDate9.withField(dateTimeFieldType36, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(copticChronology24);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1786" + "'", str35.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1686 + "'", int39 == 1686);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = copticChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology5);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.withDurationAdded(readableDuration18, (int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime15.plusMonths(0);
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology4, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime22);
        try {
            long long29 = limitChronology23.getDateTimeMillis((-28800000L), (int) (byte) -1, 0, 3, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(limitChronology23);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("68161219", "68161520", (int) (short) 0, 18);
        int int6 = fixedDateTimeZone4.getOffset((long) '#');
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        int int7 = dateTime3.getCenturyOfEra();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 17 + "'", int7 == 17);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusYears(0);
        int int7 = dateTime6.getWeekOfWeekyear();
        int int8 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime10 = dateTime1.plusWeeks(82563);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendWeekyear(292272808, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.append(dateTimeFormatter8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter8.withPivotYear(9);
        boolean boolean12 = julianChronology1.equals((java.lang.Object) dateTimeFormatter8);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (byte) 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText((long) '#', locale12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = copticChronology15.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) (byte) 100);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField20.getAsText((long) (short) 100, locale22);
        org.joda.time.DurationField durationField24 = offsetDateTimeField20.getLeapDurationField();
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.Chronology chronology27 = copticChronology25.withZone(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = copticChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, (int) (byte) 100);
        long long33 = offsetDateTimeField30.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField30.getAsText((long) '#', locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = offsetDateTimeField30.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, durationField24, dateTimeFieldType37);
        long long41 = delegatedDateTimeField38.add((long) 9, 28857367L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1786" + "'", str13.equals("1786"));
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1786" + "'", str23.equals("1786"));
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1786" + "'", str36.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 910669244860800009L + "'", long41 == 910669244860800009L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.DurationField durationField11 = copticChronology0.centuries();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology0);
        int int13 = localDate12.getYear();
        java.util.Date date14 = localDate12.toDate();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        org.joda.time.DateTime dateTime20 = dateTime18.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime21 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.LocalDate localDate24 = localDate22.plus(readablePeriod23);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.Chronology chronology27 = copticChronology25.withZone(dateTimeZone26);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology25);
        org.joda.time.DateTime dateTime30 = dateTime28.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property31 = dateTime30.millisOfDay();
        java.util.Locale locale32 = null;
        java.lang.String str33 = property31.getAsShortText(locale32);
        java.util.Locale locale34 = null;
        java.lang.String str35 = property31.getAsText(locale34);
        int int36 = property31.getMaximumValueOverall();
        int int37 = property31.getLeapAmount();
        java.lang.String str38 = property31.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property31.getFieldType();
        boolean boolean40 = localDate22.isSupported(dateTimeFieldType39);
        org.joda.time.LocalDate localDate41 = localDate12.withFields((org.joda.time.ReadablePartial) localDate22);
        org.joda.time.LocalDate localDate43 = localDate22.withCenturyOfEra(36);
        org.joda.time.LocalDate localDate45 = localDate22.withWeekyear((int) ' ');
        org.joda.time.chrono.CopticChronology copticChronology46 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.Chronology chronology48 = copticChronology46.withZone(dateTimeZone47);
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology46);
        org.joda.time.DateTime dateTime51 = dateTime49.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime52 = dateTime51.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate53 = dateTime52.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.LocalDate localDate55 = localDate53.plus(readablePeriod54);
        org.joda.time.LocalDate.Property property56 = localDate55.dayOfWeek();
        boolean boolean57 = localDate45.isAfter((org.joda.time.ReadablePartial) localDate55);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1686 + "'", int13 == 1686);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "72000018" + "'", str33.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "72000018" + "'", str35.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 86399999 + "'", int36 == 86399999);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "72000018" + "'", str38.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertNotNull(copticChronology46);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
        int int14 = skipDateTimeField8.getMinimumValue((long) 10);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.DateTime.Property property20 = dateTime19.millisOfSecond();
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        org.joda.time.DateTime dateTime23 = dateTime19.toDateTime(dateTimeZone22);
        int int25 = dateTimeZone22.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone27);
        org.joda.time.DateTime.Property property29 = dateTime28.millisOfSecond();
        java.util.TimeZone timeZone30 = null;
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forTimeZone(timeZone30);
        org.joda.time.DateTime dateTime32 = dateTime28.toDateTime(dateTimeZone31);
        int int34 = dateTimeZone31.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone31);
        int int36 = dateTimeZone22.getOffset((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone38);
        org.joda.time.DateTime.Property property40 = dateTime39.millisOfSecond();
        int int41 = dateTimeZone22.getOffset((org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.chrono.ZonedChronology zonedChronology42 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology15, dateTimeZone22);
        org.joda.time.LocalDate localDate43 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology15);
        java.util.Locale locale45 = null;
        java.lang.String str46 = skipDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) localDate43, (int) (short) 1, locale45);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292269337) + "'", int14 == (-292269337));
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(zonedChronology42);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) '#', locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "millisOfDay");
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        long long24 = copticChronology15.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology15.year();
        org.joda.time.DurationField durationField26 = copticChronology15.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField26);
        org.joda.time.DurationField durationField28 = unsupportedDateTimeField27.getDurationField();
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.Chronology chronology31 = copticChronology29.withZone(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = copticChronology29.year();
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.Chronology chronology35 = copticChronology33.withZone(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField36 = copticChronology33.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology29, dateTimeField36);
        org.joda.time.ReadablePartial readablePartial38 = null;
        int int39 = skipDateTimeField37.getMaximumValue(readablePartial38);
        long long41 = skipDateTimeField37.roundFloor((long) (byte) 1);
        org.joda.time.DateTimeField dateTimeField42 = skipDateTimeField37.getWrappedField();
        boolean boolean43 = skipDateTimeField37.isLenient();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField44 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField37);
        long long47 = delegatedDateTimeField44.add((long) (byte) 10, 17);
        long long50 = delegatedDateTimeField44.add(0L, 9);
        org.joda.time.Partial partial51 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology52 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.Chronology chronology54 = copticChronology52.withZone(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology52);
        org.joda.time.DateTime dateTime57 = dateTime55.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property58 = dateTime57.millisOfDay();
        java.util.Locale locale59 = null;
        java.lang.String str60 = property58.getAsShortText(locale59);
        java.util.Locale locale61 = null;
        java.lang.String str62 = property58.getAsText(locale61);
        int int63 = property58.getMaximumValueOverall();
        int int64 = property58.getLeapAmount();
        java.lang.String str65 = property58.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property58.getFieldType();
        int int67 = partial51.indexOf(dateTimeFieldType66);
        org.joda.time.ReadablePeriod readablePeriod68 = null;
        org.joda.time.Partial partial69 = partial51.plus(readablePeriod68);
        org.joda.time.chrono.CopticChronology copticChronology70 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.Chronology chronology72 = copticChronology70.withZone(dateTimeZone71);
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology70);
        org.joda.time.DateTime dateTime75 = dateTime73.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property76 = dateTime75.millisOfDay();
        java.util.Locale locale77 = null;
        java.lang.String str78 = property76.getAsShortText(locale77);
        java.util.Locale locale79 = null;
        java.lang.String str80 = property76.getAsText(locale79);
        int int81 = property76.getMaximumValueOverall();
        int int82 = property76.getLeapAmount();
        java.lang.String str83 = property76.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType84 = property76.getFieldType();
        org.joda.time.Partial partial85 = partial69.without(dateTimeFieldType84);
        int int86 = delegatedDateTimeField44.getMaximumValue((org.joda.time.ReadablePartial) partial85);
        try {
            int int87 = unsupportedDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) partial85);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1786" + "'", str11.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3121000L + "'", long24 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 292272708 + "'", int39 == 292272708);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-9676800000L) + "'", long41 == (-9676800000L));
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 536457600010L + "'", long47 == 536457600010L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 283996800000L + "'", long50 == 283996800000L);
        org.junit.Assert.assertNotNull(copticChronology52);
        org.junit.Assert.assertNotNull(chronology54);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "72000018" + "'", str60.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "72000018" + "'", str62.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 86399999 + "'", int63 == 86399999);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "72000018" + "'", str65.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(partial69);
        org.junit.Assert.assertNotNull(copticChronology70);
        org.junit.Assert.assertNotNull(chronology72);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(property76);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "72000018" + "'", str78.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "72000018" + "'", str80.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 86399999 + "'", int81 == 86399999);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "72000018" + "'", str83.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType84);
        org.junit.Assert.assertNotNull(partial85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 292272708 + "'", int86 == 292272708);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean3 = gJChronology0.equals((java.lang.Object) dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfSecond();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.DateTime dateTime9 = dateTime5.toDateTime(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gJChronology0.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology11 = gJChronology0.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) -1);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = copticChronology11.withZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology11);
        org.joda.time.DateTime dateTime16 = dateTime14.minusHours((int) (byte) 100);
        boolean boolean17 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime14);
        try {
            org.joda.time.DateTime dateTime19 = dateTime10.withCenturyOfEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [1,2922728]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-292269338), (int) (byte) -1, 1735, (-292269337), 0, 0, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269337 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfWeek();
        java.lang.String str4 = property3.toString();
        org.joda.time.DateTime dateTime6 = property3.addToCopy(3121000L);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime9 = dateTime6.minusWeeks((-292269338));
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[dayOfWeek]" + "'", str4.equals("Property[dayOfWeek]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 0, 82557322);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 82557322 + "'", int2 == 82557322);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = partial0.getFieldTypes();
        int int2 = partial0.size();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.Partial partial5 = partial0.withFieldAdded(durationFieldType3, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder0.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        try {
            long long14 = copticChronology0.getDateTimeMillis((-292269238), 1136, (-292269238), (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfWeek();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        int int5 = dateTime4.getYearOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(2764801018L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440619.5000117826d + "'", double1 == 2440619.5000117826d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField5.getMaximumValue(readablePartial6);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField5.getMaximumShortTextLength(locale8);
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getRangeDurationField();
        long long13 = offsetDateTimeField5.add(0L, 82563);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology14.withZone(dateTimeZone15);
        org.joda.time.DurationField durationField17 = copticChronology14.years();
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.Chronology chronology20 = copticChronology18.withZone(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = copticChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) (byte) 100);
        long long26 = offsetDateTimeField23.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField23.getAsText((long) '#', locale28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField23.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, durationField17, dateTimeFieldType30, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292272808 + "'", int7 == 292272808);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2605490150400000L + "'", long13 == 2605490150400000L);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1786" + "'", str29.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate.Property property10 = localDate9.year();
        try {
            org.joda.time.LocalDate localDate12 = localDate9.withYearOfEra((-292269338));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269338 for yearOfEra must be in the range [1,292272708]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField8.getAsShortText(0, locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField8.getAsShortText((-1), locale15);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) chronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.CopticChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("GregorianChronology[UTC]", (java.lang.Number) (short) 100, (java.lang.Number) 292272708, (java.lang.Number) (short) -1);
        java.lang.String str5 = illegalFieldValueException4.toString();
        illegalFieldValueException4.prependMessage("GregorianChronology[UTC]");
        org.joda.time.DurationFieldType durationFieldType8 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number9 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100 for GregorianChronology[UTC] must be in the range [292272708,-1]" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value 100 for GregorianChronology[UTC] must be in the range [292272708,-1]"));
        org.junit.Assert.assertNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 292272708 + "'", number9.equals(292272708));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(1686);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 1686");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfSecond();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone6);
        int int9 = dateTimeZone6.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.millisOfSecond();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.DateTime dateTime16 = dateTime12.toDateTime(dateTimeZone15);
        int int18 = dateTimeZone15.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone15);
        int int20 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfSecond();
        int int25 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime27 = dateTime23.minus(0L);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsText((long) (short) 100, locale11);
        long long14 = offsetDateTimeField9.roundCeiling((long) 1136);
        org.joda.time.DurationField durationField15 = offsetDateTimeField9.getDurationField();
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.Chronology chronology18 = copticChronology16.withZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology16);
        org.joda.time.DateTime dateTime21 = dateTime19.plusDays((int) ' ');
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.Chronology chronology24 = copticChronology22.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology22);
        org.joda.time.DateTime dateTime27 = dateTime25.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime30 = dateTime25.withDurationAdded(readableDuration28, (int) (short) 100);
        org.joda.time.DateTime dateTime32 = dateTime25.plusMonths(0);
        org.joda.time.DateTime.Property property33 = dateTime32.millisOfSecond();
        boolean boolean34 = dateTime21.equals((java.lang.Object) dateTime32);
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.Chronology chronology37 = copticChronology35.withZone(dateTimeZone36);
        org.joda.time.DateTimeField dateTimeField38 = copticChronology35.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, (int) (byte) 100);
        long long43 = offsetDateTimeField40.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale45 = null;
        java.lang.String str46 = offsetDateTimeField40.getAsText((long) '#', locale45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = offsetDateTimeField40.getType();
        boolean boolean48 = dateTime32.isSupported(dateTimeFieldType47);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, durationField15, dateTimeFieldType47);
        int int50 = delegatedDateTimeField49.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1786" + "'", str12.equals("1786"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 21859200000L + "'", long14 == 21859200000L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1786" + "'", str46.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 999 + "'", int50 == 999);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (byte) 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText((long) '#', locale12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7);
        int int17 = skipDateTimeField14.getDifference((long) 1, (long) 82563);
        int int20 = skipDateTimeField14.getDifference((-91L), (long) 35);
        int int22 = skipDateTimeField14.get((long) '#');
        org.joda.time.DateTimeField dateTimeField23 = skipDateTimeField14.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1786" + "'", str13.equals("1786"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1786 + "'", int22 == 1786);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.addWrapField((-9676800000L), 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 999);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 116553600000L + "'", long8 == 116553600000L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField5.getAsText((long) (short) 100, locale7);
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.Partial partial10 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = copticChronology11.withZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology11);
        org.joda.time.DateTime dateTime16 = dateTime14.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfDay();
        java.util.Locale locale18 = null;
        java.lang.String str19 = property17.getAsShortText(locale18);
        java.util.Locale locale20 = null;
        java.lang.String str21 = property17.getAsText(locale20);
        int int22 = property17.getMaximumValueOverall();
        int int23 = property17.getLeapAmount();
        java.lang.String str24 = property17.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property17.getFieldType();
        int int26 = partial10.indexOf(dateTimeFieldType25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.Partial partial28 = partial10.plus(readablePeriod27);
        java.util.Locale locale29 = null;
        try {
            java.lang.String str30 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) partial10, locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1786" + "'", str8.equals("1786"));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "72000018" + "'", str19.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "72000018" + "'", str21.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 86399999 + "'", int22 == 86399999);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "72000018" + "'", str24.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(partial28);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (byte) 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText((long) '#', locale12);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = copticChronology15.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) (byte) 100);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField20.getAsText((long) (short) 100, locale22);
        org.joda.time.DurationField durationField24 = offsetDateTimeField20.getLeapDurationField();
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.Chronology chronology27 = copticChronology25.withZone(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = copticChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, (int) (byte) 100);
        long long33 = offsetDateTimeField30.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField30.getAsText((long) '#', locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = offsetDateTimeField30.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, durationField24, dateTimeFieldType37);
        int int40 = offsetDateTimeField7.get(2764801018L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1786" + "'", str13.equals("1786"));
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1786" + "'", str23.equals("1786"));
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1786" + "'", str36.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1786 + "'", int40 == 1786);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes((int) (short) 100);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.Chronology chronology10 = copticChronology8.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded(readableDuration14, (int) '#');
        boolean boolean17 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime13);
        try {
            org.joda.time.DateTime dateTime19 = dateTime13.withSecondOfMinute(1686);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1686 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.minusDays((int) (short) 0);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfSecond();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = copticChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology5);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.withDurationAdded(readableDuration18, (int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime15.plusMonths(0);
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology4, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime22);
        java.lang.String str25 = dateTime11.toString("68162380");
        org.joda.time.DateTime dateTime27 = dateTime11.withWeekyear(9);
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime27.toMutableDateTime();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(limitChronology23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "68162380" + "'", str25.equals("68162380"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.LocalDate.Property property8 = localDate7.year();
        java.util.Locale locale9 = null;
        int int10 = property8.getMaximumShortTextLength(locale9);
        org.joda.time.LocalDate localDate12 = property8.addToCopy((int) '#');
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfEra();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        java.lang.String str12 = property10.toString();
        boolean boolean13 = julianChronology0.equals((java.lang.Object) str12);
        org.joda.time.DateTimeField dateTimeField14 = julianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[yearOfEra]" + "'", str12.equals("Property[yearOfEra]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) '#', locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "millisOfDay");
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        long long24 = copticChronology15.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology15.year();
        org.joda.time.DurationField durationField26 = copticChronology15.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField26);
        org.joda.time.DurationField durationField28 = unsupportedDateTimeField27.getLeapDurationField();
        long long31 = unsupportedDateTimeField27.add(0L, 0);
        java.util.Locale locale33 = null;
        try {
            java.lang.String str34 = unsupportedDateTimeField27.getAsShortText((long) 57, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1786" + "'", str11.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3121000L + "'", long24 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
        org.junit.Assert.assertNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("68161219", "68161520", (int) (short) 0, 18);
        int int6 = fixedDateTimeZone4.getOffset((long) '#');
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 82563);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = partial0.getFieldTypes();
        int int2 = partial0.size();
        java.lang.String str3 = partial0.toStringList();
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[]" + "'", str3.equals("[]"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = copticChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology1);
        long long10 = copticChronology1.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology1.year();
        org.joda.time.DurationField durationField12 = copticChronology1.centuries();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) copticChronology1);
        try {
            org.joda.time.DateTime dateTime18 = dateTime14.withDate(82559, 0, (-292269337));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3121000L + "'", long10 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField8.getWrappedField();
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.Chronology chronology16 = copticChronology14.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology14);
        org.joda.time.DateTime dateTime19 = dateTime17.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) ' ');
        org.joda.time.DateTime dateTime24 = dateTime22.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay25 = dateTime22.toTimeOfDay();
        int int26 = skipDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay25);
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.Chronology chronology30 = copticChronology28.withZone(dateTimeZone29);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology28);
        org.joda.time.DateTime dateTime33 = dateTime31.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property34 = dateTime33.millisOfDay();
        java.util.Locale locale35 = null;
        java.lang.String str36 = property34.getAsShortText(locale35);
        java.util.Locale locale37 = null;
        java.lang.String str38 = property34.getAsText(locale37);
        int int39 = property34.getMaximumValueOverall();
        int int40 = property34.getLeapAmount();
        java.lang.String str41 = property34.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property34.getFieldType();
        int int43 = partial27.indexOf(dateTimeFieldType42);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.Partial partial45 = partial27.plus(readablePeriod44);
        org.joda.time.chrono.CopticChronology copticChronology46 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.Chronology chronology48 = copticChronology46.withZone(dateTimeZone47);
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology46);
        org.joda.time.DateTime dateTime51 = dateTime49.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property52 = dateTime51.millisOfDay();
        java.util.Locale locale53 = null;
        java.lang.String str54 = property52.getAsShortText(locale53);
        java.util.Locale locale55 = null;
        java.lang.String str56 = property52.getAsText(locale55);
        int int57 = property52.getMaximumValueOverall();
        int int58 = property52.getLeapAmount();
        java.lang.String str59 = property52.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property52.getFieldType();
        org.joda.time.Partial partial61 = partial45.without(dateTimeFieldType60);
        int[] intArray63 = null;
        try {
            int[] intArray65 = skipDateTimeField8.add((org.joda.time.ReadablePartial) partial61, 57367, intArray63, 1200);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(timeOfDay25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-292269338) + "'", int26 == (-292269338));
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "72000018" + "'", str36.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "72000018" + "'", str38.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 86399999 + "'", int39 == 86399999);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "72000018" + "'", str41.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(partial45);
        org.junit.Assert.assertNotNull(copticChronology46);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "72000018" + "'", str54.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "72000018" + "'", str56.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 86399999 + "'", int57 == 86399999);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "72000018" + "'", str59.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertNotNull(partial61);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        long long3 = dateTimeZone1.convertUTCToLocal(0L);
        java.lang.String str4 = dateTimeZone1.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "68161219" + "'", str4.equals("68161219"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.DurationField durationField11 = copticChronology0.centuries();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology0);
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        org.joda.time.DateMidnight dateMidnight15 = localDate12.toDateMidnight(dateTimeZone14);
        int int16 = localDate12.getYearOfEra();
        try {
            org.joda.time.LocalDate localDate18 = localDate12.withDayOfMonth(72000018);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 72000018 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateMidnight15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1686 + "'", int16 == 1686);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes((int) (short) 100);
        int int8 = dateTime7.getHourOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(72000018);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 72000018");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField8.getWrappedField();
        boolean boolean14 = skipDateTimeField8.isLenient();
        int int15 = skipDateTimeField8.getMinimumValue();
        boolean boolean16 = skipDateTimeField8.isLenient();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-292269339) + "'", int15 == (-292269339));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865896000000L) + "'", long1 == (-210865896000000L));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHourOfDay((int) (byte) 0);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatterBuilder4.toPrinter();
        boolean boolean6 = dateTimeFormatterBuilder4.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) '#', locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "millisOfDay");
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        long long24 = copticChronology15.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology15.year();
        org.joda.time.DurationField durationField26 = copticChronology15.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField26);
        try {
            int int28 = unsupportedDateTimeField27.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1786" + "'", str11.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3121000L + "'", long24 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("97");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"97/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.LocalDate.Property property8 = localDate7.year();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.LocalDate localDate11 = property8.addToCopy(1);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = copticChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfDay();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property7.getAsShortText(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        int int12 = property7.getMaximumValueOverall();
        int int13 = property7.getLeapAmount();
        java.lang.String str14 = property7.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property7.getFieldType();
        int int16 = partial0.indexOf(dateTimeFieldType15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.Partial partial18 = partial0.plus(readablePeriod17);
        org.joda.time.DurationFieldType durationFieldType19 = null;
        try {
            org.joda.time.Partial partial21 = partial18.withFieldAddWrapped(durationFieldType19, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "72000018" + "'", str9.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "72000018" + "'", str11.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399999 + "'", int12 == 86399999);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "72000018" + "'", str14.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(partial18);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = copticChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) 100);
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField4);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.DurationField durationField9 = skipDateTimeField7.getRangeDurationField();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.Chronology chronology12 = copticChronology10.withZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology10);
        long long19 = copticChronology10.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology10.year();
        org.joda.time.DurationField durationField21 = copticChronology10.centuries();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology10);
        java.util.TimeZone timeZone23 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
        org.joda.time.DateMidnight dateMidnight25 = localDate22.toDateMidnight(dateTimeZone24);
        int int26 = localDate22.getMonthOfYear();
        int int27 = localDate22.getYearOfCentury();
        int int28 = localDate22.getWeekyear();
        org.joda.time.Partial partial30 = new org.joda.time.Partial();
        org.joda.time.chrono.CopticChronology copticChronology31 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.Chronology chronology33 = copticChronology31.withZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology31);
        org.joda.time.DateTime dateTime36 = dateTime34.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property37 = dateTime36.millisOfDay();
        java.util.Locale locale38 = null;
        java.lang.String str39 = property37.getAsShortText(locale38);
        java.util.Locale locale40 = null;
        java.lang.String str41 = property37.getAsText(locale40);
        int int42 = property37.getMaximumValueOverall();
        int int43 = property37.getLeapAmount();
        java.lang.String str44 = property37.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property37.getFieldType();
        int int46 = partial30.indexOf(dateTimeFieldType45);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.Partial partial48 = partial30.plus(readablePeriod47);
        org.joda.time.chrono.CopticChronology copticChronology49 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.Chronology chronology51 = copticChronology49.withZone(dateTimeZone50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology49);
        org.joda.time.DateTime dateTime54 = dateTime52.minusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property55 = dateTime54.millisOfDay();
        java.util.Locale locale56 = null;
        java.lang.String str57 = property55.getAsShortText(locale56);
        java.util.Locale locale58 = null;
        java.lang.String str59 = property55.getAsText(locale58);
        int int60 = property55.getMaximumValueOverall();
        int int61 = property55.getLeapAmount();
        java.lang.String str62 = property55.getAsShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = property55.getFieldType();
        org.joda.time.Partial partial64 = partial48.without(dateTimeFieldType63);
        int[] intArray65 = partial48.getValues();
        try {
            int[] intArray67 = skipDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) localDate22, 4, intArray65, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3121000L + "'", long19 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateMidnight25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 86 + "'", int27 == 86);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1686 + "'", int28 == 1686);
        org.junit.Assert.assertNotNull(copticChronology31);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "72000018" + "'", str39.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "72000018" + "'", str41.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86399999 + "'", int42 == 86399999);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "72000018" + "'", str44.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(partial48);
        org.junit.Assert.assertNotNull(copticChronology49);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "72000018" + "'", str57.equals("72000018"));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "72000018" + "'", str59.equals("72000018"));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 86399999 + "'", int60 == 86399999);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "72000018" + "'", str62.equals("72000018"));
        org.junit.Assert.assertNotNull(dateTimeFieldType63);
        org.junit.Assert.assertNotNull(partial64);
        org.junit.Assert.assertNotNull(intArray65);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 1136);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-91L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210874622400000L) + "'", long1 == (-210874622400000L));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsText((long) (short) 100, locale11);
        long long14 = offsetDateTimeField9.roundCeiling((long) 1136);
        org.joda.time.DurationField durationField15 = offsetDateTimeField9.getDurationField();
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.Chronology chronology18 = copticChronology16.withZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology16);
        org.joda.time.DateTime dateTime21 = dateTime19.plusDays((int) ' ');
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.Chronology chronology24 = copticChronology22.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology22);
        org.joda.time.DateTime dateTime27 = dateTime25.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime30 = dateTime25.withDurationAdded(readableDuration28, (int) (short) 100);
        org.joda.time.DateTime dateTime32 = dateTime25.plusMonths(0);
        org.joda.time.DateTime.Property property33 = dateTime32.millisOfSecond();
        boolean boolean34 = dateTime21.equals((java.lang.Object) dateTime32);
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.Chronology chronology37 = copticChronology35.withZone(dateTimeZone36);
        org.joda.time.DateTimeField dateTimeField38 = copticChronology35.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, (int) (byte) 100);
        long long43 = offsetDateTimeField40.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale45 = null;
        java.lang.String str46 = offsetDateTimeField40.getAsText((long) '#', locale45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = offsetDateTimeField40.getType();
        boolean boolean48 = dateTime32.isSupported(dateTimeFieldType47);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, durationField15, dateTimeFieldType47);
        org.joda.time.chrono.CopticChronology copticChronology50 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.Chronology chronology52 = copticChronology50.withZone(dateTimeZone51);
        org.joda.time.DateTimeField dateTimeField53 = copticChronology50.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, (int) (byte) 100);
        long long58 = offsetDateTimeField55.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale60 = null;
        java.lang.String str61 = offsetDateTimeField55.getAsText((long) '#', locale60);
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = offsetDateTimeField55.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, "millisOfDay");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField65 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField49, dateTimeFieldType62);
        long long67 = zeroIsMaxDateTimeField65.remainder(1560639361448L);
        org.joda.time.chrono.CopticChronology copticChronology68 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone69 = null;
        org.joda.time.Chronology chronology70 = copticChronology68.withZone(dateTimeZone69);
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology68);
        long long77 = copticChronology68.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField78 = copticChronology68.year();
        org.joda.time.DurationField durationField79 = copticChronology68.centuries();
        org.joda.time.LocalDate localDate80 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology68);
        int int81 = localDate80.getYear();
        int[] intArray83 = null;
        try {
            int[] intArray85 = zeroIsMaxDateTimeField65.addWrapField((org.joda.time.ReadablePartial) localDate80, 0, intArray83, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1786" + "'", str12.equals("1786"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 21859200000L + "'", long14 == 21859200000L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1786" + "'", str46.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(copticChronology50);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "1786" + "'", str61.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
        org.junit.Assert.assertNotNull(copticChronology68);
        org.junit.Assert.assertNotNull(chronology70);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 3121000L + "'", long77 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField78);
        org.junit.Assert.assertNotNull(durationField79);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1686 + "'", int81 == 1686);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = copticChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.year();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = copticChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology5.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.Chronology chronology11 = copticChronology1.withZone(dateTimeZone10);
        org.joda.time.DurationField durationField12 = copticChronology1.days();
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = copticChronology13.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = copticChronology13.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) (byte) 100);
        long long21 = offsetDateTimeField18.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField18.getAsText((long) '#', locale23);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField18.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "millisOfDay");
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.Chronology chronology30 = copticChronology28.withZone(dateTimeZone29);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology28);
        long long37 = copticChronology28.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField38 = copticChronology28.year();
        org.joda.time.DurationField durationField39 = copticChronology28.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField40 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField39);
        org.joda.time.DurationField durationField41 = unsupportedDateTimeField40.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = unsupportedDateTimeField40.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField43 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField12, dateTimeFieldType42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1786" + "'", str24.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3121000L + "'", long37 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField40);
        org.junit.Assert.assertNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField5.getMaximumValue(readablePartial6);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getLeapDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292272808 + "'", int7 == 292272808);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone7);
        int int10 = dateTimeZone7.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfSecond();
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTime(dateTimeZone16);
        int int19 = dateTimeZone16.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone16);
        int int21 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
        org.joda.time.DateTime.Property property25 = dateTime24.millisOfSecond();
        int int26 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone7);
        try {
            long long33 = zonedChronology27.getDateTimeMillis(10L, 1735, 36, 0, 82558);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1735 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(zonedChronology27);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = copticChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) 100);
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField4);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        java.lang.String str9 = skipDateTimeField7.toString();
        org.joda.time.DurationField durationField10 = skipDateTimeField7.getRangeDurationField();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[year]" + "'", str9.equals("DateTimeField[year]"));
        org.junit.Assert.assertNull(durationField10);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone4);
        int int7 = dateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfSecond();
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.DateTime dateTime14 = dateTime10.toDateTime(dateTimeZone13);
        int int16 = dateTimeZone13.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone13);
        int int18 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.millisOfSecond();
        int int23 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime25 = dateTime21.minus(0L);
        org.joda.time.DateTime dateTime27 = dateTime25.plusMonths(999);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.LocalDate.Property property8 = localDate7.year();
        java.util.Locale locale9 = null;
        int int10 = property8.getMaximumShortTextLength(locale9);
        org.joda.time.LocalDate localDate12 = property8.setCopy((int) (byte) 100);
        org.joda.time.LocalDate localDate13 = property8.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate13);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) '4');
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneId();
        dateTimeFormatterBuilder5.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate.Property property11 = localDate9.yearOfEra();
        try {
            org.joda.time.DateTimeField dateTimeField13 = localDate9.getField((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 52");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.Chronology chronology10 = copticChronology0.withZone(dateTimeZone9);
        org.joda.time.DurationField durationField11 = copticChronology0.days();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) '#', locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "millisOfDay");
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        long long24 = copticChronology15.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology15.year();
        org.joda.time.DurationField durationField26 = copticChronology15.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField26);
        org.joda.time.DurationField durationField28 = unsupportedDateTimeField27.getDurationField();
        try {
            long long30 = unsupportedDateTimeField27.roundHalfEven((long) 999);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1786" + "'", str11.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3121000L + "'", long24 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.Chronology chronology13 = copticChronology11.withZone(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology11);
//        long long20 = copticChronology11.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
//        org.joda.time.DateTimeField dateTimeField21 = copticChronology11.year();
//        org.joda.time.DurationField durationField22 = copticChronology11.centuries();
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology11);
//        int int24 = localDate23.getYear();
//        java.util.Date date25 = localDate23.toDate();
//        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.Chronology chronology28 = copticChronology26.withZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology26);
//        org.joda.time.DateTime dateTime31 = dateTime29.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime32 = dateTime31.withLaterOffsetAtOverlap();
//        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.LocalDate localDate35 = localDate33.plus(readablePeriod34);
//        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.Chronology chronology38 = copticChronology36.withZone(dateTimeZone37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology36);
//        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((int) (byte) 100);
//        org.joda.time.DateTime.Property property42 = dateTime41.millisOfDay();
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = property42.getAsShortText(locale43);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = property42.getAsText(locale45);
//        int int47 = property42.getMaximumValueOverall();
//        int int48 = property42.getLeapAmount();
//        java.lang.String str49 = property42.getAsShortText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = property42.getFieldType();
//        boolean boolean51 = localDate33.isSupported(dateTimeFieldType50);
//        org.joda.time.LocalDate localDate52 = localDate23.withFields((org.joda.time.ReadablePartial) localDate33);
//        org.joda.time.LocalDate localDate54 = localDate52.plusDays(1);
//        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.Chronology chronology57 = copticChronology55.withZone(dateTimeZone56);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology55);
//        long long64 = copticChronology55.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
//        org.joda.time.DateTimeField dateTimeField65 = copticChronology55.year();
//        org.joda.time.DurationField durationField66 = copticChronology55.centuries();
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology55);
//        int int68 = localDate67.getYear();
//        org.joda.time.LocalDate.Property property69 = localDate67.era();
//        boolean boolean70 = localDate52.isBefore((org.joda.time.ReadablePartial) localDate67);
//        java.util.Locale locale72 = null;
//        java.lang.String str73 = skipDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate52, 36, locale72);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3121000L + "'", long20 == 3121000L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1735 + "'", int24 == 1735);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(copticChronology26);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(copticChronology36);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "68208963" + "'", str44.equals("68208963"));
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "68208963" + "'", str46.equals("68208963"));
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 86399999 + "'", int47 == 86399999);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "68208963" + "'", str49.equals("68208963"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertNotNull(copticChronology55);
//        org.junit.Assert.assertNotNull(chronology57);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 3121000L + "'", long64 == 3121000L);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertNotNull(durationField66);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1735 + "'", int68 == 1735);
//        org.junit.Assert.assertNotNull(property69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "36" + "'", str73.equals("36"));
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = copticChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology5);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.withDurationAdded(readableDuration18, (int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime15.plusMonths(0);
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology4, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
        org.joda.time.DateTime.Property property27 = dateTime26.millisOfSecond();
        java.util.TimeZone timeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forTimeZone(timeZone28);
        org.joda.time.DateTime dateTime30 = dateTime26.toDateTime(dateTimeZone29);
        int int32 = dateTimeZone29.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone29);
        org.joda.time.Chronology chronology34 = iSOChronology24.withZone(dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone35);
        org.joda.time.DateTime.Property property37 = dateTime36.millisOfSecond();
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        org.joda.time.DateTime dateTime40 = dateTime36.toDateTime(dateTimeZone39);
        int int42 = dateTimeZone39.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone44);
        org.joda.time.DateTime.Property property46 = dateTime45.millisOfSecond();
        java.util.TimeZone timeZone47 = null;
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forTimeZone(timeZone47);
        org.joda.time.DateTime dateTime49 = dateTime45.toDateTime(dateTimeZone48);
        int int51 = dateTimeZone48.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(dateTimeZone48);
        int int53 = dateTimeZone39.getOffset((org.joda.time.ReadableInstant) dateTime52);
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.Chronology chronology55 = iSOChronology24.withZone(dateTimeZone39);
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology24.halfdayOfDay();
        boolean boolean57 = dateTime11.equals((java.lang.Object) dateTimeField56);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(limitChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(chronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = copticChronology13.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology13);
        org.joda.time.DateTime dateTime18 = dateTime16.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.withPeriodAdded(readablePeriod19, (int) ' ');
        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay24 = dateTime21.toTimeOfDay();
        int[] intArray28 = new int[] { (short) 0, 82558, 82557322 };
        int int29 = skipDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay24, intArray28);
        org.joda.time.DateTimeField dateTimeField30 = skipDateTimeField8.getWrappedField();
        org.joda.time.DurationField durationField31 = skipDateTimeField8.getRangeDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(timeOfDay24);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292272708 + "'", int29 == 292272708);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNull(durationField31);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.lang.Object obj0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = copticChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology5);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.withDurationAdded(readableDuration18, (int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime15.plusMonths(0);
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology4, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime22);
        org.joda.time.DateTimeField dateTimeField24 = limitChronology23.dayOfYear();
        org.joda.time.DateTime dateTime25 = limitChronology23.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone26 = limitChronology23.getZone();
        try {
            long long34 = limitChronology23.getDateTimeMillis(0, (int) '#', 4, (int) (byte) 10, 1136, (int) '#', 57367);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1136 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(limitChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(57367, true);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendWeekyear((-292269338), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate.Property property11 = localDate9.yearOfEra();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.LocalDate localDate13 = localDate9.minus(readablePeriod12);
        org.joda.time.DateTimeField[] dateTimeFieldArray14 = localDate9.getFields();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTimeFieldArray14);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.plusYears(0);
//        int int7 = dateTime6.getWeekOfWeekyear();
//        int int8 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        int int9 = dateTime1.getMillisOfDay();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 82610609 + "'", int9 == 82610609);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = julianChronology1.withUTC();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsText((long) (short) 100, locale11);
        long long14 = offsetDateTimeField9.roundCeiling((long) 1136);
        org.joda.time.DurationField durationField15 = offsetDateTimeField9.getDurationField();
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.Chronology chronology18 = copticChronology16.withZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology16);
        org.joda.time.DateTime dateTime21 = dateTime19.plusDays((int) ' ');
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.Chronology chronology24 = copticChronology22.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology22);
        org.joda.time.DateTime dateTime27 = dateTime25.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime30 = dateTime25.withDurationAdded(readableDuration28, (int) (short) 100);
        org.joda.time.DateTime dateTime32 = dateTime25.plusMonths(0);
        org.joda.time.DateTime.Property property33 = dateTime32.millisOfSecond();
        boolean boolean34 = dateTime21.equals((java.lang.Object) dateTime32);
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.Chronology chronology37 = copticChronology35.withZone(dateTimeZone36);
        org.joda.time.DateTimeField dateTimeField38 = copticChronology35.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, (int) (byte) 100);
        long long43 = offsetDateTimeField40.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale45 = null;
        java.lang.String str46 = offsetDateTimeField40.getAsText((long) '#', locale45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = offsetDateTimeField40.getType();
        boolean boolean48 = dateTime32.isSupported(dateTimeFieldType47);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, durationField15, dateTimeFieldType47);
        org.joda.time.chrono.CopticChronology copticChronology50 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.Chronology chronology52 = copticChronology50.withZone(dateTimeZone51);
        org.joda.time.DateTimeField dateTimeField53 = copticChronology50.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, (int) (byte) 100);
        long long58 = offsetDateTimeField55.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale60 = null;
        java.lang.String str61 = offsetDateTimeField55.getAsText((long) '#', locale60);
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = offsetDateTimeField55.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, "millisOfDay");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField65 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField49, dateTimeFieldType62);
        long long68 = zeroIsMaxDateTimeField65.add((long) 292272708, 0);
        try {
            long long71 = zeroIsMaxDateTimeField65.set((long) 82563, (-292269238));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269238 for year must be in the range [1,1000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1786" + "'", str12.equals("1786"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 21859200000L + "'", long14 == 21859200000L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1786" + "'", str46.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(copticChronology50);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "1786" + "'", str61.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 292272708L + "'", long68 == 292272708L);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.Chronology chronology12 = copticChronology10.withZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology10);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusHours((int) (byte) 100);
//        org.joda.time.DateTime.Property property16 = dateTime15.millisOfDay();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        int int21 = property16.getMaximumValueOverall();
//        int int22 = property16.getLeapAmount();
//        java.lang.String str23 = property16.getAsShortText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property16.getFieldType();
//        boolean boolean25 = localDate7.isSupported(dateTimeFieldType24);
//        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.Chronology chronology28 = copticChronology26.withZone(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField29 = copticChronology26.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) (byte) 100);
//        long long34 = offsetDateTimeField31.getDifferenceAsLong((long) 292272808, (long) ' ');
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = offsetDateTimeField31.getAsText((long) '#', locale36);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField31.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, "millisOfDay");
//        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.Chronology chronology43 = copticChronology41.withZone(dateTimeZone42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology41);
//        long long50 = copticChronology41.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
//        org.joda.time.DateTimeField dateTimeField51 = copticChronology41.year();
//        org.joda.time.DurationField durationField52 = copticChronology41.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField53 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField52);
//        org.joda.time.LocalDate.Property property54 = localDate7.property(dateTimeFieldType38);
//        org.joda.time.LocalDate localDate55 = property54.roundCeilingCopy();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "68210698" + "'", str18.equals("68210698"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "68210698" + "'", str20.equals("68210698"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 86399999 + "'", int21 == 86399999);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "68210698" + "'", str23.equals("68210698"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(copticChronology26);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1786" + "'", str37.equals("1786"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(copticChronology41);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 3121000L + "'", long50 == 3121000L);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(localDate55);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.DurationField durationField5 = copticChronology0.eras();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology0.weekyearOfCentury();
        try {
            long long15 = copticChronology0.getDateTimeMillis(82558, 82557374, (int) 'a', 292272808, 8, 999, 292272808);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292272808 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        int int5 = dateTimeZone1.getOffsetFromLocal((-210866760000000L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "68161219" + "'", str3.equals("68161219"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfWeek();
        org.joda.time.LocalDate.Property property11 = localDate9.yearOfEra();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.LocalDate localDate13 = localDate9.minus(readablePeriod12);
        org.joda.time.DateTime dateTime14 = localDate13.toDateTimeAtMidnight();
        try {
            org.joda.time.LocalDate localDate16 = localDate13.withWeekOfWeekyear(1735);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1735 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = copticChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology5);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.withDurationAdded(readableDuration18, (int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime15.plusMonths(0);
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology4, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime22);
        java.lang.String str25 = dateTime11.toString("68162380");
        org.joda.time.DateTime dateTime27 = dateTime11.withWeekyear(9);
        org.joda.time.DateTime dateTime29 = dateTime27.withMillisOfSecond((int) 'a');
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(limitChronology23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "68162380" + "'", str25.equals("68162380"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (long) 17);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.lang.String str2 = dateTimeFormatter0.print((long) 1);
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970W014T000000Z" + "'", str2.equals("1970W014T000000Z"));
        org.junit.Assert.assertNull(int3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendYearOfCentury(24, 57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate.Property property10 = localDate9.year();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.LocalDate localDate12 = localDate9.minus(readablePeriod11);
        try {
            org.joda.time.LocalDate localDate14 = localDate12.withMonthOfYear((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) '#', locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "millisOfDay");
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        long long24 = copticChronology15.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology15.year();
        org.joda.time.DurationField durationField26 = copticChronology15.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField26);
        try {
            long long29 = unsupportedDateTimeField27.remainder((-9676800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1786" + "'", str11.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3121000L + "'", long24 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 9223372003910399909L, 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundHalfEven((long) 292272708);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipDateTimeField8, (int) (byte) 1, 72, (-292269339));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for year must be in the range [72,-292269339]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology6.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology6);
        org.joda.time.DateTime dateTime11 = dateTime9.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime9.withDurationAdded(readableDuration12, (int) (short) 100);
        org.joda.time.DateTime dateTime16 = dateTime9.plusMonths(0);
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
        boolean boolean18 = dateTime5.equals((java.lang.Object) dateTime16);
        org.joda.time.DateTime dateTime19 = dateTime16.toDateTime();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("68161219", "68161520", (int) (short) 0, 18);
        long long26 = fixedDateTimeZone24.nextTransition((long) 6);
        org.joda.time.MutableDateTime mutableDateTime27 = dateTime16.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 6L + "'", long26 == 6L);
        org.junit.Assert.assertNotNull(mutableDateTime27);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
//        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
//        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField8.getWrappedField();
//        boolean boolean14 = skipDateTimeField8.isLenient();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8);
//        long long18 = delegatedDateTimeField15.add((long) (byte) 10, 17);
//        long long21 = delegatedDateTimeField15.add(0L, 9);
//        org.joda.time.Partial partial22 = new org.joda.time.Partial();
//        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.Chronology chronology25 = copticChronology23.withZone(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology23);
//        org.joda.time.DateTime dateTime28 = dateTime26.minusHours((int) (byte) 100);
//        org.joda.time.DateTime.Property property29 = dateTime28.millisOfDay();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = property29.getAsShortText(locale30);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = property29.getAsText(locale32);
//        int int34 = property29.getMaximumValueOverall();
//        int int35 = property29.getLeapAmount();
//        java.lang.String str36 = property29.getAsShortText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property29.getFieldType();
//        int int38 = partial22.indexOf(dateTimeFieldType37);
//        org.joda.time.ReadablePeriod readablePeriod39 = null;
//        org.joda.time.Partial partial40 = partial22.plus(readablePeriod39);
//        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.Chronology chronology43 = copticChronology41.withZone(dateTimeZone42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology41);
//        org.joda.time.DateTime dateTime46 = dateTime44.minusHours((int) (byte) 100);
//        org.joda.time.DateTime.Property property47 = dateTime46.millisOfDay();
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = property47.getAsShortText(locale48);
//        java.util.Locale locale50 = null;
//        java.lang.String str51 = property47.getAsText(locale50);
//        int int52 = property47.getMaximumValueOverall();
//        int int53 = property47.getLeapAmount();
//        java.lang.String str54 = property47.getAsShortText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property47.getFieldType();
//        org.joda.time.Partial partial56 = partial40.without(dateTimeFieldType55);
//        int int57 = delegatedDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) partial56);
//        java.lang.String str58 = delegatedDateTimeField15.getName();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 536457600010L + "'", long18 == 536457600010L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 283996800000L + "'", long21 == 283996800000L);
//        org.junit.Assert.assertNotNull(copticChronology23);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "68212668" + "'", str31.equals("68212668"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "68212668" + "'", str33.equals("68212668"));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 86399999 + "'", int34 == 86399999);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "68212668" + "'", str36.equals("68212668"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertNotNull(partial40);
//        org.junit.Assert.assertNotNull(copticChronology41);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "68212692" + "'", str49.equals("68212692"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "68212692" + "'", str51.equals("68212692"));
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 86399999 + "'", int52 == 86399999);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "68212692" + "'", str54.equals("68212692"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(partial56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 292272708 + "'", int57 == 292272708);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "year" + "'", str58.equals("year"));
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = copticChronology6.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        long long12 = dateTimeZone9.getMillisKeepLocal(dateTimeZone10, (long) (byte) 1);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(57370, (int) '#', 36, 999, 100, (-292269337), dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.plusDays((int) ' ');
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes((int) (short) 100);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.Chronology chronology10 = copticChronology8.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded(readableDuration14, (int) '#');
        boolean boolean17 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime5.toTimeOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeOfDay18);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.getDifferenceAsLong((long) 292272808, (long) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) '#', locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "millisOfDay");
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = copticChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology15);
        long long24 = copticChronology15.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField25 = copticChronology15.year();
        org.joda.time.DurationField durationField26 = copticChronology15.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField26);
        java.lang.String str28 = unsupportedDateTimeField27.toString();
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.Chronology chronology31 = copticChronology29.withZone(dateTimeZone30);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology29);
        org.joda.time.DateTime dateTime34 = dateTime32.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime35 = dateTime34.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate36 = dateTime35.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.LocalDate localDate38 = localDate36.plus(readablePeriod37);
        org.joda.time.LocalDate.Property property39 = localDate38.year();
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.LocalDate localDate42 = localDate38.withPeriodAdded(readablePeriod40, 82557374);
        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.Chronology chronology45 = copticChronology43.withZone(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = copticChronology43.year();
        org.joda.time.chrono.CopticChronology copticChronology47 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.Chronology chronology49 = copticChronology47.withZone(dateTimeZone48);
        org.joda.time.DateTimeField dateTimeField50 = copticChronology47.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField51 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology43, dateTimeField50);
        org.joda.time.ReadablePartial readablePartial52 = null;
        int int53 = skipDateTimeField51.getMaximumValue(readablePartial52);
        long long55 = skipDateTimeField51.roundFloor((long) (byte) 1);
        org.joda.time.chrono.CopticChronology copticChronology56 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.Chronology chronology58 = copticChronology56.withZone(dateTimeZone57);
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology56);
        org.joda.time.DateTime dateTime61 = dateTime59.plusDays((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod62 = null;
        org.joda.time.DateTime dateTime64 = dateTime61.withPeriodAdded(readablePeriod62, (int) ' ');
        org.joda.time.DateTime dateTime66 = dateTime64.minusSeconds((int) (short) -1);
        org.joda.time.TimeOfDay timeOfDay67 = dateTime64.toTimeOfDay();
        int[] intArray71 = new int[] { (short) 0, 82558, 82557322 };
        int int72 = skipDateTimeField51.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay67, intArray71);
        try {
            int int73 = unsupportedDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) localDate38, intArray71);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1786" + "'", str11.equals("1786"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3121000L + "'", long24 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UnsupportedDateTimeField" + "'", str28.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(copticChronology43);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(copticChronology47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 292272708 + "'", int53 == 292272708);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-9676800000L) + "'", long55 == (-9676800000L));
        org.junit.Assert.assertNotNull(copticChronology56);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(timeOfDay67);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 292272708 + "'", int72 == 292272708);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.DurationField durationField11 = copticChronology0.centuries();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = copticChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTimeField dateTimeField16 = copticChronology12.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField16, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField18, dateTimeFieldType19, 1200, 1000, (-57600));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
//        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone7);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.String str11 = gregorianChronology10.toString();
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        org.joda.time.Chronology chronology14 = gregorianChronology10.withZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime15 = dateTime8.withZoneRetainFields(dateTimeZone13);
//        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime15);
//        try {
//            org.joda.time.DateTime dateTime18 = dateTimeFormatter0.parseDateTime("1");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1\" is too short");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(int1);
//        org.junit.Assert.assertNull(int2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 82613 + "'", int9 == 82613);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[UTC]" + "'", str11.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019166T225653.322Z" + "'", str16.equals("2019166T225653.322Z"));
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.LocalDate.Property property8 = localDate7.year();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.LocalDate localDate11 = property8.addToCopy(1);
        org.joda.time.LocalDate localDate12 = property8.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(localDate12);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded(readableDuration6, (int) (short) 100);
//        org.joda.time.DateTime dateTime10 = dateTime3.plusMonths(0);
//        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime10);
//        int int12 = dateTime10.getDayOfWeek();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560639413418L + "'", long11 == 1560639413418L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHourOfHalfday((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendFractionOfHour((int) (byte) 100, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendHourOfDay((int) (byte) 0);
        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatterBuilder16.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder6.append(dateTimePrinter17, dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean3 = gJChronology0.equals((java.lang.Object) dateTimeZone1);
        try {
            long long11 = gJChronology0.getDateTimeMillis(0, 86399999, 1686, 2000, 72, 0, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = copticChronology4.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = skipDateTimeField8.getMaximumValue(readablePartial9);
        long long12 = skipDateTimeField8.roundFloor((long) (byte) 1);
        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField8.getWrappedField();
        boolean boolean14 = skipDateTimeField8.isLenient();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8);
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.Chronology chronology18 = copticChronology16.withZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology16);
        org.joda.time.DateTime dateTime21 = dateTime19.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime22 = dateTime21.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate25 = localDate23.plus(readablePeriod24);
        org.joda.time.LocalDate.Property property26 = localDate25.dayOfWeek();
        org.joda.time.LocalDate localDate27 = property26.withMinimumValue();
        org.joda.time.LocalDate.Property property28 = localDate27.year();
        int int29 = localDate27.getWeekyear();
        int int30 = localDate27.getWeekyear();
        java.util.Locale locale31 = null;
        java.lang.String str32 = delegatedDateTimeField15.getAsText((org.joda.time.ReadablePartial) localDate27, locale31);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292272708 + "'", int10 == 292272708);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9676800000L) + "'", long12 == (-9676800000L));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1735 + "'", int29 == 1735);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1735 + "'", int30 == 1735);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1734" + "'", str32.equals("1734"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        long long9 = copticChronology0.getDateTimeMillis((long) (byte) 0, (int) (byte) 0, (int) '4', (int) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.year();
        org.joda.time.DurationField durationField11 = copticChronology0.centuries();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology0);
        int int13 = localDate12.getYear();
        java.util.Date date14 = localDate12.toDate();
        org.joda.time.DateTime dateTime15 = localDate12.toDateTimeAtMidnight();
        int int16 = localDate12.getYearOfEra();
        try {
            org.joda.time.LocalDate localDate18 = localDate12.withDayOfWeek((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3121000L + "'", long9 == 3121000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1735 + "'", int13 == 1735);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1735 + "'", int16 == 1735);
    }
}

