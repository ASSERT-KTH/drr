import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period3 = period1.minusMillis((int) (short) 0);
        int int4 = period3.getSeconds();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableInstant6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = period7.isSupported(durationFieldType8);
        org.joda.time.Period period10 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType11 = period7.getPeriodType();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType15);
        org.joda.time.Period period18 = period16.plusMinutes(0);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period16.toDurationFrom(readableInstant19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType23 = periodType22.withWeeksRemoved();
        java.lang.String str24 = periodType23.getName();
        org.joda.time.Period period25 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration20, readableInstant21, periodType23);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableInstant27);
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = period28.get(durationFieldType29);
        org.joda.time.Period period32 = period28.withMinutes((int) (short) 10);
        org.joda.time.Period period34 = period28.withMonths((int) (short) 100);
        int int35 = period28.getSeconds();
        org.joda.time.PeriodType periodType45 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period46 = new org.joda.time.Period(0L, periodType45);
        org.joda.time.Period period47 = new org.joda.time.Period((int) (short) 10, 0, 100, (int) (byte) 100, (int) (byte) -1, 10, (int) (byte) 0, (int) (short) 1, periodType45);
        org.joda.time.Period period48 = period28.normalizedStandard(periodType45);
        org.joda.time.Period period49 = new org.joda.time.Period(readableInstant12, (org.joda.time.ReadableDuration) duration20, periodType45);
        org.joda.time.PeriodType periodType50 = periodType45.withSecondsRemoved();
        org.joda.time.PeriodType periodType51 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DurationFieldType durationFieldType53 = periodType51.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(durationFieldType53, "Pacific Standard Time");
        boolean boolean56 = periodType50.isSupported(durationFieldType53);
        boolean boolean57 = periodType11.isSupported(durationFieldType53);
        org.joda.time.field.PreciseDurationField preciseDurationField59 = new org.joda.time.field.PreciseDurationField(durationFieldType53, 2440588L);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField60 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType53);
        java.lang.String str61 = unsupportedDurationField60.getName();
        org.joda.time.chrono.ISOChronology iSOChronology62 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology62.weekyear();
        org.joda.time.DateTimeField dateTimeField64 = iSOChronology62.minuteOfHour();
        org.joda.time.DurationField durationField65 = iSOChronology62.months();
        int int66 = unsupportedDurationField60.compareTo(durationField65);
        try {
            long long69 = unsupportedDurationField60.getMillis((-25200000), (-4L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Seconds" + "'", str24.equals("Seconds"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(durationFieldType53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "years" + "'", str61.equals("years"));
        org.junit.Assert.assertNotNull(iSOChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) 1);
        int int6 = offsetDateTimeField5.getMaximumValue();
        int int7 = offsetDateTimeField5.getOffset();
        long long10 = offsetDateTimeField5.getDifferenceAsLong((-26438400001L), 32L);
        long long12 = offsetDateTimeField5.roundHalfFloor((-57539903L));
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.weekyear();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.minuteOfHour();
        org.joda.time.DurationField durationField18 = iSOChronology15.months();
        org.joda.time.chrono.LenientChronology lenientChronology19 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant20, readableDuration21, periodType22);
        org.joda.time.Period period25 = period23.plusMinutes(0);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Duration duration27 = period23.toDurationFrom(readableInstant26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration27, readableInstant28);
        org.joda.time.Period period31 = period29.withMinutes((int) 'a');
        int[] intArray34 = lenientChronology19.get((org.joda.time.ReadablePeriod) period29, (-210573432000000L), (long) (-10));
        try {
            int[] intArray36 = offsetDateTimeField5.set(readablePartial13, (-10), intArray34, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for halfdayOfDay must be in the range [1,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-612L) + "'", long10 == (-612L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-57600000L) + "'", long12 == (-57600000L));
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology19);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.get(durationFieldType3);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        org.joda.time.Period period8 = period2.withMonths((int) (short) 100);
        int int9 = period2.getSeconds();
        int int10 = period2.getYears();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType(0);
        org.joda.time.Period period15 = period2.withFieldAdded(durationFieldType13, 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(durationFieldType13, "Seconds");
        java.lang.Number number18 = illegalFieldValueException17.getIllegalNumberValue();
        java.lang.String str19 = illegalFieldValueException17.getIllegalStringValue();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException("hi!", "");
        java.lang.String str23 = illegalFieldValueException22.getFieldName();
        java.lang.String str24 = illegalFieldValueException22.getIllegalValueAsString();
        java.lang.Number number25 = illegalFieldValueException22.getUpperBound();
        java.lang.Number number26 = illegalFieldValueException22.getLowerBound();
        java.lang.String str27 = illegalFieldValueException22.toString();
        illegalFieldValueException17.addSuppressed((java.lang.Throwable) illegalFieldValueException22);
        org.joda.time.DurationFieldType durationFieldType29 = illegalFieldValueException22.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Seconds" + "'", str19.equals("Seconds"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported" + "'", str27.equals("org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(durationFieldType29);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) 1);
        long long7 = offsetDateTimeField5.roundHalfEven((long) ' ');
        org.joda.time.ReadablePartial readablePartial8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = lenientChronology10.halfdayOfDay();
        org.joda.time.DurationField durationField12 = lenientChronology10.millis();
        org.joda.time.DurationField durationField13 = lenientChronology10.seconds();
        org.joda.time.Period period15 = org.joda.time.Period.years((int) (short) 1);
        int int16 = period15.getMinutes();
        int[] intArray18 = lenientChronology10.get((org.joda.time.ReadablePeriod) period15, (long) (byte) 0);
        int int19 = offsetDateTimeField5.getMinimumValue(readablePartial8, intArray18);
        int int20 = offsetDateTimeField5.getOffset();
        long long22 = offsetDateTimeField5.roundHalfCeiling(244058800L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-14400000L) + "'", long7 == (-14400000L));
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 244800000L + "'", long22 == 244800000L);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("UTC", (int) (byte) 10, (int) ' ', (int) (byte) -1, '#', 1, (int) 'a', (int) (short) -1, false, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder0.toDateTimeZone("America/Los_Angeles", false);
        boolean boolean16 = dateTimeZone14.isStandardOffset((long) ' ');
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) '#');
        org.joda.time.Period period3 = period1.minusMillis((int) (short) 10);
        org.joda.time.Period period5 = period3.plusHours(3395);
        org.joda.time.Period period7 = period3.minusMonths((-1121));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period2 = period1.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod3 = period2.toMutablePeriod();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType7 = periodType6.withWeeksRemoved();
        org.joda.time.Period period8 = new org.joda.time.Period(100L, (-26359402L), periodType6);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType10 = periodType9.withSecondsRemoved();
        org.joda.time.Period period11 = period8.normalizedStandard(periodType9);
        org.joda.time.Period period13 = period8.multipliedBy((int) '4');
        org.joda.time.Period period14 = period2.withFields((org.joda.time.ReadablePeriod) period13);
        try {
            org.joda.time.DurationFieldType durationFieldType16 = period13.getFieldType((-35));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(mutablePeriod3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.chrono.LenientChronology lenientChronology7 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) 1);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumTextLength(locale11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.Period period15 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period17 = period15.minusMillis((int) (short) 0);
        int int18 = period17.getSeconds();
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant19, readableInstant20);
        org.joda.time.DurationFieldType durationFieldType22 = null;
        boolean boolean23 = period21.isSupported(durationFieldType22);
        org.joda.time.Period period24 = period17.plus((org.joda.time.ReadablePeriod) period21);
        int[] intArray25 = period24.getValues();
        int int26 = offsetDateTimeField10.getMaximumValue(readablePartial13, intArray25);
        int int28 = offsetDateTimeField10.getMaximumValue((-612L));
        boolean boolean29 = iSOChronology0.equals((java.lang.Object) offsetDateTimeField10);
        try {
            org.joda.time.Period period30 = new org.joda.time.Period((java.lang.Object) offsetDateTimeField10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.field.OffsetDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(lenientChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(230, (-28800000), (int) (byte) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("UTC", (int) (byte) 10, (int) ' ', (int) (byte) -1, '#', 1, (int) 'a', (int) (short) -1, false, (int) (byte) 1);
        java.lang.Class<?> wildcardClass12 = dateTimeZoneBuilder0.getClass();
        org.joda.time.DateTimeZone dateTimeZone15 = dateTimeZoneBuilder0.toDateTimeZone("hi!", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder23 = dateTimeZoneBuilder0.addCutover((int) (byte) 100, 'a', (-10), 8, (int) (short) 0, false, (int) (byte) 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder31 = dateTimeZoneBuilder0.addCutover((int) (byte) -1, ' ', (-25200000), (-1121), 99, false, 3395);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder23);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-52L) + "'", long2 == (-52L));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(99);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology2 = lenientChronology1.withUTC();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology3.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        boolean boolean7 = lenientChronology1.equals((java.lang.Object) cachedDateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = iSOChronology8.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        boolean boolean13 = dateTimeZone10.isStandardOffset((long) '#');
        long long15 = cachedDateTimeZone6.getMillisKeepLocal(dateTimeZone10, 9972000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, 4);
        java.util.TimeZone timeZone18 = dateTimeZone10.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField20 = gregorianChronology19.halfdays();
        org.joda.time.Period period22 = org.joda.time.Period.minutes((int) (byte) 10);
        org.joda.time.Period period24 = period22.plusHours((int) ' ');
        boolean boolean25 = gregorianChronology19.equals((java.lang.Object) period22);
        int int26 = gregorianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology19.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology19.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9972000000L + "'", long15 == 9972000000L);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) 1);
        int int6 = offsetDateTimeField5.getMaximumValue();
        int int7 = offsetDateTimeField5.getOffset();
        long long10 = offsetDateTimeField5.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 100L, (java.lang.Number) 100, (java.lang.Number) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) (-612L), (java.lang.Number) (-57600000L), (java.lang.Number) 9972000000L);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = illegalFieldValueException19.getDateTimeFieldType();
        java.lang.Throwable[] throwableArray21 = illegalFieldValueException19.getSuppressed();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-612L) + "'", long10 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(throwableArray21);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PeriodType[YearDay]", "Standard", 4, 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.PeriodType periodType6 = periodType4.withMillisRemoved();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', 28800032L, periodType6);
        int[] intArray8 = period7.getValues();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.era();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableInstant6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period7.get(durationFieldType8);
        org.joda.time.Period period11 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period13 = period7.withMonths((int) (short) 100);
        int int14 = period7.getSeconds();
        int int15 = period7.getYears();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DurationFieldType durationFieldType18 = periodType16.getFieldType(0);
        org.joda.time.Period period20 = period7.withFieldAdded(durationFieldType18, 0);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period7, (long) ' ', (-97L));
        org.joda.time.Period period24 = new org.joda.time.Period(28799999L, (long) (short) 10, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported", "", 1, 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.era();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.yearOfEra();
        org.joda.time.DurationField durationField5 = iSOChronology0.halfdays();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType8, "Pacific Standard Time");
        org.joda.time.field.DecoratedDurationField decoratedDurationField11 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType8);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.weekyear();
        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology12.getZone();
        org.joda.time.DurationField durationField15 = iSOChronology12.halfdays();
        long long18 = durationField15.subtract((long) 10, (long) 0);
        int int19 = decoratedDurationField11.compareTo(durationField15);
        long long22 = decoratedDurationField11.getDifferenceAsLong((-2717640000000L), (long) 3395);
        org.joda.time.DurationField durationField23 = decoratedDurationField11.getWrappedField();
        long long25 = decoratedDurationField11.getMillis(7);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62908L) + "'", long22 == (-62908L));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 302400000L + "'", long25 == 302400000L);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.get(durationFieldType3);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        org.joda.time.Period period8 = period2.withMonths((int) (short) 100);
        int int9 = period2.getSeconds();
        org.joda.time.Period period10 = period2.toPeriod();
        org.joda.time.Period period12 = period2.plusHours(3395);
        int int13 = period12.getMillis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) 1);
        int int6 = offsetDateTimeField5.getMaximumValue();
        int int9 = offsetDateTimeField5.getDifference((long) 2, 0L);
        long long11 = offsetDateTimeField5.roundHalfEven((-2737466476L));
        org.joda.time.DurationField durationField12 = offsetDateTimeField5.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2736000000L) + "'", long11 == (-2736000000L));
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = iSOChronology0.getZone();
        int int4 = dateTimeZone2.getOffsetFromLocal((-1L));
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number5 = illegalFieldValueException2.getUpperBound();
        java.lang.Number number6 = illegalFieldValueException2.getLowerBound();
        java.lang.String str7 = illegalFieldValueException2.toString();
        org.joda.time.DurationFieldType durationFieldType8 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Number number9 = illegalFieldValueException2.getIllegalNumberValue();
        illegalFieldValueException2.prependMessage("Seconds");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(durationFieldType8);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) 1);
        java.util.Locale locale6 = null;
        int int7 = offsetDateTimeField5.getMaximumTextLength(locale6);
        long long9 = offsetDateTimeField5.roundHalfEven(43200000L);
        int int10 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.chrono.LenientChronology lenientChronology13 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (short) 1);
        int int17 = offsetDateTimeField16.getMaximumValue();
        int int18 = offsetDateTimeField16.getOffset();
        long long21 = offsetDateTimeField16.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 100L, (java.lang.Number) 100, (java.lang.Number) 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType22, (int) (short) 100);
        long long30 = remainderDateTimeField28.roundHalfCeiling((long) 2);
        int int31 = remainderDateTimeField28.getMinimumValue();
        int int32 = remainderDateTimeField28.getDivisor();
        long long35 = remainderDateTimeField28.addWrapField((-2736000000L), (-3500));
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology37 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology36);
        org.joda.time.chrono.LenientChronology lenientChronology38 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology36);
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology36.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) (short) 1);
        int int42 = offsetDateTimeField41.getMaximumValue();
        int int43 = offsetDateTimeField41.getOffset();
        long long46 = offsetDateTimeField41.getDifferenceAsLong((-26438400001L), 32L);
        int int47 = offsetDateTimeField41.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = offsetDateTimeField41.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField28, dateTimeFieldType48);
        int int50 = dividedDateTimeField49.getDivisor();
        int int52 = dividedDateTimeField49.get(0L);
        try {
            long long54 = dividedDateTimeField49.roundFloor((-57600000L));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for halfdayOfDay must be in the range [1,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertNotNull(lenientChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-612L) + "'", long21 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-14400000L) + "'", long30 == (-14400000L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-2736000000L) + "'", long35 == (-2736000000L));
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(lenientChronology37);
        org.junit.Assert.assertNotNull(lenientChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-612L) + "'", long46 == (-612L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 100 + "'", int50 == 100);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = null;
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(100L, (-26359402L), periodType2);
        org.joda.time.Period period6 = period4.withSeconds((int) (short) 1);
        try {
            org.joda.time.Period period8 = period6.withHours((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period3 = period1.minusMillis((int) (short) 0);
        int int4 = period3.getSeconds();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableInstant6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = period7.isSupported(durationFieldType8);
        org.joda.time.Period period10 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType11 = period7.getPeriodType();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType15);
        org.joda.time.Period period18 = period16.plusMinutes(0);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period16.toDurationFrom(readableInstant19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType23 = periodType22.withWeeksRemoved();
        java.lang.String str24 = periodType23.getName();
        org.joda.time.Period period25 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration20, readableInstant21, periodType23);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableInstant27);
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = period28.get(durationFieldType29);
        org.joda.time.Period period32 = period28.withMinutes((int) (short) 10);
        org.joda.time.Period period34 = period28.withMonths((int) (short) 100);
        int int35 = period28.getSeconds();
        org.joda.time.PeriodType periodType45 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period46 = new org.joda.time.Period(0L, periodType45);
        org.joda.time.Period period47 = new org.joda.time.Period((int) (short) 10, 0, 100, (int) (byte) 100, (int) (byte) -1, 10, (int) (byte) 0, (int) (short) 1, periodType45);
        org.joda.time.Period period48 = period28.normalizedStandard(periodType45);
        org.joda.time.Period period49 = new org.joda.time.Period(readableInstant12, (org.joda.time.ReadableDuration) duration20, periodType45);
        org.joda.time.PeriodType periodType50 = periodType45.withSecondsRemoved();
        org.joda.time.PeriodType periodType51 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DurationFieldType durationFieldType53 = periodType51.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(durationFieldType53, "Pacific Standard Time");
        boolean boolean56 = periodType50.isSupported(durationFieldType53);
        boolean boolean57 = periodType11.isSupported(durationFieldType53);
        org.joda.time.field.PreciseDurationField preciseDurationField59 = new org.joda.time.field.PreciseDurationField(durationFieldType53, 2440588L);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField60 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType53);
        boolean boolean61 = unsupportedDurationField60.isPrecise();
        boolean boolean62 = unsupportedDurationField60.isPrecise();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Seconds" + "'", str24.equals("Seconds"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(durationFieldType53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("(\"org.joda.time.JodaTimePermission\" \"-08:00\")", (java.lang.Number) 2440587.5282475464d, (java.lang.Number) (-26359412L), (java.lang.Number) 558910576L);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-2));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period3 = period1.minusMillis((int) (short) 0);
        int int4 = period3.getSeconds();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableInstant6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = period7.isSupported(durationFieldType8);
        org.joda.time.Period period10 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period12 = period3.minusSeconds((int) (byte) -1);
        org.joda.time.Period period14 = period12.plusMonths((int) (short) 100);
        org.joda.time.Period period16 = period14.withWeeks((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) 1);
        java.util.Locale locale6 = null;
        int int7 = offsetDateTimeField5.getMaximumTextLength(locale6);
        long long9 = offsetDateTimeField5.roundHalfEven(43200000L);
        int int10 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.chrono.LenientChronology lenientChronology13 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (short) 1);
        int int17 = offsetDateTimeField16.getMaximumValue();
        int int18 = offsetDateTimeField16.getOffset();
        long long21 = offsetDateTimeField16.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 100L, (java.lang.Number) 100, (java.lang.Number) 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType22, (int) (short) 100);
        long long30 = remainderDateTimeField28.roundHalfCeiling((long) 2);
        int int31 = remainderDateTimeField28.getMinimumValue();
        int int32 = remainderDateTimeField28.getDivisor();
        long long35 = remainderDateTimeField28.addWrapField((-2736000000L), (-3500));
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology37 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology36);
        org.joda.time.chrono.LenientChronology lenientChronology38 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology36);
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology36.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) (short) 1);
        int int42 = offsetDateTimeField41.getMaximumValue();
        int int43 = offsetDateTimeField41.getOffset();
        long long46 = offsetDateTimeField41.getDifferenceAsLong((-26438400001L), 32L);
        int int47 = offsetDateTimeField41.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = offsetDateTimeField41.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField28, dateTimeFieldType48);
        int int50 = dividedDateTimeField49.getDivisor();
        int int52 = dividedDateTimeField49.get(0L);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology53.dayOfYear();
        org.joda.time.DateTimeField dateTimeField55 = iSOChronology53.dayOfWeek();
        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology57 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology56);
        org.joda.time.chrono.LenientChronology lenientChronology58 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology56);
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology56.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField(dateTimeField59, (int) (short) 1);
        int int62 = offsetDateTimeField61.getMaximumValue();
        int int63 = offsetDateTimeField61.getOffset();
        long long66 = offsetDateTimeField61.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = offsetDateTimeField61.getType();
        long long69 = offsetDateTimeField61.remainder(35L);
        org.joda.time.chrono.ISOChronology iSOChronology70 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology71 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology70);
        org.joda.time.chrono.LenientChronology lenientChronology72 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology70);
        org.joda.time.DateTimeField dateTimeField73 = iSOChronology70.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField75 = new org.joda.time.field.OffsetDateTimeField(dateTimeField73, (int) (short) 1);
        int int76 = offsetDateTimeField75.getMaximumValue();
        int int77 = offsetDateTimeField75.getOffset();
        long long80 = offsetDateTimeField75.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType81 = offsetDateTimeField75.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException84 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType81, (java.lang.Number) 100L, "Standard");
        org.joda.time.IllegalFieldValueException illegalFieldValueException87 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType81, (java.lang.Number) (-1.0d), "+00:00:00.035");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField89 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField61, dateTimeFieldType81, (int) (short) 100);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField91 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, dateTimeFieldType81, (-3500));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField92 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField49, dateTimeFieldType81);
        long long95 = dividedDateTimeField49.add((long) (-3500), 43200052L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertNotNull(lenientChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-612L) + "'", long21 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-14400000L) + "'", long30 == (-14400000L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-2736000000L) + "'", long35 == (-2736000000L));
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(lenientChronology37);
        org.junit.Assert.assertNotNull(lenientChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-612L) + "'", long46 == (-612L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 100 + "'", int50 == 100);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(iSOChronology56);
        org.junit.Assert.assertNotNull(lenientChronology57);
        org.junit.Assert.assertNotNull(lenientChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-612L) + "'", long66 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 14400035L + "'", long69 == 14400035L);
        org.junit.Assert.assertNotNull(iSOChronology70);
        org.junit.Assert.assertNotNull(lenientChronology71);
        org.junit.Assert.assertNotNull(lenientChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2 + "'", int76 == 2);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-612L) + "'", long80 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType81);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 186624224636396500L + "'", long95 == 186624224636396500L);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DurationField durationField2 = lenientChronology1.centuries();
        java.lang.String str3 = lenientChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.secondOfMinute();
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        int int11 = dateTimeZone9.getOffset(readableInstant10);
        org.joda.time.Chronology chronology12 = gregorianChronology4.withZone(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) lenientChronology1, dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = iSOChronology14.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        java.lang.String str18 = dateTimeZone16.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        org.joda.time.Chronology chronology20 = zonedChronology13.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone19);
        long long25 = zonedChronology13.getDateTimeMillis((-28378000), 100, (int) 'a', 7);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LenientChronology[ISOChronology[America/Los_Angeles]]" + "'", str3.equals("LenientChronology[ISOChronology[America/Los_Angeles]]"));
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "America/Los_Angeles" + "'", str18.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-895585082429221993L) + "'", long25 == (-895585082429221993L));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) 1);
        java.util.Locale locale6 = null;
        int int7 = offsetDateTimeField5.getMaximumTextLength(locale6);
        long long9 = offsetDateTimeField5.roundHalfEven(43200000L);
        int int10 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.chrono.LenientChronology lenientChronology13 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (short) 1);
        int int17 = offsetDateTimeField16.getMaximumValue();
        int int18 = offsetDateTimeField16.getOffset();
        long long21 = offsetDateTimeField16.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 100L, (java.lang.Number) 100, (java.lang.Number) 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType22, (int) (short) 100);
        long long30 = remainderDateTimeField28.roundHalfCeiling((long) 2);
        int int31 = remainderDateTimeField28.getMinimumValue();
        int int32 = remainderDateTimeField28.getDivisor();
        int int33 = remainderDateTimeField28.getMinimumValue();
        org.joda.time.DurationField durationField34 = remainderDateTimeField28.getDurationField();
        int int36 = remainderDateTimeField28.get(52L);
        long long38 = remainderDateTimeField28.roundHalfEven((-2440588L));
        org.joda.time.DurationField durationField39 = remainderDateTimeField28.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertNotNull(lenientChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-612L) + "'", long21 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-14400000L) + "'", long30 == (-14400000L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-14400000L) + "'", long38 == (-14400000L));
        org.junit.Assert.assertNotNull(durationField39);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField2 = lenientChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = lenientChronology1.getZone();
        java.lang.String str4 = lenientChronology1.toString();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology1.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LenientChronology[ISOChronology[America/Los_Angeles]]" + "'", str4.equals("LenientChronology[ISOChronology[America/Los_Angeles]]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period2 = period1.toPeriod();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period1.indexOf(durationFieldType3);
        org.joda.time.Period period6 = period1.plusHours((int) 'a');
        org.joda.time.Period period8 = period1.plusMillis((int) (byte) -1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.joda.time.Period period2 = new org.joda.time.Period(17L, (long) (short) 1);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) 1);
        java.util.Locale locale6 = null;
        int int7 = offsetDateTimeField5.getMaximumTextLength(locale6);
        long long9 = offsetDateTimeField5.roundHalfEven(43200000L);
        int int10 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.chrono.LenientChronology lenientChronology13 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (short) 1);
        int int17 = offsetDateTimeField16.getMaximumValue();
        int int18 = offsetDateTimeField16.getOffset();
        long long21 = offsetDateTimeField16.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 100L, (java.lang.Number) 100, (java.lang.Number) 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType22, (int) (short) 100);
        long long30 = remainderDateTimeField28.roundHalfCeiling((long) 2);
        int int31 = remainderDateTimeField28.getMinimumValue();
        int int32 = remainderDateTimeField28.getDivisor();
        long long34 = remainderDateTimeField28.roundHalfFloor((-61502817600000L));
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology36 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology35);
        org.joda.time.chrono.LenientChronology lenientChronology37 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology35);
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology35.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, (int) (short) 1);
        int int41 = offsetDateTimeField40.getMaximumValue();
        int int42 = offsetDateTimeField40.getOffset();
        long long45 = offsetDateTimeField40.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = offsetDateTimeField40.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType46, (java.lang.Number) 100L, (java.lang.Number) 100, (java.lang.Number) 10);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField51 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField28, dateTimeFieldType46);
        int int52 = dividedDateTimeField51.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertNotNull(lenientChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-612L) + "'", long21 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-14400000L) + "'", long30 == (-14400000L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-61502818022000L) + "'", long34 == (-61502818022000L));
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(lenientChronology36);
        org.junit.Assert.assertNotNull(lenientChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-612L) + "'", long45 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period3 = period1.minusMillis((int) (short) 0);
        int int4 = period3.getSeconds();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableInstant6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = period7.isSupported(durationFieldType8);
        org.joda.time.Period period10 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType11 = period7.getPeriodType();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType15);
        org.joda.time.Period period18 = period16.plusMinutes(0);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period16.toDurationFrom(readableInstant19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType23 = periodType22.withWeeksRemoved();
        java.lang.String str24 = periodType23.getName();
        org.joda.time.Period period25 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration20, readableInstant21, periodType23);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableInstant27);
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = period28.get(durationFieldType29);
        org.joda.time.Period period32 = period28.withMinutes((int) (short) 10);
        org.joda.time.Period period34 = period28.withMonths((int) (short) 100);
        int int35 = period28.getSeconds();
        org.joda.time.PeriodType periodType45 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period46 = new org.joda.time.Period(0L, periodType45);
        org.joda.time.Period period47 = new org.joda.time.Period((int) (short) 10, 0, 100, (int) (byte) 100, (int) (byte) -1, 10, (int) (byte) 0, (int) (short) 1, periodType45);
        org.joda.time.Period period48 = period28.normalizedStandard(periodType45);
        org.joda.time.Period period49 = new org.joda.time.Period(readableInstant12, (org.joda.time.ReadableDuration) duration20, periodType45);
        org.joda.time.PeriodType periodType50 = periodType45.withSecondsRemoved();
        org.joda.time.PeriodType periodType51 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DurationFieldType durationFieldType53 = periodType51.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(durationFieldType53, "Pacific Standard Time");
        boolean boolean56 = periodType50.isSupported(durationFieldType53);
        boolean boolean57 = periodType11.isSupported(durationFieldType53);
        org.joda.time.field.PreciseDurationField preciseDurationField59 = new org.joda.time.field.PreciseDurationField(durationFieldType53, 2440588L);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField60 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType53);
        java.lang.String str61 = unsupportedDurationField60.getName();
        java.lang.String str62 = unsupportedDurationField60.toString();
        java.lang.String str63 = unsupportedDurationField60.getName();
        org.joda.time.DurationFieldType durationFieldType64 = unsupportedDurationField60.getType();
        try {
            long long66 = unsupportedDurationField60.getMillis(186624224636396500L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Seconds" + "'", str24.equals("Seconds"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(durationFieldType53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "years" + "'", str61.equals("years"));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "UnsupportedDurationField[years]" + "'", str62.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "years" + "'", str63.equals("years"));
        org.junit.Assert.assertNotNull(durationFieldType64);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertNotNull(readableInterval5);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) 1);
        java.util.Locale locale6 = null;
        int int7 = offsetDateTimeField5.getMaximumTextLength(locale6);
        long long9 = offsetDateTimeField5.roundHalfEven(43200000L);
        int int10 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.chrono.LenientChronology lenientChronology13 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (short) 1);
        int int17 = offsetDateTimeField16.getMaximumValue();
        int int18 = offsetDateTimeField16.getOffset();
        long long21 = offsetDateTimeField16.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 100L, (java.lang.Number) 100, (java.lang.Number) 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType22, (int) (short) 100);
        long long30 = remainderDateTimeField28.roundHalfCeiling((long) 2);
        int int31 = remainderDateTimeField28.getMinimumValue();
        int int32 = remainderDateTimeField28.getDivisor();
        int int33 = remainderDateTimeField28.getMinimumValue();
        org.joda.time.DurationField durationField34 = remainderDateTimeField28.getDurationField();
        int int36 = remainderDateTimeField28.get(52L);
        long long38 = remainderDateTimeField28.roundHalfEven((-2440588L));
        long long40 = remainderDateTimeField28.roundHalfFloor((long) 230);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = remainderDateTimeField28.getType();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertNotNull(lenientChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-612L) + "'", long21 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-14400000L) + "'", long30 == (-14400000L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-14400000L) + "'", long38 == (-14400000L));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-14400000L) + "'", long40 == (-14400000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        java.lang.Object obj2 = null;
        boolean boolean3 = gregorianChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = gregorianChronology0.millis();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((-26409600001L), periodType6, chronology7);
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period8, 35L, 302400000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.get(durationFieldType3);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        org.joda.time.Period period8 = period2.withMonths((int) (short) 100);
        org.joda.time.Period period10 = period2.withWeeks((int) (byte) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology11.getZone();
        boolean boolean14 = period2.equals((java.lang.Object) gregorianChronology11);
        int int15 = gregorianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField16 = gregorianChronology11.months();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.era();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant3, readableInstant4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.get(durationFieldType6);
        org.joda.time.Period period9 = period5.withMinutes((int) (short) 10);
        org.joda.time.Period period11 = period5.withMonths((int) (short) 100);
        int int12 = period5.getSeconds();
        int int13 = period5.getYears();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DurationFieldType durationFieldType16 = periodType14.getFieldType(0);
        org.joda.time.Period period18 = period5.withFieldAdded(durationFieldType16, 0);
        int[] intArray21 = iSOChronology0.get((org.joda.time.ReadablePeriod) period5, (long) ' ', (-97L));
        org.joda.time.Period period23 = org.joda.time.Period.months((-28800000));
        org.joda.time.Period period25 = org.joda.time.Period.months((int) (byte) -1);
        org.joda.time.Period period27 = period25.minusSeconds(0);
        org.joda.time.Period period29 = period25.withHours(0);
        org.joda.time.Period period31 = period25.minusDays((int) ' ');
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant32, readableInstant33);
        org.joda.time.DurationFieldType durationFieldType35 = null;
        int int36 = period34.get(durationFieldType35);
        org.joda.time.Period period38 = period34.withMinutes((int) (short) 10);
        org.joda.time.Period period40 = period34.withMonths((int) (short) 100);
        org.joda.time.Period period42 = period34.minusHours((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.Period period45 = new org.joda.time.Period(readableInstant43, readableInstant44);
        org.joda.time.DurationFieldType durationFieldType46 = null;
        int int47 = period45.get(durationFieldType46);
        org.joda.time.Period period49 = period45.withMinutes((int) (short) 10);
        org.joda.time.Period period51 = period45.withMonths((int) (short) 100);
        int int52 = period45.getSeconds();
        int int53 = period45.getYears();
        org.joda.time.PeriodType periodType54 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DurationFieldType durationFieldType56 = periodType54.getFieldType(0);
        org.joda.time.Period period58 = period45.withFieldAdded(durationFieldType56, 0);
        int int59 = period42.get(durationFieldType56);
        int int60 = period25.indexOf(durationFieldType56);
        org.joda.time.field.PreciseDurationField preciseDurationField62 = new org.joda.time.field.PreciseDurationField(durationFieldType56, 2440588L);
        org.joda.time.Period period64 = period23.withFieldAdded(durationFieldType56, 1);
        org.joda.time.Period period66 = period5.withField(durationFieldType56, 10);
        org.joda.time.ReadableInstant readableInstant67 = null;
        org.joda.time.ReadableInstant readableInstant68 = null;
        org.joda.time.Period period69 = new org.joda.time.Period(readableInstant67, readableInstant68);
        int int70 = period69.getMinutes();
        org.joda.time.Period period71 = period69.negated();
        int int72 = period69.getMillis();
        org.joda.time.Period period74 = period69.plusMonths((int) '4');
        org.joda.time.ReadableInstant readableInstant75 = null;
        org.joda.time.Duration duration76 = period69.toDurationTo(readableInstant75);
        org.joda.time.Period period77 = period66.minus((org.joda.time.ReadablePeriod) period69);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(durationFieldType56);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertNotNull(period66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(duration76);
        org.junit.Assert.assertNotNull(period77);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period3 = period1.minusMillis((int) (short) 0);
        int int4 = period3.getSeconds();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableInstant6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = period7.isSupported(durationFieldType8);
        org.joda.time.Period period10 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType11 = period7.getPeriodType();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType15);
        org.joda.time.Period period18 = period16.plusMinutes(0);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period16.toDurationFrom(readableInstant19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType23 = periodType22.withWeeksRemoved();
        java.lang.String str24 = periodType23.getName();
        org.joda.time.Period period25 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration20, readableInstant21, periodType23);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableInstant27);
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = period28.get(durationFieldType29);
        org.joda.time.Period period32 = period28.withMinutes((int) (short) 10);
        org.joda.time.Period period34 = period28.withMonths((int) (short) 100);
        int int35 = period28.getSeconds();
        org.joda.time.PeriodType periodType45 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period46 = new org.joda.time.Period(0L, periodType45);
        org.joda.time.Period period47 = new org.joda.time.Period((int) (short) 10, 0, 100, (int) (byte) 100, (int) (byte) -1, 10, (int) (byte) 0, (int) (short) 1, periodType45);
        org.joda.time.Period period48 = period28.normalizedStandard(periodType45);
        org.joda.time.Period period49 = new org.joda.time.Period(readableInstant12, (org.joda.time.ReadableDuration) duration20, periodType45);
        org.joda.time.PeriodType periodType50 = periodType45.withSecondsRemoved();
        org.joda.time.PeriodType periodType51 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DurationFieldType durationFieldType53 = periodType51.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(durationFieldType53, "Pacific Standard Time");
        boolean boolean56 = periodType50.isSupported(durationFieldType53);
        boolean boolean57 = periodType11.isSupported(durationFieldType53);
        org.joda.time.field.PreciseDurationField preciseDurationField59 = new org.joda.time.field.PreciseDurationField(durationFieldType53, 2440588L);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField60 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType53);
        java.lang.String str61 = unsupportedDurationField60.getName();
        java.lang.String str62 = unsupportedDurationField60.getName();
        java.lang.Object obj63 = null;
        boolean boolean64 = unsupportedDurationField60.equals(obj63);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Seconds" + "'", str24.equals("Seconds"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(durationFieldType53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "years" + "'", str61.equals("years"));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "years" + "'", str62.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfWeek();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (short) 1);
        int int9 = offsetDateTimeField8.getMaximumValue();
        int int10 = offsetDateTimeField8.getOffset();
        long long13 = offsetDateTimeField8.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField8.getType();
        long long16 = offsetDateTimeField8.remainder(35L);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology18 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.chrono.LenientChronology lenientChronology19 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (short) 1);
        int int23 = offsetDateTimeField22.getMaximumValue();
        int int24 = offsetDateTimeField22.getOffset();
        long long27 = offsetDateTimeField22.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField22.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 100L, "Standard");
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) (-1.0d), "+00:00:00.035");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType28, (int) (short) 100);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType28, (-3500));
        boolean boolean39 = offsetDateTimeField38.isLenient();
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone41 = gregorianChronology40.getZone();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.secondOfMinute();
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology45 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology44);
        org.joda.time.chrono.LenientChronology lenientChronology46 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology44);
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology44.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) (short) 1);
        int int50 = offsetDateTimeField49.getMaximumValue();
        int int51 = offsetDateTimeField49.getOffset();
        long long54 = offsetDateTimeField49.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField49.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType55, (java.lang.Number) 100L, "Standard");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField60 = new org.joda.time.field.RemainderDateTimeField(dateTimeField43, dateTimeFieldType55, 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField62 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField38, dateTimeFieldType55, 9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-612L) + "'", long13 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 14400035L + "'", long16 == 14400035L);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(lenientChronology18);
        org.junit.Assert.assertNotNull(lenientChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-612L) + "'", long27 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(lenientChronology45);
        org.junit.Assert.assertNotNull(lenientChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-612L) + "'", long54 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.era();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.yearOfEra();
        org.joda.time.DurationField durationField5 = iSOChronology0.halfdays();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType8, "Pacific Standard Time");
        org.joda.time.field.DecoratedDurationField decoratedDurationField11 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType8);
        long long14 = decoratedDurationField11.getMillis((int) (short) 100, (long) 3395);
        long long16 = decoratedDurationField11.getMillis(99);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4320000000L + "'", long14 == 4320000000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 4276800000L + "'", long16 == 4276800000L);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (byte) -1);
        org.joda.time.Period period3 = period1.minusSeconds(0);
        org.joda.time.Period period5 = period1.withHours(0);
        int int6 = period1.getMillis();
        int[] intArray7 = period1.getValues();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekyear();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
        org.joda.time.DurationField durationField11 = iSOChronology8.months();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType15);
        org.joda.time.Period period18 = period16.plusMinutes(0);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period16.toDurationFrom(readableInstant19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration20, readableInstant21);
        org.joda.time.Period period24 = period22.withMinutes((int) 'a');
        int[] intArray27 = lenientChronology12.get((org.joda.time.ReadablePeriod) period22, (-210573432000000L), (long) (-10));
        org.joda.time.Period period28 = period1.plus((org.joda.time.ReadablePeriod) period22);
        org.joda.time.Period period30 = period22.plusMonths(8);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) 1);
        int int6 = offsetDateTimeField5.getMaximumValue();
        long long9 = offsetDateTimeField5.addWrapField((long) (-25200000), 1);
        java.lang.String str11 = offsetDateTimeField5.getAsText((-57600000L));
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField5.getType();
        int int13 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField5.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 18000000L + "'", long9 == 18000000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyear();
        org.joda.time.DurationField durationField4 = iSOChronology0.years();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period3 = period1.minusMillis((int) (short) 0);
        int int4 = period3.getSeconds();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableInstant6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = period7.isSupported(durationFieldType8);
        org.joda.time.Period period10 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType11 = period7.getPeriodType();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType15);
        org.joda.time.Period period18 = period16.plusMinutes(0);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period16.toDurationFrom(readableInstant19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType23 = periodType22.withWeeksRemoved();
        java.lang.String str24 = periodType23.getName();
        org.joda.time.Period period25 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration20, readableInstant21, periodType23);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableInstant27);
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = period28.get(durationFieldType29);
        org.joda.time.Period period32 = period28.withMinutes((int) (short) 10);
        org.joda.time.Period period34 = period28.withMonths((int) (short) 100);
        int int35 = period28.getSeconds();
        org.joda.time.PeriodType periodType45 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period46 = new org.joda.time.Period(0L, periodType45);
        org.joda.time.Period period47 = new org.joda.time.Period((int) (short) 10, 0, 100, (int) (byte) 100, (int) (byte) -1, 10, (int) (byte) 0, (int) (short) 1, periodType45);
        org.joda.time.Period period48 = period28.normalizedStandard(periodType45);
        org.joda.time.Period period49 = new org.joda.time.Period(readableInstant12, (org.joda.time.ReadableDuration) duration20, periodType45);
        org.joda.time.PeriodType periodType50 = periodType45.withSecondsRemoved();
        org.joda.time.PeriodType periodType51 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DurationFieldType durationFieldType53 = periodType51.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(durationFieldType53, "Pacific Standard Time");
        boolean boolean56 = periodType50.isSupported(durationFieldType53);
        boolean boolean57 = periodType11.isSupported(durationFieldType53);
        org.joda.time.field.PreciseDurationField preciseDurationField59 = new org.joda.time.field.PreciseDurationField(durationFieldType53, 2440588L);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField60 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType53);
        java.lang.String str61 = unsupportedDurationField60.getName();
        java.lang.String str62 = unsupportedDurationField60.toString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException("hi!", "");
        java.lang.String str66 = illegalFieldValueException65.getFieldName();
        java.lang.String str67 = illegalFieldValueException65.getIllegalValueAsString();
        java.lang.Number number68 = illegalFieldValueException65.getUpperBound();
        boolean boolean69 = unsupportedDurationField60.equals((java.lang.Object) number68);
        try {
            int int72 = unsupportedDurationField60.getDifference((-2793600000L), (-35L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Seconds" + "'", str24.equals("Seconds"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(durationFieldType53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "years" + "'", str61.equals("years"));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "UnsupportedDurationField[years]" + "'", str62.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "hi!" + "'", str66.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "" + "'", str67.equals(""));
        org.junit.Assert.assertNull(number68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-99L), (-28800032L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 2851203168");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableDuration2, periodType3);
        org.joda.time.Period period6 = period4.plusMinutes(0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period4.toDurationFrom(readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType11 = periodType10.withWeeksRemoved();
        java.lang.String str12 = periodType11.getName();
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType11);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant14, readableInstant15);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        int int18 = period16.get(durationFieldType17);
        org.joda.time.Period period20 = period16.withMinutes((int) (short) 10);
        org.joda.time.Period period22 = period16.withMonths((int) (short) 100);
        int int23 = period16.getSeconds();
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period34 = new org.joda.time.Period(0L, periodType33);
        org.joda.time.Period period35 = new org.joda.time.Period((int) (short) 10, 0, 100, (int) (byte) 100, (int) (byte) -1, 10, (int) (byte) 0, (int) (short) 1, periodType33);
        org.joda.time.Period period36 = period16.normalizedStandard(periodType33);
        org.joda.time.Period period37 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8, periodType33);
        org.joda.time.PeriodType periodType38 = org.joda.time.DateTimeUtils.getPeriodType(periodType33);
        try {
            org.joda.time.DurationFieldType durationFieldType40 = periodType38.getFieldType(97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Seconds" + "'", str12.equals("Seconds"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType38);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) 1);
        java.util.Locale locale6 = null;
        int int7 = offsetDateTimeField5.getMaximumTextLength(locale6);
        long long9 = offsetDateTimeField5.roundHalfEven(43200000L);
        int int10 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.chrono.LenientChronology lenientChronology13 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (short) 1);
        int int17 = offsetDateTimeField16.getMaximumValue();
        int int18 = offsetDateTimeField16.getOffset();
        long long21 = offsetDateTimeField16.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 100L, (java.lang.Number) 100, (java.lang.Number) 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType22, (int) (short) 100);
        long long30 = remainderDateTimeField28.roundHalfCeiling((long) 2);
        int int31 = remainderDateTimeField28.getMinimumValue();
        int int32 = remainderDateTimeField28.getDivisor();
        int int33 = remainderDateTimeField28.getMinimumValue();
        java.lang.String str34 = remainderDateTimeField28.getName();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertNotNull(lenientChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-612L) + "'", long21 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-14400000L) + "'", long30 == (-14400000L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "halfdayOfDay" + "'", str34.equals("halfdayOfDay"));
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period3 = period1.minusMillis((int) (short) 0);
        int int4 = period3.getSeconds();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableInstant6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = period7.isSupported(durationFieldType8);
        org.joda.time.Period period10 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType11 = period7.getPeriodType();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType15);
        org.joda.time.Period period18 = period16.plusMinutes(0);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period16.toDurationFrom(readableInstant19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType23 = periodType22.withWeeksRemoved();
        java.lang.String str24 = periodType23.getName();
        org.joda.time.Period period25 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration20, readableInstant21, periodType23);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableInstant27);
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = period28.get(durationFieldType29);
        org.joda.time.Period period32 = period28.withMinutes((int) (short) 10);
        org.joda.time.Period period34 = period28.withMonths((int) (short) 100);
        int int35 = period28.getSeconds();
        org.joda.time.PeriodType periodType45 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period46 = new org.joda.time.Period(0L, periodType45);
        org.joda.time.Period period47 = new org.joda.time.Period((int) (short) 10, 0, 100, (int) (byte) 100, (int) (byte) -1, 10, (int) (byte) 0, (int) (short) 1, periodType45);
        org.joda.time.Period period48 = period28.normalizedStandard(periodType45);
        org.joda.time.Period period49 = new org.joda.time.Period(readableInstant12, (org.joda.time.ReadableDuration) duration20, periodType45);
        org.joda.time.PeriodType periodType50 = periodType45.withSecondsRemoved();
        org.joda.time.PeriodType periodType51 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DurationFieldType durationFieldType53 = periodType51.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(durationFieldType53, "Pacific Standard Time");
        boolean boolean56 = periodType50.isSupported(durationFieldType53);
        boolean boolean57 = periodType11.isSupported(durationFieldType53);
        org.joda.time.field.PreciseDurationField preciseDurationField59 = new org.joda.time.field.PreciseDurationField(durationFieldType53, 2440588L);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField60 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType53);
        java.lang.String str61 = unsupportedDurationField60.getName();
        java.lang.String str62 = unsupportedDurationField60.toString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException("hi!", "");
        java.lang.String str66 = illegalFieldValueException65.getFieldName();
        java.lang.String str67 = illegalFieldValueException65.getIllegalValueAsString();
        java.lang.Number number68 = illegalFieldValueException65.getUpperBound();
        boolean boolean69 = unsupportedDurationField60.equals((java.lang.Object) number68);
        long long70 = unsupportedDurationField60.getUnitMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Seconds" + "'", str24.equals("Seconds"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(durationFieldType53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "years" + "'", str61.equals("years"));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "UnsupportedDurationField[years]" + "'", str62.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "hi!" + "'", str66.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "" + "'", str67.equals(""));
        org.junit.Assert.assertNull(number68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) 1);
        java.util.Locale locale6 = null;
        int int7 = offsetDateTimeField5.getMaximumTextLength(locale6);
        long long9 = offsetDateTimeField5.roundHalfEven(43200000L);
        int int10 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.chrono.LenientChronology lenientChronology13 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (short) 1);
        int int17 = offsetDateTimeField16.getMaximumValue();
        int int18 = offsetDateTimeField16.getOffset();
        long long21 = offsetDateTimeField16.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 100L, (java.lang.Number) 100, (java.lang.Number) 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType22, (int) (short) 100);
        long long30 = remainderDateTimeField28.roundHalfCeiling((long) 2);
        int int31 = remainderDateTimeField28.getMinimumValue();
        int int32 = remainderDateTimeField28.getDivisor();
        long long35 = remainderDateTimeField28.addWrapField((-2736000000L), (-3500));
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology37 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology36);
        org.joda.time.chrono.LenientChronology lenientChronology38 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology36);
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology36.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) (short) 1);
        int int42 = offsetDateTimeField41.getMaximumValue();
        int int43 = offsetDateTimeField41.getOffset();
        long long46 = offsetDateTimeField41.getDifferenceAsLong((-26438400001L), 32L);
        int int47 = offsetDateTimeField41.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = offsetDateTimeField41.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField28, dateTimeFieldType48);
        int int50 = dividedDateTimeField49.getDivisor();
        int int51 = dividedDateTimeField49.getDivisor();
        int int52 = dividedDateTimeField49.getDivisor();
        int int53 = dividedDateTimeField49.getMinimumValue();
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology55 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology54);
        org.joda.time.chrono.LenientChronology lenientChronology56 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology54);
        org.joda.time.DateTimeField dateTimeField57 = iSOChronology54.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField57, (int) (short) 1);
        int int60 = offsetDateTimeField59.getMaximumValue();
        int int61 = offsetDateTimeField59.getOffset();
        long long64 = offsetDateTimeField59.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType65 = offsetDateTimeField59.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException69 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType65, (java.lang.Number) 100L, (java.lang.Number) 100, (java.lang.Number) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType65, (java.lang.Number) (-612L), (java.lang.Number) (-57600000L), (java.lang.Number) 9972000000L);
        org.joda.time.DateTimeFieldType dateTimeFieldType74 = illegalFieldValueException73.getDateTimeFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField75 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField49, dateTimeFieldType74);
        org.joda.time.ReadablePartial readablePartial76 = null;
        int int77 = remainderDateTimeField75.getMaximumValue(readablePartial76);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertNotNull(lenientChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-612L) + "'", long21 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-14400000L) + "'", long30 == (-14400000L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-2736000000L) + "'", long35 == (-2736000000L));
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(lenientChronology37);
        org.junit.Assert.assertNotNull(lenientChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-612L) + "'", long46 == (-612L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 100 + "'", int50 == 100);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 100 + "'", int52 == 100);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertNotNull(lenientChronology55);
        org.junit.Assert.assertNotNull(lenientChronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2 + "'", int60 == 2);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-612L) + "'", long64 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType65);
        org.junit.Assert.assertNotNull(dateTimeFieldType74);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 99 + "'", int77 == 99);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) 1);
        int int6 = offsetDateTimeField5.getMaximumValue();
        int int7 = offsetDateTimeField5.getOffset();
        long long10 = offsetDateTimeField5.getDifferenceAsLong((-26438400001L), 32L);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsShortText(0L, locale12);
        long long16 = offsetDateTimeField5.add((-210862267200000L), 100);
        int int18 = offsetDateTimeField5.getMinimumValue((long) 2);
        long long21 = offsetDateTimeField5.addWrapField(35L, 0);
        long long24 = offsetDateTimeField5.add((long) (-35), 0);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField5.getAsShortText(readablePartial25, 0, locale27);
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField5.getAsShortText((long) 230, locale30);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-612L) + "'", long10 == (-612L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2" + "'", str13.equals("2"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-210857947200000L) + "'", long16 == (-210857947200000L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-35L) + "'", long24 == (-35L));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2" + "'", str31.equals("2"));
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DurationField durationField2 = lenientChronology1.centuries();
        java.lang.String str3 = lenientChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.secondOfMinute();
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        int int11 = dateTimeZone9.getOffset(readableInstant10);
        org.joda.time.Chronology chronology12 = gregorianChronology4.withZone(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) lenientChronology1, dateTimeZone9);
        org.joda.time.DurationField durationField14 = zonedChronology13.minutes();
        java.lang.String str15 = zonedChronology13.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LenientChronology[ISOChronology[America/Los_Angeles]]" + "'", str3.equals("LenientChronology[ISOChronology[America/Los_Angeles]]"));
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ZonedChronology[LenientChronology[ISOChronology[UTC]], America/Los_Angeles]" + "'", str15.equals("ZonedChronology[LenientChronology[ISOChronology[UTC]], America/Los_Angeles]"));
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PeriodType[YearDay]", "Standard", 4, 0);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(85420580L, locale6);
        boolean boolean8 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.004" + "'", str7.equals("+00:00:00.004"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfMinute();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (short) 1);
        int int10 = offsetDateTimeField9.getMaximumValue();
        int int11 = offsetDateTimeField9.getOffset();
        long long14 = offsetDateTimeField9.getDifferenceAsLong((-26438400001L), 32L);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, (java.lang.Number) 100L, "Standard");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType15, 10);
        long long22 = remainderDateTimeField20.roundFloor(28800035L);
        int int24 = remainderDateTimeField20.get(0L);
        long long27 = remainderDateTimeField20.add((-64800990L), (-43199990L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-612L) + "'", long14 == (-612L));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28800000L + "'", long22 == 28800000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-43264790990L) + "'", long27 == (-43264790990L));
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported", "", 1, 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long7 = fixedDateTimeZone4.nextTransition((long) '#');
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertNotNull(timeZone8);
    }
}

