import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test002");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test003");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560634372660L + "'", long1 == 1560634372660L);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) -1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField3 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        try {
            long long7 = iSOChronology1.getDateTimeMillis((int) ' ', (int) (byte) 100, (int) (byte) 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        int[] intArray7 = new int[] { 10 };
        try {
            iSOChronology0.validate((org.joda.time.ReadablePartial) yearMonthDay5, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) '4', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 152 + "'", int2 == 152);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test014");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        try {
//            int int10 = property8.getDifference(readableInstant9);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -1560691974180");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600052 + "'", int3 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("hi!", (int) (short) 1, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for hi! must be in the range [100,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 1, 1969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-1L), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 0L, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test021");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime6 = dateTime5.withEarlierOffsetAtOverlap();
//        org.joda.time.DurationFieldType durationFieldType7 = null;
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime6.withFieldAdded(durationFieldType7, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600052 + "'", int3 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        java.lang.Appendable appendable3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadablePartial) yearMonthDay7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(yearMonthDay7);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadablePartial) yearMonthDay7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(yearMonthDay7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            java.lang.String str5 = dateTimeFormatter0.print(readablePartial4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 1L, 152);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (short) 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-62166787621948L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62166787621948L) + "'", long2 == (-62166787621948L));
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
//        org.joda.time.DateTime dateTime13 = dateTime12.withEarlierOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology15);
//        int int17 = dateTime16.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime16.plus(readablePeriod18);
//        org.joda.time.DateTime dateTime21 = dateTime16.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology23);
//        int int25 = dateTime24.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.plus(readablePeriod26);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long33 = dateTimeZone29.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime34 = dateTime24.withZoneRetainFields(dateTimeZone29);
//        org.joda.time.DateTime dateTime35 = dateTime21.withZoneRetainFields(dateTimeZone29);
//        java.lang.String str36 = dateTimeZone29.toString();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((java.lang.Object) dateTime12, dateTimeZone29);
//        try {
//            org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(0, 0, (int) (short) 10, 0, 0, 0, 10, dateTimeZone29);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600052 + "'", int10 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 57600052 + "'", int17 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 57600052 + "'", int25 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-125999990L) + "'", long33 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+35:00" + "'", str36.equals("+35:00"));
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
        org.joda.time.DurationField durationField3 = iSOChronology1.centuries();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.Chronology chronology6 = iSOChronology1.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 1, dateTimeZone5);
        long long10 = dateTimeZone5.adjustOffset((long) '#', false);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test030");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology3);
//        int int5 = dateTime4.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
//        org.joda.time.LocalDateTime localDateTime8 = dateTime4.toLocalDateTime();
//        org.joda.time.DateTime dateTime10 = dateTime4.withEra(0);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57600052 + "'", int5 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(localDateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1, 100, 0, (int) '#', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
//        java.lang.Appendable appendable4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology6);
//        org.joda.time.YearMonthDay yearMonthDay8 = dateTime7.toYearMonthDay();
//        int int9 = dateTime7.getYearOfEra();
//        org.joda.time.DateTime dateTime11 = dateTime7.withWeekyear((int) 'a');
//        try {
//            dateTimeFormatter0.printTo(appendable4, (org.joda.time.ReadableInstant) dateTime7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(locale1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(yearMonthDay8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 1, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        long long7 = iSOChronology0.add((long) ' ', (long) 3, (int) ' ');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 128L + "'", long7 == 128L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test039");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        boolean boolean4 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay3);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long16 = dateTimeZone12.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime17 = dateTime7.withZoneRetainFields(dateTimeZone12);
//        java.lang.String str18 = dateTimeZone12.getID();
//        try {
//            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) boolean4, dateTimeZone12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Boolean");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600052 + "'", int8 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-125999990L) + "'", long16 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+35:00" + "'", str18.equals("+35:00"));
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("+35:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+35:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(3, 0, 365, (int) (short) 0, 0, 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long19 = dateTimeZone15.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime20 = dateTime10.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime21 = dateTime7.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone15);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfMinute();
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology25);
//        org.joda.time.YearMonthDay yearMonthDay27 = dateTime26.toYearMonthDay();
//        boolean boolean28 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay27);
//        try {
//            int int29 = property23.compareTo((org.joda.time.ReadablePartial) yearMonthDay27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfMinute' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600052 + "'", int3 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600052 + "'", int11 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-125999990L) + "'", long19 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(yearMonthDay27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        int int8 = dateTime2.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600052 + "'", int3 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
//    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
//        boolean boolean17 = dateTime6.isBefore((long) (short) 10);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600052 + "'", int10 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) ' ', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(1, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53 + "'", int2 == 53);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) (byte) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DurationField durationField5 = iSOChronology1.years();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField6 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        boolean boolean14 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        java.util.Date date15 = dateTime13.toDate();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600052 + "'", int11 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(date15);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) 0, (-1), 53, 3, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime15 = property8.withMaximumValue();
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = property8.getAsText(locale16);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600052 + "'", int3 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long10 = dateTimeZone6.convertLocalToUTC(10L, false, 0L);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((int) (byte) 1, 0, 0, 0, (int) (byte) 10, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-125999990L) + "'", long10 == (-125999990L));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField12 = iSOChronology11.hours();
//        org.joda.time.DurationField durationField13 = iSOChronology11.centuries();
//        org.joda.time.MutableDateTime mutableDateTime14 = dateTime7.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DateTime dateTime16 = dateTime7.minusDays(52);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600052 + "'", int3 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        java.util.Locale locale14 = null;
//        java.util.Calendar calendar15 = dateTime9.toCalendar(locale14);
//        org.joda.time.DateTime dateTime17 = dateTime9.withCenturyOfEra((int) (short) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology19);
//        int int21 = dateTime20.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.plus(readablePeriod22);
//        org.joda.time.DateTime dateTime25 = dateTime20.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology27);
//        int int29 = dateTime28.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime28.plus(readablePeriod30);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long37 = dateTimeZone33.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime38 = dateTime28.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTime dateTime39 = dateTime25.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now(dateTimeZone33);
//        org.joda.time.DateTime dateTime41 = dateTime9.withZone(dateTimeZone33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
//        try {
//            int int43 = dateTime9.get(dateTimeFieldType42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600052 + "'", int10 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(calendar15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 57600052 + "'", int21 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 57600052 + "'", int29 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-125999990L) + "'", long37 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 999, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1000L + "'", long2 == 1000L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) 0, 152, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("1", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) (short) 1);
//        java.lang.String str5 = dateTimeFormatter3.print((-125999990L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(int1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-30T05:00:00-08:00" + "'", str5.equals("1969-12-30T05:00:00-08:00"));
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.Integer int2 = dateTimeFormatter1.getPivotYear();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField4 = iSOChronology0.years();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10, (java.lang.Number) (short) 100, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 1, (int) (byte) 1, (int) (short) 0, 11, 3, (int) (byte) 10, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (short) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis((int) 'a', 8, 365, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField6 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField4, dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime2.plus((-125999990L));
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
//        int int12 = dateTime9.getDayOfMonth();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600052 + "'", int3 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 30 + "'", int12 == 30);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTimeISO();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withField(dateTimeFieldType4, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = iSOChronology0.get(readablePeriod2, (long) 3, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter3.withZoneUTC();
        try {
            org.joda.time.DateTime dateTime6 = dateTimeFormatter3.parseDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.Chronology chronology5 = iSOChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType7, (int) (byte) -1, 999, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) (byte) 1);
//        java.lang.StringBuffer stringBuffer4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
//        org.joda.time.DateTime dateTime12 = dateTime7.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property13 = dateTime12.millisOfSecond();
//        org.joda.time.LocalDateTime localDateTime14 = dateTime12.toLocalDateTime();
//        try {
//            dateTimeFormatter3.printTo(stringBuffer4, (org.joda.time.ReadablePartial) localDateTime14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(locale1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600052 + "'", int8 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(localDateTime14);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.Chronology chronology5 = iSOChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField8 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0, 53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime6 = dateTime5.withEarlierOffsetAtOverlap();
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(chronology7);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600052 + "'", int3 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 1, 8);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = iSOChronology1.withZone(dateTimeZone5);
        org.joda.time.DurationField durationField7 = iSOChronology1.months();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField9 = new org.joda.time.field.DecoratedDurationField(durationField7, durationFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long11 = dateTimeZone7.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime12 = dateTime2.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.DateTime dateTime14 = dateTime2.minusMinutes((int) (byte) 100);
//        org.joda.time.DateTime.Property property15 = dateTime14.era();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
//        int int19 = dateTime18.getMillisOfDay();
//        try {
//            int int20 = property15.getDifference((org.joda.time.ReadableInstant) dateTime18);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600052 + "'", int3 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-125999990L) + "'", long11 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57600052 + "'", int19 == 57600052);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology7);
//        int int9 = dateTime8.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.plus(readablePeriod10);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long17 = dateTimeZone13.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime18 = dateTime8.withZoneRetainFields(dateTimeZone13);
//        try {
//            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(999, (int) (byte) 0, 19, 8, (int) (short) 10, 365, dateTimeZone13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600052 + "'", int9 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-125999990L) + "'", long17 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) iSOChronology2);
        try {
            long long10 = iSOChronology2.getDateTimeMillis(1560634372660L, (int) (short) -1, (int) (short) 100, (int) (short) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 100L, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-1L), (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-100L) + "'", long2 == (-100L));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(69, 0, (int) (byte) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.hours();
        org.joda.time.DurationField durationField8 = iSOChronology6.centuries();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(52, 1969, 11, 30, 0, 365, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        java.util.Locale locale14 = null;
//        java.util.Calendar calendar15 = dateTime9.toCalendar(locale14);
//        org.joda.time.DateTime dateTime17 = dateTime9.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds((int) '#');
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600052 + "'", int10 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(calendar15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long11 = dateTimeZone7.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime12 = dateTime2.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusYears((int) (short) -1);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
//        int int18 = dateTime17.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.plus(readablePeriod19);
//        org.joda.time.DateTime dateTime22 = dateTime17.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property23 = dateTime22.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
//        int int25 = dateTime14.get(dateTimeField24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType26, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600052 + "'", int3 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-125999990L) + "'", long11 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 57600052 + "'", int18 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.LocalDateTime localDateTime9 = dateTime7.toLocalDateTime();
//        org.joda.time.Chronology chronology10 = dateTime7.getChronology();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600052 + "'", int3 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDateTime9);
//        org.junit.Assert.assertNotNull(chronology10);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField12 = iSOChronology11.hours();
//        org.joda.time.DurationField durationField13 = iSOChronology11.centuries();
//        org.joda.time.MutableDateTime mutableDateTime14 = dateTime7.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology11.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology11.dayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, dateTimeFieldType17, 8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600052 + "'", int3 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1");
        jodaTimePermission1.checkGuard((java.lang.Object) 11);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
//        org.joda.time.DateTime dateTime12 = dateTime7.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long24 = dateTimeZone20.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime25 = dateTime15.withZoneRetainFields(dateTimeZone20);
//        org.joda.time.DateTime dateTime26 = dateTime12.withZoneRetainFields(dateTimeZone20);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(dateTimeZone20);
//        java.lang.String str29 = dateTimeZone20.getShortName(1560634372660L);
//        try {
//            org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(10, (int) (short) -1, 0, 11, (int) (byte) 100, dateTimeZone20);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600052 + "'", int8 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57600052 + "'", int16 == 57600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-125999990L) + "'", long24 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+35:00" + "'", str29.equals("+35:00"));
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField5 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.LocalDateTime localDateTime6 = dateTime2.toLocalDateTime();
//        org.joda.time.DateTime dateTime8 = dateTime2.withEra(0);
//        org.joda.time.DateTime dateTime10 = dateTime2.withCenturyOfEra((int) (short) 0);
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded(readableDuration11, 19);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        int int9 = property8.getLeapAmount();
//        int int10 = property8.getLeapAmount();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTime dateTime8 = dateTime5.withTimeAtStartOfDay();
        try {
            java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) -1);
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withYearOfCentury((-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 999);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
        org.joda.time.DurationField durationField3 = iSOChronology1.centuries();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField5 = iSOChronology4.hours();
        org.joda.time.DurationField durationField6 = iSOChronology4.centuries();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField7 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField3, durationField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
//        int int14 = dateTime13.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
//        org.joda.time.DateTime dateTime18 = dateTime13.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology20);
//        int int22 = dateTime21.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime21.plus(readablePeriod23);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long30 = dateTimeZone26.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime31 = dateTime21.withZoneRetainFields(dateTimeZone26);
//        org.joda.time.DateTime dateTime32 = dateTime18.withZoneRetainFields(dateTimeZone26);
//        org.joda.time.DateTime dateTime33 = dateTime5.withZone(dateTimeZone26);
//        boolean boolean34 = iSOChronology1.equals((java.lang.Object) dateTime33);
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology1.weekyear();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39600052 + "'", int14 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 39600052 + "'", int22 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-125999990L) + "'", long30 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.centuryOfEra();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
//        int int14 = dateTime13.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
//        org.joda.time.DateTime dateTime18 = dateTime13.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property19 = dateTime18.millisOfSecond();
//        org.joda.time.LocalDateTime localDateTime20 = dateTime18.toLocalDateTime();
//        boolean boolean21 = cachedDateTimeZone10.isLocalDateTimeGap(localDateTime20);
//        int[] intArray25 = new int[] { 10, 11, (byte) 1 };
//        try {
//            iSOChronology0.validate((org.joda.time.ReadablePartial) localDateTime20, intArray25);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39600052 + "'", int14 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(localDateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(intArray25);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime11 = property8.roundHalfFloorCopy();
//        int int12 = property8.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
//        try {
//            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) property8, dateTimeZone15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 999 + "'", int12 == 999);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        int int4 = dateTime2.getYearOfEra();
        long long5 = dateTime2.getMillis();
        try {
            org.joda.time.DateTime dateTime9 = dateTime2.withDate((int) (short) 1, (-57600000), 53);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -57600000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        try {
            long long2 = dateTimeFormatter0.parseMillis("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter3.withZoneUTC();
//        java.lang.Appendable appendable5 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology7);
//        int int9 = dateTime8.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.plus(readablePeriod10);
//        org.joda.time.DateTime dateTime12 = dateTime11.withEarlierOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        java.lang.String str35 = dateTimeZone28.toString();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((java.lang.Object) dateTime11, dateTimeZone28);
//        try {
//            dateTimeFormatter3.printTo(appendable5, (org.joda.time.ReadableInstant) dateTime36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(locale1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 39600052 + "'", int9 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+35:00" + "'", str35.equals("+35:00"));
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.LocalDateTime localDateTime9 = dateTime7.toLocalDateTime();
//        org.joda.time.DateTime dateTime11 = dateTime7.minusMillis(365);
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime7.withDate((int) (short) 1, 0, 8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
//        int int14 = dateTime13.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
//        org.joda.time.DateTime dateTime18 = dateTime13.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology20);
//        int int22 = dateTime21.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime21.plus(readablePeriod23);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long30 = dateTimeZone26.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime31 = dateTime21.withZoneRetainFields(dateTimeZone26);
//        org.joda.time.DateTime dateTime32 = dateTime18.withZoneRetainFields(dateTimeZone26);
//        org.joda.time.DateTime dateTime33 = dateTime5.withZone(dateTimeZone26);
//        boolean boolean34 = iSOChronology1.equals((java.lang.Object) dateTime33);
//        org.joda.time.DurationField durationField35 = iSOChronology1.seconds();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39600052 + "'", int14 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 39600052 + "'", int22 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-125999990L) + "'", long30 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(durationField35);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.LocalDateTime localDateTime6 = dateTime2.toLocalDateTime();
//        org.joda.time.DateTime dateTime8 = dateTime2.withEra(0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        try {
//            org.joda.time.DateTime dateTime11 = dateTime2.withField(dateTimeFieldType9, (-100));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(365);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getOffset((long) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        int int12 = dateTime11.getMillisOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime11.withWeekyear(0);
//        int int15 = property8.compareTo((org.joda.time.ReadableInstant) dateTime11);
//        int int16 = dateTime11.getSecondOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 39600052 + "'", int12 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600 + "'", int16 == 39600);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) -1, 999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 998 + "'", int2 == 998);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTimeISO();
        boolean boolean4 = dateTime2.isBeforeNow();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField12 = iSOChronology11.hours();
//        org.joda.time.DurationField durationField13 = iSOChronology11.centuries();
//        org.joda.time.MutableDateTime mutableDateTime14 = dateTime7.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology11.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology11.dayOfWeek();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        try {
//            int[] intArray19 = iSOChronology11.get(readablePeriod17, (long) 365);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.weekOfWeekyear();
        try {
            long long10 = iSOChronology0.getDateTimeMillis((long) 8, (int) (short) 10, (int) (short) 0, 10, (-57600000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -57600000 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
//        org.joda.time.DurationField durationField3 = iSOChronology1.years();
//        java.lang.String str4 = iSOChronology1.toString();
//        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 11, (java.lang.Object) str4);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[+35:00]" + "'", str4.equals("ISOChronology[+35:00]"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
//        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) 'a');
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology11);
//        int int13 = dateTime12.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.plus(readablePeriod14);
//        org.joda.time.DateTime dateTime17 = dateTime12.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime20 = dateTime17.withEra(1);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField22 = iSOChronology21.hours();
//        org.joda.time.DurationField durationField23 = iSOChronology21.centuries();
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime17.toMutableDateTime((org.joda.time.Chronology) iSOChronology21);
//        boolean boolean25 = dateTime9.isAfter((org.joda.time.ReadableInstant) mutableDateTime24);
//        long long26 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 39600052 + "'", int13 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-39599999L) + "'", long26 == (-39599999L));
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.yearOfEra();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(1970, 19, 998, 4, 0, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
//        java.io.Writer writer1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology3);
//        int int5 = dateTime4.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
//        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(1969);
//        int int16 = property10.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime17 = property10.withMaximumValue();
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology19);
//        org.joda.time.DateTime dateTime21 = dateTime17.withChronology((org.joda.time.Chronology) iSOChronology19);
//        org.joda.time.LocalDate localDate22 = dateTime17.toLocalDate();
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 39600052 + "'", int5 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(localDate22);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = iSOChronology1.withZone(dateTimeZone5);
        try {
            long long14 = iSOChronology1.getDateTimeMillis(1, 0, (int) ' ', 0, 365, (int) (short) 10, 69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.Object obj0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long7 = fixedDateTimeZone5.previousTransition(0L);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(obj0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.util.TimeZone timeZone9 = fixedDateTimeZone5.toTimeZone();
        java.lang.String str11 = fixedDateTimeZone5.getNameKey((long) 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+35:00" + "'", str11.equals("+35:00"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime15 = property8.withMaximumValue();
//        org.joda.time.LocalTime localTime16 = dateTime15.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay17 = dateTime15.toTimeOfDay();
//        int int18 = dateTime15.getMillisOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localTime16);
//        org.junit.Assert.assertNotNull(timeOfDay17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 999 + "'", int18 == 999);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology7);
//        int int9 = dateTime8.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.plus(readablePeriod10);
//        org.joda.time.DateTime dateTime13 = dateTime8.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime15 = dateTime8.plus((-125999990L));
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.hours();
//        org.joda.time.DurationField durationField18 = iSOChronology16.centuries();
//        org.joda.time.DateTime dateTime19 = dateTime15.withChronology((org.joda.time.Chronology) iSOChronology16);
//        try {
//            org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((-57600000), 100, (int) (byte) 0, (int) (byte) -1, 39600, 30, (org.joda.time.Chronology) iSOChronology16);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 39600052 + "'", int9 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "(\"org.joda.time.JodaTimePermission\" \"1\")");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (short) 0, 998);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.joda.time.Chronology chronology4 = dateTimeFormatter3.getChronology();
        java.lang.Appendable appendable5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        try {
            dateTimeFormatter3.printTo(appendable5, readableInstant6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(chronology4);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
//        org.joda.time.DateTime.Property property16 = dateTime6.millisOfSecond();
//        org.joda.time.Interval interval17 = property16.toInterval();
//        org.joda.time.ReadableInterval readableInterval18 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval17);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertNotNull(readableInterval18);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
//        int int7 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.plus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
//        org.joda.time.DateTime dateTime14 = property12.roundHalfFloorCopy();
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
//        org.joda.time.DateTime dateTime22 = dateTime19.toDateTime();
//        org.joda.time.DateTime dateTime24 = dateTime19.minusWeeks(100);
//        boolean boolean25 = property12.equals((java.lang.Object) dateTime24);
//        boolean boolean26 = iSOChronology0.equals((java.lang.Object) boolean25);
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology0.dayOfMonth();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39600052 + "'", int7 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField7 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType5, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime2.plus((-125999990L));
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField11 = iSOChronology10.hours();
//        org.joda.time.DurationField durationField12 = iSOChronology10.centuries();
//        org.joda.time.DateTime dateTime13 = dateTime9.withChronology((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology10.yearOfCentury();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        java.util.Locale locale14 = null;
//        java.util.Calendar calendar15 = dateTime9.toCalendar(locale14);
//        org.joda.time.DateTime dateTime17 = dateTime9.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DurationFieldType durationFieldType18 = null;
//        try {
//            org.joda.time.DateTime dateTime20 = dateTime9.withFieldAdded(durationFieldType18, 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(calendar15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(chronology2);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long19 = dateTimeZone15.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime20 = dateTime10.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime21 = dateTime7.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusYears(998);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-125999990L) + "'", long19 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime2.plus((-125999990L));
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
//        boolean boolean12 = dateTime9.isEqualNow();
//        org.joda.time.DateTime dateTime15 = dateTime9.withDurationAdded(1000L, (-1));
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        java.lang.String str10 = property8.getAsText();
//        int int11 = property8.get();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.YearMonthDay yearMonthDay15 = dateTime14.toYearMonthDay();
//        int int16 = dateTime14.getYearOfEra();
//        org.joda.time.DateTime dateTime18 = dateTime14.withWeekyear((int) 'a');
//        try {
//            int int19 = property8.getDifference((org.joda.time.ReadableInstant) dateTime18);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 59105854799949");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(yearMonthDay15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime2.plus((-125999990L));
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
//        boolean boolean12 = dateTime9.isEqualNow();
//        org.joda.time.DateTime dateTime15 = dateTime9.withDurationAdded(1000L, (-1));
//        org.joda.time.Instant instant16 = dateTime9.toInstant();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(instant16);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        boolean boolean14 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        int int15 = dateTime7.getDayOfYear();
//        int int16 = dateTime7.getSecondOfMinute();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime7.toMutableDateTime(chronology17);
//        org.joda.time.DateTime dateTime20 = dateTime7.withMillis((long) 19);
//        org.joda.time.DateTime.Property property21 = dateTime7.minuteOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime2.plus((-125999990L));
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
//        java.util.Locale locale12 = null;
//        java.util.Calendar calendar13 = dateTime11.toCalendar(locale12);
//        java.util.Locale locale15 = null;
//        try {
//            java.lang.String str16 = dateTime11.toString("hi!", locale15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(calendar13);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 100, (long) 152);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 15200L + "'", long2 == 15200L);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfSecond();
//        try {
//            long long19 = iSOChronology0.getDateTimeMillis(11, 4, 10, (int) (short) 0, (int) (short) 100, 10, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long11 = dateTimeZone7.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime12 = dateTime2.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.DateTime dateTime14 = dateTime2.minusMinutes((int) (byte) 100);
//        org.joda.time.DateTime.Property property15 = dateTime14.era();
//        java.lang.String str16 = property15.getName();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-125999990L) + "'", long11 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "era" + "'", str16.equals("era"));
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.YearMonthDay yearMonthDay13 = dateTime12.toYearMonthDay();
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DurationField durationField15 = property8.getDurationField();
//        org.joda.time.DateTime dateTime16 = property8.roundFloorCopy();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(yearMonthDay13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime2.withDurationAdded(readableDuration7, 8);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(19);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-19) + "'", int1 == (-19));
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
//        org.joda.time.DateTime.Property property16 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime18 = property16.addToCopy((long) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
//        try {
//            int int20 = dateTime18.get(dateTimeFieldType19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        try {
            long long2 = dateTimeFormatter0.parseMillis("GregorianChronology[+35:00]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[+35:00]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withHourOfDay(4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.secondOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime11 = property8.roundHalfFloorCopy();
//        java.lang.String str12 = property8.getAsString();
//        java.util.Locale locale14 = null;
//        try {
//            org.joda.time.DateTime dateTime15 = property8.setCopy("hi!", locale14);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for millisOfSecond is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime11 = property8.roundHalfFloorCopy();
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime11.withDate(0, (-1), (-57600000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("+35:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+35:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime6 = dateTime5.withEarlierOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
//        org.joda.time.DateTime dateTime14 = dateTime9.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
//        int int18 = dateTime17.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.plus(readablePeriod19);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long26 = dateTimeZone22.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime27 = dateTime17.withZoneRetainFields(dateTimeZone22);
//        org.joda.time.DateTime dateTime28 = dateTime14.withZoneRetainFields(dateTimeZone22);
//        java.lang.String str29 = dateTimeZone22.toString();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) dateTime5, dateTimeZone22);
//        try {
//            org.joda.time.DateTime dateTime32 = dateTime5.withDayOfMonth(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 39600052 + "'", int18 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-125999990L) + "'", long26 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+35:00" + "'", str29.equals("+35:00"));
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        java.lang.String str2 = dateTimeFormatter0.print((long) ' ');
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "11:00:00.032" + "'", str2.equals("11:00:00.032"));
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        int int4 = dateTime2.getYearOfEra();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        java.lang.String str14 = cachedDateTimeZone12.getNameKey((long) 57600052);
        org.joda.time.DateTime dateTime15 = dateTime6.toDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+35:00" + "'", str14.equals("+35:00"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
//        boolean boolean16 = dateTime6.isBeforeNow();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime15 = property8.withMaximumValue();
//        java.lang.String str16 = property8.getAsText();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = iSOChronology2.get(readablePeriod5, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology7);
//        int int9 = dateTime8.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.plus(readablePeriod10);
//        org.joda.time.DateTime dateTime13 = dateTime8.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property14 = dateTime13.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds(1969);
//        int int20 = property14.compareTo((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology23);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) iSOChronology23);
//        org.joda.time.DateTime dateTime26 = dateTime19.toDateTime((org.joda.time.Chronology) iSOChronology23);
//        try {
//            org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((int) (byte) 10, 0, 4, 0, (int) 'a', (-39600000), (org.joda.time.Chronology) iSOChronology23);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 39600052 + "'", int9 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime15 = property8.roundHalfFloorCopy();
//        long long16 = dateTime15.getMillis();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-39599999L) + "'", long16 == (-39599999L));
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-39600000), 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-79200000L) + "'", long2 == (-79200000L));
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.DateTime dateTime10 = property8.getDateTime();
//        int int11 = property8.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        boolean boolean14 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        int int15 = dateTime7.getDayOfYear();
//        org.joda.time.DateTime dateTime17 = dateTime7.withYear(999);
//        int int18 = dateTime17.getSecondOfMinute();
//        try {
//            org.joda.time.DateTime dateTime20 = dateTime17.withWeekOfWeekyear(999);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 11 + "'", int18 == 11);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType2, 126000000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.Chronology chronology3 = dateTimeFormatter1.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNull(chronology3);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
//        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
//        long long9 = fixedDateTimeZone7.previousTransition(0L);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
//        boolean boolean13 = fixedDateTimeZone7.equals((java.lang.Object) dateTimeZone12);
//        long long16 = dateTimeZone12.adjustOffset(0L, false);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZone(dateTimeZone12);
//        java.lang.Appendable appendable18 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime21.toYearMonthDay();
//        int int23 = dateTime21.getYearOfEra();
//        long long24 = dateTime21.getMillis();
//        try {
//            dateTimeFormatter0.printTo(appendable18, (org.joda.time.ReadableInstant) dateTime21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(locale1);
//        org.junit.Assert.assertNotNull(dateTimePrinter2);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1970 + "'", int23 == 1970);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 52L + "'", long24 == 52L);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField3 = iSOChronology2.hours();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.weekyearOfCentury();
        org.joda.time.DurationField durationField6 = iSOChronology2.years();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField7 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime15 = property8.withMaximumValue();
//        org.joda.time.LocalTime localTime16 = dateTime15.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay17 = dateTime15.toTimeOfDay();
//        org.joda.time.LocalTime localTime18 = dateTime15.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
//        try {
//            org.joda.time.DateTime dateTime21 = dateTime15.withField(dateTimeFieldType19, 39600);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localTime16);
//        org.junit.Assert.assertNotNull(timeOfDay17);
//        org.junit.Assert.assertNotNull(localTime18);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
//        org.joda.time.DateTime dateTime14 = dateTime9.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property15 = dateTime14.millisOfSecond();
//        org.joda.time.LocalDateTime localDateTime16 = dateTime14.toLocalDateTime();
//        boolean boolean17 = cachedDateTimeZone6.isLocalDateTimeGap(localDateTime16);
//        long long19 = cachedDateTimeZone6.previousTransition((long) 57600052);
//        try {
//            org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57600052L + "'", long19 == 57600052L);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 57600052);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        int int4 = dateTime2.getYearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime2.withWeekyear((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            int int9 = dateTime6.get(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        java.lang.String str14 = cachedDateTimeZone12.getNameKey((long) 57600052);
        long long16 = cachedDateTimeZone12.previousTransition(0L);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) 'a', 998, 0, 53, (int) (byte) 100, 0, (int) (short) 100, (org.joda.time.DateTimeZone) cachedDateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+35:00" + "'", str14.equals("+35:00"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(30);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfMinute((-57600000), (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendOptional(dateTimeParser6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendOptional(dateTimeParser7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) -1, "+35:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime11 = property8.roundHalfFloorCopy();
//        try {
//            org.joda.time.DateTime dateTime16 = dateTime11.withTime((int) '#', (int) (short) 100, 70, 19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology6);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long23 = dateTimeZone19.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime24 = dateTime14.withZoneRetainFields(dateTimeZone19);
//        java.lang.String str25 = dateTimeZone19.getID();
//        long long27 = dateTimeZone10.getMillisKeepLocal(dateTimeZone19, 52L);
//        try {
//            org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((int) (byte) -1, (int) (short) 1, (int) (byte) -1, (-57600000), 999, dateTimeZone10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -57600000 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-125999990L) + "'", long23 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+35:00" + "'", str25.equals("+35:00"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10, 998, 53, 152, 126000000, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 152 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str7 = cachedDateTimeZone5.getNameKey((long) 57600052);
        long long9 = cachedDateTimeZone5.previousTransition(0L);
        int int11 = cachedDateTimeZone5.getOffset((long) 1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:00" + "'", str7.equals("+35:00"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime15 = property8.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime17 = dateTime15.plus((long) (-57600000));
//        java.lang.String str19 = dateTime15.toString("1");
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfHour();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis(0, 57600052, 1969, (-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for millisOfDay must be in the range [0,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (-57600000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusSeconds((-57600000));
//        org.joda.time.DateTime dateTime11 = dateTime7.withDayOfYear(152);
//        boolean boolean13 = dateTime11.isEqual((long) (-57600000));
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneOffset("11:00:00.032", "(\"org.joda.time.JodaTimePermission\" \"1\")", false, 365, 999);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale9 = dateTimeFormatter8.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter8.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser13 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder7.append(dateTimePrinter12, dateTimeParser13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNull(locale9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0, 660);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.Object obj6 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long13 = fixedDateTimeZone11.previousTransition(0L);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj6, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(365, 660, (int) (byte) 1, (int) (byte) 10, 39600, 53, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 39600 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusYears(53);
//        org.joda.time.DateTime.Property property16 = dateTime15.secondOfDay();
//        int int17 = dateTime15.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.DurationField durationField1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField3 = iSOChronology2.hours();
//        org.joda.time.DurationField durationField4 = iSOChronology2.years();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withWeekyear(0);
//        int int11 = dateTime7.getMinuteOfHour();
//        boolean boolean12 = iSOChronology2.equals((java.lang.Object) dateTime7);
//        org.joda.time.DurationField durationField13 = iSOChronology2.seconds();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField14 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 39600052 + "'", int8 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.DateTime dateTime10 = property8.getDateTime();
//        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(1969);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property21 = dateTime20.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology23);
//        org.joda.time.DateTime dateTime26 = dateTime24.minusSeconds(1969);
//        int int27 = property21.compareTo((org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology30);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) iSOChronology30);
//        org.joda.time.DateTime dateTime33 = dateTime26.toDateTime((org.joda.time.Chronology) iSOChronology30);
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology35);
//        int int37 = dateTime36.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod38 = null;
//        org.joda.time.DateTime dateTime39 = dateTime36.plus(readablePeriod38);
//        org.joda.time.DateTime dateTime41 = dateTime36.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property42 = dateTime41.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology44);
//        org.joda.time.DateTime dateTime47 = dateTime45.minusSeconds(1969);
//        int int48 = property42.compareTo((org.joda.time.ReadableInstant) dateTime47);
//        org.joda.time.DateTime dateTime49 = property42.withMaximumValue();
//        org.joda.time.LocalTime localTime50 = dateTime49.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay51 = dateTime49.toTimeOfDay();
//        int[] intArray53 = iSOChronology30.get((org.joda.time.ReadablePartial) timeOfDay51, (long) 0);
//        org.joda.time.DateTime dateTime54 = dateTime12.withFields((org.joda.time.ReadablePartial) timeOfDay51);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 39600052 + "'", int37 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(localTime50);
//        org.junit.Assert.assertNotNull(timeOfDay51);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(dateTime54);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "1969-12-30T05:00:00-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneOffset("11:00:00.032", "(\"org.joda.time.JodaTimePermission\" \"1\")", false, 365, 999);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder7.appendTimeZoneOffset("1", "era", false, 70, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "hi!");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) 52, 2);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) '#', (int) (short) -1, (-39600000), 39600);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 34 + "'", int4 == 34);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
//        org.joda.time.DurationField durationField3 = iSOChronology1.years();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.year();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
//        org.joda.time.DateTime dateTime12 = dateTime7.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property13 = dateTime12.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
//        org.joda.time.DateTime dateTime15 = property13.roundHalfFloorCopy();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime20.minus(readableDuration21);
//        org.joda.time.DateTime dateTime23 = dateTime20.toDateTime();
//        org.joda.time.DateTime dateTime25 = dateTime20.minusWeeks(100);
//        boolean boolean26 = property13.equals((java.lang.Object) dateTime25);
//        boolean boolean27 = iSOChronology1.equals((java.lang.Object) boolean26);
//        org.joda.time.DurationField durationField28 = iSOChronology1.years();
//        try {
//            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField29 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField28);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 39600052 + "'", int8 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(durationField28);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 998, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 998L + "'", long2 == 998L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfWeek();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusYears(53);
//        org.joda.time.DateTime.Property property16 = dateTime15.secondOfDay();
//        int int17 = dateTime15.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 627 + "'", int17 == 627);
//    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekyear(0);
//        org.joda.time.DateTime dateTime7 = dateTime2.minusWeeks((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.DateTime dateTime13 = dateTime10.withWeekyear(0);
//        org.joda.time.DateTime dateTime15 = dateTime10.minusWeeks((int) (byte) 100);
//        boolean boolean16 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
//        org.joda.time.DateTime.Property property16 = dateTime6.millisOfSecond();
//        org.joda.time.Interval interval17 = property16.toInterval();
//        java.lang.String str18 = property16.getAsText();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "52" + "'", str18.equals("52"));
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusSeconds((-57600000));
//        try {
//            org.joda.time.DateTime dateTime11 = dateTime9.withMonthOfYear((-57600000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -57600000 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField6 = iSOChronology5.hours();
        org.joda.time.DurationField durationField7 = iSOChronology5.years();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0, 4, (int) ' ', (int) (short) 10, (-39600000), (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -39600000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime2.minusMonths(19);
//        int int10 = dateTime2.getYear();
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime2.withDayOfMonth((-57600000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -57600000 for dayOfMonth must be in the range [1,28]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560634403684L + "'", long0 == 1560634403684L);
//    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        java.lang.String str10 = property8.getAsText();
//        org.joda.time.DateTime dateTime12 = property8.setCopy(152);
//        org.joda.time.DateTime dateTime13 = property8.getDateTime();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
//        org.joda.time.DateTime dateTime12 = dateTime7.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property13 = dateTime12.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology15);
//        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds(1969);
//        int int19 = property13.compareTo((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime20 = property13.withMaximumValue();
//        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay22 = dateTime20.toTimeOfDay();
//        int[] intArray24 = iSOChronology1.get((org.joda.time.ReadablePartial) timeOfDay22, (-1L));
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 1970, (org.joda.time.Chronology) iSOChronology1);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 39600052 + "'", int8 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localTime21);
//        org.junit.Assert.assertNotNull(timeOfDay22);
//        org.junit.Assert.assertNotNull(intArray24);
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        org.joda.time.DateTime dateTime15 = dateTime10.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
//        int int19 = dateTime18.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime18.plus(readablePeriod20);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long27 = dateTimeZone23.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime28 = dateTime18.withZoneRetainFields(dateTimeZone23);
//        org.joda.time.DateTime dateTime29 = dateTime15.withZoneRetainFields(dateTimeZone23);
//        org.joda.time.DateTime dateTime30 = dateTime2.withZone(dateTimeZone23);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology32);
//        int int34 = dateTime33.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime33.plus(readablePeriod35);
//        org.joda.time.LocalDateTime localDateTime37 = dateTime33.toLocalDateTime();
//        org.joda.time.DateTime dateTime38 = dateTime30.withFields((org.joda.time.ReadablePartial) localDateTime37);
//        int int39 = dateTime30.getYearOfEra();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 39600052 + "'", int19 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-125999990L) + "'", long27 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 39600052 + "'", int34 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(localDateTime37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1970 + "'", int39 == 1970);
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
//        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property11 = dateTime10.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds(1969);
//        int int17 = property11.compareTo((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology25);
//        int int27 = dateTime26.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime26.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property32 = dateTime31.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology34);
//        org.joda.time.DateTime dateTime37 = dateTime35.minusSeconds(1969);
//        int int38 = property32.compareTo((org.joda.time.ReadableInstant) dateTime37);
//        org.joda.time.DateTime dateTime39 = property32.withMaximumValue();
//        org.joda.time.LocalTime localTime40 = dateTime39.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay41 = dateTime39.toTimeOfDay();
//        int[] intArray43 = iSOChronology20.get((org.joda.time.ReadablePartial) timeOfDay41, (long) 0);
//        java.lang.String str44 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) timeOfDay41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(locale1);
//        org.junit.Assert.assertNotNull(dateTimePrinter2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 39600052 + "'", int27 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(localTime40);
//        org.junit.Assert.assertNotNull(timeOfDay41);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "����-��-��T00:00" + "'", str44.equals("����-��-��T00:00"));
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        boolean boolean4 = dateTimeFormatterBuilder1.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfSecond(10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatterBuilder7.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.LocalDateTime localDateTime6 = dateTime2.toLocalDateTime();
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime2.withDurationAdded(readableDuration7, 11);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
//        java.lang.StringBuffer stringBuffer4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology6);
//        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.DateTime dateTime17 = dateTime14.withWeekyear(0);
//        boolean boolean18 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime20 = dateTime11.plusMillis((int) (byte) 0);
//        org.joda.time.DateTime dateTime22 = dateTime20.minusMillis(126000000);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology24);
//        int int26 = dateTime25.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.plus(readablePeriod27);
//        org.joda.time.DateTime dateTime30 = dateTime25.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property31 = dateTime30.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology33);
//        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds(1969);
//        int int37 = property31.compareTo((org.joda.time.ReadableInstant) dateTime36);
//        org.joda.time.DateTime dateTime38 = property31.withMaximumValue();
//        org.joda.time.LocalTime localTime39 = dateTime38.toLocalTime();
//        org.joda.time.DateTime dateTime40 = dateTime22.withFields((org.joda.time.ReadablePartial) localTime39);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer4, (org.joda.time.ReadablePartial) localTime39);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(locale1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 39600052 + "'", int26 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(localTime39);
//        org.junit.Assert.assertNotNull(dateTime40);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        try {
//            org.joda.time.DateTime dateTime16 = dateTime13.withEra(999);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 57600052L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 11);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
//        org.joda.time.DateTime.Property property16 = dateTime6.millisOfSecond();
//        int int17 = property16.getMinimumValueOverall();
//        long long18 = property16.remainder();
//        java.lang.String str19 = property16.getName();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "millisOfSecond" + "'", str19.equals("millisOfSecond"));
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (-125999373L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(69);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        int int4 = dateTime2.getYearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime2.withWeekyear((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime9 = dateTime6.plusYears(57600052);
        boolean boolean10 = dateTime9.isEqualNow();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) iSOChronology2);
        int int5 = dateTime4.getMonthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField7 = iSOChronology6.hours();
//        org.joda.time.DurationField durationField8 = iSOChronology6.years();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        int int12 = dateTime11.getMillisOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime11.withWeekyear(0);
//        int int15 = dateTime11.getMinuteOfHour();
//        boolean boolean16 = iSOChronology6.equals((java.lang.Object) dateTime11);
//        org.joda.time.DurationField durationField17 = iSOChronology6.seconds();
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology19);
//        int int21 = dateTime20.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.plus(readablePeriod22);
//        org.joda.time.DateTime dateTime25 = dateTime20.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology27);
//        int int29 = dateTime28.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime28.plus(readablePeriod30);
//        org.joda.time.DateTime dateTime33 = dateTime28.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology35);
//        int int37 = dateTime36.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod38 = null;
//        org.joda.time.DateTime dateTime39 = dateTime36.plus(readablePeriod38);
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long45 = dateTimeZone41.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime46 = dateTime36.withZoneRetainFields(dateTimeZone41);
//        org.joda.time.DateTime dateTime47 = dateTime33.withZoneRetainFields(dateTimeZone41);
//        org.joda.time.DateTime dateTime48 = dateTime20.withZone(dateTimeZone41);
//        org.joda.time.chrono.ZonedChronology zonedChronology49 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, dateTimeZone41);
//        try {
//            org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(998, (-39600000), 0, 126000000, 69, (int) (short) -1, (org.joda.time.Chronology) iSOChronology6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 126000000 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 39600052 + "'", int12 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 39600052 + "'", int21 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 39600052 + "'", int29 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 39600052 + "'", int37 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-125999990L) + "'", long45 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(zonedChronology49);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(39600052);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-39600052) + "'", int1 == (-39600052));
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime2.plus((-125999990L));
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
//        boolean boolean12 = dateTime9.isEqualNow();
//        org.joda.time.DateTime dateTime15 = dateTime9.withDurationAdded(1000L, (-1));
//        org.joda.time.DateTime dateTime17 = dateTime9.plusWeeks((int) (short) 10);
//        org.joda.time.DateTime dateTime20 = dateTime9.withDurationAdded((long) (byte) -1, (int) '#');
//        org.joda.time.DateTime.Property property21 = dateTime9.yearOfEra();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = property8.addToCopy((long) 52);
//        int int17 = dateTime16.getYearOfCentury();
//        int int18 = dateTime16.getCenturyOfEra();
//        org.joda.time.DateTime dateTime20 = dateTime16.withYear((int) (short) 1);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 70 + "'", int17 == 70);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19 + "'", int18 == 19);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime15 = property8.roundHalfFloorCopy();
//        int int16 = property8.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField6 = iSOChronology5.hours();
        org.joda.time.DurationField durationField7 = iSOChronology5.centuries();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.Chronology chronology10 = iSOChronology5.withZone(dateTimeZone9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone9.getShortName(0L, locale12);
        java.lang.String str14 = dateTimeZone9.getID();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone9);
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(11, (int) (short) 10, (int) (short) 100, 70, 5, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+35:00" + "'", str13.equals("+35:00"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+35:00" + "'", str14.equals("+35:00"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        boolean boolean9 = fixedDateTimeZone4.isStandardOffset((long) 70);
        java.lang.String str11 = fixedDateTimeZone4.getNameKey((long) 'a');
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+35:00" + "'", str11.equals("+35:00"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        boolean boolean9 = fixedDateTimeZone4.isStandardOffset((long) 70);
        int int11 = fixedDateTimeZone4.getOffset((long) 53);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 11, (java.lang.Number) (-1L), (java.lang.Number) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        int int11 = dateTime4.getSecondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        java.util.Locale locale14 = null;
//        java.util.Calendar calendar15 = dateTime9.toCalendar(locale14);
//        org.joda.time.DateTime dateTime17 = dateTime9.withCenturyOfEra((int) (short) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology19);
//        int int21 = dateTime20.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.plus(readablePeriod22);
//        org.joda.time.DateTime dateTime25 = dateTime20.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology27);
//        int int29 = dateTime28.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime28.plus(readablePeriod30);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long37 = dateTimeZone33.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime38 = dateTime28.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTime dateTime39 = dateTime25.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now(dateTimeZone33);
//        org.joda.time.DateTime dateTime41 = dateTime9.withZone(dateTimeZone33);
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(calendar15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 39600052 + "'", int21 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 39600052 + "'", int29 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-125999990L) + "'", long37 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusSeconds((-57600000));
//        org.joda.time.DateTime dateTime11 = dateTime7.withDayOfYear(152);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField13 = iSOChronology12.hours();
//        org.joda.time.DurationField durationField14 = iSOChronology12.years();
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
//        int int18 = dateTime17.getMillisOfDay();
//        org.joda.time.DateTime dateTime20 = dateTime17.withWeekyear(0);
//        int int21 = dateTime17.getMinuteOfHour();
//        boolean boolean22 = iSOChronology12.equals((java.lang.Object) dateTime17);
//        org.joda.time.DurationField durationField23 = iSOChronology12.seconds();
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology25);
//        int int27 = dateTime26.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime26.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology33);
//        int int35 = dateTime34.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod36 = null;
//        org.joda.time.DateTime dateTime37 = dateTime34.plus(readablePeriod36);
//        org.joda.time.DateTime dateTime39 = dateTime34.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology41);
//        int int43 = dateTime42.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod44 = null;
//        org.joda.time.DateTime dateTime45 = dateTime42.plus(readablePeriod44);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long51 = dateTimeZone47.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime52 = dateTime42.withZoneRetainFields(dateTimeZone47);
//        org.joda.time.DateTime dateTime53 = dateTime39.withZoneRetainFields(dateTimeZone47);
//        org.joda.time.DateTime dateTime54 = dateTime26.withZone(dateTimeZone47);
//        org.joda.time.chrono.ZonedChronology zonedChronology55 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology12, dateTimeZone47);
//        org.joda.time.DateTimeField dateTimeField56 = zonedChronology55.secondOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone61 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone62 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone61);
//        java.lang.String str64 = cachedDateTimeZone62.getNameKey((long) 57600052);
//        org.joda.time.Chronology chronology65 = zonedChronology55.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone62);
//        org.joda.time.DateTimeZone dateTimeZone67 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeUtils.getZone(dateTimeZone67);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone67);
//        java.util.Locale locale71 = null;
//        java.lang.String str72 = dateTimeZone67.getShortName(0L, locale71);
//        org.joda.time.Chronology chronology73 = zonedChronology55.withZone(dateTimeZone67);
//        org.joda.time.DateTime dateTime74 = dateTime7.toDateTime((org.joda.time.Chronology) zonedChronology55);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 39600052 + "'", int18 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 39600052 + "'", int27 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 39600052 + "'", int35 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(iSOChronology41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 39600052 + "'", int43 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-125999990L) + "'", long51 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(zonedChronology55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone62);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "+35:00" + "'", str64.equals("+35:00"));
//        org.junit.Assert.assertNotNull(chronology65);
//        org.junit.Assert.assertNotNull(dateTimeZone67);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "+35:00" + "'", str72.equals("+35:00"));
//        org.junit.Assert.assertNotNull(chronology73);
//        org.junit.Assert.assertNotNull(dateTime74);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter3.withZoneUTC();
        java.util.Locale locale5 = dateTimeFormatter4.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(locale5);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 69);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 69 + "'", int1 == 69);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
        int int9 = dateTime5.getMinuteOfHour();
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
        int int15 = dateTime14.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
        org.joda.time.DateTime dateTime19 = dateTime14.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
        int int23 = dateTime22.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
        int int31 = dateTime30.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime42 = dateTime14.withZone(dateTimeZone35);
        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone35);
        java.lang.String str44 = zonedChronology43.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(zonedChronology43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "ZonedChronology[ISOChronology[UTC], +35:00]" + "'", str44.equals("ZonedChronology[ISOChronology[UTC], +35:00]"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
        int int9 = dateTime5.getMinuteOfHour();
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
        int int15 = dateTime14.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
        org.joda.time.DateTime dateTime19 = dateTime14.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
        int int23 = dateTime22.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
        int int31 = dateTime30.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime42 = dateTime14.withZone(dateTimeZone35);
        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField44 = zonedChronology43.secondOfDay();
        try {
            long long50 = zonedChronology43.getDateTimeMillis((long) 19, (int) ' ', 8, (-100), (-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(zonedChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        int int4 = dateTime2.getYearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime2.withWeekyear((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime9 = dateTime6.plusYears(57600052);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime6.plus(readablePeriod10);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime15 = property8.withMaximumValue();
        org.joda.time.LocalTime localTime16 = dateTime15.toLocalTime();
        org.joda.time.TimeOfDay timeOfDay17 = dateTime15.toTimeOfDay();
        boolean boolean18 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay17);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localTime16);
        org.junit.Assert.assertNotNull(timeOfDay17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
        org.joda.time.DateTime.Property property16 = dateTime6.millisOfSecond();
        int int17 = property16.getMinimumValueOverall();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((long) 3);
        int int20 = dateTime19.getDayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long11 = dateTimeZone7.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime12 = dateTime2.withZoneRetainFields(dateTimeZone7);
        org.joda.time.DateTime dateTime14 = dateTime12.plusYears((int) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
        int int18 = dateTime17.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.plus(readablePeriod19);
        org.joda.time.DateTime dateTime22 = dateTime17.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property23 = dateTime22.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        int int25 = dateTime14.get(dateTimeField24);
        org.joda.time.DateTime dateTime26 = dateTime14.toDateTime();
        int int27 = dateTime26.getMinuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-125999990L) + "'", long11 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 39600052 + "'", int18 == 39600052);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime2.plus((-125999990L));
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
        boolean boolean12 = dateTime9.isEqualNow();
        org.joda.time.DateTime dateTime15 = dateTime9.withDurationAdded(1000L, (-1));
        org.joda.time.DateTime dateTime17 = dateTime9.plusWeeks((int) (short) 10);
        org.joda.time.DateTime dateTime19 = dateTime9.minusWeeks(30);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long5 = dateTimeZone1.convertLocalToUTC(10L, false, 0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
        org.joda.time.DateTime dateTime14 = dateTime9.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds(1969);
        int int21 = property15.compareTo((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime22 = property15.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime24 = dateTime22.plus((long) (-57600000));
        boolean boolean25 = cachedDateTimeZone6.equals((java.lang.Object) dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-125999990L) + "'", long5 == (-125999990L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        int int12 = dateTime11.getMillisOfDay();
        org.joda.time.DateTime dateTime14 = dateTime11.withWeekyear(0);
        boolean boolean15 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime17 = dateTime8.plusMillis((int) (byte) 0);
        org.joda.time.DateTime dateTime19 = dateTime17.minusMillis(126000000);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 39600052 + "'", int12 == 39600052);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        org.joda.time.DateTime dateTime8 = dateTime5.toDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        int int12 = dateTime11.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        boolean boolean15 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime14);
        int int16 = dateTime8.getDayOfYear();
        int int17 = dateTime8.getSecondOfMinute();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = dateTime8.toMutableDateTime(chronology18);
        int int22 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime19, "ISOChronology[+35:00]", (int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 39600052 + "'", int12 == 39600052);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 11 + "'", int17 == 11);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-11) + "'", int22 == (-11));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.centuryOfEra();
        try {
            long long10 = iSOChronology0.getDateTimeMillis((long) 34, 69, 1970, 11, 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        java.lang.String str13 = cachedDateTimeZone11.getNameKey((long) 57600052);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone11);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) '#', (-57600000), (int) (byte) 1, (int) (short) 0, (-39600000), 998, (org.joda.time.DateTimeZone) cachedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -39600000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+35:00" + "'", str13.equals("+35:00"));
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
        org.joda.time.DateTime dateTime12 = dateTime7.minusMonths(999);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime15 = property8.withMaximumValue();
        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
        int int17 = dateTime16.getYearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 70 + "'", int17 == 70);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = property8.roundHalfFloorCopy();
        java.lang.String str12 = property8.getAsString();
        org.joda.time.DurationField durationField13 = property8.getRangeDurationField();
        org.joda.time.DurationField durationField14 = property8.getRangeDurationField();
        int int15 = property8.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long19 = dateTimeZone15.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime20 = dateTime10.withZoneRetainFields(dateTimeZone15);
        org.joda.time.DateTime dateTime21 = dateTime7.withZoneRetainFields(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean25 = property23.equals((java.lang.Object) dateTimeFormatter24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property23.getFieldType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType26, (-100), 11, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for secondOfMinute must be in the range [11,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-125999990L) + "'", long19 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfYear();
        org.joda.time.DateTime dateTime6 = property5.withMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey((long) 57600052);
        org.joda.time.DateTime dateTime10 = dateTime1.toDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTime dateTime11 = dateTime10.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+35:00" + "'", str9.equals("+35:00"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.joda.time.Chronology chronology4 = dateTimeFormatter3.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime2.plus((-125999990L));
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField11 = iSOChronology10.hours();
        org.joda.time.DurationField durationField12 = iSOChronology10.centuries();
        org.joda.time.DateTime dateTime13 = dateTime9.withChronology((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime.Property property14 = dateTime9.millisOfDay();
        int int15 = property14.get();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 62 + "'", int15 == 62);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.withHourOfDay(4);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        java.util.Locale locale9 = null;
        int int10 = property8.getMaximumTextLength(locale9);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        java.lang.String str10 = property8.getAsText();
        org.joda.time.DateTime dateTime12 = property8.setCopy(152);
        org.joda.time.ReadableInstant readableInstant13 = null;
        try {
            int int14 = property8.getDifference(readableInstant13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -1560674013959");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
        int int9 = dateTime5.getMinuteOfHour();
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DurationField durationField2 = iSOChronology0.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField3 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("GregorianChronology[+35:00]", (-1), (-1), (int) (byte) 0, ' ', 0, (int) ' ', 52, false, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "ZonedChronology[ISOChronology[UTC], +35:00]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
        int int9 = dateTime5.getMinuteOfHour();
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
        int int15 = dateTime14.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
        org.joda.time.DateTime dateTime19 = dateTime14.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
        int int23 = dateTime22.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
        int int31 = dateTime30.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime42 = dateTime14.withZone(dateTimeZone35);
        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField44 = zonedChronology43.secondOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone49 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone50 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone49);
        java.lang.String str52 = cachedDateTimeZone50.getNameKey((long) 57600052);
        org.joda.time.Chronology chronology53 = zonedChronology43.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone50);
        long long55 = cachedDateTimeZone50.previousTransition((long) (short) 100);
        int int57 = cachedDateTimeZone50.getOffset(128L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(zonedChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(cachedDateTimeZone50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "+35:00" + "'", str52.equals("+35:00"));
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 100L + "'", long55 == 100L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) 'a');
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology11);
        int int13 = dateTime12.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.plus(readablePeriod14);
        org.joda.time.DateTime dateTime17 = dateTime12.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
        org.joda.time.DateTime dateTime20 = dateTime17.withEra(1);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField22 = iSOChronology21.hours();
        org.joda.time.DurationField durationField23 = iSOChronology21.centuries();
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime17.toMutableDateTime((org.joda.time.Chronology) iSOChronology21);
        boolean boolean25 = dateTime9.isAfter((org.joda.time.ReadableInstant) mutableDateTime24);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology27);
        org.joda.time.DateTime dateTime30 = dateTime28.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration31 = null;
        org.joda.time.DateTime dateTime32 = dateTime30.minus(readableDuration31);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology34);
        int int36 = dateTime35.getMillisOfDay();
        org.joda.time.DateTime dateTime38 = dateTime35.withWeekyear(0);
        boolean boolean39 = dateTime32.isBefore((org.joda.time.ReadableInstant) dateTime35);
        java.util.Locale locale40 = null;
        java.util.Calendar calendar41 = dateTime35.toCalendar(locale40);
        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime35);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 39600052 + "'", int13 == 39600052);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 39600052 + "'", int36 == 39600052);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(calendar41);
        org.junit.Assert.assertNotNull(chronology42);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("11:00:00.032", number1, (java.lang.Number) 1, (java.lang.Number) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long19 = dateTimeZone15.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime20 = dateTime10.withZoneRetainFields(dateTimeZone15);
        org.joda.time.DateTime dateTime21 = dateTime7.withZoneRetainFields(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfMinute();
        int int24 = dateTime22.getWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-125999990L) + "'", long19 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
        int int7 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.plus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
        org.joda.time.DateTime dateTime14 = property12.roundHalfFloorCopy();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
        org.joda.time.DateTime dateTime22 = dateTime19.toDateTime();
        org.joda.time.DateTime dateTime24 = dateTime19.minusWeeks(100);
        boolean boolean25 = property12.equals((java.lang.Object) dateTime24);
        boolean boolean26 = iSOChronology0.equals((java.lang.Object) boolean25);
        org.joda.time.DurationField durationField27 = iSOChronology0.years();
        long long30 = durationField27.subtract((long) 11, (long) (-19));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39600052 + "'", int7 == 39600052);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000011L + "'", long30 == 599616000011L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter4, dateTimeParser5);
        java.lang.StringBuffer stringBuffer7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        int int12 = dateTime11.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.DateTime dateTime16 = dateTime11.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
        org.joda.time.LocalDateTime localDateTime18 = dateTime16.toLocalDateTime();
        long long20 = gregorianChronology8.set((org.joda.time.ReadablePartial) localDateTime18, (long) 53);
        try {
            dateTimeFormatter6.printTo(stringBuffer7, (org.joda.time.ReadablePartial) localDateTime18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 39600052 + "'", int12 == 39600052);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDateTime18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-39599999L) + "'", long20 == (-39599999L));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
        java.util.Locale locale14 = null;
        java.util.Calendar calendar15 = dateTime9.toCalendar(locale14);
        org.joda.time.DateTime dateTime17 = dateTime9.withCenturyOfEra((int) (short) 10);
        org.joda.time.DateTime.Property property18 = dateTime9.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(calendar15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(128L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter0.printTo(writer2, (long) 998);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime15 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks(57600052);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone19.getShortName(1L, locale22);
        org.joda.time.DateTime dateTime24 = dateTime17.toDateTime(dateTimeZone19);
        org.joda.time.DateTime.Property property25 = dateTime24.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+35:00" + "'", str23.equals("+35:00"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        int int4 = dateTime2.getYearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime2.withWeekyear((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime9 = dateTime6.withSecondOfMinute(0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
        org.joda.time.DateTime.Property property16 = dateTime6.millisOfSecond();
        org.joda.time.Interval interval17 = property16.toInterval();
        int int18 = property16.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(interval17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 999 + "'", int18 == 999);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("ISOChronology[+35:00]", 2019, 39600052, 30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for ISOChronology[+35:00] must be in the range [39600052,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYearOfEra(70, 152);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.Interval interval10 = property8.toInterval();
        java.util.Locale locale12 = null;
        try {
            org.joda.time.DateTime dateTime13 = property8.setCopy("hi!", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(interval10);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.Chronology chronology5 = iSOChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.minuteOfHour();
        org.joda.time.DurationField durationField7 = iSOChronology0.weeks();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField12 = iSOChronology11.hours();
        org.joda.time.DurationField durationField13 = iSOChronology11.centuries();
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime7.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology11.dayOfYear();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology11.dayOfYear();
        org.joda.time.DurationField durationField17 = iSOChronology11.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime15 = dateTime6.plusYears(53);
        org.joda.time.DateTime.Property property16 = dateTime15.secondOfDay();
        int int17 = property16.getLeapAmount();
        java.lang.String str18 = property16.getAsShortText();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "37631" + "'", str18.equals("37631"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("GregorianChronology[+35:00]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"GregorianChronology[+35:00]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology2);
        int int4 = dateTime3.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime3.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        int int12 = dateTime11.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long20 = dateTimeZone16.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime21 = dateTime11.withZoneRetainFields(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = dateTime8.withZoneRetainFields(dateTimeZone16);
        java.util.Locale locale24 = null;
        java.lang.String str25 = dateTimeZone16.getShortName((long) 998, locale24);
        long long28 = dateTimeZone16.convertLocalToUTC((long) 627, true);
        try {
            org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((java.lang.Object) false, dateTimeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 39600052 + "'", int4 == 39600052);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 39600052 + "'", int12 == 39600052);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-125999990L) + "'", long20 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+35:00" + "'", str25.equals("+35:00"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-125999373L) + "'", long28 == (-125999373L));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        boolean boolean4 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay3);
        boolean boolean5 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay3);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology7);
        int int9 = dateTime8.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime8.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfSecond();
        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
        boolean boolean16 = cachedDateTimeZone5.isLocalDateTimeGap(localDateTime15);
        long long18 = cachedDateTimeZone5.previousTransition((long) 57600052);
        int int20 = cachedDateTimeZone5.getOffset((long) (short) 100);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 39600052 + "'", int9 == 39600052);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 57600052L + "'", long18 == 57600052L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "52");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "GregorianChronology[+35:00]", "GregorianChronology[+35:00]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfYear();
        try {
            org.joda.time.DateTime dateTime7 = property5.setCopy(660);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 660 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(1970);
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter0.printTo(writer3, (-79200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
        boolean boolean14 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime13);
        int int15 = dateTime7.getDayOfYear();
        int int16 = dateTime7.getSecondOfMinute();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime7.toMutableDateTime(chronology17);
        org.joda.time.DateTime dateTime20 = dateTime7.withWeekyear(0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 152);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMillisOfDay(53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendYearOfCentury(30, 5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 365);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.Chronology chronology5 = iSOChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str7 = cachedDateTimeZone5.getNameKey((long) 57600052);
        long long9 = cachedDateTimeZone5.previousTransition(0L);
        boolean boolean10 = cachedDateTimeZone5.isFixed();
        long long12 = cachedDateTimeZone5.convertUTCToLocal((long) (-100));
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:00" + "'", str7.equals("+35:00"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-101L) + "'", long12 == (-101L));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
        org.joda.time.DateTime.Property property16 = dateTime6.millisOfSecond();
        int int17 = property16.getMaximumValueOverall();
        org.joda.time.DateTime dateTime19 = property16.addToCopy(8);
        org.joda.time.ReadableInstant readableInstant20 = null;
        boolean boolean21 = dateTime19.isAfter(readableInstant20);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 999 + "'", int17 == 999);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) property11);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology15);
        int int17 = dateTime16.getMillisOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withWeekyear(0);
        long long20 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime19);
        boolean boolean21 = gregorianChronology0.equals((java.lang.Object) long20);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 39600052 + "'", int17 == 39600052);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62166787199948L) + "'", long20 == (-62166787199948L));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
        org.joda.time.DateTime dateTime14 = dateTime9.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds(1969);
        int int21 = property15.compareTo((org.joda.time.ReadableInstant) dateTime20);
        boolean boolean22 = fixedDateTimeZone4.equals((java.lang.Object) dateTime20);
        java.util.Locale locale24 = null;
        java.lang.String str25 = fixedDateTimeZone4.getName(0L, locale24);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-00:00:00.001" + "'", str25.equals("-00:00:00.001"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.LocalDateTime localDateTime9 = dateTime7.toLocalDateTime();
        org.joda.time.DateTime.Property property10 = dateTime7.weekyear();
        org.joda.time.DateTime dateTime12 = dateTime7.withMillisOfSecond(4);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(52L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime6 = dateTime5.withEarlierOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
        org.joda.time.DateTime dateTime14 = dateTime9.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
        int int18 = dateTime17.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.plus(readablePeriod19);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long26 = dateTimeZone22.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime27 = dateTime17.withZoneRetainFields(dateTimeZone22);
        org.joda.time.DateTime dateTime28 = dateTime14.withZoneRetainFields(dateTimeZone22);
        java.lang.String str29 = dateTimeZone22.toString();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) dateTime5, dateTimeZone22);
        boolean boolean32 = dateTimeZone22.isStandardOffset((long) 126000000);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology34);
        int int36 = dateTime35.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.DateTime dateTime38 = dateTime35.plus(readablePeriod37);
        org.joda.time.DateTime dateTime40 = dateTime35.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology42);
        int int44 = dateTime43.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.DateTime dateTime46 = dateTime43.plus(readablePeriod45);
        org.joda.time.DateTime dateTime48 = dateTime43.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology50);
        int int52 = dateTime51.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        org.joda.time.DateTime dateTime54 = dateTime51.plus(readablePeriod53);
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long60 = dateTimeZone56.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime61 = dateTime51.withZoneRetainFields(dateTimeZone56);
        org.joda.time.DateTime dateTime62 = dateTime48.withZoneRetainFields(dateTimeZone56);
        org.joda.time.DateTime dateTime63 = dateTime35.withZone(dateTimeZone56);
        org.joda.time.chrono.ISOChronology iSOChronology65 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology65);
        int int67 = dateTime66.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod68 = null;
        org.joda.time.DateTime dateTime69 = dateTime66.plus(readablePeriod68);
        org.joda.time.LocalDateTime localDateTime70 = dateTime66.toLocalDateTime();
        org.joda.time.DateTime dateTime71 = dateTime63.withFields((org.joda.time.ReadablePartial) localDateTime70);
        boolean boolean72 = dateTimeZone22.isLocalDateTimeGap(localDateTime70);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 39600052 + "'", int18 == 39600052);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-125999990L) + "'", long26 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+35:00" + "'", str29.equals("+35:00"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 39600052 + "'", int36 == 39600052);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 39600052 + "'", int44 == 39600052);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 39600052 + "'", int52 == 39600052);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-125999990L) + "'", long60 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(iSOChronology65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 39600052 + "'", int67 == 39600052);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(localDateTime70);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("11:00:00.032", number1, (java.lang.Number) 1, (java.lang.Number) 1);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "11:00:00.032" + "'", str5.equals("11:00:00.032"));
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(dateTimeFieldType7);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter0.parseLocalDate("GregorianChronology[+35:00]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[+35:00]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("ISOChronology[+35:00]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[+35:00]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = property8.addToCopy((long) 52);
        int int17 = dateTime16.getYearOfCentury();
        int int18 = dateTime16.getCenturyOfEra();
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime16.toYearMonthDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 70 + "'", int17 == 70);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19 + "'", int18 == 19);
        org.junit.Assert.assertNotNull(yearMonthDay19);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long19 = dateTimeZone15.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime20 = dateTime10.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime21 = dateTime7.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone15);
//        int int23 = dateTime22.getHourOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.plusMillis(52);
//        org.joda.time.LocalTime localTime26 = dateTime25.toLocalTime();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-125999990L) + "'", long19 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localTime26);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime12.toYearMonthDay();
        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime12);
        java.util.Locale locale16 = null;
        try {
            org.joda.time.DateTime dateTime17 = property8.setCopy("11:00:00.032", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"11:00:00.032\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "+35:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
        int int9 = dateTime5.getMinuteOfHour();
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        try {
            int[] intArray14 = iSOChronology0.get(readablePeriod12, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(100L, 15200L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1520000 + "'", int2 == 1520000);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMillisOfDay(53);
        dateTimeFormatterBuilder8.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime4.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime15 = property8.withMaximumValue();
        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime18 = dateTime15.plusWeeks(19);
        org.joda.time.DateTime dateTime20 = dateTime15.plusWeeks(627);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
        int int9 = dateTime5.getMinuteOfHour();
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.minus(readableDuration16);
        org.joda.time.DateTime dateTime18 = dateTime15.toDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology20);
        int int22 = dateTime21.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime21.plus(readablePeriod23);
        boolean boolean25 = dateTime18.isEqual((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.Chronology chronology26 = dateTime24.getChronology();
        int int27 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 39600052 + "'", int22 == 39600052);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) iSOChronology9);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(126000000, 30, 3, 3, 152, 0, 1970, (org.joda.time.Chronology) iSOChronology9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 152 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology9);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"1\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology3);
        int int5 = dateTime4.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long13 = dateTimeZone9.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime14 = dateTime4.withZoneRetainFields(dateTimeZone9);
        java.lang.String str15 = dateTimeZone9.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 39600052 + "'", int5 == 39600052);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-125999990L) + "'", long13 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:00" + "'", str15.equals("+35:00"));
        org.junit.Assert.assertNotNull(zonedChronology16);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long19 = dateTimeZone15.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime20 = dateTime10.withZoneRetainFields(dateTimeZone15);
        org.joda.time.DateTime dateTime21 = dateTime7.withZoneRetainFields(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime25 = dateTime22.withMinuteOfHour((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-125999990L) + "'", long19 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.eras();
        java.lang.String str4 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[+35:00]" + "'", str4.equals("GregorianChronology[+35:00]"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
        int int11 = dateTime10.getMillisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime10.withMillisOfSecond(10);
        int int14 = dateTime10.getHourOfDay();
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) '4', 10, 0, 660, (int) (short) 1, chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 660 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.lang.Appendable appendable2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime dateTime12 = dateTime5.plus((-125999990L));
        org.joda.time.DateTime dateTime14 = dateTime5.minusHours(100);
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadableInstant) dateTime14);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(999, 152, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(30);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
        int int14 = dateTime13.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long22 = dateTimeZone18.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime23 = dateTime13.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTime dateTime24 = dateTime10.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime.Property property26 = dateTime25.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean28 = property26.equals((java.lang.Object) dateTimeFormatter27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property26.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType29, 0, 57600052);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType29, 69, (int) (short) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for secondOfMinute must be in the range [10,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39600052 + "'", int14 == 39600052);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-125999990L) + "'", long22 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime6 = dateTime5.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime5.minus((long) (byte) 1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        dateTimeFormatterBuilder1.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime4.minusWeeks(100);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.DateTime.Property property11 = dateTime9.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("11:00:00.032", false);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("52", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long9 = fixedDateTimeZone7.previousTransition(0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
        boolean boolean13 = fixedDateTimeZone7.equals((java.lang.Object) dateTimeZone12);
        long long16 = dateTimeZone12.adjustOffset(0L, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZone(dateTimeZone12);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone23 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology25);
        int int27 = dateTime26.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.plus(readablePeriod28);
        org.joda.time.DateTime dateTime31 = dateTime26.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property32 = dateTime31.millisOfSecond();
        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
        boolean boolean34 = cachedDateTimeZone23.isLocalDateTimeGap(localDateTime33);
        long long36 = cachedDateTimeZone23.previousTransition((long) 57600052);
        long long38 = dateTimeZone12.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone23, 52L);
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(cachedDateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 39600052 + "'", int27 == 39600052);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 57600052L + "'", long36 == 57600052L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 126000053L + "'", long38 == 126000053L);
        org.junit.Assert.assertNotNull(iSOChronology39);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("11:00:00.032");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"11:00:00.032/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField12 = iSOChronology11.hours();
        org.joda.time.DurationField durationField13 = iSOChronology11.centuries();
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime7.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology11.dayOfYear();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology11.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, dateTimeFieldType17, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendDayOfYear(660);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 10, 70);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 700L + "'", long2 == 700L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
        int int11 = dateTime10.getMillisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime10.withMillisOfSecond(10);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(5);
        org.joda.time.DateTime dateTime17 = dateTime15.plusMinutes(0);
        org.joda.time.DateTime dateTime18 = dateTime15.toDateTime();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 100);
        try {
            org.joda.time.LocalDate localDate6 = dateTimeFormatter0.parseLocalDate("52");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"52\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) 'a');
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology11);
        int int13 = dateTime12.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.plus(readablePeriod14);
        org.joda.time.DateTime dateTime17 = dateTime12.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
        org.joda.time.DateTime dateTime20 = dateTime17.withEra(1);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField22 = iSOChronology21.hours();
        org.joda.time.DurationField durationField23 = iSOChronology21.centuries();
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime17.toMutableDateTime((org.joda.time.Chronology) iSOChronology21);
        boolean boolean25 = dateTime9.isAfter((org.joda.time.ReadableInstant) mutableDateTime24);
        org.joda.time.DateTime dateTime27 = dateTime9.withMillisOfSecond(2);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
        int int31 = dateTime30.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
        org.joda.time.DateTime dateTime35 = dateTime30.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime dateTime37 = dateTime30.plus((-125999990L));
        boolean boolean38 = dateTime9.isBefore((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime dateTime40 = dateTime9.minusWeeks(3);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 39600052 + "'", int13 == 39600052);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTime40);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean6 = cachedDateTimeZone5.isFixed();
        java.lang.String str8 = cachedDateTimeZone5.getNameKey((long) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone9 = cachedDateTimeZone5.getUncachedZone();
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+35:00" + "'", str8.equals("+35:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTime dateTime20 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology17);
        try {
            org.joda.time.DateTime dateTime22 = dateTime20.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long11 = dateTimeZone7.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime12 = dateTime2.withZoneRetainFields(dateTimeZone7);
        org.joda.time.DateTime dateTime14 = dateTime12.plusYears((int) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
        int int18 = dateTime17.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.plus(readablePeriod19);
        org.joda.time.DateTime dateTime22 = dateTime17.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property23 = dateTime22.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        int int25 = dateTime14.get(dateTimeField24);
        org.joda.time.DateTime dateTime27 = dateTime14.withMillis(15200L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-125999990L) + "'", long11 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 39600052 + "'", int18 == 39600052);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = property8.addToCopy((long) 52);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField19 = iSOChronology18.hours();
        org.joda.time.DurationField durationField20 = iSOChronology18.centuries();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.Chronology chronology23 = iSOChronology18.withZone(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) 1, dateTimeZone22);
        int int25 = property8.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime26 = property8.withMinimumValue();
        java.lang.String str27 = property8.getAsString();
        java.lang.String str28 = property8.getAsString();
        org.joda.time.Interval interval29 = property8.toInterval();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-39600000) + "'", int25 == (-39600000));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1" + "'", str27.equals("1"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1" + "'", str28.equals("1"));
        org.junit.Assert.assertNotNull(interval29);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(int3);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("����-��-��T00:00");
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
        int int11 = dateTime10.getMillisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime10.withMillisOfSecond(10);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(5);
        try {
            java.lang.String str17 = dateTime13.toString("1970-01-02T��:��");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        int int4 = dateTime2.getYearOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology6);
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
        org.joda.time.DateTime dateTime12 = dateTime7.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property13 = dateTime12.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds(1969);
        int int19 = property13.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
        int int23 = dateTime22.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
        int int31 = dateTime30.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now(dateTimeZone35);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfMinute();
        boolean boolean44 = property13.equals((java.lang.Object) dateTime42);
        org.joda.time.DateTime dateTime46 = dateTime42.withYear(126000000);
        org.joda.time.DateTime.Property property47 = dateTime46.weekyear();
        boolean boolean48 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime46);
        try {
            org.joda.time.DateTime dateTime50 = dateTime2.withYearOfCentury((-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 39600052 + "'", int8 == 39600052);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusSeconds((-57600000));
        org.joda.time.DateTime dateTime11 = dateTime7.minusMinutes(0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.monthOfYear();
        try {
            long long15 = gregorianChronology6.getDateTimeMillis(70, 1520000, 1520000, 11, 5, 2019, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
        boolean boolean14 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime13);
        int int15 = dateTime7.getDayOfYear();
        int int16 = dateTime7.getSecondOfMinute();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime7.toMutableDateTime(chronology17);
        org.joda.time.DateTime dateTime20 = dateTime7.withMillis((long) 19);
        int int21 = dateTime7.getDayOfYear();
        org.joda.time.DateTime dateTime23 = dateTime7.plusSeconds((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology25);
        int int27 = dateTime26.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.plus(readablePeriod28);
        org.joda.time.DateTimeZone dateTimeZone30 = dateTime26.getZone();
        org.joda.time.DateTime dateTime31 = dateTime7.withZone(dateTimeZone30);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 39600052 + "'", int27 == 39600052);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter4, dateTimeParser5);
        org.joda.time.ReadWritableInstant readWritableInstant7 = null;
        try {
            int int10 = dateTimeFormatter6.parseInto(readWritableInstant7, "37631", (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.months();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime15 = dateTime9.withCenturyOfEra((int) (byte) 0);
        org.joda.time.DateTime.Property property16 = dateTime9.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 152);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = property8.roundHalfFloorCopy();
        java.util.Locale locale13 = null;
        try {
            org.joda.time.DateTime dateTime14 = property8.setCopy("T08:33:40+35:00", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"T08:33:40+35:00\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("millisOfSecond");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"millisOfSecond\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 100, 126000000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 126000100 + "'", int2 == 126000100);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.minus(readableDuration16);
        org.joda.time.DateTime dateTime18 = dateTime15.toDateTime();
        org.joda.time.DateTime dateTime20 = dateTime15.minusWeeks(100);
        boolean boolean21 = property8.equals((java.lang.Object) dateTime20);
        org.joda.time.DateTime dateTime22 = dateTime20.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology7);
        int int9 = dateTime8.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime8.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime dateTime15 = dateTime8.plus((-125999990L));
        boolean boolean16 = cachedDateTimeZone5.equals((java.lang.Object) dateTime15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = cachedDateTimeZone5.getShortName((long) (short) -1, locale18);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 39600052 + "'", int9 == 39600052);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "52");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "+35:00", "era");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
        int int9 = dateTime5.getMinuteOfHour();
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
        int int15 = dateTime14.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
        org.joda.time.DateTime dateTime19 = dateTime14.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
        int int23 = dateTime22.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
        int int31 = dateTime30.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime42 = dateTime14.withZone(dateTimeZone35);
        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone35);
        try {
            long long49 = zonedChronology43.getDateTimeMillis((long) 53, 3, 152, 126000100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 152 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(zonedChronology43);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
        org.joda.time.DateTime dateTime15 = dateTime10.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.plus(readablePeriod20);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long27 = dateTimeZone23.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime28 = dateTime18.withZoneRetainFields(dateTimeZone23);
        org.joda.time.DateTime dateTime29 = dateTime15.withZoneRetainFields(dateTimeZone23);
        org.joda.time.DateTime dateTime30 = dateTime2.withZone(dateTimeZone23);
        org.joda.time.DateTime.Property property31 = dateTime30.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime34 = dateTime30.withPeriodAdded(readablePeriod32, (int) (short) 100);
        org.joda.time.DateTime.Property property35 = dateTime34.centuryOfEra();
        int int36 = dateTime34.getMillisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 39600052 + "'", int19 == 39600052);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-125999990L) + "'", long27 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 39600052 + "'", int36 == 39600052);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = property8.addToCopy((long) 52);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField19 = iSOChronology18.hours();
        org.joda.time.DurationField durationField20 = iSOChronology18.centuries();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.Chronology chronology23 = iSOChronology18.withZone(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) 1, dateTimeZone22);
        int int25 = property8.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime26 = property8.withMinimumValue();
        try {
            org.joda.time.DateTime dateTime28 = dateTime26.withDayOfWeek(39600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 39600 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-39600000) + "'", int25 == (-39600000));
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(3, 3, (-39600052));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField12 = iSOChronology11.hours();
        org.joda.time.DurationField durationField13 = iSOChronology11.centuries();
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime7.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology11.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
        int int9 = dateTime5.getMinuteOfHour();
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
        int int7 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.plus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
        org.joda.time.DateTime dateTime14 = property12.roundHalfFloorCopy();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
        org.joda.time.DateTime dateTime22 = dateTime19.toDateTime();
        org.joda.time.DateTime dateTime24 = dateTime19.minusWeeks(100);
        boolean boolean25 = property12.equals((java.lang.Object) dateTime24);
        boolean boolean26 = iSOChronology0.equals((java.lang.Object) boolean25);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39600052 + "'", int7 == 39600052);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology2);
        int int4 = dateTime3.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime3.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        int int12 = dateTime11.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long20 = dateTimeZone16.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime21 = dateTime11.withZoneRetainFields(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = dateTime8.withZoneRetainFields(dateTimeZone16);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone16);
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean26 = property24.equals((java.lang.Object) dateTimeFormatter25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 39600052 + "'", int4 == 39600052);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 39600052 + "'", int12 == 39600052);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-125999990L) + "'", long20 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, 1969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("11:00:00.032", false);
        long long7 = dateTimeZone3.convertLocalToUTC((long) 365, true, 0L);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 365L + "'", long7 == 365L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        int int4 = dateTime2.getYearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime2.withWeekyear((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DurationField durationField8 = property7.getDurationField();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        java.lang.StringBuffer stringBuffer2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (-62166787199948L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTime dateTime9 = property8.roundCeilingCopy();
        org.joda.time.Interval interval10 = property8.toInterval();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(interval10);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        int int4 = dateTime2.getYearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime2.withWeekyear((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime9 = dateTime6.plusYears(57600052);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(30);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
        int int16 = dateTime15.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
        int int24 = dateTime23.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder10.appendFraction(dateTimeFieldType39, 0, 57600052);
        org.joda.time.DateTime.Property property43 = dateTime9.property(dateTimeFieldType39);
        int int44 = property43.getLeapAmount();
        java.lang.String str45 = property43.getAsText();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "0" + "'", str45.equals("0"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long19 = dateTimeZone15.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime20 = dateTime10.withZoneRetainFields(dateTimeZone15);
        org.joda.time.DateTime dateTime21 = dateTime7.withZoneRetainFields(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfMinute();
        org.joda.time.DateTime dateTime25 = property23.addWrapFieldToCopy((int) (short) 10);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-125999990L) + "'", long19 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis(4, (int) (short) 1, (int) (short) -1, 39600052);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
        int int16 = dateTime15.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
        int int24 = dateTime23.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology47);
        int int49 = dateTime48.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.DateTime dateTime51 = dateTime48.plus(readablePeriod50);
        org.joda.time.DateTime dateTime53 = dateTime48.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property54 = dateTime53.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology56);
        org.joda.time.DateTime dateTime59 = dateTime57.minusSeconds(1969);
        int int60 = property54.compareTo((org.joda.time.ReadableInstant) dateTime59);
        org.joda.time.DateTime dateTime61 = property54.withMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology63);
        org.joda.time.DateTime dateTime65 = dateTime61.withChronology((org.joda.time.Chronology) iSOChronology63);
        org.joda.time.LocalDate localDate66 = dateTime61.toLocalDate();
        java.util.Locale locale67 = null;
        try {
            java.lang.String str68 = remainderDateTimeField44.getAsText((org.joda.time.ReadablePartial) localDate66, locale67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfMinute' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNull(durationField45);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 39600052 + "'", int49 == 39600052);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(iSOChronology56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(iSOChronology63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(localDate66);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long11 = dateTimeZone7.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime12 = dateTime2.withZoneRetainFields(dateTimeZone7);
        org.joda.time.DateTime dateTime14 = dateTime12.plusYears((int) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
        int int18 = dateTime17.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.plus(readablePeriod19);
        org.joda.time.DateTime dateTime22 = dateTime17.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property23 = dateTime22.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        int int25 = dateTime14.get(dateTimeField24);
        org.joda.time.DateTime dateTime26 = dateTime14.toDateTime();
        int int27 = dateTime14.getEra();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-125999990L) + "'", long11 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 39600052 + "'", int18 == 39600052);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
        int int11 = dateTime10.getMillisOfSecond();
        org.joda.time.DateTime dateTime13 = dateTime10.withMillisOfSecond(10);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(5);
        boolean boolean16 = dateTime13.isAfterNow();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        long long8 = fixedDateTimeZone4.nextTransition(10L);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
        org.joda.time.LocalTime localTime16 = dateTime6.toLocalTime();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime6.getZone();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localTime16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withWeekOfWeekyear(70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfYear();
        java.util.Locale locale6 = null;
        int int7 = property5.getMaximumTextLength(locale6);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser3);
        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser5);
        java.io.Writer writer7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField9 = iSOChronology8.hours();
        org.joda.time.DurationField durationField10 = iSOChronology8.years();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitWeekyear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendYearOfEra(70, 152);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(100);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
        int int24 = dateTime23.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
        org.joda.time.DateTime dateTime28 = dateTime23.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology30);
        int int32 = dateTime31.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.DateTime dateTime34 = dateTime31.plus(readablePeriod33);
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long40 = dateTimeZone36.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime41 = dateTime31.withZoneRetainFields(dateTimeZone36);
        org.joda.time.DateTime dateTime42 = dateTime28.withZoneRetainFields(dateTimeZone36);
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone36);
        org.joda.time.DateTime.Property property44 = dateTime43.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean46 = property44.equals((java.lang.Object) dateTimeFormatter45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property44.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder15.appendSignedDecimal(dateTimeFieldType47, (int) (byte) 1, (int) '4');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType47, 998);
        org.joda.time.DurationField durationField53 = remainderDateTimeField52.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology55);
        int int57 = dateTime56.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod58 = null;
        org.joda.time.DateTime dateTime59 = dateTime56.plus(readablePeriod58);
        org.joda.time.DateTime dateTime61 = dateTime56.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property62 = dateTime61.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology64);
        org.joda.time.DateTime dateTime67 = dateTime65.minusSeconds(1969);
        int int68 = property62.compareTo((org.joda.time.ReadableInstant) dateTime67);
        org.joda.time.DateTime dateTime69 = property62.withMaximumValue();
        org.joda.time.LocalTime localTime70 = dateTime69.toLocalTime();
        java.util.Locale locale72 = null;
        java.lang.String str73 = remainderDateTimeField52.getAsText((org.joda.time.ReadablePartial) localTime70, 3, locale72);
        try {
            dateTimeFormatter6.printTo(writer7, (org.joda.time.ReadablePartial) localTime70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 39600052 + "'", int32 == 39600052);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-125999990L) + "'", long40 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNull(durationField53);
        org.junit.Assert.assertNotNull(iSOChronology55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 39600052 + "'", int57 == 39600052);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(iSOChronology64);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(localTime70);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "3" + "'", str73.equals("3"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(30);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
        int int14 = dateTime13.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long22 = dateTimeZone18.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime23 = dateTime13.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTime dateTime24 = dateTime10.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime.Property property26 = dateTime25.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean28 = property26.equals((java.lang.Object) dateTimeFormatter27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property26.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType29, 0, 57600052);
        dateTimeFormatterBuilder0.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39600052 + "'", int14 == 39600052);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-125999990L) + "'", long22 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMillisOfSecond(30);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
        int int7 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.plus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
        int int15 = dateTime14.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long23 = dateTimeZone19.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime24 = dateTime14.withZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTime dateTime25 = dateTime11.withZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.DateTime.Property property27 = dateTime26.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean29 = property27.equals((java.lang.Object) dateTimeFormatter28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder1.appendFraction(dateTimeFieldType30, 0, 57600052);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType30, 69, 3, 627);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39600052 + "'", int7 == 39600052);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-125999990L) + "'", long23 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMillisOfDay(53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder8.appendTimeZoneOffset("ZonedChronology[ISOChronology[UTC], +35:00]", "52", false, 152, 1520000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        int int4 = dateTime2.getYearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime2.withWeekyear((int) 'a');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField8 = iSOChronology7.hours();
        org.joda.time.DurationField durationField9 = iSOChronology7.years();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendYearOfEra(70, 152);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(100);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
        int int23 = dateTime22.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
        int int31 = dateTime30.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now(dateTimeZone35);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean45 = property43.equals((java.lang.Object) dateTimeFormatter44);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property43.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendSignedDecimal(dateTimeFieldType46, (int) (byte) 1, (int) '4');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField51 = new org.joda.time.field.RemainderDateTimeField(dateTimeField10, dateTimeFieldType46, 998);
        boolean boolean52 = dateTime2.isSupported(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(30);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
        int int14 = dateTime13.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long22 = dateTimeZone18.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime23 = dateTime13.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTime dateTime24 = dateTime10.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime.Property property26 = dateTime25.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean28 = property26.equals((java.lang.Object) dateTimeFormatter27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property26.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType29, 0, 57600052);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendYearOfEra(627, 2);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder35.appendTimeZoneOffset("(\"org.joda.time.JodaTimePermission\" \"1\")", false, (int) (short) -1, 152);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39600052 + "'", int14 == 39600052);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-125999990L) + "'", long22 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(365, 3, 1, 1969, (-39600000), (-11), 0, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = property8.addToCopy((long) 52);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField19 = iSOChronology18.hours();
        org.joda.time.DurationField durationField20 = iSOChronology18.centuries();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.Chronology chronology23 = iSOChronology18.withZone(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) 1, dateTimeZone22);
        int int25 = property8.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime26 = property8.withMinimumValue();
        org.joda.time.DateTime dateTime27 = property8.roundCeilingCopy();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-39600000) + "'", int25 == (-39600000));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
        org.joda.time.DateTime dateTime15 = dateTime10.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.plus(readablePeriod20);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long27 = dateTimeZone23.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime28 = dateTime18.withZoneRetainFields(dateTimeZone23);
        org.joda.time.DateTime dateTime29 = dateTime15.withZoneRetainFields(dateTimeZone23);
        org.joda.time.DateTime dateTime30 = dateTime2.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime32 = dateTime30.minusMonths(2019);
        org.joda.time.DateTime.Property property33 = dateTime32.millisOfDay();
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime32);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 39600052 + "'", int19 == 39600052);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-125999990L) + "'", long27 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(chronology34);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(30);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
        int int14 = dateTime13.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long22 = dateTimeZone18.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime23 = dateTime13.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTime dateTime24 = dateTime10.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime.Property property26 = dateTime25.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean28 = property26.equals((java.lang.Object) dateTimeFormatter27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property26.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType29, 0, 57600052);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendFractionOfMinute(62, 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39600052 + "'", int14 == 39600052);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-125999990L) + "'", long22 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) 'a');
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTimeISO();
        org.joda.time.DateTime dateTime12 = dateTime9.withYearOfCentury(19);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
        int int16 = dateTime15.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
        int int24 = dateTime23.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
        org.joda.time.DurationField durationField47 = iSOChronology45.years();
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
        int int51 = dateTime50.getMillisOfDay();
        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
        int int54 = dateTime50.getMinuteOfHour();
        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
        try {
            long long59 = unsupportedDateTimeField57.roundFloor(128L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
        int int9 = dateTime5.getMinuteOfHour();
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
        int int15 = dateTime14.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
        org.joda.time.DateTime dateTime19 = dateTime14.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
        int int23 = dateTime22.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
        int int31 = dateTime30.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime42 = dateTime14.withZone(dateTimeZone35);
        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField44 = zonedChronology43.secondOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone49 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone50 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone49);
        java.lang.String str52 = cachedDateTimeZone50.getNameKey((long) 57600052);
        org.joda.time.Chronology chronology53 = zonedChronology43.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone50);
        int int55 = cachedDateTimeZone50.getOffset(1L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(zonedChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(cachedDateTimeZone50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "+35:00" + "'", str52.equals("+35:00"));
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology2);
        int int4 = dateTime3.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime3.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        int int12 = dateTime11.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long20 = dateTimeZone16.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime21 = dateTime11.withZoneRetainFields(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = dateTime8.withZoneRetainFields(dateTimeZone16);
        java.lang.String str23 = dateTimeZone16.toString();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 30, dateTimeZone16);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 39600052 + "'", int4 == 39600052);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 39600052 + "'", int12 == 39600052);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-125999990L) + "'", long20 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+35:00" + "'", str23.equals("+35:00"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
        int int7 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.plus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds(1969);
        int int18 = property12.compareTo((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime19 = property12.withMaximumValue();
        org.joda.time.LocalTime localTime20 = dateTime19.toLocalTime();
        org.joda.time.TimeOfDay timeOfDay21 = dateTime19.toTimeOfDay();
        int[] intArray23 = iSOChronology0.get((org.joda.time.ReadablePartial) timeOfDay21, (-1L));
        org.joda.time.DurationField durationField24 = iSOChronology0.centuries();
        try {
            long long29 = iSOChronology0.getDateTimeMillis(0, (-100), 39600052, 627);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39600052 + "'", int7 == 39600052);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localTime20);
        org.junit.Assert.assertNotNull(timeOfDay21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
        int int9 = dateTime5.getMinuteOfHour();
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
        int int15 = dateTime14.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
        org.joda.time.DateTime dateTime19 = dateTime14.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
        int int23 = dateTime22.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
        int int31 = dateTime30.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
        org.joda.time.DateTime dateTime42 = dateTime14.withZone(dateTimeZone35);
        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField44 = zonedChronology43.secondOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone49 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone50 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone49);
        java.lang.String str52 = cachedDateTimeZone50.getNameKey((long) 57600052);
        org.joda.time.Chronology chronology53 = zonedChronology43.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone50);
        int int55 = cachedDateTimeZone50.getStandardOffset(599616000011L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(zonedChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(cachedDateTimeZone50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "+35:00" + "'", str52.equals("+35:00"));
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 100 + "'", int55 == 100);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
        int int15 = dateTime13.getDayOfMonth();
        int int16 = dateTime13.getDayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long19 = dateTimeZone15.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime20 = dateTime10.withZoneRetainFields(dateTimeZone15);
        org.joda.time.DateTime dateTime21 = dateTime7.withZoneRetainFields(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean25 = property23.equals((java.lang.Object) dateTimeFormatter24);
        org.joda.time.DateTime dateTime26 = property23.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-125999990L) + "'", long19 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMillisOfDay(53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfDay(1970, (int) (short) 10);
        boolean boolean12 = dateTimeFormatterBuilder11.canBuildFormatter();
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatterBuilder11.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendMillisOfSecond(34);
        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatterBuilder11.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimePrinter16);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology7);
        int int9 = dateTime8.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime8.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfSecond();
        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
        boolean boolean16 = cachedDateTimeZone5.isLocalDateTimeGap(localDateTime15);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology18);
        int int20 = dateTime19.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.plus(readablePeriod21);
        org.joda.time.DateTime dateTime24 = dateTime19.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property25 = dateTime24.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField26 = property25.getField();
        org.joda.time.DateTime dateTime27 = property25.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime28 = dateTime27.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField30 = iSOChronology29.hours();
        org.joda.time.DurationField durationField31 = iSOChronology29.years();
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology33);
        int int35 = dateTime34.getMillisOfDay();
        org.joda.time.DateTime dateTime37 = dateTime34.withWeekyear(0);
        int int38 = dateTime34.getMinuteOfHour();
        boolean boolean39 = iSOChronology29.equals((java.lang.Object) dateTime34);
        org.joda.time.DurationField durationField40 = iSOChronology29.seconds();
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology42);
        int int44 = dateTime43.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.DateTime dateTime46 = dateTime43.plus(readablePeriod45);
        org.joda.time.DateTime dateTime48 = dateTime43.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology50);
        int int52 = dateTime51.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        org.joda.time.DateTime dateTime54 = dateTime51.plus(readablePeriod53);
        org.joda.time.DateTime dateTime56 = dateTime51.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology58);
        int int60 = dateTime59.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod61 = null;
        org.joda.time.DateTime dateTime62 = dateTime59.plus(readablePeriod61);
        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long68 = dateTimeZone64.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime69 = dateTime59.withZoneRetainFields(dateTimeZone64);
        org.joda.time.DateTime dateTime70 = dateTime56.withZoneRetainFields(dateTimeZone64);
        org.joda.time.DateTime dateTime71 = dateTime43.withZone(dateTimeZone64);
        org.joda.time.chrono.ZonedChronology zonedChronology72 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology29, dateTimeZone64);
        org.joda.time.MutableDateTime mutableDateTime73 = dateTime27.toMutableDateTime(dateTimeZone64);
        long long75 = cachedDateTimeZone5.getMillisKeepLocal(dateTimeZone64, (long) (byte) 100);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 39600052 + "'", int9 == 39600052);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 39600052 + "'", int20 == 39600052);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 39600052 + "'", int35 == 39600052);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 39600052 + "'", int44 == 39600052);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 39600052 + "'", int52 == 39600052);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 39600052 + "'", int60 == 39600052);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-125999990L) + "'", long68 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(zonedChronology72);
        org.junit.Assert.assertNotNull(mutableDateTime73);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-125999901L) + "'", long75 == (-125999901L));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
        org.joda.time.DateTime dateTime15 = dateTime10.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.plus(readablePeriod20);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long27 = dateTimeZone23.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime28 = dateTime18.withZoneRetainFields(dateTimeZone23);
        org.joda.time.DateTime dateTime29 = dateTime15.withZoneRetainFields(dateTimeZone23);
        org.joda.time.DateTime dateTime30 = dateTime2.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime32 = dateTime30.minusMonths(2019);
        org.joda.time.DateTime.Property property33 = dateTime32.millisOfDay();
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.DateTime dateTime35 = dateTime32.minus(readableDuration34);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 39600052 + "'", int19 == 39600052);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-125999990L) + "'", long27 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("+35:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+35:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
        int int16 = dateTime15.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime dateTime22 = dateTime15.plus((-125999990L));
        boolean boolean23 = cachedDateTimeZone12.equals((java.lang.Object) dateTime22);
        try {
            org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(70, 19, (-11), (int) (short) -1, (int) 'a', 152, 5, (org.joda.time.DateTimeZone) cachedDateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((-19), (-39600052));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
        int int16 = dateTime15.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
        int int24 = dateTime23.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
        org.joda.time.DurationField durationField47 = iSOChronology45.years();
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
        int int51 = dateTime50.getMillisOfDay();
        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
        int int54 = dateTime50.getMinuteOfHour();
        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
        try {
            int int59 = unsupportedDateTimeField57.getMaximumValue(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        boolean boolean4 = dateTimeFormatterBuilder1.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfSecond(10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfSecond((int) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime2.plus((-125999990L));
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
        boolean boolean12 = dateTime9.isEqualNow();
        org.joda.time.DateTime dateTime15 = dateTime9.withDurationAdded(1000L, (-1));
        int int16 = dateTime15.getMinuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1439 + "'", int16 == 1439);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
        int int7 = dateTime6.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.plus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
        org.joda.time.DateTime dateTime14 = property12.roundHalfFloorCopy();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
        org.joda.time.DateTime dateTime22 = dateTime19.toDateTime();
        org.joda.time.DateTime dateTime24 = dateTime19.minusWeeks(100);
        boolean boolean25 = property12.equals((java.lang.Object) dateTime24);
        boolean boolean26 = iSOChronology0.equals((java.lang.Object) boolean25);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39600052 + "'", int7 == 39600052);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfSecond(30);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology6);
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
        org.joda.time.DateTime dateTime12 = dateTime7.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
        int int16 = dateTime15.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long24 = dateTimeZone20.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime25 = dateTime15.withZoneRetainFields(dateTimeZone20);
        org.joda.time.DateTime dateTime26 = dateTime12.withZoneRetainFields(dateTimeZone20);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(dateTimeZone20);
        org.joda.time.DateTime.Property property28 = dateTime27.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean30 = property28.equals((java.lang.Object) dateTimeFormatter29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder2.appendFraction(dateTimeFieldType31, 0, 57600052);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType31, (-11), 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 39600052 + "'", int8 == 39600052);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-125999990L) + "'", long24 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long19 = dateTimeZone15.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime20 = dateTime10.withZoneRetainFields(dateTimeZone15);
        org.joda.time.DateTime dateTime21 = dateTime7.withZoneRetainFields(dateTimeZone15);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTimeZone15.getShortName((long) 998, locale23);
        boolean boolean26 = dateTimeZone15.isStandardOffset((long) 'a');
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-125999990L) + "'", long19 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+35:00" + "'", str24.equals("+35:00"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMillisOfDay(53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfDay(1970, (int) (short) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale13 = dateTimeFormatter12.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter12.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter15.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser17 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter16, dateTimeParser17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder11.append(dateTimePrinter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder11.appendCenturyOfEra(5, (int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNull(locale13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimePrinter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
        java.util.GregorianCalendar gregorianCalendar16 = dateTime15.toGregorianCalendar();
        org.joda.time.DateTime.Property property17 = dateTime15.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gregorianCalendar16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        int int4 = dateTime2.getYearOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
//        org.joda.time.DateTime dateTime12 = dateTime7.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property13 = dateTime12.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology15);
//        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds(1969);
//        int int19 = property13.compareTo((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
//        int int23 = dateTime22.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
//        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
//        int int31 = dateTime30.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now(dateTimeZone35);
//        org.joda.time.DateTime.Property property43 = dateTime42.secondOfMinute();
//        boolean boolean44 = property13.equals((java.lang.Object) dateTime42);
//        org.joda.time.DateTime dateTime46 = dateTime42.withYear(126000000);
//        org.joda.time.DateTime.Property property47 = dateTime46.weekyear();
//        boolean boolean48 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime46);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str50 = dateTime46.toString(dateTimeFormatter49);
//        java.io.Writer writer51 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology53);
//        int int55 = dateTime54.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod56 = null;
//        org.joda.time.DateTime dateTime57 = dateTime54.plus(readablePeriod56);
//        org.joda.time.DateTime dateTime59 = dateTime54.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property60 = dateTime59.millisOfSecond();
//        org.joda.time.DateTime dateTime62 = dateTime59.withEra(1);
//        int int63 = dateTime62.getMillisOfSecond();
//        org.joda.time.DateTime dateTime65 = dateTime62.withMillisOfSecond(10);
//        int int66 = dateTime62.getHourOfDay();
//        org.joda.time.LocalDateTime localDateTime67 = dateTime62.toLocalDateTime();
//        try {
//            dateTimeFormatter49.printTo(writer51, (org.joda.time.ReadablePartial) localDateTime67);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 39600052 + "'", int8 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "T08:33:52+35:00" + "'", str50.equals("T08:33:52+35:00"));
//        org.junit.Assert.assertNotNull(iSOChronology53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 39600052 + "'", int55 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertNotNull(localDateTime67);
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withLocale(locale3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withPivotYear((java.lang.Integer) (-39600000));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneId();
        boolean boolean5 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendFractionOfSecond(10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMillisOfSecond(30);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology15);
        int int17 = dateTime16.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.plus(readablePeriod18);
        org.joda.time.DateTime dateTime21 = dateTime16.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology23);
        int int25 = dateTime24.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime24.plus(readablePeriod26);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long33 = dateTimeZone29.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime34 = dateTime24.withZoneRetainFields(dateTimeZone29);
        org.joda.time.DateTime dateTime35 = dateTime21.withZoneRetainFields(dateTimeZone29);
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.DateTime.Property property37 = dateTime36.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean39 = property37.equals((java.lang.Object) dateTimeFormatter38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property37.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType40, 0, 57600052);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder2.appendSignedDecimal(dateTimeFieldType40, 100, 999);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField47 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 39600052 + "'", int17 == 39600052);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 39600052 + "'", int25 == 39600052);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-125999990L) + "'", long33 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime12.toYearMonthDay();
        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DurationField durationField15 = property8.getDurationField();
        org.joda.time.ReadablePartial readablePartial16 = null;
        try {
            int int17 = property8.compareTo(readablePartial16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
        org.joda.time.DateTime dateTime15 = dateTime10.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.plus(readablePeriod20);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long27 = dateTimeZone23.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime28 = dateTime18.withZoneRetainFields(dateTimeZone23);
        org.joda.time.DateTime dateTime29 = dateTime15.withZoneRetainFields(dateTimeZone23);
        org.joda.time.DateTime dateTime30 = dateTime2.withZone(dateTimeZone23);
        org.joda.time.DateTime.Property property31 = dateTime30.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime34 = dateTime30.withPeriodAdded(readablePeriod32, (int) (short) 100);
        org.joda.time.DateTime.Property property35 = dateTime34.centuryOfEra();
        org.joda.time.DurationField durationField36 = property35.getLeapDurationField();
        java.util.Locale locale37 = null;
        int int38 = property35.getMaximumTextLength(locale37);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 39600052 + "'", int19 == 39600052);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-125999990L) + "'", long27 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNull(durationField36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 7 + "'", int38 == 7);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.lang.Object obj0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long7 = fixedDateTimeZone5.previousTransition(0L);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(obj0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean9 = dateTime8.isAfterNow();
        java.util.Date date10 = dateTime8.toDate();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        boolean boolean4 = dateTimeFormatterBuilder1.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfSecond(10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(30);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
        int int16 = dateTime15.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
        int int24 = dateTime23.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder10.appendFraction(dateTimeFieldType39, 0, 57600052);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType39, 100, 999);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatterBuilder1.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
        int int16 = dateTime15.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
        int int24 = dateTime23.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology47);
        int int49 = dateTime48.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.DateTime dateTime51 = dateTime48.plus(readablePeriod50);
        org.joda.time.DateTime dateTime53 = dateTime48.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property54 = dateTime53.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology56);
        org.joda.time.DateTime dateTime59 = dateTime57.minusSeconds(1969);
        int int60 = property54.compareTo((org.joda.time.ReadableInstant) dateTime59);
        org.joda.time.DateTime dateTime61 = property54.withMaximumValue();
        org.joda.time.LocalTime localTime62 = dateTime61.toLocalTime();
        java.util.Locale locale64 = null;
        java.lang.String str65 = remainderDateTimeField44.getAsText((org.joda.time.ReadablePartial) localTime62, 3, locale64);
        org.joda.time.DurationField durationField66 = remainderDateTimeField44.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNull(durationField45);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 39600052 + "'", int49 == 39600052);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(iSOChronology56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(localTime62);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "3" + "'", str65.equals("3"));
        org.junit.Assert.assertNotNull(durationField66);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
        int int16 = dateTime15.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
        int int24 = dateTime23.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
        long long46 = remainderDateTimeField44.roundHalfEven((long) 11);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-126000000L) + "'", long46 == (-126000000L));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("����-��-��T00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����-��-��T00:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.LocalDateTime localDateTime9 = dateTime7.toLocalDateTime();
        org.joda.time.DateTime.Property property10 = dateTime7.weekyear();
        int int11 = dateTime7.getMinuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32) + "'", int1 == (-32));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekyear(0);
        int int6 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime11 = dateTime2.withTime((int) (byte) 1, 0, (int) (byte) 0, 0);
        org.joda.time.DateTime.Property property12 = dateTime11.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        java.lang.String str3 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        int int4 = dateTime2.getYearOfEra();
        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime6 = property5.roundCeilingCopy();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = iSOChronology1.withZone(dateTimeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long18 = dateTimeZone14.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime19 = dateTime9.withZoneRetainFields(dateTimeZone14);
        java.lang.String str20 = dateTimeZone14.getID();
        long long22 = dateTimeZone5.getMillisKeepLocal(dateTimeZone14, 52L);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField24 = gregorianChronology23.minutes();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-125999990L) + "'", long18 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+35:00" + "'", str20.equals("+35:00"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 52L + "'", long22 == 52L);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField13 = iSOChronology12.hours();
        org.joda.time.DurationField durationField14 = iSOChronology12.years();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
        int int18 = dateTime17.getMillisOfDay();
        org.joda.time.DateTime dateTime20 = dateTime17.withWeekyear(0);
        int int21 = dateTime17.getMinuteOfHour();
        boolean boolean22 = iSOChronology12.equals((java.lang.Object) dateTime17);
        org.joda.time.DurationField durationField23 = iSOChronology12.seconds();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology25);
        int int27 = dateTime26.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.plus(readablePeriod28);
        org.joda.time.DateTime dateTime31 = dateTime26.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology33);
        int int35 = dateTime34.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime37 = dateTime34.plus(readablePeriod36);
        org.joda.time.DateTime dateTime39 = dateTime34.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology41);
        int int43 = dateTime42.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.DateTime dateTime45 = dateTime42.plus(readablePeriod44);
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long51 = dateTimeZone47.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime52 = dateTime42.withZoneRetainFields(dateTimeZone47);
        org.joda.time.DateTime dateTime53 = dateTime39.withZoneRetainFields(dateTimeZone47);
        org.joda.time.DateTime dateTime54 = dateTime26.withZone(dateTimeZone47);
        org.joda.time.chrono.ZonedChronology zonedChronology55 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology12, dateTimeZone47);
        org.joda.time.MutableDateTime mutableDateTime56 = dateTime10.toMutableDateTime(dateTimeZone47);
        long long57 = mutableDateTime56.getMillis();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 39600052 + "'", int18 == 39600052);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 39600052 + "'", int27 == 39600052);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 39600052 + "'", int35 == 39600052);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 39600052 + "'", int43 == 39600052);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-125999990L) + "'", long51 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(zonedChronology55);
        org.junit.Assert.assertNotNull(mutableDateTime56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-39599999L) + "'", long57 == (-39599999L));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.Interval interval10 = property8.toInterval();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval10);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(interval10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
        org.joda.time.DateTime dateTime15 = dateTime10.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.plus(readablePeriod20);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long27 = dateTimeZone23.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime28 = dateTime18.withZoneRetainFields(dateTimeZone23);
        org.joda.time.DateTime dateTime29 = dateTime15.withZoneRetainFields(dateTimeZone23);
        org.joda.time.DateTime dateTime30 = dateTime2.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime32 = dateTime30.minusMonths(2019);
        org.joda.time.DateTime.Property property33 = dateTime32.millisOfDay();
        org.joda.time.DateTime dateTime35 = property33.addToCopy((-101L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 39600052 + "'", int19 == 39600052);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-125999990L) + "'", long27 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
        int int16 = dateTime15.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
        int int24 = dateTime23.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
        org.joda.time.DurationField durationField47 = iSOChronology45.years();
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
        int int51 = dateTime50.getMillisOfDay();
        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
        int int54 = dateTime50.getMinuteOfHour();
        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
        boolean boolean58 = unsupportedDateTimeField57.isSupported();
        try {
            int int60 = unsupportedDateTimeField57.getMinimumValue((long) 57600052);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }
}

