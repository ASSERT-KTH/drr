import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "secondOfMinute");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology3);
//        int int5 = dateTime4.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
//        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime12 = dateTime9.withEra(1);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField14 = iSOChronology13.hours();
//        org.joda.time.DurationField durationField15 = iSOChronology13.centuries();
//        org.joda.time.MutableDateTime mutableDateTime16 = dateTime9.toMutableDateTime((org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology13.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology13.dayOfYear();
//        org.joda.time.DurationField durationField19 = iSOChronology13.seconds();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 39600052 + "'", int5 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
//        org.joda.time.DateTime dateTime19 = dateTime14.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
//        int int23 = dateTime22.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
//        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
//        int int31 = dateTime30.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime42 = dateTime14.withZone(dateTimeZone35);
//        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone35);
//        org.joda.time.DateTimeField dateTimeField44 = zonedChronology43.secondOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone49 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone50 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone49);
//        java.lang.String str52 = cachedDateTimeZone50.getNameKey((long) 57600052);
//        org.joda.time.Chronology chronology53 = zonedChronology43.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone50);
//        java.lang.String str54 = zonedChronology43.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(zonedChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "+35:00" + "'", str52.equals("+35:00"));
//        org.junit.Assert.assertNotNull(chronology53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ZonedChronology[ISOChronology[UTC], +35:00]" + "'", str54.equals("ZonedChronology[ISOChronology[UTC], +35:00]"));
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        int int6 = dateTime5.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = property8.addToCopy((long) 52);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField19 = iSOChronology18.hours();
//        org.joda.time.DurationField durationField20 = iSOChronology18.centuries();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        org.joda.time.Chronology chronology23 = iSOChronology18.withZone(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) 1, dateTimeZone22);
//        int int25 = property8.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime27 = dateTime24.withMillisOfDay((int) (byte) 10);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-39600000) + "'", int25 == (-39600000));
//        org.junit.Assert.assertNotNull(dateTime27);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        int int4 = dateTime2.getYearOfEra();
//        org.joda.time.DateTime dateTime6 = dateTime2.withWeekyear((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusYears(57600052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder10.appendFraction(dateTimeFieldType39, 0, 57600052);
//        org.joda.time.DateTime.Property property43 = dateTime9.property(dateTimeFieldType39);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology45);
//        int int47 = dateTime46.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod48 = null;
//        org.joda.time.DateTime dateTime49 = dateTime46.plus(readablePeriod48);
//        org.joda.time.DateTime dateTime51 = dateTime46.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology53);
//        int int55 = dateTime54.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod56 = null;
//        org.joda.time.DateTime dateTime57 = dateTime54.plus(readablePeriod56);
//        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long63 = dateTimeZone59.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime64 = dateTime54.withZoneRetainFields(dateTimeZone59);
//        org.joda.time.DateTime dateTime65 = dateTime51.withZoneRetainFields(dateTimeZone59);
//        org.joda.time.DateTime dateTime67 = dateTime65.withYear((int) ' ');
//        int int68 = dateTime9.compareTo((org.joda.time.ReadableInstant) dateTime65);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 39600052 + "'", int47 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(iSOChronology53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 39600052 + "'", int55 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-125999990L) + "'", long63 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime15 = property8.withMaximumValue();
//        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime18 = dateTime15.plusWeeks(19);
//        org.joda.time.DateTime dateTime20 = dateTime18.plusHours(126000100);
//        java.util.Locale locale22 = null;
//        try {
//            java.lang.String str23 = dateTime20.toString("����-��-��T00:00", locale22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
//        org.joda.time.DateTime dateTime14 = dateTime9.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property15 = dateTime14.millisOfSecond();
//        org.joda.time.LocalDateTime localDateTime16 = dateTime14.toLocalDateTime();
//        boolean boolean17 = cachedDateTimeZone6.isLocalDateTimeGap(localDateTime16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) '4', 627);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        boolean boolean58 = unsupportedDateTimeField57.isSupported();
//        java.lang.String str59 = unsupportedDateTimeField57.getName();
//        try {
//            int int61 = unsupportedDateTimeField57.get((long) 1520000);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "secondOfMinute" + "'", str59.equals("secondOfMinute"));
//    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
//        int int7 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.plus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
//        org.joda.time.DateTime dateTime14 = property12.roundHalfFloorCopy();
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
//        org.joda.time.DateTime dateTime22 = dateTime19.toDateTime();
//        org.joda.time.DateTime dateTime24 = dateTime19.minusWeeks(100);
//        boolean boolean25 = property12.equals((java.lang.Object) dateTime24);
//        boolean boolean26 = iSOChronology0.equals((java.lang.Object) boolean25);
//        org.joda.time.DurationField durationField27 = iSOChronology0.minutes();
//        org.joda.time.DurationFieldType durationFieldType28 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField30 = new org.joda.time.field.ScaledDurationField(durationField27, durationFieldType28, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39600052 + "'", int7 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(durationField27);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("11:00:00.032", false);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
//        int int7 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.plus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
//        org.joda.time.DateTime dateTime14 = dateTime11.withEra(1);
//        int int15 = dateTime14.getMillisOfSecond();
//        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfSecond(10);
//        int int18 = dateTime14.getHourOfDay();
//        org.joda.time.LocalDateTime localDateTime19 = dateTime14.toLocalDateTime();
//        boolean boolean20 = dateTimeZone3.isLocalDateTimeGap(localDateTime19);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39600052 + "'", int7 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        boolean boolean4 = dateTimeFormatterBuilder1.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfSecond(10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale11 = dateTimeFormatter10.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter10.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser13 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter12, dateTimeParser13);
        org.joda.time.format.DateTimeParser dateTimeParser15 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter12, dateTimeParser15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder9.append(dateTimePrinter12);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap18 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendTimeZoneShortName(strMap18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendTwoDigitWeekyear(2, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNull(locale11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = iSOChronology3.add(readablePeriod4, 599616000011L, (-39600000));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 599616000011L + "'", long7 == 599616000011L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("-00:00:00.001", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-00:00:00.001\" is malformed at \":00:00.001\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
//        int int7 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.plus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
//        org.joda.time.DateTime dateTime14 = property12.roundHalfFloorCopy();
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
//        org.joda.time.DateTime dateTime22 = dateTime19.toDateTime();
//        org.joda.time.DateTime dateTime24 = dateTime19.minusWeeks(100);
//        boolean boolean25 = property12.equals((java.lang.Object) dateTime24);
//        boolean boolean26 = iSOChronology0.equals((java.lang.Object) boolean25);
//        org.joda.time.DurationField durationField27 = iSOChronology0.weeks();
//        long long30 = durationField27.subtract((long) 52, (long) 4);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39600052 + "'", int7 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2419199948L) + "'", long30 == (-2419199948L));
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        boolean boolean58 = unsupportedDateTimeField57.isSupported();
//        org.joda.time.chrono.ISOChronology iSOChronology60 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology60);
//        int int62 = dateTime61.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod63 = null;
//        org.joda.time.DateTime dateTime64 = dateTime61.plus(readablePeriod63);
//        org.joda.time.DateTime dateTime66 = dateTime61.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property67 = dateTime66.millisOfSecond();
//        org.joda.time.DateTime dateTime69 = dateTime66.withEra(1);
//        int int70 = dateTime69.getMillisOfSecond();
//        org.joda.time.DateTime dateTime72 = dateTime69.withMillisOfSecond(10);
//        int int73 = dateTime69.getHourOfDay();
//        org.joda.time.LocalDateTime localDateTime74 = dateTime69.toLocalDateTime();
//        java.util.Locale locale76 = null;
//        try {
//            java.lang.String str77 = unsupportedDateTimeField57.getAsShortText((org.joda.time.ReadablePartial) localDateTime74, 998, locale76);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(iSOChronology60);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 39600052 + "'", int62 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(property67);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
//        org.junit.Assert.assertNotNull(localDateTime74);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        int int4 = dateTime2.getYearOfEra();
//        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
//        int int6 = property5.getMaximumValue();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2922789 + "'", int6 == 2922789);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        boolean boolean58 = unsupportedDateTimeField57.isSupported();
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) (short) -1);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone65 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone66 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone65);
//        java.lang.String str68 = cachedDateTimeZone66.getNameKey((long) 57600052);
//        org.joda.time.DateTime dateTime69 = dateTime60.toDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone66);
//        org.joda.time.TimeOfDay timeOfDay70 = dateTime69.toTimeOfDay();
//        int[] intArray72 = null;
//        try {
//            int[] intArray74 = unsupportedDateTimeField57.set((org.joda.time.ReadablePartial) timeOfDay70, 62, intArray72, 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone66);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "+35:00" + "'", str68.equals("+35:00"));
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(timeOfDay70);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        try {
//            int int59 = unsupportedDateTimeField57.getMinimumValue((long) 2922789);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.millis();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
//        int int7 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.plus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology15);
//        org.joda.time.YearMonthDay yearMonthDay17 = dateTime16.toYearMonthDay();
//        int int18 = property12.compareTo((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime19 = property12.roundHalfCeilingCopy();
//        boolean boolean20 = gregorianChronology0.equals((java.lang.Object) property12);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39600052 + "'", int7 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(yearMonthDay17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField59 = iSOChronology58.hours();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology58.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology58.weekyearOfCentury();
//        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology63);
//        int int65 = dateTime64.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod66 = null;
//        org.joda.time.DateTime dateTime67 = dateTime64.plus(readablePeriod66);
//        org.joda.time.DateTime dateTime69 = dateTime64.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property70 = dateTime69.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology72);
//        org.joda.time.DateTime dateTime75 = dateTime73.minusSeconds(1969);
//        int int76 = property70.compareTo((org.joda.time.ReadableInstant) dateTime75);
//        org.joda.time.DateTime dateTime77 = property70.withMaximumValue();
//        org.joda.time.LocalTime localTime78 = dateTime77.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay79 = dateTime77.toTimeOfDay();
//        int[] intArray81 = iSOChronology58.get((org.joda.time.ReadablePartial) timeOfDay79, (-1L));
//        java.util.Locale locale82 = null;
//        try {
//            java.lang.String str83 = unsupportedDateTimeField57.getAsShortText((org.joda.time.ReadablePartial) timeOfDay79, locale82);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertNotNull(iSOChronology58);
//        org.junit.Assert.assertNotNull(durationField59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(iSOChronology63);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 39600052 + "'", int65 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(property70);
//        org.junit.Assert.assertNotNull(iSOChronology72);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(localTime78);
//        org.junit.Assert.assertNotNull(timeOfDay79);
//        org.junit.Assert.assertNotNull(intArray81);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.Chronology chronology5 = iSOChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = remainderDateTimeField44.getAsText((int) '#', locale46);
//        int int49 = remainderDateTimeField44.getMinimumValue(1560634372660L);
//        java.util.Locale locale50 = null;
//        int int51 = remainderDateTimeField44.getMaximumTextLength(locale50);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "35" + "'", str47.equals("35"));
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 3 + "'", int51 == 3);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 100, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.minuteOfDay();
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
//        java.util.GregorianCalendar gregorianCalendar16 = dateTime15.toGregorianCalendar();
//        int int17 = dateTime15.getHourOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(gregorianCalendar16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
//        int int11 = dateTime10.getMillisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime10.withMillisOfSecond(10);
//        int int14 = dateTime10.getHourOfDay();
//        org.joda.time.LocalDateTime localDateTime15 = dateTime10.toLocalDateTime();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
//        int int19 = dateTime18.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime18.plus(readablePeriod20);
//        org.joda.time.DateTime dateTime23 = dateTime18.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime25 = dateTime18.plus((-125999990L));
//        org.joda.time.ReadableDuration readableDuration26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime25.minus(readableDuration26);
//        boolean boolean28 = dateTime25.isEqualNow();
//        org.joda.time.ReadableDuration readableDuration29 = null;
//        org.joda.time.DateTime dateTime31 = dateTime25.withDurationAdded(readableDuration29, 30);
//        int int32 = dateTime25.getMillisOfSecond();
//        int int33 = dateTime25.getEra();
//        boolean boolean34 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime25);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 39600052 + "'", int19 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 62 + "'", int32 == 62);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 52, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.LocalDateTime localDateTime9 = dateTime7.toLocalDateTime();
//        org.joda.time.DateTime dateTime11 = dateTime7.withMillisOfSecond(999);
//        org.joda.time.DateTime dateTime12 = dateTime11.withTimeAtStartOfDay();
//        int int13 = dateTime12.getYear();
//        org.joda.time.DateTime.Property property14 = dateTime12.era();
//        org.joda.time.DateTime dateTime16 = dateTime12.plus((long) (byte) 1);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.YearMonthDay yearMonthDay13 = dateTime12.toYearMonthDay();
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime15 = property8.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime17 = dateTime15.minusMillis(660);
//        org.joda.time.DateTime dateTime19 = dateTime15.plusMillis(0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(yearMonthDay13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        int int4 = dateTime2.getYearOfEra();
//        org.joda.time.DateTime dateTime6 = dateTime2.withWeekyear((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusYears(57600052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder10.appendFraction(dateTimeFieldType39, 0, 57600052);
//        org.joda.time.DateTime.Property property43 = dateTime9.property(dateTimeFieldType39);
//        int int44 = dateTime9.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 576001 + "'", int44 == 576001);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfWeek(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitYear(52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology47);
//        int int49 = dateTime48.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod50 = null;
//        org.joda.time.DateTime dateTime51 = dateTime48.plus(readablePeriod50);
//        org.joda.time.DateTime dateTime53 = dateTime48.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property54 = dateTime53.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.DateTime dateTime59 = dateTime57.minusSeconds(1969);
//        int int60 = property54.compareTo((org.joda.time.ReadableInstant) dateTime59);
//        org.joda.time.DateTime dateTime61 = property54.withMaximumValue();
//        org.joda.time.LocalTime localTime62 = dateTime61.toLocalTime();
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = remainderDateTimeField44.getAsText((org.joda.time.ReadablePartial) localTime62, 3, locale64);
//        java.lang.String str66 = remainderDateTimeField44.getName();
//        int int67 = remainderDateTimeField44.getDivisor();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNull(durationField45);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 39600052 + "'", int49 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(localTime62);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "3" + "'", str65.equals("3"));
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "secondOfMinute" + "'", str66.equals("secondOfMinute"));
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 998 + "'", int67 == 998);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale8 = dateTimeFormatter7.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter7.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendSecondOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendMillisOfDay(53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendFractionOfDay(1970, (int) (short) 10);
        boolean boolean24 = dateTimeFormatterBuilder23.canBuildFormatter();
        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatterBuilder23.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale27 = dateTimeFormatter26.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter26.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter26.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeParser dateTimeParser33 = dateTimeFormatter32.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray34 = new org.joda.time.format.DateTimeParser[] { dateTimeParser11, dateTimeParser25, dateTimeParser31, dateTimeParser33 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder5.append(dateTimePrinter9, dateTimeParserArray34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNull(locale8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNull(locale27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeParser31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimeParser33);
        org.junit.Assert.assertNotNull(dateTimeParserArray34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        int int4 = dateTime2.getYearOfEra();
//        org.joda.time.DateTime dateTime6 = dateTime2.withWeekyear((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusYears(57600052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder10.appendFraction(dateTimeFieldType39, 0, 57600052);
//        org.joda.time.DateTime.Property property43 = dateTime9.property(dateTimeFieldType39);
//        int int44 = property43.getLeapAmount();
//        java.util.Locale locale46 = null;
//        try {
//            org.joda.time.DateTime dateTime47 = property43.setCopy("", locale46);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfMinute is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        boolean boolean3 = dateTime2.isBeforeNow();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMillisOfSecond(57600052);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology47);
//        int int49 = dateTime48.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod50 = null;
//        org.joda.time.DateTime dateTime51 = dateTime48.plus(readablePeriod50);
//        org.joda.time.DateTime dateTime53 = dateTime48.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property54 = dateTime53.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.DateTime dateTime59 = dateTime57.minusSeconds(1969);
//        int int60 = property54.compareTo((org.joda.time.ReadableInstant) dateTime59);
//        org.joda.time.DateTime dateTime61 = property54.withMaximumValue();
//        org.joda.time.LocalTime localTime62 = dateTime61.toLocalTime();
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = remainderDateTimeField44.getAsText((org.joda.time.ReadablePartial) localTime62, 3, locale64);
//        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology67);
//        int int69 = dateTime68.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod70 = null;
//        org.joda.time.DateTime dateTime71 = dateTime68.plus(readablePeriod70);
//        org.joda.time.DateTime dateTime73 = dateTime68.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property74 = dateTime73.millisOfSecond();
//        org.joda.time.LocalDateTime localDateTime75 = dateTime73.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology77 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int78 = gregorianChronology77.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone79 = gregorianChronology77.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology80 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone79);
//        org.joda.time.DateTimeField dateTimeField81 = iSOChronology80.era();
//        org.joda.time.chrono.ISOChronology iSOChronology83 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime84 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology83);
//        org.joda.time.YearMonthDay yearMonthDay85 = dateTime84.toYearMonthDay();
//        boolean boolean86 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay85);
//        int[] intArray88 = iSOChronology80.get((org.joda.time.ReadablePartial) yearMonthDay85, (long) 62);
//        try {
//            int[] intArray90 = remainderDateTimeField44.add((org.joda.time.ReadablePartial) localDateTime75, 999, intArray88, 69);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 999");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNull(durationField45);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 39600052 + "'", int49 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(localTime62);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "3" + "'", str65.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology67);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 39600052 + "'", int69 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertNotNull(localDateTime75);
//        org.junit.Assert.assertNotNull(gregorianChronology77);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 4 + "'", int78 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone79);
//        org.junit.Assert.assertNotNull(iSOChronology80);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//        org.junit.Assert.assertNotNull(iSOChronology83);
//        org.junit.Assert.assertNotNull(yearMonthDay85);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
//        org.junit.Assert.assertNotNull(intArray88);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(35L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology2);
//        int int4 = dateTime3.getMillisOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime3.withWeekyear(0);
//        org.joda.time.DateTime dateTime8 = dateTime3.minusWeeks((int) (byte) 100);
//        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 11, (java.lang.Object) dateTime3);
//        org.joda.time.DateTime.Property property10 = dateTime3.millisOfSecond();
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 39600052 + "'", int4 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(property10);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime2.minusMonths(19);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(chronology10);
//        org.joda.time.DateTime.Property property12 = dateTime9.minuteOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        boolean boolean4 = dateTimeFormatterBuilder1.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfSecond(10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendHourOfHalfday(57600052);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitWeekyear(39600, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendEraText();
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        java.lang.String str3 = gregorianChronology0.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[+35:00]" + "'", str3.equals("GregorianChronology[+35:00]"));
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusYears(53);
//        org.joda.time.DateTime.Property property16 = dateTime15.minuteOfHour();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        org.joda.time.DateTime dateTime15 = dateTime10.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
//        int int19 = dateTime18.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime18.plus(readablePeriod20);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long27 = dateTimeZone23.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime28 = dateTime18.withZoneRetainFields(dateTimeZone23);
//        org.joda.time.DateTime dateTime29 = dateTime15.withZoneRetainFields(dateTimeZone23);
//        org.joda.time.DateTime dateTime30 = dateTime2.withZone(dateTimeZone23);
//        org.joda.time.DateTime dateTime32 = dateTime30.minusMonths(2019);
//        org.joda.time.DateTime.Property property33 = dateTime32.millisOfDay();
//        java.util.Date date34 = dateTime32.toDate();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 39600052 + "'", int19 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-125999990L) + "'", long27 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(date34);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        try {
            long long9 = iSOChronology0.getDateTimeMillis(0, (-100), 126000000, (-19), 1520000, (-39600052), 999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -19 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.millis();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        java.lang.String str2 = gregorianChronology0.toString();
//        try {
//            long long10 = gregorianChronology0.getDateTimeMillis(11, (int) (short) -1, 0, 999, 7, (int) '#', 1520000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[+35:00]" + "'", str2.equals("GregorianChronology[+35:00]"));
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.Chronology chronology15 = dateTime13.getChronology();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(chronology15);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology2);
//        int int4 = dateTime3.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
//        org.joda.time.DateTime dateTime8 = dateTime3.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property9 = dateTime8.millisOfSecond();
//        org.joda.time.LocalDateTime localDateTime10 = dateTime8.toLocalDateTime();
//        long long12 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDateTime10, (long) 53);
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.minuteOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 39600052 + "'", int4 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(localDateTime10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-39599999L) + "'", long12 == (-39599999L));
//        org.junit.Assert.assertNotNull(dateTimeField13);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
//        int int14 = dateTime13.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long22 = dateTimeZone18.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime23 = dateTime13.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTime dateTime24 = dateTime10.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime.Property property26 = dateTime25.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean28 = property26.equals((java.lang.Object) dateTimeFormatter27);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property26.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType29, 0, 57600052);
//        org.joda.time.format.DateTimePrinter dateTimePrinter33 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        java.util.Locale locale39 = dateTimeFormatter38.getLocale();
//        org.joda.time.format.DateTimePrinter dateTimePrinter40 = dateTimeFormatter38.getPrinter();
//        org.joda.time.format.DateTimeParser dateTimeParser41 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter40, dateTimeParser41);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
//        org.joda.time.format.DateTimeParser dateTimeParser44 = dateTimeFormatter43.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder34.append(dateTimePrinter40, dateTimeParser44);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder32.append(dateTimePrinter33, dateTimeParser44);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39600052 + "'", int14 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-125999990L) + "'", long22 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNull(locale39);
//        org.junit.Assert.assertNotNull(dateTimePrinter40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(dateTimeParser44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long19 = dateTimeZone15.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime20 = dateTime10.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime21 = dateTime7.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone15);
//        int int24 = dateTimeZone15.getOffsetFromLocal((long) 8);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-125999990L) + "'", long19 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 126000000 + "'", int24 == 126000000);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
//        org.joda.time.DateTime.Property property16 = dateTime6.millisOfSecond();
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(chronology17);
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        int int4 = dateTime2.getYearOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.plus(readablePeriod9);
//        org.joda.time.DateTime dateTime12 = dateTime7.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property13 = dateTime12.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology15);
//        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds(1969);
//        int int19 = property13.compareTo((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
//        int int23 = dateTime22.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
//        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
//        int int31 = dateTime30.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now(dateTimeZone35);
//        org.joda.time.DateTime.Property property43 = dateTime42.secondOfMinute();
//        boolean boolean44 = property13.equals((java.lang.Object) dateTime42);
//        org.joda.time.DateTime dateTime46 = dateTime42.withYear(126000000);
//        org.joda.time.DateTime.Property property47 = dateTime46.weekyear();
//        boolean boolean48 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime46);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str50 = dateTime46.toString(dateTimeFormatter49);
//        try {
//            long long52 = dateTimeFormatter49.parseMillis("0");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 39600052 + "'", int8 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "T08:34:01+35:00" + "'", str50.equals("T08:34:01+35:00"));
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfSecond();
//        org.joda.time.Chronology chronology12 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology18);
//        int int20 = dateTime19.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.plus(readablePeriod21);
//        org.joda.time.DateTime dateTime24 = dateTime19.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology26);
//        int int28 = dateTime27.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.plus(readablePeriod29);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long36 = dateTimeZone32.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime37 = dateTime27.withZoneRetainFields(dateTimeZone32);
//        org.joda.time.DateTime dateTime38 = dateTime24.withZoneRetainFields(dateTimeZone32);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone32);
//        org.joda.time.DateTime.Property property40 = dateTime39.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean42 = property40.equals((java.lang.Object) dateTimeFormatter41);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property40.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType43, 0, 57600052);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType43, 69, 3, 627);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType43, 999);
//        long long54 = remainderDateTimeField52.roundCeiling((long) (byte) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.YearMonthDay yearMonthDay58 = dateTime57.toYearMonthDay();
//        int int59 = remainderDateTimeField52.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay58);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 39600052 + "'", int20 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 39600052 + "'", int28 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-125999990L) + "'", long36 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1000L + "'", long54 == 1000L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(yearMonthDay58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 998 + "'", int59 == 998);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        java.lang.String str3 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField4 = iSOChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[+35:00]" + "'", str3.equals("ISOChronology[+35:00]"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime15 = property8.roundHalfFloorCopy();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime20.minus(readableDuration21);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology24);
//        int int26 = dateTime25.getMillisOfDay();
//        org.joda.time.DateTime dateTime28 = dateTime25.withWeekyear(0);
//        boolean boolean29 = dateTime22.isBefore((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime31 = dateTime22.plusMillis((int) (byte) 0);
//        java.util.GregorianCalendar gregorianCalendar32 = dateTime31.toGregorianCalendar();
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField34 = iSOChronology33.hours();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology33.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology33.weekyearOfCentury();
//        int int38 = dateTime31.get(dateTimeField37);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder39.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder40.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder40.appendTimeZoneId();
//        boolean boolean43 = dateTimeFormatterBuilder40.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder40.appendFractionOfSecond(10, (int) (short) -1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder40.appendMinuteOfDay(5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder49.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology53);
//        int int55 = dateTime54.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod56 = null;
//        org.joda.time.DateTime dateTime57 = dateTime54.plus(readablePeriod56);
//        org.joda.time.DateTime dateTime59 = dateTime54.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology61 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology61);
//        int int63 = dateTime62.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod64 = null;
//        org.joda.time.DateTime dateTime65 = dateTime62.plus(readablePeriod64);
//        org.joda.time.DateTimeZone dateTimeZone67 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long71 = dateTimeZone67.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime72 = dateTime62.withZoneRetainFields(dateTimeZone67);
//        org.joda.time.DateTime dateTime73 = dateTime59.withZoneRetainFields(dateTimeZone67);
//        org.joda.time.DateTime dateTime74 = org.joda.time.DateTime.now(dateTimeZone67);
//        org.joda.time.DateTime.Property property75 = dateTime74.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter76 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean77 = property75.equals((java.lang.Object) dateTimeFormatter76);
//        org.joda.time.DateTimeFieldType dateTimeFieldType78 = property75.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder49.appendFraction(dateTimeFieldType78, 0, 57600052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder40.appendSignedDecimal(dateTimeFieldType78, 100, 999);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField86 = new org.joda.time.field.RemainderDateTimeField(dateTimeField37, dateTimeFieldType78, 8);
//        boolean boolean87 = dateTime15.isSupported(dateTimeFieldType78);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 39600052 + "'", int26 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(gregorianCalendar32);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 70 + "'", int38 == 70);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(iSOChronology53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 39600052 + "'", int55 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(iSOChronology61);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 39600052 + "'", int63 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(dateTimeZone67);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-125999990L) + "'", long71 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(dateTimeFormatter76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType78);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder84);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendTimeZoneShortName(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType5, 0, 70, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.YearMonthDay yearMonthDay13 = dateTime12.toYearMonthDay();
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime12);
//        java.lang.String str15 = property8.getAsString();
//        int int16 = property8.getLeapAmount();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(yearMonthDay13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
//        boolean boolean4 = dateTimeFormatterBuilder1.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfSecond(10, (int) (short) -1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendMinuteOfDay(5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder10.appendFraction(dateTimeFieldType39, 0, 57600052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType39, 100, 999);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType39, 10, (int) (short) -1, 1520000);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        try {
//            long long59 = unsupportedDateTimeField57.remainder(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        org.joda.time.DurationField durationField58 = unsupportedDateTimeField57.getDurationField();
//        java.util.Locale locale60 = null;
//        try {
//            java.lang.String str61 = unsupportedDateTimeField57.getAsShortText(100, locale60);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertNotNull(durationField58);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0L, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("35");
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = remainderDateTimeField44.getAsText((int) '#', locale46);
//        long long49 = remainderDateTimeField44.roundHalfEven(1560634403684L);
//        long long52 = remainderDateTimeField44.add((long) (short) 1, 365);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "35" + "'", str47.equals("35"));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1546174800000L + "'", long49 == 1546174800000L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 11518243200001L + "'", long52 == 11518243200001L);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        org.joda.time.DurationField durationField58 = unsupportedDateTimeField57.getDurationField();
//        try {
//            long long60 = unsupportedDateTimeField57.roundHalfEven((long) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertNotNull(durationField58);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        boolean boolean58 = unsupportedDateTimeField57.isSupported();
//        org.joda.time.chrono.ISOChronology iSOChronology60 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology60);
//        int int62 = dateTime61.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod63 = null;
//        org.joda.time.DateTime dateTime64 = dateTime61.plus(readablePeriod63);
//        org.joda.time.DateTime dateTime66 = dateTime61.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property67 = dateTime66.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology69);
//        org.joda.time.DateTime dateTime72 = dateTime70.minusSeconds(1969);
//        int int73 = property67.compareTo((org.joda.time.ReadableInstant) dateTime72);
//        org.joda.time.DateTime dateTime74 = property67.roundHalfFloorCopy();
//        org.joda.time.YearMonthDay yearMonthDay75 = dateTime74.toYearMonthDay();
//        java.util.Locale locale77 = null;
//        try {
//            java.lang.String str78 = unsupportedDateTimeField57.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay75, 10, locale77);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(iSOChronology60);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 39600052 + "'", int62 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(property67);
//        org.junit.Assert.assertNotNull(iSOChronology69);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(yearMonthDay75);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        boolean boolean14 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        int int15 = dateTime7.getDayOfYear();
//        int int16 = dateTime7.getSecondOfMinute();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime7.toMutableDateTime(chronology17);
//        org.joda.time.DateTime dateTime20 = dateTime7.withMillis((long) 19);
//        int int21 = dateTime7.getDayOfYear();
//        org.joda.time.DateTime dateTime23 = dateTime7.plusSeconds((int) (byte) 10);
//        int int24 = dateTime23.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 19 + "'", int24 == 19);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
//        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) 'a');
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology11);
//        int int13 = dateTime12.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.plus(readablePeriod14);
//        org.joda.time.DateTime dateTime17 = dateTime12.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime20 = dateTime17.withEra(1);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField22 = iSOChronology21.hours();
//        org.joda.time.DurationField durationField23 = iSOChronology21.centuries();
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime17.toMutableDateTime((org.joda.time.Chronology) iSOChronology21);
//        boolean boolean25 = dateTime9.isAfter((org.joda.time.ReadableInstant) mutableDateTime24);
//        org.joda.time.DateTime dateTime27 = dateTime9.withMillisOfSecond(2);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
//        int int31 = dateTime30.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
//        org.joda.time.DateTime dateTime35 = dateTime30.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime37 = dateTime30.plus((-125999990L));
//        boolean boolean38 = dateTime9.isBefore((org.joda.time.ReadableInstant) dateTime37);
//        boolean boolean39 = dateTime37.isEqualNow();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 39600052 + "'", int13 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneOffset("11:00:00.032", "(\"org.joda.time.JodaTimePermission\" \"1\")", false, 365, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendMonthOfYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfDay((int) (short) 0, (int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfSecond();
//        org.joda.time.Chronology chronology12 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology18);
//        int int20 = dateTime19.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.plus(readablePeriod21);
//        org.joda.time.DateTime dateTime24 = dateTime19.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology26);
//        int int28 = dateTime27.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.plus(readablePeriod29);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long36 = dateTimeZone32.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime37 = dateTime27.withZoneRetainFields(dateTimeZone32);
//        org.joda.time.DateTime dateTime38 = dateTime24.withZoneRetainFields(dateTimeZone32);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone32);
//        org.joda.time.DateTime.Property property40 = dateTime39.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean42 = property40.equals((java.lang.Object) dateTimeFormatter41);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property40.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType43, 0, 57600052);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType43, 69, 3, 627);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType43, 999);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        java.util.Locale locale54 = dateTimeFormatter53.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = dateTimeFormatter53.withDefaultYear((int) (byte) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology58);
//        org.joda.time.YearMonthDay yearMonthDay60 = dateTime59.toYearMonthDay();
//        boolean boolean61 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay60);
//        java.lang.String str62 = dateTimeFormatter56.print((org.joda.time.ReadablePartial) yearMonthDay60);
//        int int63 = remainderDateTimeField52.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay60);
//        long long65 = remainderDateTimeField52.roundCeiling((long) 69);
//        long long67 = remainderDateTimeField52.roundHalfFloor((long) 365);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) remainderDateTimeField52, (int) (byte) 1, 1520000, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for secondOfMinute must be in the range [1520000,100]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 39600052 + "'", int20 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 39600052 + "'", int28 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-125999990L) + "'", long36 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNull(locale54);
//        org.junit.Assert.assertNotNull(dateTimeFormatter56);
//        org.junit.Assert.assertNotNull(iSOChronology58);
//        org.junit.Assert.assertNotNull(yearMonthDay60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1970-01-02T��:��" + "'", str62.equals("1970-01-02T��:��"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1000L + "'", long65 == 1000L);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime2.plus((-125999990L));
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
//        java.util.Locale locale12 = null;
//        java.util.Calendar calendar13 = dateTime11.toCalendar(locale12);
//        int int14 = dateTime11.getDayOfMonth();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(calendar13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.hours();
        org.joda.time.DurationField durationField8 = iSOChronology6.centuries();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.Chronology chronology11 = iSOChronology6.withZone(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(0, (int) (byte) 0, (int) (byte) -1, 39600052, 0, 39600, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 39600052 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
//        org.joda.time.DurationField durationField3 = iSOChronology1.centuries();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        org.joda.time.Chronology chronology6 = iSOChronology1.withZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 1, dateTimeZone5);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        org.joda.time.DateTime dateTime15 = dateTime10.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
//        int int19 = dateTime18.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime18.plus(readablePeriod20);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long27 = dateTimeZone23.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime28 = dateTime18.withZoneRetainFields(dateTimeZone23);
//        org.joda.time.DateTime dateTime29 = dateTime15.withZoneRetainFields(dateTimeZone23);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone23);
//        org.joda.time.DateTime.Property property31 = dateTime30.secondOfMinute();
//        int int32 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField34 = iSOChronology33.hours();
//        org.joda.time.DurationField durationField35 = iSOChronology33.years();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology33.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder37.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder40.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder40.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology47);
//        int int49 = dateTime48.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod50 = null;
//        org.joda.time.DateTime dateTime51 = dateTime48.plus(readablePeriod50);
//        org.joda.time.DateTime dateTime53 = dateTime48.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology55);
//        int int57 = dateTime56.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod58 = null;
//        org.joda.time.DateTime dateTime59 = dateTime56.plus(readablePeriod58);
//        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long65 = dateTimeZone61.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime66 = dateTime56.withZoneRetainFields(dateTimeZone61);
//        org.joda.time.DateTime dateTime67 = dateTime53.withZoneRetainFields(dateTimeZone61);
//        org.joda.time.DateTime dateTime68 = org.joda.time.DateTime.now(dateTimeZone61);
//        org.joda.time.DateTime.Property property69 = dateTime68.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean71 = property69.equals((java.lang.Object) dateTimeFormatter70);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = property69.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder40.appendSignedDecimal(dateTimeFieldType72, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField77 = new org.joda.time.field.RemainderDateTimeField(dateTimeField36, dateTimeFieldType72, 998);
//        java.util.Locale locale79 = null;
//        java.lang.String str80 = remainderDateTimeField77.getAsText((int) '#', locale79);
//        org.joda.time.DurationField durationField81 = remainderDateTimeField77.getRangeDurationField();
//        boolean boolean82 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int32, (java.lang.Object) remainderDateTimeField77);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 39600052 + "'", int19 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-125999990L) + "'", long27 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 126000000 + "'", int32 == 126000000);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 39600052 + "'", int49 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(iSOChronology55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 39600052 + "'", int57 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-125999990L) + "'", long65 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTime68);
//        org.junit.Assert.assertNotNull(property69);
//        org.junit.Assert.assertNotNull(dateTimeFormatter70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "35" + "'", str80.equals("35"));
//        org.junit.Assert.assertNotNull(durationField81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.Object obj0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long7 = fixedDateTimeZone5.previousTransition(0L);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(obj0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str10 = fixedDateTimeZone5.getNameKey((long) (-57600000));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+35:00" + "'", str10.equals("+35:00"));
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
//        org.joda.time.DateTime dateTime19 = dateTime14.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
//        int int23 = dateTime22.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
//        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
//        int int31 = dateTime30.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime42 = dateTime14.withZone(dateTimeZone35);
//        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone35);
//        org.joda.time.DateTimeField dateTimeField44 = zonedChronology43.secondOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone49 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone50 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone49);
//        java.lang.String str52 = cachedDateTimeZone50.getNameKey((long) 57600052);
//        org.joda.time.Chronology chronology53 = zonedChronology43.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone50);
//        org.joda.time.DateTimeField dateTimeField54 = zonedChronology43.clockhourOfHalfday();
//        try {
//            long long59 = zonedChronology43.getDateTimeMillis(70, 0, 0, 39600052);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(zonedChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "+35:00" + "'", str52.equals("+35:00"));
//        org.junit.Assert.assertNotNull(chronology53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.LocalDateTime localDateTime9 = dateTime7.toLocalDateTime();
//        org.joda.time.DateTime dateTime11 = dateTime7.withMillisOfSecond(999);
//        org.joda.time.DateTime dateTime12 = dateTime11.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime13 = dateTime12.toDateTime();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
//        int int18 = dateTime17.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.plus(readablePeriod19);
//        org.joda.time.DateTime dateTime22 = dateTime17.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology24);
//        int int26 = dateTime25.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.plus(readablePeriod27);
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long34 = dateTimeZone30.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime35 = dateTime25.withZoneRetainFields(dateTimeZone30);
//        org.joda.time.DateTime dateTime36 = dateTime22.withZoneRetainFields(dateTimeZone30);
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now(dateTimeZone30);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
//        boolean boolean39 = property8.equals((java.lang.Object) dateTime37);
//        java.lang.String str40 = property8.getAsShortText();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 39600052 + "'", int18 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 39600052 + "'", int26 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-125999990L) + "'", long34 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = iSOChronology1.withZone(dateTimeZone5);
        org.joda.time.DurationField durationField7 = iSOChronology1.months();
        org.joda.time.DurationField durationField8 = iSOChronology1.weeks();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusYears(53);
//        org.joda.time.DateTime.Property property16 = dateTime15.secondOfDay();
//        org.joda.time.DateTime dateTime18 = property16.addToCopy((long) 100);
//        org.joda.time.DateTime dateTime20 = property16.addToCopy((long) (-57600000));
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey(1L);
        long long10 = fixedDateTimeZone4.previousTransition(1560634403684L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+35:00" + "'", str8.equals("+35:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560634403684L + "'", long10 == 1560634403684L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField4 = new org.joda.time.field.ScaledDurationField(durationField1, durationFieldType2, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.secondOfMinute();
//        org.joda.time.DurationField durationField13 = iSOChronology0.centuries();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime16 = dateTime15.toDateTime();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField5 = iSOChronology4.hours();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.weekyearOfCentury();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        org.joda.time.DateTime dateTime15 = dateTime10.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property16 = dateTime15.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology18);
//        org.joda.time.DateTime dateTime21 = dateTime19.minusSeconds(1969);
//        int int22 = property16.compareTo((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime dateTime23 = property16.withMaximumValue();
//        org.joda.time.LocalTime localTime24 = dateTime23.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay25 = dateTime23.toTimeOfDay();
//        int[] intArray27 = iSOChronology4.get((org.joda.time.ReadablePartial) timeOfDay25, (-1L));
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
//        int int31 = dateTime30.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
//        org.joda.time.DateTime dateTime35 = dateTime30.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property36 = dateTime35.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology38);
//        org.joda.time.DateTime dateTime41 = dateTime39.minusSeconds(1969);
//        int int42 = property36.compareTo((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology45);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) iSOChronology45);
//        org.joda.time.DateTime dateTime48 = dateTime41.toDateTime((org.joda.time.Chronology) iSOChronology45);
//        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology50);
//        int int52 = dateTime51.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod53 = null;
//        org.joda.time.DateTime dateTime54 = dateTime51.plus(readablePeriod53);
//        org.joda.time.DateTime dateTime56 = dateTime51.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology59);
//        org.joda.time.DateTime dateTime62 = dateTime60.minusSeconds(1969);
//        int int63 = property57.compareTo((org.joda.time.ReadableInstant) dateTime62);
//        org.joda.time.DateTime dateTime64 = property57.withMaximumValue();
//        org.joda.time.LocalTime localTime65 = dateTime64.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay66 = dateTime64.toTimeOfDay();
//        int[] intArray68 = iSOChronology45.get((org.joda.time.ReadablePartial) timeOfDay66, (long) 0);
//        iSOChronology1.validate((org.joda.time.ReadablePartial) timeOfDay25, intArray68);
//        org.joda.time.DurationField durationField70 = iSOChronology1.hours();
//        org.joda.time.DurationFieldType durationFieldType71 = null;
//        try {
//            org.joda.time.field.DecoratedDurationField decoratedDurationField72 = new org.joda.time.field.DecoratedDurationField(durationField70, durationFieldType71);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(localTime24);
//        org.junit.Assert.assertNotNull(timeOfDay25);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(iSOChronology50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 39600052 + "'", int52 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(localTime65);
//        org.junit.Assert.assertNotNull(timeOfDay66);
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertNotNull(durationField70);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(30);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear(4, (int) (byte) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField7 = iSOChronology6.hours();
//        org.joda.time.DurationField durationField8 = iSOChronology6.years();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        int int12 = dateTime11.getMillisOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime11.withWeekyear(0);
//        int int15 = dateTime11.getMinuteOfHour();
//        boolean boolean16 = iSOChronology6.equals((java.lang.Object) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology6.millisOfSecond();
//        org.joda.time.Chronology chronology18 = iSOChronology6.withUTC();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology6.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology24);
//        int int26 = dateTime25.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.plus(readablePeriod27);
//        org.joda.time.DateTime dateTime30 = dateTime25.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology32);
//        int int34 = dateTime33.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime33.plus(readablePeriod35);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long42 = dateTimeZone38.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime43 = dateTime33.withZoneRetainFields(dateTimeZone38);
//        org.joda.time.DateTime dateTime44 = dateTime30.withZoneRetainFields(dateTimeZone38);
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now(dateTimeZone38);
//        org.joda.time.DateTime.Property property46 = dateTime45.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean48 = property46.equals((java.lang.Object) dateTimeFormatter47);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property46.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType49, 0, 57600052);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType49, 69, 3, 627);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField(dateTimeField19, dateTimeFieldType49, 999);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 39600052 + "'", int12 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 39600052 + "'", int26 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 39600052 + "'", int34 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-125999990L) + "'", long42 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        boolean boolean58 = unsupportedDateTimeField57.isSupported();
//        java.lang.String str59 = unsupportedDateTimeField57.getName();
//        try {
//            long long61 = unsupportedDateTimeField57.roundHalfEven((long) 30);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "secondOfMinute" + "'", str59.equals("secondOfMinute"));
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, (long) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("11:00:00.032", number1, (java.lang.Number) 1, (java.lang.Number) 1);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "11:00:00.032" + "'", str5.equals("11:00:00.032"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        boolean boolean14 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        int int15 = dateTime7.getDayOfYear();
//        org.joda.time.DateTime dateTime17 = dateTime7.withYear(999);
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime17.toMutableDateTimeISO();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) 'a');
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = dateTime2.toCalendar(locale3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(calendar4);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
//        int int14 = dateTime13.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
//        org.joda.time.DateTime dateTime18 = dateTime13.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology20);
//        int int22 = dateTime21.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime21.plus(readablePeriod23);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long30 = dateTimeZone26.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime31 = dateTime21.withZoneRetainFields(dateTimeZone26);
//        org.joda.time.DateTime dateTime32 = dateTime18.withZoneRetainFields(dateTimeZone26);
//        org.joda.time.DateTime dateTime33 = dateTime5.withZone(dateTimeZone26);
//        boolean boolean34 = iSOChronology1.equals((java.lang.Object) dateTime33);
//        org.joda.time.DateTime dateTime36 = dateTime33.minusWeeks((int) '4');
//        int int37 = dateTime33.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39600052 + "'", int14 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 39600052 + "'", int22 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-125999990L) + "'", long30 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("11:00:00.032", false);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("����-��-��T00:00", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("52", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"52/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) -1, 8, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
//        int int7 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.plus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
//        org.joda.time.DateTime dateTime14 = property12.roundHalfFloorCopy();
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
//        org.joda.time.DateTime dateTime22 = dateTime19.toDateTime();
//        org.joda.time.DateTime dateTime24 = dateTime19.minusWeeks(100);
//        boolean boolean25 = property12.equals((java.lang.Object) dateTime24);
//        boolean boolean26 = iSOChronology0.equals((java.lang.Object) boolean25);
//        org.joda.time.DurationField durationField27 = iSOChronology0.weeks();
//        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39600052 + "'", int7 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(chronology28);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = remainderDateTimeField44.getAsText((int) '#', locale46);
//        long long49 = remainderDateTimeField44.roundHalfEven(1560634403684L);
//        int int52 = remainderDateTimeField44.getDifference((long) 0, (long) 8);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "35" + "'", str47.equals("35"));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1546174800000L + "'", long49 == 1546174800000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField5 = iSOChronology0.halfdays();
        org.joda.time.DurationField durationField6 = iSOChronology0.millis();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        boolean boolean58 = unsupportedDateTimeField57.isSupported();
//        java.lang.String str59 = unsupportedDateTimeField57.getName();
//        java.util.Locale locale60 = null;
//        try {
//            int int61 = unsupportedDateTimeField57.getMaximumTextLength(locale60);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "secondOfMinute" + "'", str59.equals("secondOfMinute"));
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
//        long long6 = fixedDateTimeZone4.previousTransition(0L);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
//        org.joda.time.DateTime dateTime14 = dateTime9.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property15 = dateTime14.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds(1969);
//        int int21 = property15.compareTo((org.joda.time.ReadableInstant) dateTime20);
//        boolean boolean22 = fixedDateTimeZone4.equals((java.lang.Object) dateTime20);
//        java.util.TimeZone timeZone23 = fixedDateTimeZone4.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField47 = iSOChronology46.hours();
//        org.joda.time.DateTimeField dateTimeField48 = iSOChronology46.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology46.weekyearOfCentury();
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology51);
//        int int53 = dateTime52.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod54 = null;
//        org.joda.time.DateTime dateTime55 = dateTime52.plus(readablePeriod54);
//        org.joda.time.DateTime dateTime57 = dateTime52.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property58 = dateTime57.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology60 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology60);
//        org.joda.time.DateTime dateTime63 = dateTime61.minusSeconds(1969);
//        int int64 = property58.compareTo((org.joda.time.ReadableInstant) dateTime63);
//        org.joda.time.DateTime dateTime65 = property58.withMaximumValue();
//        org.joda.time.LocalTime localTime66 = dateTime65.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay67 = dateTime65.toTimeOfDay();
//        int[] intArray69 = iSOChronology46.get((org.joda.time.ReadablePartial) timeOfDay67, (-1L));
//        java.util.Locale locale70 = null;
//        java.lang.String str71 = remainderDateTimeField44.getAsText((org.joda.time.ReadablePartial) timeOfDay67, locale70);
//        java.util.Locale locale73 = null;
//        java.lang.String str74 = remainderDateTimeField44.getAsShortText((long) 1439, locale73);
//        long long76 = remainderDateTimeField44.roundHalfCeiling((long) (-32));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNull(durationField45);
//        org.junit.Assert.assertNotNull(iSOChronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 39600052 + "'", int53 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(iSOChronology60);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(localTime66);
//        org.junit.Assert.assertNotNull(timeOfDay67);
//        org.junit.Assert.assertNotNull(intArray69);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "972" + "'", str74.equals("972"));
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-126000000L) + "'", long76 == (-126000000L));
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField47 = iSOChronology46.hours();
//        org.joda.time.DateTimeField dateTimeField48 = iSOChronology46.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology46.weekyearOfCentury();
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology51);
//        int int53 = dateTime52.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod54 = null;
//        org.joda.time.DateTime dateTime55 = dateTime52.plus(readablePeriod54);
//        org.joda.time.DateTime dateTime57 = dateTime52.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property58 = dateTime57.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology60 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology60);
//        org.joda.time.DateTime dateTime63 = dateTime61.minusSeconds(1969);
//        int int64 = property58.compareTo((org.joda.time.ReadableInstant) dateTime63);
//        org.joda.time.DateTime dateTime65 = property58.withMaximumValue();
//        org.joda.time.LocalTime localTime66 = dateTime65.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay67 = dateTime65.toTimeOfDay();
//        int[] intArray69 = iSOChronology46.get((org.joda.time.ReadablePartial) timeOfDay67, (-1L));
//        java.util.Locale locale70 = null;
//        java.lang.String str71 = remainderDateTimeField44.getAsText((org.joda.time.ReadablePartial) timeOfDay67, locale70);
//        java.util.Locale locale73 = null;
//        java.lang.String str74 = remainderDateTimeField44.getAsShortText((long) 1439, locale73);
//        long long76 = remainderDateTimeField44.roundCeiling((long) (byte) 0);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNull(durationField45);
//        org.junit.Assert.assertNotNull(iSOChronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 39600052 + "'", int53 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(iSOChronology60);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(localTime66);
//        org.junit.Assert.assertNotNull(timeOfDay67);
//        org.junit.Assert.assertNotNull(intArray69);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "972" + "'", str74.equals("972"));
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 31410000000L + "'", long76 == 31410000000L);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        java.io.Writer writer1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology3);
//        int int5 = dateTime4.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
//        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology11);
//        int int13 = dateTime12.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.plus(readablePeriod14);
//        org.joda.time.DateTime dateTime17 = dateTime12.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology19);
//        int int21 = dateTime20.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.plus(readablePeriod22);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long29 = dateTimeZone25.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime30 = dateTime20.withZoneRetainFields(dateTimeZone25);
//        org.joda.time.DateTime dateTime31 = dateTime17.withZoneRetainFields(dateTimeZone25);
//        org.joda.time.DateTime dateTime32 = dateTime4.withZone(dateTimeZone25);
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology34);
//        int int36 = dateTime35.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime35.plus(readablePeriod37);
//        org.joda.time.LocalDateTime localDateTime39 = dateTime35.toLocalDateTime();
//        org.joda.time.DateTime dateTime40 = dateTime32.withFields((org.joda.time.ReadablePartial) localDateTime39);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDateTime39);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 39600052 + "'", int5 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 39600052 + "'", int13 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 39600052 + "'", int21 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-125999990L) + "'", long29 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 39600052 + "'", int36 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(localDateTime39);
//        org.junit.Assert.assertNotNull(dateTime40);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime2.plus((-125999990L));
//        int int10 = dateTime2.getMinuteOfDay();
//        int int11 = dateTime2.getCenturyOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField13 = iSOChronology12.hours();
//        org.joda.time.DurationField durationField14 = iSOChronology12.centuries();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.dayOfWeek();
//        org.joda.time.DateTime dateTime16 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology12.secondOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 660 + "'", int10 == 660);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter3.withZoneUTC();
        try {
            org.joda.time.MutableDateTime mutableDateTime6 = dateTimeFormatter4.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        boolean boolean58 = unsupportedDateTimeField57.isSupported();
//        java.lang.String str59 = unsupportedDateTimeField57.getName();
//        boolean boolean60 = unsupportedDateTimeField57.isLenient();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "secondOfMinute" + "'", str59.equals("secondOfMinute"));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        java.lang.String str58 = unsupportedDateTimeField57.getName();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "secondOfMinute" + "'", str58.equals("secondOfMinute"));
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long19 = dateTimeZone15.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime20 = dateTime10.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime21 = dateTime7.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone15);
//        int int23 = dateTime22.getHourOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime22.plusMillis(52);
//        org.joda.time.DateTime.Property property26 = dateTime25.monthOfYear();
//        try {
//            org.joda.time.DateTime dateTime28 = property26.setCopy(70);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-125999990L) + "'", long19 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTimeZone dateTimeZone6 = dateTime2.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        org.joda.time.DateTime dateTime15 = dateTime10.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology17);
//        int int19 = dateTime18.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime18.plus(readablePeriod20);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long27 = dateTimeZone23.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime28 = dateTime18.withZoneRetainFields(dateTimeZone23);
//        org.joda.time.DateTime dateTime29 = dateTime15.withZoneRetainFields(dateTimeZone23);
//        org.joda.time.DateTime dateTime30 = dateTime2.withZone(dateTimeZone23);
//        org.joda.time.DateTime dateTime32 = dateTime30.minusMonths(2019);
//        org.joda.time.DateTime.Property property33 = dateTime32.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime34 = dateTime32.toMutableDateTime();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 39600052 + "'", int19 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-125999990L) + "'", long27 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
//        org.joda.time.DateTime.Property property16 = dateTime6.millisOfSecond();
//        org.joda.time.Interval interval17 = property16.toInterval();
//        org.joda.time.DateTime dateTime18 = property16.roundHalfFloorCopy();
//        org.joda.time.DateTime.Property property19 = dateTime18.millisOfDay();
//        org.joda.time.DateTime dateTime21 = dateTime18.minusSeconds(39600);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology26);
//        int int28 = dateTime27.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.plus(readablePeriod29);
//        org.joda.time.DateTime dateTime32 = dateTime27.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology34);
//        int int36 = dateTime35.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime35.plus(readablePeriod37);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long44 = dateTimeZone40.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime45 = dateTime35.withZoneRetainFields(dateTimeZone40);
//        org.joda.time.DateTime dateTime46 = dateTime32.withZoneRetainFields(dateTimeZone40);
//        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now(dateTimeZone40);
//        org.joda.time.DateTime.Property property48 = dateTime47.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean50 = property48.equals((java.lang.Object) dateTimeFormatter49);
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property48.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder22.appendFraction(dateTimeFieldType51, 0, 57600052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder55.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology59);
//        int int61 = dateTime60.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod62 = null;
//        org.joda.time.DateTime dateTime63 = dateTime60.plus(readablePeriod62);
//        org.joda.time.DateTime dateTime65 = dateTime60.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology67);
//        int int69 = dateTime68.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod70 = null;
//        org.joda.time.DateTime dateTime71 = dateTime68.plus(readablePeriod70);
//        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long77 = dateTimeZone73.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime78 = dateTime68.withZoneRetainFields(dateTimeZone73);
//        org.joda.time.DateTime dateTime79 = dateTime65.withZoneRetainFields(dateTimeZone73);
//        org.joda.time.DateTime dateTime80 = org.joda.time.DateTime.now(dateTimeZone73);
//        org.joda.time.DateTime.Property property81 = dateTime80.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter82 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean83 = property81.equals((java.lang.Object) dateTimeFormatter82);
//        org.joda.time.DateTimeFieldType dateTimeFieldType84 = property81.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder87 = dateTimeFormatterBuilder55.appendFraction(dateTimeFieldType84, 0, 57600052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder88 = dateTimeFormatterBuilder54.appendShortText(dateTimeFieldType84);
//        boolean boolean89 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime21, (java.lang.Object) dateTimeFieldType84);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 39600052 + "'", int28 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 39600052 + "'", int36 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-125999990L) + "'", long44 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 39600052 + "'", int61 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(iSOChronology67);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 39600052 + "'", int69 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-125999990L) + "'", long77 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(dateTime79);
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertNotNull(property81);
//        org.junit.Assert.assertNotNull(dateTimeFormatter82);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType84);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder87);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder88);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        int int9 = fixedDateTimeZone4.getStandardOffset((long) 999);
        long long11 = fixedDateTimeZone4.convertUTCToLocal((-2419199948L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2419199949L) + "'", long11 == (-2419199949L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (short) 10);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
//        int int18 = dateTime17.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.plus(readablePeriod19);
//        org.joda.time.DateTime dateTime22 = dateTime17.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology24);
//        int int26 = dateTime25.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.plus(readablePeriod27);
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long34 = dateTimeZone30.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime35 = dateTime25.withZoneRetainFields(dateTimeZone30);
//        org.joda.time.DateTime dateTime36 = dateTime22.withZoneRetainFields(dateTimeZone30);
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now(dateTimeZone30);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
//        boolean boolean39 = property8.equals((java.lang.Object) dateTime37);
//        long long40 = property8.remainder();
//        org.joda.time.DateTime dateTime41 = property8.getDateTime();
//        org.joda.time.DateTime dateTime43 = property8.setCopy(1);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 39600052 + "'", int18 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 39600052 + "'", int26 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-125999990L) + "'", long34 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("11:00:00.032", number1, (java.lang.Number) 1, (java.lang.Number) 1);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        illegalFieldValueException4.prependMessage("era");
        java.lang.String str8 = illegalFieldValueException4.getFieldName();
        java.lang.Throwable[] throwableArray9 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "11:00:00.032" + "'", str5.equals("11:00:00.032"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "11:00:00.032" + "'", str8.equals("11:00:00.032"));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime15 = property8.roundHalfFloorCopy();
//        org.joda.time.YearMonthDay yearMonthDay16 = dateTime15.toYearMonthDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.hourOfHalfday();
//        org.joda.time.DurationField durationField20 = gregorianChronology17.millis();
//        org.joda.time.DateTime dateTime21 = dateTime15.withChronology((org.joda.time.Chronology) gregorianChronology17);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(yearMonthDay16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.minus(readableDuration16);
//        org.joda.time.DateTime dateTime18 = dateTime15.toDateTime();
//        org.joda.time.DateTime dateTime20 = dateTime15.minusWeeks(100);
//        boolean boolean21 = property8.equals((java.lang.Object) dateTime20);
//        org.joda.time.DateTime dateTime22 = property8.roundFloorCopy();
//        org.joda.time.DateTime dateTime24 = dateTime22.plusMinutes(660);
//        org.joda.time.YearMonthDay yearMonthDay25 = dateTime22.toYearMonthDay();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(yearMonthDay25);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendYearOfCentury((-100), 2922789);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long19 = dateTimeZone15.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime20 = dateTime10.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime21 = dateTime7.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone15);
//        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
//        org.joda.time.DateTime.Property property24 = dateTime22.weekyear();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-125999990L) + "'", long19 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(property24);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long19 = dateTimeZone15.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime20 = dateTime10.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime21 = dateTime7.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone15);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfMinute();
//        org.joda.time.DateTime.Property property24 = dateTime22.centuryOfEra();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-125999990L) + "'", long19 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(property24);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        int int4 = dateTime2.getYearOfEra();
//        long long5 = dateTime2.getMillis();
//        int int6 = dateTime2.getDayOfWeek();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = property8.addToCopy((long) 52);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField19 = iSOChronology18.hours();
//        org.joda.time.DurationField durationField20 = iSOChronology18.centuries();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        org.joda.time.Chronology chronology23 = iSOChronology18.withZone(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) 1, dateTimeZone22);
//        int int25 = property8.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime26 = property8.withMinimumValue();
//        int int27 = dateTime26.getYear();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-39600000) + "'", int25 == (-39600000));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1970 + "'", int27 == 1970);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendMillisOfSecond(152);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long9 = fixedDateTimeZone7.previousTransition(0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
        boolean boolean13 = fixedDateTimeZone7.equals((java.lang.Object) dateTimeZone12);
        long long16 = dateTimeZone12.adjustOffset(0L, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZone(dateTimeZone12);
        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatter17.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter17.withPivotYear((java.lang.Integer) 3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long27 = fixedDateTimeZone25.previousTransition(0L);
        long long29 = fixedDateTimeZone25.nextTransition(10L);
        java.lang.Class<?> wildcardClass30 = fixedDateTimeZone25.getClass();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter17.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.format.DateTimePrinter dateTimePrinter32 = dateTimeFormatter17.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimePrinter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimePrinter32);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMillisOfDay(53);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfDay(1970, (int) (short) 10);
//        boolean boolean12 = dateTimeFormatterBuilder11.canBuildFormatter();
//        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatterBuilder11.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendMillisOfSecond(34);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.hours();
//        org.joda.time.DurationField durationField18 = iSOChronology16.years();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology20);
//        int int22 = dateTime21.getMillisOfDay();
//        org.joda.time.DateTime dateTime24 = dateTime21.withWeekyear(0);
//        int int25 = dateTime21.getMinuteOfHour();
//        boolean boolean26 = iSOChronology16.equals((java.lang.Object) dateTime21);
//        org.joda.time.DurationField durationField27 = iSOChronology16.seconds();
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
//        int int31 = dateTime30.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
//        org.joda.time.DateTime dateTime35 = dateTime30.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology37);
//        int int39 = dateTime38.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod40 = null;
//        org.joda.time.DateTime dateTime41 = dateTime38.plus(readablePeriod40);
//        org.joda.time.DateTime dateTime43 = dateTime38.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology45);
//        int int47 = dateTime46.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod48 = null;
//        org.joda.time.DateTime dateTime49 = dateTime46.plus(readablePeriod48);
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long55 = dateTimeZone51.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime56 = dateTime46.withZoneRetainFields(dateTimeZone51);
//        org.joda.time.DateTime dateTime57 = dateTime43.withZoneRetainFields(dateTimeZone51);
//        org.joda.time.DateTime dateTime58 = dateTime30.withZone(dateTimeZone51);
//        org.joda.time.chrono.ZonedChronology zonedChronology59 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology16, dateTimeZone51);
//        org.joda.time.DateTimeField dateTimeField60 = zonedChronology59.secondOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone65 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone66 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone65);
//        java.lang.String str68 = cachedDateTimeZone66.getNameKey((long) 57600052);
//        org.joda.time.Chronology chronology69 = zonedChronology59.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone66);
//        org.joda.time.DateTimeField dateTimeField70 = zonedChronology59.clockhourOfHalfday();
//        boolean boolean71 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFormatterBuilder11, (java.lang.Object) zonedChronology59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(dateTimeParser13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 39600052 + "'", int22 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 39600052 + "'", int39 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 39600052 + "'", int47 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-125999990L) + "'", long55 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(zonedChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone66);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "+35:00" + "'", str68.equals("+35:00"));
//        org.junit.Assert.assertNotNull(chronology69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTime dateTime9 = property8.roundCeilingCopy();
//        org.joda.time.DateTime.Property property10 = dateTime9.secondOfMinute();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
//        int int18 = dateTime17.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.plus(readablePeriod19);
//        org.joda.time.DateTime dateTime22 = dateTime17.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology24);
//        int int26 = dateTime25.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.plus(readablePeriod27);
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long34 = dateTimeZone30.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime35 = dateTime25.withZoneRetainFields(dateTimeZone30);
//        org.joda.time.DateTime dateTime36 = dateTime22.withZoneRetainFields(dateTimeZone30);
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now(dateTimeZone30);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfMinute();
//        boolean boolean39 = property8.equals((java.lang.Object) dateTime37);
//        org.joda.time.DateTime dateTime41 = dateTime37.withYear(126000000);
//        org.joda.time.DateTime.Property property42 = dateTime41.weekyear();
//        org.joda.time.DateTime dateTime43 = property42.roundCeilingCopy();
//        org.joda.time.DateTime dateTime44 = property42.withMaximumValue();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 39600052 + "'", int18 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 39600052 + "'", int26 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-125999990L) + "'", long34 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime44);
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime2.plus((-125999990L));
//        int int10 = dateTime2.getMinuteOfDay();
//        int int11 = dateTime2.getCenturyOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField13 = iSOChronology12.hours();
//        org.joda.time.DurationField durationField14 = iSOChronology12.centuries();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.dayOfWeek();
//        org.joda.time.DateTime dateTime16 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology12.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.clockhourOfHalfday();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 660 + "'", int10 == 660);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusSeconds((-57600000));
//        boolean boolean11 = dateTime9.isBefore((long) 1);
//        org.joda.time.DateTime dateTime13 = dateTime9.plusMonths(999);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMillisOfDay(53);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfMinute((int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendFractionOfDay(152, 126000000);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology15);
//        org.joda.time.YearMonthDay yearMonthDay17 = dateTime16.toYearMonthDay();
//        int int18 = dateTime16.getYearOfEra();
//        org.joda.time.DateTime.Property property19 = dateTime16.centuryOfEra();
//        org.joda.time.DurationField durationField20 = property19.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property19.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendFraction(dateTimeFieldType21, 100, (-19));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(yearMonthDay17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1970 + "'", int18 == 1970);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.lang.Object obj6 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long13 = fixedDateTimeZone11.previousTransition(0L);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj6, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        java.util.TimeZone timeZone15 = fixedDateTimeZone11.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) (short) 0, 660, 4, 10, (int) '#', 627, dateTimeZone16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 627 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property11 = dateTime10.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) property11);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology15);
//        int int17 = dateTime16.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime16.plus(readablePeriod18);
//        org.joda.time.DateTime dateTime21 = dateTime16.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology23);
//        int int25 = dateTime24.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.plus(readablePeriod26);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long33 = dateTimeZone29.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime34 = dateTime24.withZoneRetainFields(dateTimeZone29);
//        org.joda.time.DateTime dateTime35 = dateTime21.withZoneRetainFields(dateTimeZone29);
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now(dateTimeZone29);
//        int int37 = dateTime36.getHourOfDay();
//        boolean boolean38 = property11.equals((java.lang.Object) dateTime36);
//        org.joda.time.DateTime dateTime39 = property11.roundFloorCopy();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 39600052 + "'", int17 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 39600052 + "'", int25 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-125999990L) + "'", long33 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 8 + "'", int37 == 8);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTime39);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = property8.addToCopy((long) 52);
//        int int17 = dateTime16.getYearOfCentury();
//        int int18 = dateTime16.getCenturyOfEra();
//        boolean boolean20 = dateTime16.isAfter((long) '4');
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 70 + "'", int17 == 70);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19 + "'", int18 == 19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime9.withCenturyOfEra((int) (byte) 0);
//        org.joda.time.DateTime dateTime17 = dateTime9.minusMinutes(5);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfWeek(0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendTimeZoneShortName(strMap9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime2.plus((-125999990L));
//        int int10 = dateTime2.getMinuteOfDay();
//        int int11 = dateTime2.getCenturyOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField13 = iSOChronology12.hours();
//        org.joda.time.DurationField durationField14 = iSOChronology12.centuries();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.dayOfWeek();
//        org.joda.time.DateTime dateTime16 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology12.dayOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, dateTimeFieldType18, 1439);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 660 + "'", int10 == 660);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        int int4 = dateTime2.getYearOfEra();
//        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
//        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths(62);
//        int int8 = dateTime2.getYear();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.YearMonthDay yearMonthDay13 = dateTime12.toYearMonthDay();
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime15 = property8.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime17 = dateTime15.minusMillis(660);
//        int int18 = dateTime17.getSecondOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(yearMonthDay13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86399 + "'", int18 == 86399);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology7);
//        int int9 = dateTime8.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.plus(readablePeriod10);
//        org.joda.time.DateTime dateTime13 = dateTime8.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property14 = dateTime13.millisOfSecond();
//        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
//        boolean boolean16 = cachedDateTimeZone5.isLocalDateTimeGap(localDateTime15);
//        long long18 = cachedDateTimeZone5.previousTransition((long) 57600052);
//        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone5.getUncachedZone();
//        int int21 = cachedDateTimeZone5.getStandardOffset(599616000011L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 39600052 + "'", int9 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 57600052L + "'", long18 == 57600052L);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = iSOChronology1.withZone(dateTimeZone5);
        org.joda.time.DurationField durationField7 = iSOChronology1.months();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology1.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = remainderDateTimeField44.getAsText((int) '#', locale46);
//        int int48 = remainderDateTimeField44.getMinimumValue();
//        long long51 = remainderDateTimeField44.getDifferenceAsLong((long) '4', (long) (-39600052));
//        java.util.Locale locale54 = null;
//        try {
//            long long55 = remainderDateTimeField44.set(1560634403684L, "secondOfMinute", locale54);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"secondOfMinute\" for secondOfMinute is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "35" + "'", str47.equals("35"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("11:00:00.032", number1, (java.lang.Number) 1, (java.lang.Number) 1);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        illegalFieldValueException4.prependMessage("era");
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number11 = illegalFieldValueException10.getUpperBound();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "11:00:00.032" + "'", str5.equals("11:00:00.032"));
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.lang.Object obj1 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long8 = fixedDateTimeZone6.previousTransition(0L);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(obj1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        java.util.TimeZone timeZone10 = fixedDateTimeZone6.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(35L, dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (-57600000));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = remainderDateTimeField44.getAsText((int) '#', locale46);
//        int int48 = remainderDateTimeField44.getMinimumValue();
//        long long51 = remainderDateTimeField44.getDifferenceAsLong((long) '4', (long) (-39600052));
//        int int53 = remainderDateTimeField44.get(1L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "35" + "'", str47.equals("35"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 972 + "'", int53 == 972);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
//        int int7 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.plus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
//        org.joda.time.DateTime dateTime14 = property12.roundHalfFloorCopy();
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
//        org.joda.time.DateTime dateTime22 = dateTime19.toDateTime();
//        org.joda.time.DateTime dateTime24 = dateTime19.minusWeeks(100);
//        boolean boolean25 = property12.equals((java.lang.Object) dateTime24);
//        boolean boolean26 = iSOChronology0.equals((java.lang.Object) boolean25);
//        org.joda.time.DurationField durationField27 = iSOChronology0.weeks();
//        org.joda.time.DurationFieldType durationFieldType28 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField30 = new org.joda.time.field.ScaledDurationField(durationField27, durationFieldType28, 86399);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39600052 + "'", int7 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(durationField27);
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
//        int int14 = dateTime13.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long22 = dateTimeZone18.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime23 = dateTime13.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTime dateTime24 = dateTime10.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime.Property property26 = dateTime25.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean28 = property26.equals((java.lang.Object) dateTimeFormatter27);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property26.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType29, 0, 57600052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (byte) 0, 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendLiteral("");
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39600052 + "'", int14 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-125999990L) + "'", long22 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.LocalDateTime localDateTime6 = dateTime2.toLocalDateTime();
//        org.joda.time.DateTime dateTime8 = dateTime2.withEra(0);
//        org.joda.time.DateTime dateTime10 = dateTime2.withCenturyOfEra((int) (short) 0);
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime2.minus(readableDuration11);
//        int int13 = dateTime12.getHourOfDay();
//        org.joda.time.DateTime.Property property14 = dateTime12.secondOfMinute();
//        org.joda.time.DateTime dateTime16 = property14.addWrapFieldToCopy(5);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "52");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 126000053L, (java.lang.Number) 627, (java.lang.Number) 999);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) unsupportedDateTimeField57, 34, 1969, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 34 for secondOfMinute must be in the range [1969,0]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        boolean boolean58 = unsupportedDateTimeField57.isSupported();
//        java.lang.String str59 = unsupportedDateTimeField57.getName();
//        long long62 = unsupportedDateTimeField57.add(128L, 1560634372660L);
//        try {
//            int int64 = unsupportedDateTimeField57.getMaximumValue((long) 70);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "secondOfMinute" + "'", str59.equals("secondOfMinute"));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560634372660128L + "'", long62 == 1560634372660128L);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime2.minusMonths(19);
//        int int10 = dateTime2.getYear();
//        org.joda.time.DateTime dateTime11 = dateTime2.withEarlierOffsetAtOverlap();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYearOfEra(70, 152);
        boolean boolean7 = dateTimeFormatterBuilder3.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        boolean boolean14 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        int int15 = dateTime7.getDayOfYear();
//        int int16 = dateTime7.getSecondOfMinute();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime7.toMutableDateTime(chronology17);
//        org.joda.time.DateTime dateTime20 = dateTime7.withMillis((long) 19);
//        int int21 = dateTime7.getDayOfYear();
//        org.joda.time.DateTime dateTime23 = dateTime7.plusSeconds((int) (byte) 10);
//        org.joda.time.ReadableDuration readableDuration24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime7.minus(readableDuration24);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
//        org.joda.time.DateTime dateTime19 = dateTime14.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
//        int int23 = dateTime22.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
//        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
//        int int31 = dateTime30.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime42 = dateTime14.withZone(dateTimeZone35);
//        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone35);
//        org.joda.time.DateTimeField dateTimeField44 = zonedChronology43.weekOfWeekyear();
//        try {
//            long long50 = zonedChronology43.getDateTimeMillis(0L, 660, 1520000, 0, (-39600000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 660 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(zonedChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        int int4 = dateTime2.getYearOfEra();
//        org.joda.time.DateTime dateTime6 = dateTime2.withWeekyear((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusYears(57600052);
//        org.joda.time.DateTime.Property property10 = dateTime6.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = remainderDateTimeField44.getAsText((int) '#', locale46);
//        boolean boolean48 = remainderDateTimeField44.isSupported();
//        long long51 = remainderDateTimeField44.getDifferenceAsLong((long) 53, (long) (byte) -1);
//        int int54 = remainderDateTimeField44.getDifference(1560634372660L, (long) 34);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "35" + "'", str47.equals("35"));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 49 + "'", int54 == 49);
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = remainderDateTimeField44.getAsText((int) '#', locale46);
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology50);
//        int int52 = dateTime51.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod53 = null;
//        org.joda.time.DateTime dateTime54 = dateTime51.plus(readablePeriod53);
//        org.joda.time.DateTime dateTime56 = dateTime51.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.LocalDateTime localDateTime58 = dateTime56.toLocalDateTime();
//        long long60 = gregorianChronology48.set((org.joda.time.ReadablePartial) localDateTime58, (long) 53);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = remainderDateTimeField44.getAsText((org.joda.time.ReadablePartial) localDateTime58, locale61);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "35" + "'", str47.equals("35"));
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(iSOChronology50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 39600052 + "'", int52 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(localDateTime58);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-39599999L) + "'", long60 == (-39599999L));
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "0" + "'", str62.equals("0"));
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField5 = iSOChronology4.hours();
        org.joda.time.DurationField durationField6 = iSOChronology4.centuries();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.Chronology chronology9 = iSOChronology4.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 1, dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(zonedChronology11);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        try {
//            java.lang.String str59 = unsupportedDateTimeField57.getAsShortText((long) 365);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfSecond();
//        org.joda.time.Chronology chronology12 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology18);
//        int int20 = dateTime19.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.plus(readablePeriod21);
//        org.joda.time.DateTime dateTime24 = dateTime19.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology26);
//        int int28 = dateTime27.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.plus(readablePeriod29);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long36 = dateTimeZone32.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime37 = dateTime27.withZoneRetainFields(dateTimeZone32);
//        org.joda.time.DateTime dateTime38 = dateTime24.withZoneRetainFields(dateTimeZone32);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone32);
//        org.joda.time.DateTime.Property property40 = dateTime39.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean42 = property40.equals((java.lang.Object) dateTimeFormatter41);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property40.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType43, 0, 57600052);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType43, 69, 3, 627);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType43, 999);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        java.util.Locale locale54 = dateTimeFormatter53.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = dateTimeFormatter53.withDefaultYear((int) (byte) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology58);
//        org.joda.time.YearMonthDay yearMonthDay60 = dateTime59.toYearMonthDay();
//        boolean boolean61 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay60);
//        java.lang.String str62 = dateTimeFormatter56.print((org.joda.time.ReadablePartial) yearMonthDay60);
//        int int63 = remainderDateTimeField52.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay60);
//        java.util.Locale locale64 = null;
//        int int65 = remainderDateTimeField52.getMaximumTextLength(locale64);
//        long long68 = remainderDateTimeField52.set((long) (short) 0, 0);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 39600052 + "'", int20 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 39600052 + "'", int28 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-125999990L) + "'", long36 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNull(locale54);
//        org.junit.Assert.assertNotNull(dateTimeFormatter56);
//        org.junit.Assert.assertNotNull(iSOChronology58);
//        org.junit.Assert.assertNotNull(yearMonthDay60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1970-01-02T��:��" + "'", str62.equals("1970-01-02T��:��"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 3 + "'", int65 == 3);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-639000L) + "'", long68 == (-639000L));
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.LocalDateTime localDateTime6 = dateTime2.toLocalDateTime();
//        org.joda.time.DateTime dateTime8 = dateTime2.withEra(0);
//        org.joda.time.DateTime dateTime10 = dateTime2.withCenturyOfEra((int) (short) 0);
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime2.minus(readableDuration11);
//        int int13 = dateTime12.getHourOfDay();
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime12.withMonthOfYear(70);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((-32), (int) (short) 1, (int) (short) 1, 1439, 999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
//        org.joda.time.DateTime dateTime19 = dateTime14.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
//        int int23 = dateTime22.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
//        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
//        int int31 = dateTime30.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime42 = dateTime14.withZone(dateTimeZone35);
//        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone35);
//        org.joda.time.DateTimeField dateTimeField44 = zonedChronology43.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder45.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder48.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder48.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology55);
//        int int57 = dateTime56.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod58 = null;
//        org.joda.time.DateTime dateTime59 = dateTime56.plus(readablePeriod58);
//        org.joda.time.DateTime dateTime61 = dateTime56.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology63);
//        int int65 = dateTime64.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod66 = null;
//        org.joda.time.DateTime dateTime67 = dateTime64.plus(readablePeriod66);
//        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long73 = dateTimeZone69.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime74 = dateTime64.withZoneRetainFields(dateTimeZone69);
//        org.joda.time.DateTime dateTime75 = dateTime61.withZoneRetainFields(dateTimeZone69);
//        org.joda.time.DateTime dateTime76 = org.joda.time.DateTime.now(dateTimeZone69);
//        org.joda.time.DateTime.Property property77 = dateTime76.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter78 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean79 = property77.equals((java.lang.Object) dateTimeFormatter78);
//        org.joda.time.DateTimeFieldType dateTimeFieldType80 = property77.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder48.appendSignedDecimal(dateTimeFieldType80, (int) (byte) 1, (int) '4');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField(dateTimeField44, dateTimeFieldType80, 2);
//        int int87 = dividedDateTimeField85.get((long) 10);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(zonedChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//        org.junit.Assert.assertNotNull(iSOChronology55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 39600052 + "'", int57 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(iSOChronology63);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 39600052 + "'", int65 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTimeZone69);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-125999990L) + "'", long73 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertNotNull(property77);
//        org.junit.Assert.assertNotNull(dateTimeFormatter78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType80);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 19800 + "'", int87 == 19800);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("1", 152, 69, 62);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 152 for 1 must be in the range [69,62]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime2.plus((-125999990L));
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
//        boolean boolean12 = dateTime9.isEqualNow();
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime9.withDurationAdded(readableDuration13, 30);
//        boolean boolean17 = dateTime15.isEqual((long) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime15.toDateTimeISO();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1970-01-02T��:��");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1970-01-02T��:��' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        int int4 = dateTime2.getYearOfEra();
//        long long5 = dateTime2.getMillis();
//        int int6 = dateTime2.getWeekyear();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0);
        dateTimeFormatterBuilder2.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        int int60 = unsupportedDateTimeField57.getDifference(1000L, 0L);
//        org.joda.time.DurationField durationField61 = unsupportedDateTimeField57.getDurationField();
//        try {
//            int int63 = unsupportedDateTimeField57.getMaximumValue(1560634372660L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertNotNull(durationField61);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = remainderDateTimeField44.getAsText((int) '#', locale46);
//        int int48 = remainderDateTimeField44.getMinimumValue();
//        long long51 = remainderDateTimeField44.getDifferenceAsLong((long) '4', (long) (-39600052));
//        org.joda.time.DurationField durationField52 = remainderDateTimeField44.getDurationField();
//        org.joda.time.DurationField durationField53 = remainderDateTimeField44.getRangeDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "35" + "'", str47.equals("35"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(durationField53);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfSecond();
//        org.joda.time.Chronology chronology12 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.minuteOfHour();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
//        org.joda.time.DateTime.Property property16 = dateTime6.millisOfSecond();
//        org.joda.time.Interval interval17 = property16.toInterval();
//        org.joda.time.DateTime dateTime18 = property16.roundHalfFloorCopy();
//        org.joda.time.DateTime.Property property19 = dateTime18.millisOfDay();
//        int int20 = dateTime18.getDayOfMonth();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime2.minusMonths(19);
//        int int10 = dateTime2.getYear();
//        java.util.Locale locale11 = null;
//        java.util.Calendar calendar12 = dateTime2.toCalendar(locale11);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
//        org.junit.Assert.assertNotNull(calendar12);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = property8.addToCopy((long) 52);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField19 = iSOChronology18.hours();
//        org.joda.time.DurationField durationField20 = iSOChronology18.centuries();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        org.joda.time.Chronology chronology23 = iSOChronology18.withZone(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) 1, dateTimeZone22);
//        int int25 = property8.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime26 = property8.withMinimumValue();
//        java.lang.String str27 = property8.getAsString();
//        try {
//            org.joda.time.DateTime dateTime29 = property8.setCopy("era");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"era\" for millisOfSecond is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-39600000) + "'", int25 == (-39600000));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1" + "'", str27.equals("1"));
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        boolean boolean14 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        int int15 = dateTime7.getDayOfYear();
//        org.joda.time.DateTime dateTime17 = dateTime7.withYear(999);
//        int int18 = dateTime17.getEra();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
//        org.joda.time.DateTime.Property property16 = dateTime6.millisOfSecond();
//        org.joda.time.Interval interval17 = property16.toInterval();
//        org.joda.time.DateTime dateTime18 = property16.roundHalfFloorCopy();
//        int int19 = property16.getMaximumValue();
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
//        int int23 = dateTime22.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long31 = dateTimeZone27.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime32 = dateTime22.withZoneRetainFields(dateTimeZone27);
//        org.joda.time.DateTime dateTime34 = dateTime32.plusYears((int) (short) -1);
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology36);
//        int int38 = dateTime37.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod39 = null;
//        org.joda.time.DateTime dateTime40 = dateTime37.plus(readablePeriod39);
//        org.joda.time.DateTime dateTime42 = dateTime37.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property43 = dateTime42.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField44 = property43.getField();
//        int int45 = dateTime34.get(dateTimeField44);
//        org.joda.time.ReadablePeriod readablePeriod46 = null;
//        org.joda.time.DateTime dateTime48 = dateTime34.withPeriodAdded(readablePeriod46, 5);
//        boolean boolean50 = dateTime34.isAfter((-126000000L));
//        try {
//            int int51 = property16.getDifference((org.joda.time.ReadableInstant) dateTime34);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 31534031000");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 999 + "'", int19 == 999);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-125999990L) + "'", long31 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 39600052 + "'", int38 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 52 + "'", int45 == 52);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime2.withWeekyear(0);
//        org.joda.time.DateTime dateTime7 = dateTime2.minusWeeks((int) (byte) 100);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime2.plus(readableDuration8);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        boolean boolean4 = dateTimeFormatterBuilder1.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfSecond(10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder9.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendWeekyear((int) ' ', 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        java.lang.String str10 = property8.getAsText();
//        org.joda.time.DateTime dateTime12 = property8.setCopy(152);
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.withDurationAdded(readableDuration13, 19800);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime11 = property8.roundHalfFloorCopy();
//        java.lang.String str12 = property8.getAsString();
//        org.joda.time.DurationField durationField13 = property8.getLeapDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//        org.junit.Assert.assertNull(durationField13);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
//        int int14 = dateTime13.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long22 = dateTimeZone18.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime23 = dateTime13.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTime dateTime24 = dateTime10.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime.Property property26 = dateTime25.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean28 = property26.equals((java.lang.Object) dateTimeFormatter27);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property26.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType29, 0, 57600052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (byte) 0, 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder0.appendYearOfEra((int) 'a', 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39600052 + "'", int14 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-125999990L) + "'", long22 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
//        org.joda.time.DateTime dateTime19 = dateTime14.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
//        int int23 = dateTime22.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
//        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
//        int int31 = dateTime30.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime42 = dateTime14.withZone(dateTimeZone35);
//        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone35);
//        org.joda.time.DateTimeField dateTimeField44 = zonedChronology43.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone45 = zonedChronology43.getZone();
//        org.joda.time.DurationField durationField46 = zonedChronology43.weeks();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(zonedChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(durationField46);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMillisOfDay(53);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfMinute((int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendFractionOfDay(152, 126000000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology18);
//        int int20 = dateTime19.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.plus(readablePeriod21);
//        org.joda.time.DateTime dateTime24 = dateTime19.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology26);
//        int int28 = dateTime27.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.plus(readablePeriod29);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long36 = dateTimeZone32.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime37 = dateTime27.withZoneRetainFields(dateTimeZone32);
//        org.joda.time.DateTime dateTime38 = dateTime24.withZoneRetainFields(dateTimeZone32);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone32);
//        org.joda.time.DateTime.Property property40 = dateTime39.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean42 = property40.equals((java.lang.Object) dateTimeFormatter41);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property40.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType43, 0, 57600052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder13.appendFixedSignedDecimal(dateTimeFieldType43, 30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 39600052 + "'", int20 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 39600052 + "'", int28 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-125999990L) + "'", long36 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        java.lang.String str4 = dateTimeZone2.getShortName((long) (byte) 1);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+35:00" + "'", str4.equals("+35:00"));
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        boolean boolean58 = unsupportedDateTimeField57.isSupported();
//        java.lang.String str59 = unsupportedDateTimeField57.getName();
//        try {
//            long long62 = unsupportedDateTimeField57.addWrapField((long) 34, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "secondOfMinute" + "'", str59.equals("secondOfMinute"));
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.Chronology chronology5 = iSOChronology0.withZone(dateTimeZone4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTimeZone4.getShortName(0L, locale7);
        java.lang.String str9 = dateTimeZone4.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+35:00" + "'", str8.equals("+35:00"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+35:00" + "'", str9.equals("+35:00"));
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = remainderDateTimeField44.getAsText((int) '#', locale46);
//        boolean boolean48 = remainderDateTimeField44.isSupported();
//        long long51 = remainderDateTimeField44.getDifferenceAsLong((long) (-39600052), (long) 19);
//        long long54 = remainderDateTimeField44.add((long) 57600052, 0);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "35" + "'", str47.equals("35"));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 57600052L + "'", long54 == 57600052L);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
//        org.joda.time.DateTime dateTime19 = dateTime14.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
//        int int23 = dateTime22.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
//        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
//        int int31 = dateTime30.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime42 = dateTime14.withZone(dateTimeZone35);
//        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone35);
//        org.joda.time.DateTimeField dateTimeField44 = zonedChronology43.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder45.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder48.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder48.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology55);
//        int int57 = dateTime56.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod58 = null;
//        org.joda.time.DateTime dateTime59 = dateTime56.plus(readablePeriod58);
//        org.joda.time.DateTime dateTime61 = dateTime56.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology63);
//        int int65 = dateTime64.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod66 = null;
//        org.joda.time.DateTime dateTime67 = dateTime64.plus(readablePeriod66);
//        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long73 = dateTimeZone69.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime74 = dateTime64.withZoneRetainFields(dateTimeZone69);
//        org.joda.time.DateTime dateTime75 = dateTime61.withZoneRetainFields(dateTimeZone69);
//        org.joda.time.DateTime dateTime76 = org.joda.time.DateTime.now(dateTimeZone69);
//        org.joda.time.DateTime.Property property77 = dateTime76.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter78 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean79 = property77.equals((java.lang.Object) dateTimeFormatter78);
//        org.joda.time.DateTimeFieldType dateTimeFieldType80 = property77.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder48.appendSignedDecimal(dateTimeFieldType80, (int) (byte) 1, (int) '4');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField(dateTimeField44, dateTimeFieldType80, 2);
//        int int88 = dividedDateTimeField85.getDifference((-1L), (long) 100);
//        long long91 = dividedDateTimeField85.set((long) 126000000, 52);
//        int int92 = dividedDateTimeField85.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(zonedChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//        org.junit.Assert.assertNotNull(iSOChronology55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 39600052 + "'", int57 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(iSOChronology63);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 39600052 + "'", int65 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTimeZone69);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-125999990L) + "'", long73 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertNotNull(property77);
//        org.junit.Assert.assertNotNull(dateTimeFormatter78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType80);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 46904000L + "'", long91 == 46904000L);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
//    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        boolean boolean58 = unsupportedDateTimeField57.isSupported();
//        java.lang.String str59 = unsupportedDateTimeField57.getName();
//        try {
//            java.lang.String str61 = unsupportedDateTimeField57.getAsShortText((long) (-32));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "secondOfMinute" + "'", str59.equals("secondOfMinute"));
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField4 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType2, 999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime15 = property8.withMaximumValue();
//        org.joda.time.LocalTime localTime16 = dateTime15.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay17 = dateTime15.toTimeOfDay();
//        org.joda.time.DateTime dateTime19 = dateTime15.withMillis((-39599999L));
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localTime16);
//        org.junit.Assert.assertNotNull(timeOfDay17);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        boolean boolean4 = dateTimeFormatterBuilder1.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfSecond(10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendHourOfHalfday(57600052);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitWeekyear(39600, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendDayOfYear(1439);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale16 = dateTimeFormatter15.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter15.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter18.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser20 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter19, dateTimeParser20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter22.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendTwoDigitWeekyear(10, true);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale29 = dateTimeFormatter28.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter30 = dateTimeFormatter28.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser31 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter30, dateTimeParser31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeParser dateTimeParser34 = dateTimeFormatter33.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder24.append(dateTimePrinter30, dateTimeParser34);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatter36.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale39 = dateTimeFormatter38.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter38.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = dateTimeFormatter38.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser43 = dateTimeFormatter42.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray44 = new org.joda.time.format.DateTimeParser[] { dateTimeParser23, dateTimeParser34, dateTimeParser37, dateTimeParser43 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder14.append(dateTimePrinter19, dateTimeParserArray44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNull(locale16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNull(locale29);
        org.junit.Assert.assertNotNull(dateTimePrinter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeParser34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeParser37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNull(locale39);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(dateTimeParser43);
        org.junit.Assert.assertNotNull(dateTimeParserArray44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology3);
//        int int5 = dateTime4.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
//        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime11 = dateTime4.plus((-125999990L));
//        int int12 = dateTime4.getMinuteOfDay();
//        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 39600052 + "'", int5 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 660 + "'", int12 == 660);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = remainderDateTimeField44.getAsText((int) '#', locale46);
//        int int48 = remainderDateTimeField44.getMinimumValue();
//        long long51 = remainderDateTimeField44.getDifferenceAsLong((long) '4', (long) (-39600052));
//        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology53);
//        int int55 = dateTime54.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod56 = null;
//        org.joda.time.DateTime dateTime57 = dateTime54.plus(readablePeriod56);
//        org.joda.time.DateTime dateTime59 = dateTime54.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property60 = dateTime59.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology62 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology62);
//        org.joda.time.DateTime dateTime65 = dateTime63.minusSeconds(1969);
//        int int66 = property60.compareTo((org.joda.time.ReadableInstant) dateTime65);
//        org.joda.time.DateTime dateTime67 = property60.withMaximumValue();
//        org.joda.time.LocalTime localTime68 = dateTime67.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay69 = dateTime67.toTimeOfDay();
//        org.joda.time.LocalTime localTime70 = dateTime67.toLocalTime();
//        java.util.Locale locale72 = null;
//        java.lang.String str73 = remainderDateTimeField44.getAsShortText((org.joda.time.ReadablePartial) localTime70, 999, locale72);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "35" + "'", str47.equals("35"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 39600052 + "'", int55 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(iSOChronology62);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(localTime68);
//        org.junit.Assert.assertNotNull(timeOfDay69);
//        org.junit.Assert.assertNotNull(localTime70);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "999" + "'", str73.equals("999"));
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = property8.addToCopy((long) 52);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField19 = iSOChronology18.hours();
//        org.joda.time.DurationField durationField20 = iSOChronology18.centuries();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        org.joda.time.Chronology chronology23 = iSOChronology18.withZone(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) 1, dateTimeZone22);
//        int int25 = property8.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.Interval interval26 = property8.toInterval();
//        org.joda.time.DateTime dateTime28 = property8.setCopy(49);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-39600000) + "'", int25 == (-39600000));
//        org.junit.Assert.assertNotNull(interval26);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        boolean boolean4 = dateTimeFormatterBuilder1.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfSecond(10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendMinuteOfDay(5);
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendTimeZoneOffset("1", false, 0, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 39600052);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        java.util.Date date3 = dateTime1.toDate();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(34, 0, 0, 1969);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 34 + "'", int4 == 34);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        long long7 = dateTimeZone2.convertLocalToUTC(126000053L, false, (-125999373L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 53L + "'", long7 == 53L);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        boolean boolean4 = dateTimeFormatterBuilder1.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfSecond(10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendHourOfHalfday(57600052);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitWeekyear(39600, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str8 = fixedDateTimeZone4.getName(700L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-00:00:00.001" + "'", str8.equals("-00:00:00.001"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.toString();
        java.lang.String str4 = jodaTimePermission1.toString();
        java.lang.String str5 = jodaTimePermission1.toString();
        java.security.PermissionCollection permissionCollection6 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("1");
        java.lang.String str9 = jodaTimePermission8.getName();
        boolean boolean10 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"1\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"1\")"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"1\")"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"1\")"));
        org.junit.Assert.assertNotNull(permissionCollection6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
//        int int14 = dateTime13.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long22 = dateTimeZone18.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime23 = dateTime13.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTime dateTime24 = dateTime10.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime.Property property26 = dateTime25.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean28 = property26.equals((java.lang.Object) dateTimeFormatter27);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property26.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType29, 0, 57600052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology37);
//        int int39 = dateTime38.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod40 = null;
//        org.joda.time.DateTime dateTime41 = dateTime38.plus(readablePeriod40);
//        org.joda.time.DateTime dateTime43 = dateTime38.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology45);
//        int int47 = dateTime46.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod48 = null;
//        org.joda.time.DateTime dateTime49 = dateTime46.plus(readablePeriod48);
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long55 = dateTimeZone51.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime56 = dateTime46.withZoneRetainFields(dateTimeZone51);
//        org.joda.time.DateTime dateTime57 = dateTime43.withZoneRetainFields(dateTimeZone51);
//        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now(dateTimeZone51);
//        org.joda.time.DateTime.Property property59 = dateTime58.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean61 = property59.equals((java.lang.Object) dateTimeFormatter60);
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property59.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder33.appendFraction(dateTimeFieldType62, 0, 57600052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder32.appendShortText(dateTimeFieldType62);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException69 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, (java.lang.Number) 53L, "GregorianChronology[UTC]");
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39600052 + "'", int14 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-125999990L) + "'", long22 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 39600052 + "'", int39 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 39600052 + "'", int47 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-125999990L) + "'", long55 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(property59);
//        org.junit.Assert.assertNotNull(dateTimeFormatter60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.dayOfMonth();
        java.lang.Object obj5 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long12 = fixedDateTimeZone10.previousTransition(0L);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(obj5, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        long long15 = fixedDateTimeZone10.nextTransition((long) 57600052);
        org.joda.time.Chronology chronology16 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 57600052L + "'", long15 == 57600052L);
        org.junit.Assert.assertNotNull(chronology16);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology3);
//        int int5 = dateTime4.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
//        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(1969);
//        int int16 = property10.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime17 = property10.withMaximumValue();
//        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay19 = dateTime17.toTimeOfDay();
//        int[] intArray21 = iSOChronology1.get((org.joda.time.ReadablePartial) timeOfDay19, (long) '4');
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 39600052 + "'", int5 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertNotNull(timeOfDay19);
//        org.junit.Assert.assertNotNull(intArray21);
//    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        boolean boolean14 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        int int15 = dateTime7.getDayOfYear();
//        int int16 = dateTime7.getSecondOfMinute();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime7.toMutableDateTime(chronology17);
//        org.joda.time.DateTime dateTime20 = dateTime7.withMillis((long) 19);
//        org.joda.time.DateTime.Property property21 = dateTime20.secondOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = remainderDateTimeField44.getAsText((int) '#', locale46);
//        boolean boolean48 = remainderDateTimeField44.isSupported();
//        long long51 = remainderDateTimeField44.getDifferenceAsLong((long) 53, (long) (byte) -1);
//        java.util.Locale locale54 = null;
//        long long55 = remainderDateTimeField44.set((long) 0, "972", locale54);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "35" + "'", str47.equals("35"));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 576001);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 576001 + "'", int1 == 576001);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
//        boolean boolean4 = dateTimeFormatterBuilder1.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfSecond(10, (int) (short) -1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendMinuteOfDay(5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder10.appendFraction(dateTimeFieldType39, 0, 57600052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType39, 100, 999);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder45.appendHourOfDay((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder47.appendWeekOfWeekyear(8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
//        int int7 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.plus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
//        org.joda.time.DateTime dateTime14 = property12.roundHalfFloorCopy();
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
//        org.joda.time.DateTime dateTime22 = dateTime19.toDateTime();
//        org.joda.time.DateTime dateTime24 = dateTime19.minusWeeks(100);
//        boolean boolean25 = property12.equals((java.lang.Object) dateTime24);
//        boolean boolean26 = iSOChronology0.equals((java.lang.Object) boolean25);
//        org.joda.time.DurationField durationField27 = iSOChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology0.dayOfYear();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39600052 + "'", int7 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfSecond();
//        org.joda.time.Chronology chronology12 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology18);
//        int int20 = dateTime19.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.plus(readablePeriod21);
//        org.joda.time.DateTime dateTime24 = dateTime19.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology26);
//        int int28 = dateTime27.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.plus(readablePeriod29);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long36 = dateTimeZone32.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime37 = dateTime27.withZoneRetainFields(dateTimeZone32);
//        org.joda.time.DateTime dateTime38 = dateTime24.withZoneRetainFields(dateTimeZone32);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone32);
//        org.joda.time.DateTime.Property property40 = dateTime39.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean42 = property40.equals((java.lang.Object) dateTimeFormatter41);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property40.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType43, 0, 57600052);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType43, 69, 3, 627);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType43, 999);
//        long long54 = remainderDateTimeField52.roundCeiling((long) (byte) 10);
//        java.util.Locale locale56 = null;
//        java.lang.String str57 = remainderDateTimeField52.getAsShortText(0L, locale56);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 39600052 + "'", int20 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 39600052 + "'", int28 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-125999990L) + "'", long36 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1000L + "'", long54 == 1000L);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "639" + "'", str57.equals("639"));
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        int int4 = dateTime2.getYearOfEra();
//        org.joda.time.DateTime dateTime6 = dateTime2.withWeekyear((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusYears(57600052);
//        org.joda.time.DateTime.Property property10 = dateTime6.millisOfSecond();
//        boolean boolean12 = dateTime6.isEqual((long) 53);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.LocalDateTime localDateTime6 = dateTime2.toLocalDateTime();
//        org.joda.time.DateTime dateTime8 = dateTime2.withEra(0);
//        org.joda.time.DateTime dateTime9 = dateTime2.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime2.yearOfCentury();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfCeilingCopy();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.toString();
        java.lang.String str4 = jodaTimePermission1.getActions();
        java.lang.String str5 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"1\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"1\")"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology7);
//        int int9 = dateTime8.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.plus(readablePeriod10);
//        org.joda.time.DateTime dateTime13 = dateTime8.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime15 = dateTime8.plus((-125999990L));
//        boolean boolean16 = cachedDateTimeZone5.equals((java.lang.Object) dateTime15);
//        boolean boolean17 = cachedDateTimeZone5.isFixed();
//        java.lang.String str19 = cachedDateTimeZone5.getShortName((long) 53);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 39600052 + "'", int9 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property11 = dateTime10.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) property11);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology15);
//        int int17 = dateTime16.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime16.plus(readablePeriod18);
//        org.joda.time.DateTime dateTime21 = dateTime16.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology23);
//        int int25 = dateTime24.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.plus(readablePeriod26);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long33 = dateTimeZone29.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime34 = dateTime24.withZoneRetainFields(dateTimeZone29);
//        org.joda.time.DateTime dateTime35 = dateTime21.withZoneRetainFields(dateTimeZone29);
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now(dateTimeZone29);
//        int int37 = dateTime36.getHourOfDay();
//        boolean boolean38 = property11.equals((java.lang.Object) dateTime36);
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology40);
//        int int42 = dateTime41.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod43 = null;
//        org.joda.time.DateTime dateTime44 = dateTime41.plus(readablePeriod43);
//        org.joda.time.DateTime dateTime46 = dateTime41.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property47 = dateTime46.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField48 = property47.getField();
//        org.joda.time.DateTime dateTime49 = property47.roundHalfFloorCopy();
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology51);
//        org.joda.time.DateTime dateTime54 = dateTime52.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration55 = null;
//        org.joda.time.DateTime dateTime56 = dateTime54.minus(readableDuration55);
//        org.joda.time.DateTime dateTime57 = dateTime54.toDateTime();
//        org.joda.time.DateTime dateTime59 = dateTime54.minusWeeks(100);
//        boolean boolean60 = property47.equals((java.lang.Object) dateTime59);
//        org.joda.time.DateTime dateTime61 = property47.roundFloorCopy();
//        org.joda.time.DateTime dateTime63 = dateTime61.plusMinutes(660);
//        int int64 = property11.compareTo((org.joda.time.ReadableInstant) dateTime61);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 39600052 + "'", int17 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 39600052 + "'", int25 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-125999990L) + "'", long33 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 8 + "'", int37 == 8);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 39600052 + "'", int42 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = remainderDateTimeField44.getAsText((int) '#', locale46);
//        int int48 = remainderDateTimeField44.getMinimumValue();
//        long long51 = remainderDateTimeField44.getDifferenceAsLong((long) '4', (long) (-39600052));
//        org.joda.time.DurationField durationField52 = remainderDateTimeField44.getDurationField();
//        java.util.Locale locale54 = null;
//        java.lang.String str55 = remainderDateTimeField44.getAsText(152, locale54);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "35" + "'", str47.equals("35"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "152" + "'", str55.equals("152"));
//    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
//        org.joda.time.DateTime.Property property16 = dateTime6.millisOfSecond();
//        int int17 = property16.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime19 = property16.addToCopy((long) 3);
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.plus(readablePeriod20);
//        org.joda.time.DateTime dateTime23 = dateTime19.plusMonths(53);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str7 = fixedDateTimeZone4.getNameKey((long) (short) -1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:00" + "'", str7.equals("+35:00"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        java.util.Locale locale14 = null;
//        java.util.Calendar calendar15 = dateTime9.toCalendar(locale14);
//        org.joda.time.DateTime dateTime17 = dateTime9.withCenturyOfEra((int) (short) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField19 = iSOChronology18.hours();
//        org.joda.time.DurationField durationField20 = iSOChronology18.years();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology18.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder25.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology32);
//        int int34 = dateTime33.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime33.plus(readablePeriod35);
//        org.joda.time.DateTime dateTime38 = dateTime33.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology40);
//        int int42 = dateTime41.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod43 = null;
//        org.joda.time.DateTime dateTime44 = dateTime41.plus(readablePeriod43);
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long50 = dateTimeZone46.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime51 = dateTime41.withZoneRetainFields(dateTimeZone46);
//        org.joda.time.DateTime dateTime52 = dateTime38.withZoneRetainFields(dateTimeZone46);
//        org.joda.time.DateTime dateTime53 = org.joda.time.DateTime.now(dateTimeZone46);
//        org.joda.time.DateTime.Property property54 = dateTime53.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean56 = property54.equals((java.lang.Object) dateTimeFormatter55);
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property54.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder25.appendSignedDecimal(dateTimeFieldType57, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField62 = new org.joda.time.field.RemainderDateTimeField(dateTimeField21, dateTimeFieldType57, 998);
//        org.joda.time.DurationField durationField63 = remainderDateTimeField62.getLeapDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology65 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology65);
//        int int67 = dateTime66.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod68 = null;
//        org.joda.time.DateTime dateTime69 = dateTime66.plus(readablePeriod68);
//        org.joda.time.DateTime dateTime71 = dateTime66.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property72 = dateTime71.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology74 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology74);
//        org.joda.time.DateTime dateTime77 = dateTime75.minusSeconds(1969);
//        int int78 = property72.compareTo((org.joda.time.ReadableInstant) dateTime77);
//        org.joda.time.DateTime dateTime79 = property72.withMaximumValue();
//        org.joda.time.LocalTime localTime80 = dateTime79.toLocalTime();
//        java.util.Locale locale82 = null;
//        java.lang.String str83 = remainderDateTimeField62.getAsText((org.joda.time.ReadablePartial) localTime80, 3, locale82);
//        org.joda.time.DateTime dateTime84 = dateTime17.withFields((org.joda.time.ReadablePartial) localTime80);
//        org.joda.time.DateTime dateTime86 = dateTime17.plusWeeks(0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(calendar15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 39600052 + "'", int34 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 39600052 + "'", int42 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-125999990L) + "'", long50 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeFormatter55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertNull(durationField63);
//        org.junit.Assert.assertNotNull(iSOChronology65);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 39600052 + "'", int67 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(property72);
//        org.junit.Assert.assertNotNull(iSOChronology74);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
//        org.junit.Assert.assertNotNull(dateTime79);
//        org.junit.Assert.assertNotNull(localTime80);
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "3" + "'", str83.equals("3"));
//        org.junit.Assert.assertNotNull(dateTime84);
//        org.junit.Assert.assertNotNull(dateTime86);
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
//        int int11 = dateTime10.getMillisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime10.withMillisOfSecond(10);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(5);
//        org.joda.time.DateTime dateTime17 = dateTime15.plusMinutes(0);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusDays(999);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField21 = iSOChronology20.hours();
//        org.joda.time.DurationField durationField22 = iSOChronology20.years();
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology24);
//        int int26 = dateTime25.getMillisOfDay();
//        org.joda.time.DateTime dateTime28 = dateTime25.withWeekyear(0);
//        int int29 = dateTime25.getMinuteOfHour();
//        boolean boolean30 = iSOChronology20.equals((java.lang.Object) dateTime25);
//        org.joda.time.DurationField durationField31 = iSOChronology20.seconds();
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology20.secondOfMinute();
//        org.joda.time.DurationField durationField33 = iSOChronology20.centuries();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology20.weekOfWeekyear();
//        org.joda.time.DateTime dateTime35 = dateTime19.toDateTime((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeZone dateTimeZone36 = dateTime35.getZone();
//        org.joda.time.DateTime dateTime38 = dateTime35.plusMonths(2019);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 39600052 + "'", int26 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(dateTime38);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField6 = iSOChronology5.hours();
//        org.joda.time.DurationField durationField7 = iSOChronology5.years();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.DateTime dateTime13 = dateTime10.withWeekyear(0);
//        int int14 = dateTime10.getMinuteOfHour();
//        boolean boolean15 = iSOChronology5.equals((java.lang.Object) dateTime10);
//        org.joda.time.DurationField durationField16 = iSOChronology5.seconds();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology5.secondOfMinute();
//        try {
//            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(0, 69, 1439, (int) (short) -1, 52, (org.joda.time.Chronology) iSOChronology5);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        boolean boolean58 = unsupportedDateTimeField57.isSupported();
//        try {
//            int int60 = unsupportedDateTimeField57.getLeapAmount(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        org.joda.time.DurationField durationField58 = unsupportedDateTimeField57.getDurationField();
//        org.joda.time.DurationField durationField59 = unsupportedDateTimeField57.getLeapDurationField();
//        try {
//            long long62 = unsupportedDateTimeField57.addWrapField((long) '#', 69);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNull(durationField59);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
//        org.joda.time.DateTime.Property property16 = dateTime6.millisOfSecond();
//        int int17 = property16.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime19 = property16.addToCopy((long) 3);
//        org.joda.time.DateTime.Property property20 = dateTime19.secondOfMinute();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test251");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
//        boolean boolean4 = dateTimeFormatterBuilder1.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfSecond(10, (int) (short) -1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendMinuteOfDay(5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder10.appendFraction(dateTimeFieldType39, 0, 57600052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType39, 100, 999);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException47 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType39, "52");
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusMillis((int) (byte) 0);
//        org.joda.time.DateTime.Property property16 = dateTime6.millisOfSecond();
//        int int17 = property16.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime19 = property16.addToCopy((long) 3);
//        int int20 = dateTime19.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 627 + "'", int20 == 627);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long5 = dateTimeZone1.convertLocalToUTC(10L, false, 0L);
        java.lang.String str6 = dateTimeZone1.getID();
        java.lang.String str8 = dateTimeZone1.getShortName((long) 3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-125999990L) + "'", long5 == (-125999990L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+35:00" + "'", str6.equals("+35:00"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+35:00" + "'", str8.equals("+35:00"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        boolean boolean58 = unsupportedDateTimeField57.isSupported();
//        java.lang.String str59 = unsupportedDateTimeField57.getName();
//        long long62 = unsupportedDateTimeField57.add(128L, 1560634372660L);
//        java.lang.String str63 = unsupportedDateTimeField57.getName();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "secondOfMinute" + "'", str59.equals("secondOfMinute"));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560634372660128L + "'", long62 == 1560634372660128L);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "secondOfMinute" + "'", str63.equals("secondOfMinute"));
//    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology7);
//        int int9 = dateTime8.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.plus(readablePeriod10);
//        org.joda.time.DateTime dateTime13 = dateTime8.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property14 = dateTime13.millisOfSecond();
//        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
//        boolean boolean16 = cachedDateTimeZone5.isLocalDateTimeGap(localDateTime15);
//        long long18 = cachedDateTimeZone5.previousTransition((long) 57600052);
//        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone5.getUncachedZone();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 39600052 + "'", int9 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 57600052L + "'", long18 == 57600052L);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.era();
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(chronology14);
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        org.joda.time.DurationField durationField58 = unsupportedDateTimeField57.getDurationField();
//        org.joda.time.DurationField durationField59 = unsupportedDateTimeField57.getLeapDurationField();
//        try {
//            java.lang.String str61 = unsupportedDateTimeField57.getAsText((long) 49);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNull(durationField59);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test259");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        org.joda.time.DurationField durationField58 = unsupportedDateTimeField57.getDurationField();
//        java.util.Locale locale60 = null;
//        try {
//            java.lang.String str61 = unsupportedDateTimeField57.getAsText(972, locale60);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertNotNull(durationField58);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        int int60 = unsupportedDateTimeField57.getDifference(1000L, 0L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = unsupportedDateTimeField57.getType();
//        java.lang.String str62 = unsupportedDateTimeField57.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "UnsupportedDateTimeField" + "'", str62.equals("UnsupportedDateTimeField"));
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        int int4 = dateTime2.getYearOfEra();
//        org.joda.time.DateTime dateTime6 = dateTime2.withWeekyear((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        int int8 = property7.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
//        int int14 = dateTime13.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
//        org.joda.time.DateTime dateTime18 = dateTime13.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology20);
//        int int22 = dateTime21.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime21.plus(readablePeriod23);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long30 = dateTimeZone26.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime31 = dateTime21.withZoneRetainFields(dateTimeZone26);
//        org.joda.time.DateTime dateTime32 = dateTime18.withZoneRetainFields(dateTimeZone26);
//        org.joda.time.DateTime dateTime33 = dateTime5.withZone(dateTimeZone26);
//        boolean boolean34 = iSOChronology1.equals((java.lang.Object) dateTime33);
//        org.joda.time.Instant instant35 = dateTime33.toInstant();
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField37 = iSOChronology36.hours();
//        org.joda.time.DurationField durationField38 = iSOChronology36.years();
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology36.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder40.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder43.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder43.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology50);
//        int int52 = dateTime51.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod53 = null;
//        org.joda.time.DateTime dateTime54 = dateTime51.plus(readablePeriod53);
//        org.joda.time.DateTime dateTime56 = dateTime51.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology58);
//        int int60 = dateTime59.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod61 = null;
//        org.joda.time.DateTime dateTime62 = dateTime59.plus(readablePeriod61);
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long68 = dateTimeZone64.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime69 = dateTime59.withZoneRetainFields(dateTimeZone64);
//        org.joda.time.DateTime dateTime70 = dateTime56.withZoneRetainFields(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = org.joda.time.DateTime.now(dateTimeZone64);
//        org.joda.time.DateTime.Property property72 = dateTime71.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean74 = property72.equals((java.lang.Object) dateTimeFormatter73);
//        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property72.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder43.appendSignedDecimal(dateTimeFieldType75, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField80 = new org.joda.time.field.RemainderDateTimeField(dateTimeField39, dateTimeFieldType75, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology81 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField82 = iSOChronology81.hours();
//        org.joda.time.DurationField durationField83 = iSOChronology81.years();
//        org.joda.time.chrono.ISOChronology iSOChronology85 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime86 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology85);
//        int int87 = dateTime86.getMillisOfDay();
//        org.joda.time.DateTime dateTime89 = dateTime86.withWeekyear(0);
//        int int90 = dateTime86.getMinuteOfHour();
//        boolean boolean91 = iSOChronology81.equals((java.lang.Object) dateTime86);
//        org.joda.time.DurationField durationField92 = iSOChronology81.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField93 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType75, durationField92);
//        org.joda.time.DurationField durationField94 = unsupportedDateTimeField93.getDurationField();
//        org.joda.time.DurationField durationField95 = unsupportedDateTimeField93.getLeapDurationField();
//        try {
//            int int96 = dateTime33.get((org.joda.time.DateTimeField) unsupportedDateTimeField93);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39600052 + "'", int14 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 39600052 + "'", int22 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-125999990L) + "'", long30 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(instant35);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(iSOChronology50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 39600052 + "'", int52 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(iSOChronology58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 39600052 + "'", int60 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-125999990L) + "'", long68 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(property72);
//        org.junit.Assert.assertNotNull(dateTimeFormatter73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType75);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
//        org.junit.Assert.assertNotNull(iSOChronology81);
//        org.junit.Assert.assertNotNull(durationField82);
//        org.junit.Assert.assertNotNull(durationField83);
//        org.junit.Assert.assertNotNull(iSOChronology85);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 39600052 + "'", int87 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime89);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//        org.junit.Assert.assertNotNull(durationField92);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField93);
//        org.junit.Assert.assertNotNull(durationField94);
//        org.junit.Assert.assertNull(durationField95);
//    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfSecond();
//        org.joda.time.Chronology chronology12 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology18);
//        int int20 = dateTime19.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.plus(readablePeriod21);
//        org.joda.time.DateTime dateTime24 = dateTime19.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology26);
//        int int28 = dateTime27.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.plus(readablePeriod29);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long36 = dateTimeZone32.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime37 = dateTime27.withZoneRetainFields(dateTimeZone32);
//        org.joda.time.DateTime dateTime38 = dateTime24.withZoneRetainFields(dateTimeZone32);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone32);
//        org.joda.time.DateTime.Property property40 = dateTime39.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean42 = property40.equals((java.lang.Object) dateTimeFormatter41);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property40.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType43, 0, 57600052);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType43, 69, 3, 627);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType43, 999);
//        long long54 = remainderDateTimeField52.roundCeiling((long) (byte) 10);
//        long long56 = remainderDateTimeField52.roundHalfEven((long) 780317186);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 39600052 + "'", int20 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 39600052 + "'", int28 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-125999990L) + "'", long36 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1000L + "'", long54 == 1000L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 780317000L + "'", long56 == 780317000L);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(0);
        boolean boolean3 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
//        org.joda.time.DateTime dateTime19 = dateTime14.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
//        int int23 = dateTime22.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
//        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
//        int int31 = dateTime30.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime42 = dateTime14.withZone(dateTimeZone35);
//        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone35);
//        org.joda.time.DateTimeField dateTimeField44 = zonedChronology43.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder45.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder48.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder48.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology55);
//        int int57 = dateTime56.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod58 = null;
//        org.joda.time.DateTime dateTime59 = dateTime56.plus(readablePeriod58);
//        org.joda.time.DateTime dateTime61 = dateTime56.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology63);
//        int int65 = dateTime64.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod66 = null;
//        org.joda.time.DateTime dateTime67 = dateTime64.plus(readablePeriod66);
//        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long73 = dateTimeZone69.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime74 = dateTime64.withZoneRetainFields(dateTimeZone69);
//        org.joda.time.DateTime dateTime75 = dateTime61.withZoneRetainFields(dateTimeZone69);
//        org.joda.time.DateTime dateTime76 = org.joda.time.DateTime.now(dateTimeZone69);
//        org.joda.time.DateTime.Property property77 = dateTime76.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter78 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean79 = property77.equals((java.lang.Object) dateTimeFormatter78);
//        org.joda.time.DateTimeFieldType dateTimeFieldType80 = property77.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder48.appendSignedDecimal(dateTimeFieldType80, (int) (byte) 1, (int) '4');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField(dateTimeField44, dateTimeFieldType80, 2);
//        int int88 = dividedDateTimeField85.getDifference((-1L), (long) 100);
//        int int91 = dividedDateTimeField85.getDifference(1560634372660L, (long) (short) 10);
//        int int92 = dividedDateTimeField85.getMaximumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(zonedChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//        org.junit.Assert.assertNotNull(iSOChronology55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 39600052 + "'", int57 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(iSOChronology63);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 39600052 + "'", int65 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTimeZone69);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-125999990L) + "'", long73 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertNotNull(property77);
//        org.junit.Assert.assertNotNull(dateTimeFormatter78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType80);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 780317186 + "'", int91 == 780317186);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 43199 + "'", int92 == 43199);
//    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = remainderDateTimeField44.getAsText((int) '#', locale46);
//        int int49 = remainderDateTimeField44.getMinimumValue(1560634372660L);
//        int int50 = remainderDateTimeField44.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "35" + "'", str47.equals("35"));
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.millis();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
//        int int7 = dateTime6.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.plus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds(1969);
//        int int18 = property12.compareTo((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime19 = property12.withMaximumValue();
//        org.joda.time.LocalTime localTime20 = dateTime19.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay21 = dateTime19.toTimeOfDay();
//        org.joda.time.LocalTime localTime22 = dateTime19.toLocalTime();
//        int[] intArray24 = gregorianChronology0.get((org.joda.time.ReadablePartial) localTime22, (-62166787199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39600052 + "'", int7 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localTime20);
//        org.junit.Assert.assertNotNull(timeOfDay21);
//        org.junit.Assert.assertNotNull(localTime22);
//        org.junit.Assert.assertNotNull(intArray24);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DurationField durationField11 = iSOChronology0.seconds();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.plus(readablePeriod16);
//        org.joda.time.DateTime dateTime19 = dateTime14.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology21);
//        int int23 = dateTime22.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.plus(readablePeriod24);
//        org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
//        int int31 = dateTime30.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long39 = dateTimeZone35.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime40 = dateTime30.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime41 = dateTime27.withZoneRetainFields(dateTimeZone35);
//        org.joda.time.DateTime dateTime42 = dateTime14.withZone(dateTimeZone35);
//        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone35);
//        org.joda.time.DateTimeField dateTimeField44 = zonedChronology43.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder45.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder48.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder48.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology55);
//        int int57 = dateTime56.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod58 = null;
//        org.joda.time.DateTime dateTime59 = dateTime56.plus(readablePeriod58);
//        org.joda.time.DateTime dateTime61 = dateTime56.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology63);
//        int int65 = dateTime64.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod66 = null;
//        org.joda.time.DateTime dateTime67 = dateTime64.plus(readablePeriod66);
//        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long73 = dateTimeZone69.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime74 = dateTime64.withZoneRetainFields(dateTimeZone69);
//        org.joda.time.DateTime dateTime75 = dateTime61.withZoneRetainFields(dateTimeZone69);
//        org.joda.time.DateTime dateTime76 = org.joda.time.DateTime.now(dateTimeZone69);
//        org.joda.time.DateTime.Property property77 = dateTime76.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter78 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean79 = property77.equals((java.lang.Object) dateTimeFormatter78);
//        org.joda.time.DateTimeFieldType dateTimeFieldType80 = property77.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder48.appendSignedDecimal(dateTimeFieldType80, (int) (byte) 1, (int) '4');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField(dateTimeField44, dateTimeFieldType80, 2);
//        int int88 = dividedDateTimeField85.getDifference((-1L), (long) 100);
//        long long91 = dividedDateTimeField85.set((long) 126000000, 52);
//        org.joda.time.chrono.ISOChronology iSOChronology93 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime94 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology93);
//        org.joda.time.YearMonthDay yearMonthDay95 = dateTime94.toYearMonthDay();
//        int int96 = dividedDateTimeField85.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay95);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 39600052 + "'", int15 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 39600052 + "'", int23 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-125999990L) + "'", long39 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(zonedChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//        org.junit.Assert.assertNotNull(iSOChronology55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 39600052 + "'", int57 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(iSOChronology63);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 39600052 + "'", int65 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTimeZone69);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-125999990L) + "'", long73 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertNotNull(property77);
//        org.junit.Assert.assertNotNull(dateTimeFormatter78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType80);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 46904000L + "'", long91 == 46904000L);
//        org.junit.Assert.assertNotNull(iSOChronology93);
//        org.junit.Assert.assertNotNull(yearMonthDay95);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 43199 + "'", int96 == 43199);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray4 = iSOChronology0.get(readablePeriod1, (long) 999, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        int int60 = unsupportedDateTimeField57.getDifference(1000L, 0L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = unsupportedDateTimeField57.getType();
//        java.util.Locale locale63 = null;
//        try {
//            java.lang.String str64 = unsupportedDateTimeField57.getAsShortText(19800, locale63);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType61);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(0);
//        int int9 = dateTime5.getMinuteOfHour();
//        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfSecond();
//        org.joda.time.Chronology chronology12 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMillisOfSecond(30);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology18);
//        int int20 = dateTime19.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.plus(readablePeriod21);
//        org.joda.time.DateTime dateTime24 = dateTime19.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology26);
//        int int28 = dateTime27.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.plus(readablePeriod29);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long36 = dateTimeZone32.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime37 = dateTime27.withZoneRetainFields(dateTimeZone32);
//        org.joda.time.DateTime dateTime38 = dateTime24.withZoneRetainFields(dateTimeZone32);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone32);
//        org.joda.time.DateTime.Property property40 = dateTime39.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean42 = property40.equals((java.lang.Object) dateTimeFormatter41);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property40.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType43, 0, 57600052);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType43, 69, 3, 627);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType43, 999);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        java.util.Locale locale54 = dateTimeFormatter53.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = dateTimeFormatter53.withDefaultYear((int) (byte) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology58);
//        org.joda.time.YearMonthDay yearMonthDay60 = dateTime59.toYearMonthDay();
//        boolean boolean61 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay60);
//        java.lang.String str62 = dateTimeFormatter56.print((org.joda.time.ReadablePartial) yearMonthDay60);
//        int int63 = remainderDateTimeField52.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay60);
//        boolean boolean64 = remainderDateTimeField52.isSupported();
//        org.joda.time.DurationField durationField65 = remainderDateTimeField52.getRangeDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 39600052 + "'", int6 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 39600052 + "'", int20 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 39600052 + "'", int28 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-125999990L) + "'", long36 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNull(locale54);
//        org.junit.Assert.assertNotNull(dateTimeFormatter56);
//        org.junit.Assert.assertNotNull(iSOChronology58);
//        org.junit.Assert.assertNotNull(yearMonthDay60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1970-01-02T��:��" + "'", str62.equals("1970-01-02T��:��"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertNotNull(durationField65);
//    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField5 = iSOChronology4.hours();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.weekyearOfCentury();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.plus(readablePeriod12);
//        org.joda.time.DateTime dateTime15 = dateTime10.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property16 = dateTime15.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology18);
//        org.joda.time.DateTime dateTime21 = dateTime19.minusSeconds(1969);
//        int int22 = property16.compareTo((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime dateTime23 = property16.withMaximumValue();
//        org.joda.time.LocalTime localTime24 = dateTime23.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay25 = dateTime23.toTimeOfDay();
//        int[] intArray27 = iSOChronology4.get((org.joda.time.ReadablePartial) timeOfDay25, (-1L));
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology29);
//        int int31 = dateTime30.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
//        org.joda.time.DateTime dateTime35 = dateTime30.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property36 = dateTime35.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology38);
//        org.joda.time.DateTime dateTime41 = dateTime39.minusSeconds(1969);
//        int int42 = property36.compareTo((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology45);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) iSOChronology45);
//        org.joda.time.DateTime dateTime48 = dateTime41.toDateTime((org.joda.time.Chronology) iSOChronology45);
//        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology50);
//        int int52 = dateTime51.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod53 = null;
//        org.joda.time.DateTime dateTime54 = dateTime51.plus(readablePeriod53);
//        org.joda.time.DateTime dateTime56 = dateTime51.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property57 = dateTime56.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology59);
//        org.joda.time.DateTime dateTime62 = dateTime60.minusSeconds(1969);
//        int int63 = property57.compareTo((org.joda.time.ReadableInstant) dateTime62);
//        org.joda.time.DateTime dateTime64 = property57.withMaximumValue();
//        org.joda.time.LocalTime localTime65 = dateTime64.toLocalTime();
//        org.joda.time.TimeOfDay timeOfDay66 = dateTime64.toTimeOfDay();
//        int[] intArray68 = iSOChronology45.get((org.joda.time.ReadablePartial) timeOfDay66, (long) 0);
//        iSOChronology1.validate((org.joda.time.ReadablePartial) timeOfDay25, intArray68);
//        org.joda.time.DurationField durationField70 = iSOChronology1.hours();
//        org.joda.time.DateTimeField dateTimeField71 = iSOChronology1.clockhourOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39600052 + "'", int11 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(localTime24);
//        org.junit.Assert.assertNotNull(timeOfDay25);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 39600052 + "'", int31 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(iSOChronology50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 39600052 + "'", int52 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(localTime65);
//        org.junit.Assert.assertNotNull(timeOfDay66);
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertNotNull(durationField70);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.LocalDateTime localDateTime6 = dateTime2.toLocalDateTime();
//        org.joda.time.DateTime dateTime8 = dateTime2.withEra(0);
//        org.joda.time.DateTime dateTime9 = dateTime2.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime2.toDateTimeISO();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
//        int int4 = dateTime2.getYearOfEra();
//        long long5 = dateTime2.getMillis();
//        boolean boolean7 = dateTime2.isBefore(0L);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) '#', 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 135L + "'", long2 == 135L);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime9.withCenturyOfEra((int) (byte) 0);
//        org.joda.time.DateTime dateTime16 = dateTime9.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property17 = dateTime9.hourOfDay();
//        org.joda.time.DateTime.Property property18 = dateTime9.secondOfMinute();
//        java.lang.String str19 = property18.getAsShortText();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (-19), 7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.minus(readableDuration16);
//        org.joda.time.DateTime dateTime18 = dateTime15.toDateTime();
//        org.joda.time.DateTime dateTime20 = dateTime15.minusWeeks(100);
//        boolean boolean21 = property8.equals((java.lang.Object) dateTime20);
//        org.joda.time.DateTime dateTime22 = property8.roundFloorCopy();
//        java.lang.String str23 = dateTime22.toString();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1970-01-02T00:00:00.001+35:00" + "'", str23.equals("1970-01-02T00:00:00.001+35:00"));
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("1970-01-02T00:00:00.001+35:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970-01-02T00:00:00.001+35:00\" is malformed at \".001+35:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str7 = cachedDateTimeZone5.getNameKey((long) 57600052);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:00" + "'", str7.equals("+35:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        int int60 = unsupportedDateTimeField57.getDifference(1000L, 0L);
//        org.joda.time.DurationField durationField61 = unsupportedDateTimeField57.getDurationField();
//        java.util.Locale locale62 = null;
//        try {
//            int int63 = unsupportedDateTimeField57.getMaximumShortTextLength(locale62);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertNotNull(durationField61);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMillisOfDay(53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfDay(1970, (int) (short) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale13 = dateTimeFormatter12.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter12.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter15.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser17 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter16, dateTimeParser17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder11.append(dateTimePrinter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder11.appendFractionOfHour(576001, (-39600000));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNull(locale13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimePrinter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long11 = dateTimeZone7.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime12 = dateTime2.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusYears((int) (short) -1);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
//        int int18 = dateTime17.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.plus(readablePeriod19);
//        org.joda.time.DateTime dateTime22 = dateTime17.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property23 = dateTime22.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
//        int int25 = dateTime14.get(dateTimeField24);
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime28 = dateTime14.withPeriodAdded(readablePeriod26, 5);
//        int int29 = dateTime28.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-125999990L) + "'", long11 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 39600052 + "'", int18 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField13 = iSOChronology12.hours();
//        org.joda.time.DurationField durationField14 = iSOChronology12.years();
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
//        int int18 = dateTime17.getMillisOfDay();
//        org.joda.time.DateTime dateTime20 = dateTime17.withWeekyear(0);
//        int int21 = dateTime17.getMinuteOfHour();
//        boolean boolean22 = iSOChronology12.equals((java.lang.Object) dateTime17);
//        org.joda.time.DurationField durationField23 = iSOChronology12.seconds();
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology25);
//        int int27 = dateTime26.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime26.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology33);
//        int int35 = dateTime34.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod36 = null;
//        org.joda.time.DateTime dateTime37 = dateTime34.plus(readablePeriod36);
//        org.joda.time.DateTime dateTime39 = dateTime34.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology41);
//        int int43 = dateTime42.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod44 = null;
//        org.joda.time.DateTime dateTime45 = dateTime42.plus(readablePeriod44);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long51 = dateTimeZone47.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime52 = dateTime42.withZoneRetainFields(dateTimeZone47);
//        org.joda.time.DateTime dateTime53 = dateTime39.withZoneRetainFields(dateTimeZone47);
//        org.joda.time.DateTime dateTime54 = dateTime26.withZone(dateTimeZone47);
//        org.joda.time.chrono.ZonedChronology zonedChronology55 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology12, dateTimeZone47);
//        org.joda.time.MutableDateTime mutableDateTime56 = dateTime10.toMutableDateTime(dateTimeZone47);
//        java.lang.String str57 = mutableDateTime56.toString();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 39600052 + "'", int18 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 39600052 + "'", int27 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 39600052 + "'", int35 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(iSOChronology41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 39600052 + "'", int43 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-125999990L) + "'", long51 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(zonedChronology55);
//        org.junit.Assert.assertNotNull(mutableDateTime56);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "1970-01-02T00:00:00.001+35:00" + "'", str57.equals("1970-01-02T00:00:00.001+35:00"));
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1969);
//        int int14 = property8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime15 = property8.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime17 = dateTime15.plus((long) (-57600000));
//        org.joda.time.DateTime dateTime19 = dateTime15.plusWeeks(2);
//        org.joda.time.DateTime.Property property20 = dateTime15.secondOfMinute();
//        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
//        int int11 = dateTime10.getMillisOfSecond();
//        org.joda.time.DateTime dateTime13 = dateTime10.withMillisOfSecond(10);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(5);
//        org.joda.time.DateTime dateTime17 = dateTime15.plusMinutes(0);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusDays(999);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField21 = iSOChronology20.hours();
//        org.joda.time.DurationField durationField22 = iSOChronology20.years();
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology24);
//        int int26 = dateTime25.getMillisOfDay();
//        org.joda.time.DateTime dateTime28 = dateTime25.withWeekyear(0);
//        int int29 = dateTime25.getMinuteOfHour();
//        boolean boolean30 = iSOChronology20.equals((java.lang.Object) dateTime25);
//        org.joda.time.DurationField durationField31 = iSOChronology20.seconds();
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology20.secondOfMinute();
//        org.joda.time.DurationField durationField33 = iSOChronology20.centuries();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology20.weekOfWeekyear();
//        org.joda.time.DateTime dateTime35 = dateTime19.toDateTime((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeZone dateTimeZone36 = dateTime35.getZone();
//        boolean boolean38 = dateTime35.isBefore((long) (byte) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology40);
//        int int42 = dateTime41.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod43 = null;
//        org.joda.time.DateTime dateTime44 = dateTime41.plus(readablePeriod43);
//        org.joda.time.DateTime dateTime46 = dateTime41.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime.Property property47 = dateTime46.millisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        org.joda.time.DateTime dateTime52 = dateTime50.minusSeconds(1969);
//        int int53 = property47.compareTo((org.joda.time.ReadableInstant) dateTime52);
//        org.joda.time.DateTime dateTime54 = property47.roundHalfFloorCopy();
//        org.joda.time.YearMonthDay yearMonthDay55 = dateTime54.toYearMonthDay();
//        org.joda.time.DateTime dateTime56 = dateTime35.withFields((org.joda.time.ReadablePartial) yearMonthDay55);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39600052 + "'", int3 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 39600052 + "'", int26 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 39600052 + "'", int42 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(yearMonthDay55);
//        org.junit.Assert.assertNotNull(dateTime56);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long5 = dateTimeZone1.convertLocalToUTC(10L, false, 0L);
        java.lang.String str6 = dateTimeZone1.getID();
        java.util.TimeZone timeZone7 = dateTimeZone1.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-125999990L) + "'", long5 == (-125999990L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+35:00" + "'", str6.equals("+35:00"));
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = iSOChronology7.getZone();
        boolean boolean10 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeZone9);
        long long13 = dateTimeZone9.adjustOffset(0L, false);
        java.util.TimeZone timeZone14 = dateTimeZone9.toTimeZone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("19");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '19' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime6.plusYears(53);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime6.withPeriodAdded(readablePeriod16, 0);
//        int int19 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime dateTime21 = dateTime6.withCenturyOfEra(0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField2 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(70, 152);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology14);
//        int int16 = dateTime15.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withMillisOfDay((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology22);
//        int int24 = dateTime23.getMillisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.plus(readablePeriod25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
//        long long32 = dateTimeZone28.convertLocalToUTC(10L, false, 0L);
//        org.joda.time.DateTime dateTime33 = dateTime23.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime20.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.date();
//        boolean boolean38 = property36.equals((java.lang.Object) dateTimeFormatter37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType39, (int) (byte) 1, (int) '4');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType39, 998);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField46 = iSOChronology45.hours();
//        org.joda.time.DurationField durationField47 = iSOChronology45.years();
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology49);
//        int int51 = dateTime50.getMillisOfDay();
//        org.joda.time.DateTime dateTime53 = dateTime50.withWeekyear(0);
//        int int54 = dateTime50.getMinuteOfHour();
//        boolean boolean55 = iSOChronology45.equals((java.lang.Object) dateTime50);
//        org.joda.time.DurationField durationField56 = iSOChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField56);
//        boolean boolean58 = unsupportedDateTimeField57.isSupported();
//        java.lang.String str59 = unsupportedDateTimeField57.getName();
//        long long62 = unsupportedDateTimeField57.add(128L, 1560634372660L);
//        try {
//            int int63 = unsupportedDateTimeField57.getMinimumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39600052 + "'", int16 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 39600052 + "'", int24 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-125999990L) + "'", long32 == (-125999990L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 39600052 + "'", int51 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "secondOfMinute" + "'", str59.equals("secondOfMinute"));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560634372660128L + "'", long62 == 1560634372660128L);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMillisOfDay(53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfMinute((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendYear(0, 39600052);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(1969);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.withWeekyear(0);
//        boolean boolean13 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime9.withCenturyOfEra((int) (byte) 0);
//        org.joda.time.DateTime dateTime16 = dateTime9.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property17 = dateTime9.hourOfDay();
//        org.joda.time.DateTime.Property property18 = dateTime9.secondOfMinute();
//        org.joda.time.DateTime dateTime20 = property18.addToCopy((long) 4);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 39600052 + "'", int10 == 39600052);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime11 = dateTime6.withDayOfYear((int) 'a');
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime2.plus((-125999990L));
        int int10 = dateTime2.getMinuteOfDay();
        int int11 = dateTime2.getCenturyOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField13 = iSOChronology12.hours();
        org.joda.time.DurationField durationField14 = iSOChronology12.centuries();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.dayOfWeek();
        org.joda.time.DateTime dateTime16 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology12.millisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 51 + "'", int3 == 51);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "+35:00", (int) (byte) -1, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        int int9 = fixedDateTimeZone4.getStandardOffset((long) 999);
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((-126000000L), dateTimeZone1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long11 = dateTimeZone7.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime12 = dateTime2.withZoneRetainFields(dateTimeZone7);
        org.joda.time.DateTime dateTime14 = dateTime12.plusYears((int) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology16);
        int int18 = dateTime17.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.plus(readablePeriod19);
        org.joda.time.DateTime dateTime22 = dateTime17.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property23 = dateTime22.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        int int25 = dateTime14.get(dateTimeField24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField27 = iSOChronology26.hours();
        org.joda.time.DurationField durationField28 = iSOChronology26.years();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology26.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendTwoDigitWeekyear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendYearOfEra(70, 152);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder33.appendTwoDigitWeekyear(100);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology40);
        int int42 = dateTime41.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.DateTime dateTime44 = dateTime41.plus(readablePeriod43);
        org.joda.time.DateTime dateTime46 = dateTime41.withMillisOfDay((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology48);
        int int50 = dateTime49.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        org.joda.time.DateTime dateTime52 = dateTime49.plus(readablePeriod51);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        long long58 = dateTimeZone54.convertLocalToUTC(10L, false, 0L);
        org.joda.time.DateTime dateTime59 = dateTime49.withZoneRetainFields(dateTimeZone54);
        org.joda.time.DateTime dateTime60 = dateTime46.withZoneRetainFields(dateTimeZone54);
        org.joda.time.DateTime dateTime61 = org.joda.time.DateTime.now(dateTimeZone54);
        org.joda.time.DateTime.Property property62 = dateTime61.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter63 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean64 = property62.equals((java.lang.Object) dateTimeFormatter63);
        org.joda.time.DateTimeFieldType dateTimeFieldType65 = property62.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder33.appendSignedDecimal(dateTimeFieldType65, (int) (byte) 1, (int) '4');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField(dateTimeField29, dateTimeFieldType65, 998);
        org.joda.time.chrono.ISOChronology iSOChronology71 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField72 = iSOChronology71.hours();
        org.joda.time.DurationField durationField73 = iSOChronology71.years();
        org.joda.time.chrono.ISOChronology iSOChronology75 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology75);
        int int77 = dateTime76.getMillisOfDay();
        org.joda.time.DateTime dateTime79 = dateTime76.withWeekyear(0);
        int int80 = dateTime76.getMinuteOfHour();
        boolean boolean81 = iSOChronology71.equals((java.lang.Object) dateTime76);
        org.joda.time.DurationField durationField82 = iSOChronology71.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField83 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType65, durationField82);
        int int86 = unsupportedDateTimeField83.getDifference(1000L, 0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType87 = unsupportedDateTimeField83.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField88 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField24, dateTimeFieldType87);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 51 + "'", int3 == 51);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-125999990L) + "'", long11 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 51 + "'", int18 == 51);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 50 + "'", int25 == 50);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 51 + "'", int42 == 51);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 51 + "'", int50 == 51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-125999990L) + "'", long58 == (-125999990L));
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(dateTimeFormatter63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertNotNull(iSOChronology71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(durationField73);
        org.junit.Assert.assertNotNull(iSOChronology75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 51 + "'", int77 == 51);
        org.junit.Assert.assertNotNull(dateTime79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(durationField82);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField83);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType87);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTime dateTime10 = dateTime7.withEra(1);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField12 = iSOChronology11.hours();
        org.joda.time.DurationField durationField13 = iSOChronology11.centuries();
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime7.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology11.dayOfYear();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology11.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology11.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 51 + "'", int3 == 51);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds(1969);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.minus(readableDuration9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology12);
        int int14 = dateTime13.getMillisOfDay();
        org.joda.time.DateTime dateTime16 = dateTime13.withWeekyear(0);
        boolean boolean17 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime19 = dateTime10.plusMillis((int) (byte) 0);
        org.joda.time.DateTime dateTime21 = dateTime19.minusMillis(126000000);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology23);
        int int25 = dateTime24.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime24.plus(readablePeriod26);
        org.joda.time.DateTime dateTime29 = dateTime24.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime.Property property30 = dateTime29.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology32);
        org.joda.time.DateTime dateTime35 = dateTime33.minusSeconds(1969);
        int int36 = property30.compareTo((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime dateTime37 = property30.withMaximumValue();
        org.joda.time.LocalTime localTime38 = dateTime37.toLocalTime();
        org.joda.time.DateTime dateTime39 = dateTime21.withFields((org.joda.time.ReadablePartial) localTime38);
        boolean boolean40 = jodaTimePermission1.equals((java.lang.Object) localTime38);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"1\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"1\")"));
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 51 + "'", int14 == 51);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 51 + "'", int25 == 51);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }
}

