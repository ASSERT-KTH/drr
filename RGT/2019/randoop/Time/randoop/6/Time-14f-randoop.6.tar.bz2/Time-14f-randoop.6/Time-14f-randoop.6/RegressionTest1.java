import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test01() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test01");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay3.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField6 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType5);
//        long long8 = zeroIsMaxDateTimeField6.roundHalfEven((long) '#');
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        int int11 = dateTime10.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = dateTime10.withChronology((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        java.util.Date date16 = dateTime15.toDate();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay19.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property22 = dateTime18.property(dateTimeFieldType21);
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime15, (org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime24 = dateTime13.toDateTime(chronology23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField26 = iSOChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.minuteOfHour();
//        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = monthDay28.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField31 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField27, dateTimeFieldType30);
//        long long34 = zeroIsMaxDateTimeField31.addWrapField((long) 19, (int) (byte) 1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField(chronology23, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField31, 41);
//        int int37 = skipDateTimeField36.getMinimumValue();
//        org.joda.time.MonthDay monthDay38 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = monthDay38.getFieldType((int) (byte) 1);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField36, dateTimeFieldType40, 60);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField6, dateTimeFieldType40, 100, 100, 458);
//        long long48 = offsetDateTimeField46.roundFloor((long) 596);
//        int int50 = offsetDateTimeField46.get(0L);
//        java.lang.String str52 = offsetDateTimeField46.getAsShortText(1920390L);
//        int int54 = offsetDateTimeField46.getMinimumValue((long) 32);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 584 + "'", int11 == 584);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 60019L + "'", long34 == 60019L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(monthDay38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 160 + "'", int50 == 160);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "132" + "'", str52.equals("132"));
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 101 + "'", int54 == 101);
//    }

//    @Test
//    public void test02() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test02");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getYearOfEra();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYear(586);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        int int7 = dateTime6.getYearOfEra();
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        java.util.Date date11 = dateTime10.toDate();
//        org.joda.time.DateTime dateTime13 = dateTime10.plusMillis((int) ' ');
//        int int14 = dateTime10.getDayOfMonth();
//        boolean boolean15 = dateTime4.isEqual((org.joda.time.ReadableInstant) dateTime10);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay3.getFieldType((int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay7 = monthDay3.plus(readablePeriod6);
        int[] intArray9 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay7, (-60000L));
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField11 = iSOChronology10.millis();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.minuteOfHour();
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = monthDay13.getFieldType((int) (byte) 1);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField16 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField12, dateTimeFieldType15);
        int int17 = zeroIsMaxDateTimeField16.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField16, 207);
        org.joda.time.DurationField durationField20 = iSOChronology0.years();
        long long23 = durationField20.subtract((long) 29, (long) 20);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-631151999971L) + "'", long23 == (-631151999971L));
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test04");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = dateTime1.withChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = monthDay10.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property13 = dateTime9.property(dateTimeFieldType12);
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime4.toDateTime(chronology14);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay19.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
//        long long25 = zeroIsMaxDateTimeField22.addWrapField((long) 19, (int) (byte) 1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology14, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField22, 41);
//        int int28 = skipDateTimeField27.getMinimumValue();
//        org.joda.time.MonthDay monthDay29 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = monthDay29.getFieldType((int) (byte) 1);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField27, dateTimeFieldType31, 60);
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField35 = iSOChronology34.millis();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        org.joda.time.MonthDay monthDay37 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = monthDay37.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField36, dateTimeFieldType39);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField33, dateTimeFieldType39);
//        int int42 = dividedDateTimeField33.getMinimumValue();
//        java.lang.String str44 = dividedDateTimeField33.getAsText((long) 10);
//        long long47 = dividedDateTimeField33.addWrapField((long) (short) 1, 350);
//        long long49 = dividedDateTimeField33.roundFloor((long) 501);
//        try {
//            long long51 = dividedDateTimeField33.remainder(900020L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 74 for dayOfMonth must be in the range [0,60]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 917 + "'", int2 == 917);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 60019L + "'", long25 == 60019L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(monthDay29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(monthDay37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1" + "'", str44.equals("1"));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
//    }

//    @Test
//    public void test05() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test05");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = monthDay0.getFieldType((int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay4 = monthDay0.plus(readablePeriod3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        org.joda.time.MonthDay monthDay6 = property5.getMonthDay();
//        int int7 = property5.get();
//        java.util.Locale locale8 = null;
//        int int9 = property5.getMaximumTextLength(locale8);
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType2);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test07() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test07");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        long long1 = dateTime0.getMillis();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560630828969L + "'", long1 == 1560630828969L);
//    }

//    @Test
//    public void test08() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test08");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = dateTime1.withChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = monthDay10.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property13 = dateTime9.property(dateTimeFieldType12);
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime4.toDateTime(chronology14);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay19.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
//        long long25 = zeroIsMaxDateTimeField22.addWrapField((long) 19, (int) (byte) 1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology14, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField22, 41);
//        int int28 = skipDateTimeField27.getMinimumValue();
//        org.joda.time.DurationField durationField29 = skipDateTimeField27.getRangeDurationField();
//        long long32 = skipDateTimeField27.set((-60000L), 0);
//        int int33 = skipDateTimeField27.getMinimumValue();
//        long long35 = skipDateTimeField27.roundCeiling(0L);
//        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = monthDay36.getFieldType((int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod39 = null;
//        org.joda.time.MonthDay monthDay40 = monthDay36.plus(readablePeriod39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay(dateTimeZone41);
//        boolean boolean43 = monthDay40.isAfter((org.joda.time.ReadablePartial) monthDay42);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = skipDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) monthDay42, 20, locale45);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField48 = iSOChronology47.millis();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.minuteOfHour();
//        org.joda.time.MonthDay monthDay50 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = monthDay50.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField53 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField49, dateTimeFieldType52);
//        boolean boolean55 = zeroIsMaxDateTimeField53.isLeap((long) 970);
//        boolean boolean57 = zeroIsMaxDateTimeField53.isLeap((long) 404);
//        int int58 = zeroIsMaxDateTimeField53.getMaximumValue();
//        org.joda.time.MonthDay monthDay59 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = monthDay59.getFieldType((int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod62 = null;
//        org.joda.time.MonthDay monthDay63 = monthDay59.plus(readablePeriod62);
//        org.joda.time.DateTimeZone dateTimeZone64 = null;
//        org.joda.time.MonthDay monthDay65 = new org.joda.time.MonthDay(dateTimeZone64);
//        boolean boolean66 = monthDay63.isAfter((org.joda.time.ReadablePartial) monthDay65);
//        int int67 = zeroIsMaxDateTimeField53.getMinimumValue((org.joda.time.ReadablePartial) monthDay63);
//        long long69 = zeroIsMaxDateTimeField53.roundHalfEven((long) 249);
//        org.joda.time.DateTimeZone dateTimeZone70 = null;
//        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime(dateTimeZone70);
//        org.joda.time.MonthDay monthDay72 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType74 = monthDay72.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property75 = dateTime71.property(dateTimeFieldType74);
//        int int76 = property75.getMaximumValue();
//        org.joda.time.DateTime dateTime78 = property75.addToCopy(100);
//        org.joda.time.DateTimeZone dateTimeZone79 = null;
//        org.joda.time.DateTime dateTime80 = new org.joda.time.DateTime(dateTimeZone79);
//        org.joda.time.MonthDay monthDay81 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType83 = monthDay81.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property84 = dateTime80.property(dateTimeFieldType83);
//        boolean boolean85 = dateTime78.isSupported(dateTimeFieldType83);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType83, 1, 0, 1);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField91 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField53, dateTimeFieldType83, 255);
//        org.joda.time.MonthDay.Property property92 = monthDay42.property(dateTimeFieldType83);
//        org.joda.time.MonthDay monthDay94 = property92.addWrapFieldToCopy(458);
//        int int95 = property92.getMaximumValue();
//        int int96 = property92.getMinimumValue();
//        java.util.Locale locale98 = null;
//        try {
//            org.joda.time.MonthDay monthDay99 = property92.setCopy("", locale98);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 980 + "'", int2 == 980);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 60019L + "'", long25 == 60019L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3540000L) + "'", long32 == (-3540000L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(monthDay40);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "20" + "'", str46.equals("20"));
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(monthDay50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 60 + "'", int58 == 60);
//        org.junit.Assert.assertNotNull(monthDay59);
//        org.junit.Assert.assertNotNull(dateTimeFieldType61);
//        org.junit.Assert.assertNotNull(monthDay63);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
//        org.junit.Assert.assertNotNull(monthDay72);
//        org.junit.Assert.assertNotNull(dateTimeFieldType74);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 30 + "'", int76 == 30);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(monthDay81);
//        org.junit.Assert.assertNotNull(dateTimeFieldType83);
//        org.junit.Assert.assertNotNull(property84);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
//        org.junit.Assert.assertNotNull(property92);
//        org.junit.Assert.assertNotNull(monthDay94);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 30 + "'", int95 == 30);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
//    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        java.lang.String str3 = dateTimeZone2.toString();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField5 = julianChronology4.seconds();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology8 = julianChronology4.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) "132", dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+32:00" + "'", str3.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test10");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = dateTime1.withChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DurationField durationField5 = iSOChronology3.weeks();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology3.hourOfHalfday();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test13");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = dateTime1.withChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = monthDay10.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property13 = dateTime9.property(dateTimeFieldType12);
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime4.toDateTime(chronology14);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay19.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
//        long long25 = zeroIsMaxDateTimeField22.addWrapField((long) 19, (int) (byte) 1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology14, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField22, 41);
//        int int28 = skipDateTimeField27.getMinimumValue();
//        org.joda.time.DurationField durationField29 = skipDateTimeField27.getRangeDurationField();
//        long long32 = skipDateTimeField27.set((-60000L), 0);
//        int int33 = skipDateTimeField27.getMinimumValue();
//        long long35 = skipDateTimeField27.roundCeiling(0L);
//        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = monthDay36.getFieldType((int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod39 = null;
//        org.joda.time.MonthDay monthDay40 = monthDay36.plus(readablePeriod39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay(dateTimeZone41);
//        boolean boolean43 = monthDay40.isAfter((org.joda.time.ReadablePartial) monthDay42);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = skipDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) monthDay42, 20, locale45);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField48 = iSOChronology47.millis();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.minuteOfHour();
//        org.joda.time.MonthDay monthDay50 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = monthDay50.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField53 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField49, dateTimeFieldType52);
//        boolean boolean55 = zeroIsMaxDateTimeField53.isLeap((long) 970);
//        boolean boolean57 = zeroIsMaxDateTimeField53.isLeap((long) 404);
//        int int58 = zeroIsMaxDateTimeField53.getMaximumValue();
//        org.joda.time.MonthDay monthDay59 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = monthDay59.getFieldType((int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod62 = null;
//        org.joda.time.MonthDay monthDay63 = monthDay59.plus(readablePeriod62);
//        org.joda.time.DateTimeZone dateTimeZone64 = null;
//        org.joda.time.MonthDay monthDay65 = new org.joda.time.MonthDay(dateTimeZone64);
//        boolean boolean66 = monthDay63.isAfter((org.joda.time.ReadablePartial) monthDay65);
//        int int67 = zeroIsMaxDateTimeField53.getMinimumValue((org.joda.time.ReadablePartial) monthDay63);
//        long long69 = zeroIsMaxDateTimeField53.roundHalfEven((long) 249);
//        org.joda.time.DateTimeZone dateTimeZone70 = null;
//        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime(dateTimeZone70);
//        org.joda.time.MonthDay monthDay72 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType74 = monthDay72.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property75 = dateTime71.property(dateTimeFieldType74);
//        int int76 = property75.getMaximumValue();
//        org.joda.time.DateTime dateTime78 = property75.addToCopy(100);
//        org.joda.time.DateTimeZone dateTimeZone79 = null;
//        org.joda.time.DateTime dateTime80 = new org.joda.time.DateTime(dateTimeZone79);
//        org.joda.time.MonthDay monthDay81 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType83 = monthDay81.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property84 = dateTime80.property(dateTimeFieldType83);
//        boolean boolean85 = dateTime78.isSupported(dateTimeFieldType83);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType83, 1, 0, 1);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField91 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField53, dateTimeFieldType83, 255);
//        org.joda.time.MonthDay.Property property92 = monthDay42.property(dateTimeFieldType83);
//        org.joda.time.MonthDay monthDay94 = property92.addWrapFieldToCopy(458);
//        java.util.Locale locale95 = null;
//        java.lang.String str96 = property92.getAsShortText(locale95);
//        org.joda.time.MonthDay monthDay98 = property92.addWrapFieldToCopy(761);
//        org.joda.time.MonthDay monthDay99 = property92.getMonthDay();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 92 + "'", int2 == 92);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 60019L + "'", long25 == 60019L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3540000L) + "'", long32 == (-3540000L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(monthDay40);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "20" + "'", str46.equals("20"));
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(monthDay50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 60 + "'", int58 == 60);
//        org.junit.Assert.assertNotNull(monthDay59);
//        org.junit.Assert.assertNotNull(dateTimeFieldType61);
//        org.junit.Assert.assertNotNull(monthDay63);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
//        org.junit.Assert.assertNotNull(monthDay72);
//        org.junit.Assert.assertNotNull(dateTimeFieldType74);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 30 + "'", int76 == 30);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(monthDay81);
//        org.junit.Assert.assertNotNull(dateTimeFieldType83);
//        org.junit.Assert.assertNotNull(property84);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
//        org.junit.Assert.assertNotNull(property92);
//        org.junit.Assert.assertNotNull(monthDay94);
//        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "15" + "'", str96.equals("15"));
//        org.junit.Assert.assertNotNull(monthDay98);
//        org.junit.Assert.assertNotNull(monthDay99);
//    }

//    @Test
//    public void test14() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test14");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = dateTime1.withChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = monthDay10.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property13 = dateTime9.property(dateTimeFieldType12);
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime4.toDateTime(chronology14);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay19.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
//        long long25 = zeroIsMaxDateTimeField22.addWrapField((long) 19, (int) (byte) 1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology14, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField22, 41);
//        int int28 = skipDateTimeField27.getMinimumValue();
//        org.joda.time.DurationField durationField29 = skipDateTimeField27.getRangeDurationField();
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = monthDay30.getFieldType((int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod33 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay30.plus(readablePeriod33);
//        org.joda.time.MonthDay.Property property35 = monthDay34.dayOfMonth();
//        org.joda.time.MonthDay monthDay36 = property35.getMonthDay();
//        int int37 = skipDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) monthDay36);
//        int int39 = skipDateTimeField27.getMaximumValue((long) 76);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 132 + "'", int2 == 132);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 60019L + "'", long25 == 60019L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 60 + "'", int37 == 60);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 60 + "'", int39 == 60);
//    }

//    @Test
//    public void test15() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test15");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.DateTime dateTime4 = dateTime1.withWeekOfWeekyear((int) (byte) 10);
//        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 635 + "'", int2 == 635);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay3.getFieldType((int) (byte) 1);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField6 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType5);
        boolean boolean8 = zeroIsMaxDateTimeField6.isLeap((long) 970);
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = monthDay9.getFieldType((int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay13 = monthDay9.plus(readablePeriod12);
        int int14 = zeroIsMaxDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) monthDay9);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime16 = monthDay9.toDateTime((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime17 = dateTime16.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime17.plusMillis(735);
        org.joda.time.DateTime dateTime20 = dateTime19.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 60 + "'", int14 == 60);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay3.getFieldType((int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay7 = monthDay3.plus(readablePeriod6);
        int[] intArray9 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay7, (-60000L));
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

//    @Test
//    public void test18() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test18");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = dateTime1.withChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = monthDay10.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property13 = dateTime9.property(dateTimeFieldType12);
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime4.toDateTime(chronology14);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay19.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
//        long long25 = zeroIsMaxDateTimeField22.addWrapField((long) 19, (int) (byte) 1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology14, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField22, 41);
//        int int28 = skipDateTimeField27.getMinimumValue();
//        org.joda.time.DurationField durationField29 = skipDateTimeField27.getRangeDurationField();
//        long long32 = skipDateTimeField27.set((-60000L), 0);
//        int int33 = skipDateTimeField27.getMinimumValue();
//        long long35 = skipDateTimeField27.roundCeiling(0L);
//        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = monthDay36.getFieldType((int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod39 = null;
//        org.joda.time.MonthDay monthDay40 = monthDay36.plus(readablePeriod39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay(dateTimeZone41);
//        boolean boolean43 = monthDay40.isAfter((org.joda.time.ReadablePartial) monthDay42);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = skipDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) monthDay42, 20, locale45);
//        java.lang.String str48 = monthDay42.toString("1");
//        org.joda.time.MonthDay.Property property49 = monthDay42.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = property49.getFieldType();
//        org.joda.time.MonthDay monthDay52 = property49.addToCopy(100);
//        org.joda.time.DurationField durationField53 = property49.getDurationField();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 889 + "'", int2 == 889);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 60019L + "'", long25 == 60019L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3540000L) + "'", long32 == (-3540000L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(monthDay40);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "20" + "'", str46.equals("20"));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(durationField53);
//    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str1 = gJChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = monthDay4.getFieldType((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime3.property(dateTimeFieldType6);
        int int8 = property7.getMaximumValue();
        org.joda.time.DateTime dateTime10 = property7.addToCopy(100);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 1);
        long long16 = dateTimeZone12.convertLocalToUTC((long) 1, false, (long) (byte) 10);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now(dateTimeZone12);
        boolean boolean18 = dateTime10.equals((java.lang.Object) dateTimeZone12);
        java.lang.String str20 = dateTimeZone12.getName(1560630735497L);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        java.util.Date date23 = dateTime22.toDate();
        org.joda.time.DateTime.Property property24 = dateTime22.dayOfWeek();
        org.joda.time.DateTime dateTime26 = dateTime22.minus((long) (short) -1);
        org.joda.time.DateTime.Property property27 = dateTime22.millisOfDay();
        long long28 = property27.remainder();
        org.joda.time.DateTime dateTime30 = property27.addToCopy(458);
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) dateTime30);
        java.lang.String str32 = dateTimeZone12.getID();
        org.joda.time.Chronology chronology33 = gJChronology0.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone34);
        java.util.Date date36 = dateTime35.toDate();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(dateTimeZone37);
        org.joda.time.MonthDay monthDay39 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = monthDay39.getFieldType((int) (byte) 1);
        org.joda.time.DateTime.Property property42 = dateTime38.property(dateTimeFieldType41);
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime35, (org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.DateTime dateTime45 = dateTime35.minus(readablePeriod44);
        try {
            org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) dateTime35, 1968);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1968");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00:00.001" + "'", str20.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "+00:00:00.001" + "'", str32.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(dateTime45);
    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test20");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.DateTime dateTime4 = dateTime1.withWeekOfWeekyear((int) (byte) 10);
//        org.joda.time.DurationFieldType durationFieldType5 = null;
//        try {
//            org.joda.time.DateTime dateTime7 = dateTime4.withFieldAdded(durationFieldType5, 514);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 254 + "'", int2 == 254);
//        org.junit.Assert.assertNotNull(dateTime4);
//    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay2.getFieldType((int) (byte) 1);
        org.joda.time.DateTime.Property property5 = dateTime1.property(dateTimeFieldType4);
        int int6 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property5.addToCopy(100);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = monthDay11.getFieldType((int) (byte) 1);
        org.joda.time.DateTime.Property property14 = dateTime10.property(dateTimeFieldType13);
        boolean boolean15 = dateTime8.isSupported(dateTimeFieldType13);
        try {
            org.joda.time.DateTime dateTime17 = dateTime8.withEra(698);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 698 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 30 + "'", int6 == 30);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "6");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test23() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test23");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay3.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField6 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType5);
//        long long8 = zeroIsMaxDateTimeField6.roundHalfEven((long) '#');
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        int int11 = dateTime10.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = dateTime10.withChronology((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        java.util.Date date16 = dateTime15.toDate();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay19.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property22 = dateTime18.property(dateTimeFieldType21);
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime15, (org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime24 = dateTime13.toDateTime(chronology23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField26 = iSOChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.minuteOfHour();
//        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = monthDay28.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField31 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField27, dateTimeFieldType30);
//        long long34 = zeroIsMaxDateTimeField31.addWrapField((long) 19, (int) (byte) 1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField(chronology23, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField31, 41);
//        int int37 = skipDateTimeField36.getMinimumValue();
//        org.joda.time.MonthDay monthDay38 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = monthDay38.getFieldType((int) (byte) 1);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField36, dateTimeFieldType40, 60);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField6, dateTimeFieldType40, 100, 100, 458);
//        long long49 = offsetDateTimeField46.add((long) (short) 1, (long) 618);
//        long long51 = offsetDateTimeField46.roundHalfFloor((long) 117);
//        boolean boolean53 = offsetDateTimeField46.isLeap((long) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        java.util.Date date56 = dateTime55.toDate();
//        org.joda.time.DateTime dateTime58 = dateTime55.plusMillis((int) ' ');
//        int int59 = dateTime55.getDayOfMonth();
//        org.joda.time.DateTime.Property property60 = dateTime55.millisOfSecond();
//        org.joda.time.MonthDay monthDay61 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType63 = monthDay61.getFieldType((int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod64 = null;
//        org.joda.time.MonthDay monthDay65 = monthDay61.plus(readablePeriod64);
//        org.joda.time.DateTime dateTime66 = dateTime55.withFields((org.joda.time.ReadablePartial) monthDay61);
//        org.joda.time.chrono.ISOChronology iSOChronology68 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField69 = iSOChronology68.millis();
//        org.joda.time.DateTimeField dateTimeField70 = iSOChronology68.weekyearOfCentury();
//        org.joda.time.MonthDay monthDay71 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = monthDay71.getFieldType((int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod74 = null;
//        org.joda.time.MonthDay monthDay75 = monthDay71.plus(readablePeriod74);
//        int[] intArray77 = iSOChronology68.get((org.joda.time.ReadablePartial) monthDay75, (-60000L));
//        try {
//            int[] intArray79 = offsetDateTimeField46.add((org.joda.time.ReadablePartial) monthDay61, 503, intArray77, 507);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 503");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 300 + "'", int11 == 300);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 60019L + "'", long34 == 60019L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(monthDay38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 37080001L + "'", long49 == 37080001L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 15 + "'", int59 == 15);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(monthDay61);
//        org.junit.Assert.assertNotNull(dateTimeFieldType63);
//        org.junit.Assert.assertNotNull(monthDay65);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(iSOChronology68);
//        org.junit.Assert.assertNotNull(durationField69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(monthDay71);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray77);
//    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = iSOChronology0.get(readablePeriod3, (long) 787);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(491, 402);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 491 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test26() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test26");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
//        int[] intArray5 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay3, 0L);
//        org.joda.time.DurationField durationField6 = iSOChronology1.millis();
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) 458, (org.joda.time.Chronology) iSOChronology1);
//        java.lang.String str8 = iSOChronology1.toString();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.yearOfCentury();
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = monthDay10.getFieldType((int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.MonthDay monthDay14 = monthDay10.plus(readablePeriod13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.MonthDay monthDay16 = monthDay14.minus(readablePeriod15);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        int int19 = dateTime18.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = dateTime18.withChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        java.util.Date date24 = dateTime23.toDate();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
//        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay27.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property30 = dateTime26.property(dateTimeFieldType29);
//        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime23, (org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.DateTime dateTime32 = dateTime21.toDateTime(chronology31);
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField34 = iSOChronology33.millis();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.minuteOfHour();
//        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = monthDay36.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField35, dateTimeFieldType38);
//        long long42 = zeroIsMaxDateTimeField39.addWrapField((long) 19, (int) (byte) 1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField(chronology31, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField39, 41);
//        int int45 = skipDateTimeField44.getMinimumValue();
//        long long47 = skipDateTimeField44.roundFloor((long) 318);
//        org.joda.time.ReadablePartial readablePartial48 = null;
//        org.joda.time.MonthDay monthDay49 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = monthDay49.getFieldType((int) (byte) 1);
//        int[] intArray52 = monthDay49.getValues();
//        int int53 = skipDateTimeField44.getMinimumValue(readablePartial48, intArray52);
//        iSOChronology1.validate((org.joda.time.ReadablePartial) monthDay16, intArray52);
//        org.joda.time.Chronology chronology55 = iSOChronology1.withUTC();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str8.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 355 + "'", int19 == 355);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(monthDay27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 60019L + "'", long42 == 60019L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
//        org.junit.Assert.assertNotNull(monthDay49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(chronology55);
//    }

//    @Test
//    public void test27() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test27");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = dateTime1.withChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = monthDay10.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property13 = dateTime9.property(dateTimeFieldType12);
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime4.toDateTime(chronology14);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay19.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
//        long long25 = zeroIsMaxDateTimeField22.addWrapField((long) 19, (int) (byte) 1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology14, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField22, 41);
//        int int28 = skipDateTimeField27.getMinimumValue();
//        org.joda.time.DurationField durationField29 = skipDateTimeField27.getRangeDurationField();
//        long long32 = skipDateTimeField27.set((-60000L), 0);
//        int int33 = skipDateTimeField27.getMinimumValue();
//        long long35 = skipDateTimeField27.roundFloor((long) (short) -1);
//        int int37 = skipDateTimeField27.getMaximumValue((long) 281);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 741 + "'", int2 == 741);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 60019L + "'", long25 == 60019L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3540000L) + "'", long32 == (-3540000L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-60000L) + "'", long35 == (-60000L));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 60 + "'", int37 == 60);
//    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("48792508", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"48792508/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        int[] intArray5 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay3, 0L);
        org.joda.time.DurationField durationField6 = iSOChronology1.millis();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) 458, (org.joda.time.Chronology) iSOChronology1);
        java.lang.String str8 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.clockhourOfHalfday();
        java.lang.String str10 = iSOChronology1.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str8.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay3.getFieldType((int) (byte) 1);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField6 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType5);
        boolean boolean8 = zeroIsMaxDateTimeField6.isLeap((long) 970);
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = monthDay9.getFieldType((int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay13 = monthDay9.plus(readablePeriod12);
        int int14 = zeroIsMaxDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) monthDay9);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = zeroIsMaxDateTimeField6.getType();
        long long17 = zeroIsMaxDateTimeField6.roundHalfFloor((long) 645);
        try {
            long long20 = zeroIsMaxDateTimeField6.set(2311199999L, 976);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 976 for dayOfMonth must be in the range [1,60]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 60 + "'", int14 == 60);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMonthOfYear((int) (short) 10);
        java.lang.String str8 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "20" + "'", str8.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeParser9);
    }

//    @Test
//    public void test32() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test32");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay3.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField6 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType5);
//        long long8 = zeroIsMaxDateTimeField6.roundHalfEven((long) '#');
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        int int11 = dateTime10.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = dateTime10.withChronology((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        java.util.Date date16 = dateTime15.toDate();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay19.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property22 = dateTime18.property(dateTimeFieldType21);
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime15, (org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime24 = dateTime13.toDateTime(chronology23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField26 = iSOChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.minuteOfHour();
//        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = monthDay28.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField31 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField27, dateTimeFieldType30);
//        long long34 = zeroIsMaxDateTimeField31.addWrapField((long) 19, (int) (byte) 1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField(chronology23, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField31, 41);
//        int int37 = skipDateTimeField36.getMinimumValue();
//        org.joda.time.MonthDay monthDay38 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = monthDay38.getFieldType((int) (byte) 1);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField36, dateTimeFieldType40, 60);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField6, dateTimeFieldType40, 100, 100, 458);
//        long long49 = offsetDateTimeField46.add((long) (short) 1, (long) 618);
//        long long51 = offsetDateTimeField46.roundHalfFloor((long) 117);
//        boolean boolean53 = offsetDateTimeField46.isLeap((long) (byte) 10);
//        int int55 = offsetDateTimeField46.getLeapAmount(1560630749563L);
//        java.lang.String str56 = offsetDateTimeField46.getName();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 988 + "'", int11 == 988);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 60019L + "'", long34 == 60019L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(monthDay38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 37080001L + "'", long49 == 37080001L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "dayOfMonth" + "'", str56.equals("dayOfMonth"));
//    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(1560630795637L, dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test34() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test34");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = monthDay0.getFieldType((int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay4 = monthDay0.plus(readablePeriod3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(dateTimeZone5);
//        boolean boolean7 = monthDay4.isAfter((org.joda.time.ReadablePartial) monthDay6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        java.lang.Integer int9 = dateTimeFormatter8.getPivotYear();
//        java.lang.String str10 = monthDay6.toString(dateTimeFormatter8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withPivotYear(911);
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType2);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNull(int9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "����-06-15T��" + "'", str10.equals("����-06-15T��"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        org.joda.time.DateTime dateTime6 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime7 = monthDay0.toDateTime((org.joda.time.ReadableInstant) dateTime6);
        boolean boolean9 = dateTime6.isEqual(19080537L);
        try {
            org.joda.time.DateTime dateTime13 = dateTime6.withDate(185, 643, 787);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 643 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay2.getFieldType((int) (byte) 1);
        org.joda.time.DateTime.Property property5 = dateTime1.property(dateTimeFieldType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        java.util.Date date8 = dateTime7.toDate();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfWeek();
        long long10 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay3.getFieldType((int) (byte) 1);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField6 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType5);
        boolean boolean8 = zeroIsMaxDateTimeField6.isLeap((long) 970);
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = monthDay9.getFieldType((int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay13 = monthDay9.plus(readablePeriod12);
        int int14 = zeroIsMaxDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) monthDay9);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime16 = monthDay9.toDateTime((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime17 = dateTime16.withEarlierOffsetAtOverlap();
        org.joda.time.DateMidnight dateMidnight18 = dateTime16.toDateMidnight();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 60 + "'", int14 == 60);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateMidnight18);
    }

//    @Test
//    public void test38() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test38");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = dateTime1.withChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = monthDay10.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property13 = dateTime9.property(dateTimeFieldType12);
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime4.toDateTime(chronology14);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay19.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
//        long long25 = zeroIsMaxDateTimeField22.addWrapField((long) 19, (int) (byte) 1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology14, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField22, 41);
//        int int28 = skipDateTimeField27.getMinimumValue();
//        org.joda.time.MonthDay monthDay29 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = monthDay29.getFieldType((int) (byte) 1);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField27, dateTimeFieldType31, 60);
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField35 = iSOChronology34.millis();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        org.joda.time.MonthDay monthDay37 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = monthDay37.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField36, dateTimeFieldType39);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField33, dateTimeFieldType39);
//        int int42 = dividedDateTimeField33.getMinimumValue();
//        long long44 = dividedDateTimeField33.remainder((long) 788);
//        long long47 = dividedDateTimeField33.addWrapField((long) 483, 86399999);
//        int int50 = dividedDateTimeField33.getDifference((long) 774, (long) 423);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 507 + "'", int2 == 507);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 60019L + "'", long25 == 60019L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(monthDay29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(monthDay37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 788L + "'", long44 == 788L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 60483L + "'", long47 == 60483L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//    }

//    @Test
//    public void test39() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test39");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = dateTime1.withChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = monthDay10.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property13 = dateTime9.property(dateTimeFieldType12);
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime4.toDateTime(chronology14);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay19.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
//        long long25 = zeroIsMaxDateTimeField22.addWrapField((long) 19, (int) (byte) 1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology14, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField22, 41);
//        int int28 = skipDateTimeField27.getMinimumValue();
//        org.joda.time.MonthDay monthDay29 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = monthDay29.getFieldType((int) (byte) 1);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField27, dateTimeFieldType31, 60);
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField35 = iSOChronology34.millis();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        org.joda.time.MonthDay monthDay37 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = monthDay37.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField36, dateTimeFieldType39);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField33, dateTimeFieldType39);
//        long long44 = dividedDateTimeField33.add((long) 231, (long) 481);
//        long long47 = dividedDateTimeField33.addWrapField((long) 355, 0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 696 + "'", int2 == 696);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 60019L + "'", long25 == 60019L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(monthDay29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(monthDay37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1731600231L + "'", long44 == 1731600231L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 355L + "'", long47 == 355L);
//    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay2.getFieldType((int) (byte) 1);
        org.joda.time.DateTime.Property property5 = dateTime1.property(dateTimeFieldType4);
        int int6 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property5.addToCopy(100);
        int int9 = property5.getMaximumValueOverall();
        org.joda.time.DateTime dateTime10 = property5.getDateTime();
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 30 + "'", int6 == 30);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay2.getFieldType((int) (byte) 1);
        org.joda.time.DateTime.Property property5 = dateTime1.property(dateTimeFieldType4);
        int int6 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property5.addToCopy(100);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 1);
        long long14 = dateTimeZone10.convertLocalToUTC((long) 1, false, (long) (byte) 10);
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now(dateTimeZone10);
        boolean boolean16 = dateTime8.equals((java.lang.Object) dateTimeZone10);
        java.lang.String str18 = dateTimeZone10.getName(1560630735497L);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
        java.util.Date date21 = dateTime20.toDate();
        org.joda.time.DateTime.Property property22 = dateTime20.dayOfWeek();
        org.joda.time.DateTime dateTime24 = dateTime20.minus((long) (short) -1);
        org.joda.time.DateTime.Property property25 = dateTime20.millisOfDay();
        long long26 = property25.remainder();
        org.joda.time.DateTime dateTime28 = property25.addToCopy(458);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime28);
        java.lang.String str30 = dateTimeZone10.getID();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone10);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 30 + "'", int6 == 30);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.001" + "'", str18.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+00:00:00.001" + "'", str30.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay3.getFieldType((int) (byte) 1);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField6 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType5);
        boolean boolean8 = zeroIsMaxDateTimeField6.isLeap((long) 970);
        boolean boolean10 = zeroIsMaxDateTimeField6.isLeap((long) 404);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = monthDay11.getFieldType((int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay15 = monthDay11.plus(readablePeriod14);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(dateTimeZone16);
        boolean boolean18 = monthDay15.isAfter((org.joda.time.ReadablePartial) monthDay17);
        int int19 = zeroIsMaxDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) monthDay15);
        long long21 = zeroIsMaxDateTimeField6.roundHalfCeiling(21L);
        int int23 = zeroIsMaxDateTimeField6.getMinimumValue((long) 479);
        java.util.Locale locale25 = null;
        java.lang.String str26 = zeroIsMaxDateTimeField6.getAsShortText(830, locale25);
        long long28 = zeroIsMaxDateTimeField6.roundHalfEven((long) 219);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 60 + "'", int19 == 60);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "830" + "'", str26.equals("830"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.centuries();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = monthDay7.getFieldType((int) (byte) 1);
        org.joda.time.DateTime.Property property10 = dateTime6.property(dateTimeFieldType9);
        int int11 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.addToCopy(100);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 1);
        long long19 = dateTimeZone15.convertLocalToUTC((long) 1, false, (long) (byte) 10);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now(dateTimeZone15);
        boolean boolean21 = dateTime13.equals((java.lang.Object) dateTimeZone15);
        try {
            org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(0, 425, 813, 998, 286, dateTimeZone15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 998 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 30 + "'", int11 == 30);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test45() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test45");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getMillisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime3.withWeekOfWeekyear((int) (byte) 10);
//        org.joda.time.DateTime dateTime8 = dateTime3.withHourOfDay(0);
//        org.joda.time.TimeOfDay timeOfDay9 = dateTime8.toTimeOfDay();
//        int int10 = dateTime8.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
//        org.joda.time.DateMidnight dateMidnight15 = dateTime14.toDateMidnight();
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime8, (org.joda.time.ReadableInstant) dateTime14);
//        try {
//            org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(296, 117, chronology16);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 296 for monthOfYear must not be larger than 12");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 253 + "'", int4 == 253);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(timeOfDay9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateMidnight15);
//        org.junit.Assert.assertNotNull(chronology16);
//    }

//    @Test
//    public void test46() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test46");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = dateTime1.withChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = monthDay10.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property13 = dateTime9.property(dateTimeFieldType12);
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime4.toDateTime(chronology14);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay19.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
//        long long25 = zeroIsMaxDateTimeField22.addWrapField((long) 19, (int) (byte) 1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology14, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField22, 41);
//        int int28 = skipDateTimeField27.getMinimumValue();
//        org.joda.time.DurationField durationField29 = skipDateTimeField27.getRangeDurationField();
//        long long32 = skipDateTimeField27.set((-60000L), 0);
//        int int35 = skipDateTimeField27.getDifference((long) 41, 37080001L);
//        try {
//            long long38 = skipDateTimeField27.set((long) 117, 201);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 201 for dayOfMonth must be in the range [0,60]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 269 + "'", int2 == 269);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 60019L + "'", long25 == 60019L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3540000L) + "'", long32 == (-3540000L));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-617) + "'", int35 == (-617));
//    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 1);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, true);
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone1.isLocalDateTimeGap(localDateTime6);
        long long10 = dateTimeZone1.convertLocalToUTC((long) 587, true);
        long long12 = dateTimeZone1.convertUTCToLocal((long) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 586L + "'", long10 == 586L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 101L + "'", long12 == 101L);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 618, 6, 494, 507, 858, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 494 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) 645, 212);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 212");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test50() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test50");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay3.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField6 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType5);
//        boolean boolean8 = zeroIsMaxDateTimeField6.isLeap((long) 970);
//        boolean boolean10 = zeroIsMaxDateTimeField6.isLeap((long) 404);
//        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = monthDay11.getFieldType((int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.MonthDay monthDay15 = monthDay11.plus(readablePeriod14);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(dateTimeZone16);
//        boolean boolean18 = monthDay15.isAfter((org.joda.time.ReadablePartial) monthDay17);
//        int int19 = zeroIsMaxDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) monthDay15);
//        int int20 = monthDay15.getDayOfMonth();
//        org.joda.time.ReadablePartial readablePartial21 = null;
//        try {
//            boolean boolean22 = monthDay15.isEqual(readablePartial21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 60 + "'", int19 == 60);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
//    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        java.util.Locale locale4 = dateTimeFormatter3.getLocale();
        org.joda.time.Chronology chronology5 = dateTimeFormatter3.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(locale4);
        org.junit.Assert.assertNull(chronology5);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay3.getFieldType((int) (byte) 1);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField6 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType5);
        long long9 = zeroIsMaxDateTimeField6.addWrapField((long) 19, (int) (byte) 1);
        org.joda.time.DurationField durationField10 = zeroIsMaxDateTimeField6.getLeapDurationField();
        long long12 = zeroIsMaxDateTimeField6.roundHalfFloor((long) 0);
        long long14 = zeroIsMaxDateTimeField6.roundHalfFloor((long) 425);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 60019L + "'", long9 == 60019L);
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

//    @Test
//    public void test53() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test53");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = dateTime1.withChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = monthDay10.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property13 = dateTime9.property(dateTimeFieldType12);
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime4.toDateTime(chronology14);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay19.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
//        long long25 = zeroIsMaxDateTimeField22.addWrapField((long) 19, (int) (byte) 1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology14, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField22, 41);
//        int int28 = skipDateTimeField27.getMinimumValue();
//        org.joda.time.DurationField durationField29 = skipDateTimeField27.getRangeDurationField();
//        long long32 = skipDateTimeField27.set((-60000L), 0);
//        int int33 = skipDateTimeField27.getMinimumValue();
//        long long35 = skipDateTimeField27.roundCeiling(0L);
//        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = monthDay36.getFieldType((int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod39 = null;
//        org.joda.time.MonthDay monthDay40 = monthDay36.plus(readablePeriod39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay(dateTimeZone41);
//        boolean boolean43 = monthDay40.isAfter((org.joda.time.ReadablePartial) monthDay42);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = skipDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) monthDay42, 20, locale45);
//        java.lang.String str48 = monthDay42.toString("1");
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.MonthDay monthDay51 = new org.joda.time.MonthDay(dateTimeZone50);
//        int[] intArray53 = iSOChronology49.get((org.joda.time.ReadablePartial) monthDay51, 0L);
//        org.joda.time.MonthDay monthDay55 = monthDay51.minusMonths(1);
//        boolean boolean56 = monthDay42.isAfter((org.joda.time.ReadablePartial) monthDay55);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 389 + "'", int2 == 389);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 60019L + "'", long25 == 60019L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3540000L) + "'", long32 == (-3540000L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(monthDay40);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "20" + "'", str46.equals("20"));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(monthDay55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        int[] intArray5 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay3, 0L);
        org.joda.time.DurationField durationField6 = iSOChronology1.millis();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(10L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay10 = monthDay7.withPeriodAdded(readablePeriod8, 175);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(monthDay10);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = monthDay4.getFieldType((int) (byte) 1);
        org.joda.time.DateTime.Property property7 = dateTime3.property(dateTimeFieldType6);
        int int8 = property7.getMaximumValue();
        org.joda.time.DateTime dateTime10 = property7.addToCopy(100);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 1);
        long long16 = dateTimeZone12.convertLocalToUTC((long) 1, false, (long) (byte) 10);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now(dateTimeZone12);
        boolean boolean18 = dateTime10.equals((java.lang.Object) dateTimeZone12);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(1731600231L, dateTimeZone12);
        boolean boolean21 = dateTimeZone12.isStandardOffset((long) 506);
        org.joda.time.Chronology chronology22 = julianChronology0.withZone(dateTimeZone12);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay2.getFieldType((int) (byte) 1);
        org.joda.time.DateTime.Property property5 = dateTime1.property(dateTimeFieldType4);
        int int6 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property5.addToCopy(100);
        org.joda.time.DateTime dateTime9 = property5.getDateTime();
        org.joda.time.DateTime dateTime10 = property5.roundFloorCopy();
        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfSecond(912);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 30 + "'", int6 == 30);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = monthDay0.getFieldType((int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay4 = monthDay0.plus(readablePeriod3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.MonthDay monthDay9 = monthDay4.withFieldAdded(durationFieldType7, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(dateTimeFieldType2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay3.getFieldType((int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay7 = monthDay3.plus(readablePeriod6);
        int[] intArray9 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay7, (-60000L));
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology0.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeFormatter11.getZone();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        java.util.Date date15 = dateTime14.toDate();
        org.joda.time.DateTime.Property property16 = dateTime14.dayOfWeek();
        org.joda.time.DateTime dateTime18 = dateTime14.minus((long) (short) -1);
        int int19 = dateTime18.getCenturyOfEra();
        int int20 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone12);
        int int23 = dateTimeZone12.getOffsetFromLocal((long) 458);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

//    @Test
//    public void test59() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test59");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = dateTime1.withChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = monthDay10.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property13 = dateTime9.property(dateTimeFieldType12);
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime4.toDateTime(chronology14);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay19.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
//        long long25 = zeroIsMaxDateTimeField22.addWrapField((long) 19, (int) (byte) 1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology14, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField22, 41);
//        int int28 = skipDateTimeField27.getMinimumValue();
//        org.joda.time.DurationField durationField29 = skipDateTimeField27.getRangeDurationField();
//        long long32 = skipDateTimeField27.set((-60000L), 0);
//        int int33 = skipDateTimeField27.getMinimumValue();
//        long long35 = skipDateTimeField27.roundCeiling(0L);
//        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = monthDay36.getFieldType((int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod39 = null;
//        org.joda.time.MonthDay monthDay40 = monthDay36.plus(readablePeriod39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay(dateTimeZone41);
//        boolean boolean43 = monthDay40.isAfter((org.joda.time.ReadablePartial) monthDay42);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = skipDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) monthDay42, 20, locale45);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField48 = iSOChronology47.millis();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.minuteOfHour();
//        org.joda.time.MonthDay monthDay50 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = monthDay50.getFieldType((int) (byte) 1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField53 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField49, dateTimeFieldType52);
//        boolean boolean55 = zeroIsMaxDateTimeField53.isLeap((long) 970);
//        boolean boolean57 = zeroIsMaxDateTimeField53.isLeap((long) 404);
//        int int58 = zeroIsMaxDateTimeField53.getMaximumValue();
//        org.joda.time.MonthDay monthDay59 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = monthDay59.getFieldType((int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod62 = null;
//        org.joda.time.MonthDay monthDay63 = monthDay59.plus(readablePeriod62);
//        org.joda.time.DateTimeZone dateTimeZone64 = null;
//        org.joda.time.MonthDay monthDay65 = new org.joda.time.MonthDay(dateTimeZone64);
//        boolean boolean66 = monthDay63.isAfter((org.joda.time.ReadablePartial) monthDay65);
//        int int67 = zeroIsMaxDateTimeField53.getMinimumValue((org.joda.time.ReadablePartial) monthDay63);
//        long long69 = zeroIsMaxDateTimeField53.roundHalfEven((long) 249);
//        org.joda.time.DateTimeZone dateTimeZone70 = null;
//        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime(dateTimeZone70);
//        org.joda.time.MonthDay monthDay72 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType74 = monthDay72.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property75 = dateTime71.property(dateTimeFieldType74);
//        int int76 = property75.getMaximumValue();
//        org.joda.time.DateTime dateTime78 = property75.addToCopy(100);
//        org.joda.time.DateTimeZone dateTimeZone79 = null;
//        org.joda.time.DateTime dateTime80 = new org.joda.time.DateTime(dateTimeZone79);
//        org.joda.time.MonthDay monthDay81 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeFieldType dateTimeFieldType83 = monthDay81.getFieldType((int) (byte) 1);
//        org.joda.time.DateTime.Property property84 = dateTime80.property(dateTimeFieldType83);
//        boolean boolean85 = dateTime78.isSupported(dateTimeFieldType83);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType83, 1, 0, 1);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField91 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField53, dateTimeFieldType83, 255);
//        org.joda.time.MonthDay.Property property92 = monthDay42.property(dateTimeFieldType83);
//        org.joda.time.MonthDay monthDay94 = property92.addWrapFieldToCopy(458);
//        int int95 = property92.getMaximumValue();
//        int int96 = property92.getMinimumValue();
//        org.joda.time.DurationField durationField97 = property92.getDurationField();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 60019L + "'", long25 == 60019L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3540000L) + "'", long32 == (-3540000L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(monthDay40);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "20" + "'", str46.equals("20"));
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(monthDay50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 60 + "'", int58 == 60);
//        org.junit.Assert.assertNotNull(monthDay59);
//        org.junit.Assert.assertNotNull(dateTimeFieldType61);
//        org.junit.Assert.assertNotNull(monthDay63);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
//        org.junit.Assert.assertNotNull(monthDay72);
//        org.junit.Assert.assertNotNull(dateTimeFieldType74);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 30 + "'", int76 == 30);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(monthDay81);
//        org.junit.Assert.assertNotNull(dateTimeFieldType83);
//        org.junit.Assert.assertNotNull(property84);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
//        org.junit.Assert.assertNotNull(property92);
//        org.junit.Assert.assertNotNull(monthDay94);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 30 + "'", int95 == 30);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
//        org.junit.Assert.assertNotNull(durationField97);
//    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusDays(458);
        org.joda.time.DateTime.Property property6 = dateTime5.hourOfDay();
        java.lang.String str7 = property6.getAsString();
        int int8 = property6.getMinimumValueOverall();
        java.util.Locale locale9 = null;
        int int10 = property6.getMaximumShortTextLength(locale9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13" + "'", str7.equals("13"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }
}

